import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "l Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Java V");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java V" + "'", str1.equals("Java V"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.lang.Byte byte0 = org.apache.commons.lang3.math.NumberUtils.BYTE_MINUS_ONE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) -1 + "'", byte0.equals((byte) -1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("l Machine Specification", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("a a", "                                                                                                 ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("cification", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("10.14.3");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "cosx.LWCToolkitawt.masun.lw", (java.lang.CharSequence) "10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 26 + "'", int2 == 26);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("ry/Ja/Libr", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1004041");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1004041.0d + "'", double1 == 1004041.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("tnemnorivnE emitnuR ES )MT(avaJ", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tnemnorivnE emitnuR ES )MT(avaJ" + "'", str2.equals("tnemnorivnE emitnuR ES )MT(avaJ"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("97#35#-1#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97#35#-1#-1" + "'", str1.equals("97#35#-1#-1"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "al Machine Specification", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 0, (long) 100, (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 10, (byte) 1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "Java V");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Java V");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, '4', 0, (int) (byte) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java(TM) SE Runtime Environment", "/Library/J");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1004041");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1004041 + "'", int1 == 1004041);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                                                                     sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1004041", 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   1004041" + "'", str3.equals("   1004041"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("l Machine Specification", "Java V");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "l Machine Specification" + "'", str2.equals("l Machine Specification"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("\n", "1.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("mixed mode", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("http://java.oracle.com/", "cification", "    n     ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.4", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str1.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("n     ", "sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 1004041);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.7.0_80-b15", "      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("Java Platform API Specificatio", "al Machine Specification", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specificatio" + "'", str3.equals("Java Platform API Specificatio"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", (java.lang.CharSequence) "0.0a10.0a1.0a100.0a-1.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_MAC;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        char[] charArray7 = new char[] { '#', ' ', ' ', '#' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "a#a", "US", (int) 'a');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "a aOracleCorporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("   1004041");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1004041" + "'", str1.equals("1004041"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "7.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.PATH_SEPARATOR;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + ":" + "'", str0.equals(":"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("44444444444444444444444444444444444", "Java Platform API Specification", (int) ' ', (int) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "44444444444444444444444444444444Java Platform API Specification" + "'", str4.equals("44444444444444444444444444444444Java Platform API Specification"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100#-1#100#1", 32, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("al Machine Specification", 0, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.41.01" + "'", str1.equals("3.41.01"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("tnemnorivnE emitnuR ES )MT(avaJ", (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                                                                                                 ");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java Virtual Machine Specification", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(10, 2, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        long[] longArray4 = new long[] { (byte) -1, (byte) 1, (short) 100, (short) 100 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                          " + "'", str2.equals("                          "));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih" + "'", str1.equals("!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java Platform API Specificatio", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Specificatio API Platform Java" + "'", str2.equals("Specificatio API Platform Java"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 10, (byte) 1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "Mixed mode");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Mixed mode");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 0 + "'", byte5 == (byte) 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle(" ", "/Library/J", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("44444444444444444444444444444444444", "/Library/J");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.awt.CGraphicsEnvironment", 26, "-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str3.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Library/J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("cification", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cification" + "'", str2.equals("cification"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 32.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("US", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.0 10.0", "cification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0 10.0" + "'", str2.equals("1.0 10.0"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80-b15", "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0" + "'", str1.equals("10.0"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("l Machine Specificatio", "/Library/J", 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "l Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio" + "'", str3.equals("l Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) ' ', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "Oracle Corporation", "cosx.LWCToolkitawt.masun.lw");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!" + "'", str3.equals("Ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "97#35#-1#-1", 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("i", "   1004041", (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "i" + "'", str3.equals("i"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double[] doubleArray0 = new double[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a', (int) (byte) 100, 0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Mac OS X", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("\n", 6, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n     " + "'", str3.equals("\n     "));
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_HOME;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str0.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("97#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-1", "Mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-1" + "'", str2.equals("97#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-1"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "l Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio", (java.lang.CharSequence) "l Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                                                                     sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                                     sun.awt.CGraphicsEnvironment" + "'", charSequence2.equals("                                                                     sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_AWT_PRINTERJOB;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str0.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "100#-1#100#1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.7.0_80-b15", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        char[] charArray5 = new char[] { ' ', '4', '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80", (int) (short) 100, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "1.4", 26);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("US", "sun.lwawt.macosx.CPrinterJob", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_80-b15", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "", "10.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.0/10.0L10.0i10.0b10.0r10.0a10.0r10.0y10.0/10.0J10.0a10.0v10.0a10.0/10.0J10.0a10.0v10.0a10.0V10.0i10.0r10.0t10.0u10.0a10.0l10.0M10.0a10.0c10.0h10.0i10.0n10.0e10.0s10.0/10.0j10.0d10.0k10.0110.0.10.0710.0.10.0010.0_10.0810.0010.0.10.0j10.0d10.0k10.0/10.0C10.0o10.0n10.0t10.0e10.0n10.0t10.0s10.0/10.0H10.0o10.0m10.0e10.0/10.0j10.0r10.0e10.0/10.0l10.0i10.0b10.0/10.0e10.0n10.0d10.0o10.0r10.0s10.0e10.0d10.0" + "'", str3.equals("10.0/10.0L10.0i10.0b10.0r10.0a10.0r10.0y10.0/10.0J10.0a10.0v10.0a10.0/10.0J10.0a10.0v10.0a10.0V10.0i10.0r10.0t10.0u10.0a10.0l10.0M10.0a10.0c10.0h10.0i10.0n10.0e10.0s10.0/10.0j10.0d10.0k10.0110.0.10.0710.0.10.0010.0_10.0810.0010.0.10.0j10.0d10.0k10.0/10.0C10.0o10.0n10.0t10.0e10.0n10.0t10.0s10.0/10.0H10.0o10.0m10.0e10.0/10.0j10.0r10.0e10.0/10.0l10.0i10.0b10.0/10.0e10.0n10.0d10.0o10.0r10.0s10.0e10.0d10.0"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B11" + "'", str1.equals("24.80-B11"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("l Machine Specification", "al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", "l Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str2.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.lang.String[] strArray3 = new java.lang.String[] { "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "sun.awt.CGraphicsEnvironment" };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "-1");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) '4', "/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str3.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "a aOracleCorporation", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java Virtual Machine Specification", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n" + "'", str2.equals("n"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("44444444444444444444444444444444444", "10.0");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("\n     ", "cosx.LWCToolkitawt.masun.lw");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n     " + "'", str2.equals("\n     "));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Mixed mode", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("44444444444444444444444444444444Java Platform API Specification", "n     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n     " + "'", str2.equals("n     "));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "l Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "al Machine Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "1.7", "en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger(":");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Java Virtual Machine Specif", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "souvriLLLLLLLLLLLLLLLLLLLLLLLLLLLLL" + "'", str3.equals("souvriLLLLLLLLLLLLLLLLLLLLLLLLLLLLL"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java Virtual Machine Specif", "I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specif" + "'", str2.equals("Java Virtual Machine Specif"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                                                     sun.awt.CGraphicsEnvironment", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                     sun.awt.CGraphicsEnvironment" + "'", str2.equals("                                                                     sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("Java Platform API Specification", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10.14.3", (int) 'a', "mixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.14.3" + "'", str3.equals("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.14.3"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "n", (java.lang.CharSequence) "Java Virtual Machine Specif", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 26 + "'", int3 == 26);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.Class<?> wildcardClass5 = strArray2.getClass();
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "3.41.01", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("-1", "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1" + "'", str2.equals("-1"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        float[] floatArray2 = new float[] { '#', 0L };
        float[] floatArray5 = new float[] { '#', 0L };
        float[] floatArray8 = new float[] { '#', 0L };
        float[] floatArray11 = new float[] { '#', 0L };
        float[] floatArray14 = new float[] { '#', 0L };
        float[][] floatArray15 = new float[][] { floatArray2, floatArray5, floatArray8, floatArray11, floatArray14 };
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(floatArray15);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "44444444444444444444444444444444Java Platform API Specification", (java.lang.CharSequence) "souvriLLLLLLLLLLLLLLLLLLLLLLLLLLLLL", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("10.0/10.0L10.0i10.0b10.0r10.0a10.0r10.0y10.0/10.0J10.0a10.0v10.0a10.0/10.0J10.0a10.0v10.0a10.0V10.0i10.0r10.0t10.0u10.0a10.0l10.0M10.0a10.0c10.0h10.0i10.0n10.0e10.0s10.0/10.0j10.0d10.0k10.0110.0.10.0710.0.10.0010.0_10.0810.0010.0.10.0j10.0d10.0k10.0/10.0C10.0o10.0n10.0t10.0e10.0n10.0t10.0s10.0/10.0H10.0o10.0m10.0e10.0/10.0j10.0r10.0e10.0/10.0l10.0i10.0b10.0/10.0e10.0n10.0d10.0o10.0r10.0s10.0e10.0d10.0");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978", (java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.14.3", (java.lang.CharSequence) "hi!", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        float[] floatArray2 = new float[] { (byte) 1, (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 0, (int) (byte) 0);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4', (int) (short) 100, 1004041);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "l Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio", (java.lang.CharSequence) "0.0a10.0a1.0a100.0a-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.0410.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0410.0" + "'", str1.equals("1.0410.0"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Mac OS X", 0, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X" + "'", str3.equals("Mac OS X"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "UTF-8", (java.lang.CharSequence) "Specificatio API Platform Java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("cification");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        float[] floatArray2 = new float[] { (byte) 1, (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 0, (int) (byte) 0);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.Class<?> wildcardClass8 = floatArray2.getClass();
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        java.lang.Class<?> wildcardClass13 = strArray10.getClass();
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(strArray15);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray15);
        java.lang.Class<?> wildcardClass18 = strArray15.getClass();
        float[] floatArray21 = new float[] { (byte) 1, (short) 10 };
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(floatArray21, 'a', 0, (int) (byte) 0);
        float float26 = org.apache.commons.lang3.math.NumberUtils.max(floatArray21);
        java.lang.Class<?> wildcardClass27 = floatArray21.getClass();
        float[] floatArray30 = new float[] { (byte) 1, (short) 10 };
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.join(floatArray30, 'a', 0, (int) (byte) 0);
        float float35 = org.apache.commons.lang3.math.NumberUtils.max(floatArray30);
        java.lang.Class<?> wildcardClass36 = floatArray30.getClass();
        float[] floatArray39 = new float[] { (byte) 1, (short) 10 };
        java.lang.String str43 = org.apache.commons.lang3.StringUtils.join(floatArray39, 'a', 0, (int) (byte) 0);
        float float44 = org.apache.commons.lang3.math.NumberUtils.max(floatArray39);
        java.lang.Class<?> wildcardClass45 = floatArray39.getClass();
        java.lang.reflect.Type[] typeArray46 = new java.lang.reflect.Type[] { wildcardClass8, wildcardClass13, wildcardClass18, wildcardClass27, wildcardClass36, wildcardClass45 };
        java.lang.String str47 = org.apache.commons.lang3.StringUtils.join(typeArray46);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 10.0f + "'", float26 == 10.0f);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 10.0f + "'", float35 == 10.0f);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 10.0f + "'", float44 == 10.0f);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(typeArray46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Fclass [F" + "'", str47.equals("class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Fclass [F"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.0410.0", ":", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0410.0" + "'", str3.equals("1.0410.0"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("97#35#-1#-1", (int) (byte) 100, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("Sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-B11", "44444444444444444444444444444444Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "l Machine Specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "cification", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("10.14.3", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("\n     ", 29, "mixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed modem\n     mixed modemi" + "'", str3.equals("mixed modem\n     mixed modemi"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("10.0/10.0L10.0i10.0b10.0r10.0a10.0r10.0y10.0/10.0J10.0a10.0v10.0a10.0/10.0J10.0a10.0v10.0a10.0V10.0i10.0r10.0t10.0u10.0a10.0l10.0M10.0a10.0c10.0h10.0i10.0n10.0e10.0s10.0/10.0j10.0d10.0k10.0110.0.10.0710.0.10.0010.0_10.0810.0010.0.10.0j10.0d10.0k10.0/10.0C10.0o10.0n10.0t10.0e10.0n10.0t10.0s10.0/10.0H10.0o10.0m10.0e10.0/10.0j10.0r10.0e10.0/10.0l10.0i10.0b10.0/10.0e10.0n10.0d10.0o10.0r10.0s10.0e10.0d10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1.0a10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0A10.0" + "'", str1.equals("1.0A10.0"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("souvriLLLLLLLLLLLLLLLLLLLLLLLLLLLLL");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"souvriLLLLLLLLLLLLLLLLLLLLLLLLLLLLL\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.7.0_80-b15", "l Machine Specificatio");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java V", "100#-1#100#1", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java V" + "'", str3.equals("Java V"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "44444444444444444444444444444444444", (java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "1.7.0_80", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("44444444444444444444444444444444Java Platform API Specification", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/", 2, "\n     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n/" + "'", str3.equals("\n/"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("a aOracleCorporation", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Java V", "                                                                     sun.awt.CGraphicsEnvironment", "", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java V" + "'", str4.equals("Java V"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("mixed mode", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (double) 20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.0d + "'", double2 == 20.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.0A10.0", (java.lang.CharSequence) "l Machine Specification", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.14.3", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Mac OS X");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("l Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "l Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio" + "'", str2.equals("l Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        long[] longArray4 = new long[] { (byte) -1, (byte) 1, (short) 100, (short) 100 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray4);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 10, (int) (short) -1, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.0A10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0A10.0" + "'", str1.equals("1.0A10.0"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray5 = new char[] { 'a', ' ', ' ', 'a' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("OracleCorporation", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("en", "1004-1410041", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en1004-1410041en" + "'", str3.equals("en1004-1410041en"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1004041");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        long[] longArray4 = new long[] { (byte) -1, (byte) 1, (short) 100, (short) 100 };
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray4, '#', (-1), 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "46_68x" + "'", str1.equals("46_68x"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = null;
        try {
            boolean boolean2 = javaVersion0.atLeast(javaVersion1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double[] doubleArray0 = new double[] {};
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "cification", (java.lang.CharSequence) "44444444444444444444444444444444Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_JAVA_1_6;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("UTF-8", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-" + "'", str2.equals("UTF-"));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        char[] charArray1 = new char[] {};
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray1, '4', (int) '#', (int) (short) -1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray1, '#', 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24.80-B11", "mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-B11" + "'", str2.equals("24.80-B11"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "0a10a1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "/Users/sophie", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "100a-1a100a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java Platform API Specificatio", 21, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "l Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio/Library/Jl Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Virtual Machine Specif", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "J#v# Virtu#l M#chine Specif" + "'", str3.equals("J#v# Virtu#l M#chine Specif"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1004-1410041", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "7.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "al Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Fclass [F", (java.lang.CharSequence) "\n/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.7.0_80-b15", "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("7.1", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                 7.1" + "'", str2.equals("                                                                                                 7.1"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.lang.Float float0 = org.apache.commons.lang3.math.NumberUtils.FLOAT_ZERO;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0.equals(0.0f));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("\n", (int) (short) -1, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "UTF-8");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "100#-1#100#1", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("hi!", "Java HotSpot(TM) 64-Bit Server VM", "OracleCorporation");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie", "1.7", "                                                                     sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("i", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "i" + "'", str3.equals("i"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("100a-1a100a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100a-1a100a1" + "'", str1.equals("100a-1a100a1"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "US", "\n     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("UTF-", (-1), "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-" + "'", str3.equals("UTF-"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("                                                                     sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.0 10.0", 0, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0 10.0" + "'", str3.equals("1.0 10.0"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("OracleCorporation", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "a aOracleCorporation", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "1.0A10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("tnemnorivnE emitnuR ES )MT(avaJ", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tnemnorivnE4emitnuR4ES4)MT(avaJ" + "'", str3.equals("tnemnorivnE4emitnuR4ES4)MT(avaJ"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/" + "'", str1.equals("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mixed mode" + "'", str1.equals("Mixed mode"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        boolean boolean0 = org.apache.commons.lang3.SystemUtils.IS_OS_WINDOWS_7;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 1, (short) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.0a10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "n", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "n", (java.lang.CharSequence) "!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih!ih");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Fclass [F", (java.lang.CharSequence) "7.1", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("sun.lwawt.macosx.CPrinterJob", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 0, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!" + "'", str3.equals("Ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.0a10.0", "al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("      ", "a ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      " + "'", str2.equals("      "));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                          " + "'", str2.equals("                          "));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) (byte) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "Specificatio API Platform Java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("al Machine Specification", "1.0A10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(10, (int) '4', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("mixed mode", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ria ta" + "'", str3.equals("ria ta"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "al Machine Specification", 29);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("0a10a1", "1.4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a10a1" + "'", str2.equals("0a10a1"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("      ", 'a');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 10, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("en1004-1410041en", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en1004-1410041en" + "'", str2.equals("en1004-1410041en"));
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        java.lang.String str0 = org.apache.commons.lang3.SystemUtils.JAVA_SPECIFICATION_VERSION;
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "1.7" + "'", str0.equals("1.7"));
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("souvriLLLLLLLLLLLLLLLLLLLLLLLLLLLLL", "", "x86_64");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "souvriLLLLLLLLLLLLLLLLLLLLLLLLLLLLL" + "'", str3.equals("souvriLLLLLLLLLLLLLLLLLLLLLLLLLLLLL"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', 6, 1004041);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("ry/Ja/Libr", "l Machine Specificatio", 97, 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "l Machine Specificatio" + "'", str4.equals("l Machine Specificatio"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "10414100", (java.lang.CharSequence) "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "7.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-1", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "Specificatio API Platform Java", "1.4");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 0, (int) '#', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h", (int) (byte) 10, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h" + "'", str3.equals("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("0.0#10.0#1.0#100.0#-1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.0#10.0#1.0#100.0#-1.0" + "'", str1.equals("0.0#10.0#1.0#100.0#-1.0"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "\n", (java.lang.CharSequence) "/Users/sophie", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Library/J");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("mixed mode", (int) (short) -1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.min(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("24.80-B11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-B11" + "'", str1.equals("24.80-B11"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("100a-1a100a1", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a-1a100a1" + "'", str2.equals("100a-1a100a1"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978", "46_68x");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "7.1", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 1, 100L, (long) 26);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("souvriLLLLLLLLLLLLLLLLLLLLLLLLLLLLL");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "souvrilllllllllllllllllllllllllllll" + "'", str1.equals("souvrilllllllllllllllllllllllllllll"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("tnemnorivnE emitnuR ES )MT(avaJ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tnemnorivnE emitnuR ES )MT(avaJ" + "'", str2.equals("tnemnorivnE emitnuR ES )MT(avaJ"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 10, (long) '#', (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/VAR/FOLDERS/_V/6V597ZMN4_V31CQ2N2X1N4FC0000GN/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "10.0", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("J#v# Virtu#l M#chine Specif", "                                                                     sun.awt.CGraphicsEnvironment", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("3.41.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.41.01" + "'", str1.equals("3.41.01"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                                                                                 7.1", charSequence1, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specificatio" + "'", str1.equals("Java Virtual Machine Specificatio"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!" + "'", str1.equals("Ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) -1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("i444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\n", 0, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 6, "Java Virtual Machine Specif");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java V" + "'", str3.equals("Java V"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "a#a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("\n     ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        short[] shortArray1 = new short[] { (short) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', (int) (short) 100, 35);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.0410.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("mixed modem\n     mixed modemi", 1, "J#v# Virtu#l M#chine Specif");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed modem\n     mixed modemi" + "'", str3.equals("mixed modem\n     mixed modemi"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "souvriLLLLLLLLLLLLLLLLLLLLLLLLLLLLL", (java.lang.CharSequence) "sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Threshold must not be negative");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MIXED MODE" + "'", str1.equals("MIXED MODE"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("ry/Ja/Libr");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        byte[] byteArray3 = new byte[] { (byte) 100, (byte) 0, (byte) 1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray3, '4');
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray3, "sophie");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: sophie");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1004041" + "'", str5.equals("1004041"));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.0 10.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.0410.0", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             1.0410.0              " + "'", str2.equals("             1.0410.0              "));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("1.2", (int) '4', 20);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "cosx.LWCToolkitawt.masun.lw", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("7.1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Java Virtual Machine Specificatio", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specificatio" + "'", str2.equals("Java Virtual Machine Specificatio"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("10.0", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0" + "'", str2.equals("10.0"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b11", "");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10414100", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("tnemnorivnE4emitnuR4ES4)MT(avaJ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java HotSpot(TM) 64-Bit Server VM", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java(TM) SE Runtime Environment", "1004041", "1.6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "cification", "aaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        byte[] byteArray3 = new byte[] { (byte) 0, (byte) 10, (byte) 1 };
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray3, 'a');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray3, '#', (int) (short) 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 0 + "'", byte4 == (byte) 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0a10a1" + "'", str6.equals("0a10a1"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("a a", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getUserHome();
        org.junit.Assert.assertNotNull(file0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "souvrilllllllllllllllllllllllllllll");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24.80-b11", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.0A10.0", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0A10.0" + "'", str2.equals("1.0A10.0"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mixed modem\n     mixed modemi", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "0.0#10.0#1.0#100.0#-1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Java(TM) SE Runtime Environment", 5, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 1, (int) '4', (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("cosx.LWCToolkitawt.masun.lw");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Java HotSpot(TM) 64-Bit Server VM", "1004041");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("en1004-1410041en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en1004-1410041en" + "'", str1.equals("en1004-1410041en"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44444444444444444444444444444444Java Platform API Specification", "sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.0 10.0", 2, "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0 10.0" + "'", str3.equals("1.0 10.0"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "0a10a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        short[] shortArray3 = new short[] { (byte) 10, (byte) 1, (byte) 10 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10a1a10" + "'", str5.equals("10a1a10"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "100#-1#100#1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("Sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.lwctoolkit" + "'", str1.equals("sun.lwawt.macosx.lwctoolkit"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "MIXED MODE", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("   1004041", 100, "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                             1004041" + "'", str3.equals("                                                                                             1004041"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("-1", (int) (short) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("-1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                                                                                             1004041");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("hi!", "                                                                                             1004041");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.0a10.0", "sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 52);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "UTF-", (java.lang.CharSequence) "l Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("0.0#10.0#1.0#100.0#-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0.0#10.0#1.0#100.0#-1.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1.6", (java.lang.CharSequence) "Java Virtual Machine Specification", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "tmp/run_randoop.pl_50190_1560276978" + "'", str2.equals("tmp/run_randoop.pl_50190_1560276978"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "n" + "'", str1.equals("n"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0.0#10.0#1.0#100.0#-1.0", (-1), "mixed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0#10.0#1.0#100.0#-1.0" + "'", str3.equals("0.0#10.0#1.0#100.0#-1.0"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 28, "en");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "enenenenenenenenenenenenenen" + "'", str3.equals("enenenenenenenenenenenenenen"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java Virtual Machine Specif", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specif" + "'", str3.equals("Java Virtual Machine Specif"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                                                             1004041");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1004041" + "'", str1.equals("1004041"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charSequence1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("cosx.LWCToolkitawt.masun.lw", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cosx.LWCToolkitawt.masun.lw" + "'", str2.equals("cosx.LWCToolkitawt.masun.lw"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("10.0", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "10414100", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        char[] charArray2 = new char[] {};
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "", charArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray2);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray2, 'a', 32, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("l Machine Specificatio", "", (int) (byte) 100);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "\n/", 28, 5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("\n     ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n     " + "'", str2.equals("\n     "));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("ria ta");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) 21);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21L + "'", long2 == 21L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "a a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("10a1a10", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                              10a1a10                                               " + "'", str2.equals("                                              10a1a10                                               "));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "l Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("1.7.0_80", "MIXED MODE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!ha!", (java.lang.CharSequence) "97#35#-1#-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("tnemnorivnE4emitnuR4ES4)MT(avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM)4SE4Runtime4Environment" + "'", str1.equals("Java(TM)4SE4Runtime4Environment"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS X" + "'", str1.equals("MAC OS X"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("1.0a10.0", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_50190_1560276978");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a10.0" + "'", str2.equals("1.0a10.0"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("100a-1a100a1", (int) '4', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100a-1a100a14444444444444444444444444444444444444444" + "'", str3.equals("100a-1a100a14444444444444444444444444444444444444444"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("0.0a10.0a1.0a100.0a-1.0");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ', 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        java.lang.String str0 = org.apache.commons.lang3.StringUtils.EMPTY;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "" + "'", str0.equals(""));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        float[] floatArray0 = null;
        try {
            float float1 = org.apache.commons.lang3.math.NumberUtils.max(floatArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "enenenenenenenenenenenenenen");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) -1, (int) '4', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "   1004041");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "97 35 -1 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "tnemnorivnE4emitnuR4ES4)MT(avaJ", (java.lang.CharSequence) "10 10 10 10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1), 0.0d, (double) 28);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        float[] floatArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '#', (long) 21, (long) 52);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 21L + "'", long3 == 21L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!" + "'", str1.equals("hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("a#a", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a#a" + "'", str2.equals("a#a"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "10414100", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("100#-1#100#1", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1" + "'", str2.equals("100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1100#-1#100#1"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.0410.0", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "UTF-8");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "44444444444444444444444444444444444", (java.lang.CharSequence[]) strArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence[]) strArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.cgraphicsenvironment" + "'", str1.equals("sun.awt.cgraphicsenvironment"));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("al Machine Specification", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "al Machine Specification" + "'", str3.equals("al Machine Specification"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("SUN.AWT.CGRAPHICSENVIRONMENT", 35, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getUserDir();
        org.junit.Assert.assertNotNull(file0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("mixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed modemixed mode10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode10.14.3" + "'", str1.equals("mixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmodemixedmode10.14.3"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Mac OS X", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/J", "al Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Java Platform API Specification", "100#0#10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 0, (float) 26, (float) 1L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("Sun.lwawt.macosx.LWCToolkit", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("Sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 100, 21, 1004041);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1004041 + "'", int3 == 1004041);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "10414100");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", charSequence2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("-1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "l Machine Specification", (java.lang.CharSequence) "7.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Library/J", (java.lang.CharSequence) "l Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.0 10.0", (java.lang.CharSequence) "sun.awt.cgraphicsenvironment", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        float[] floatArray2 = new float[] { (byte) 1, (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 0, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', (int) '4', 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', 97, (int) (short) 10);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray2, '4', (int) (byte) -1, 29);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "    n     ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.0410.0", 35, "1.0A10.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0410.01.0A10.01.0A10.01.0A10.01.0" + "'", str3.equals("1.0410.01.0A10.01.0A10.01.0A10.01.0"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "i", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 100, (float) 10, 10.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "97#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sun.lwawt.macosx.LWCToolkit", "n     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "Hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "a aOracleCorporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 26);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444I444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1a1a100a100", 97, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("10.14.3");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("-1", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.0a10.0", "n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0a10.0" + "'", str2.equals("1.0a10.0"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        float[] floatArray2 = new float[] { (byte) 1, (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 0, (int) (byte) 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', (int) '4', 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray2, ' ', 97, (int) (short) 10);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Oracle Corporation", "Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("cification", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cification" + "'", str2.equals("cification"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("Mac OS X", "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "1.0410.01.0A10.01.0A10.01.0A10.01.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X" + "'", str3.equals("Mac OS X"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "1.0a10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("## # ##");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "## # ##" + "'", str1.equals("## # ##"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("97 35 -1 -1", "24.80-B11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97 35 -1 -1" + "'", str2.equals("97 35 -1 -1"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "UTF-8");
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "44444444444444444444444444444444444", (java.lang.CharSequence[]) strArray5);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("UTF-8", '#');
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                     sun.awt.CGraphicsEnvironment", (java.lang.CharSequence[]) strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.0 10.0", strArray5, strArray13);
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray13, 'a', 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.0 10.0" + "'", str15.equals("1.0 10.0"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "en", (java.lang.CharSequence) "J#v# Virtu#l M#chine Specif", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "\n/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("51.0", (double) 1004041);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.0d + "'", double2 == 51.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Oracle Corporation", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.7.0_80-b15", "hI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!HI!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification", (java.lang.CharSequence) "100a-1a100a1", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("1004-1410041", "Java(TM)4SE4Runtime4Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1004-1410041" + "'", str2.equals("1004-1410041"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.0410.0", (java.lang.CharSequence) "-1#1#100#100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("x86_64", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("tmp/run_randoop.pl_50190_1560276978", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tmp/run_r4ndoop.pl_50190_1560276978" + "'", str3.equals("tmp/run_r4ndoop.pl_50190_1560276978"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "100a-1a100a1", (int) (short) 1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "class [Fclass [Ljava.lang.String;class [Ljava.lang.String;class [Fclass [Fclass [F", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "      ", (java.lang.CharSequence) "sophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaasophieaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("97#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-1" + "'", str1.equals("97#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-1"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/J", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.0", "OracleCorporation", "97#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-197#35#-1#-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0" + "'", str3.equals("1.0"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("hi!", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        float[] floatArray2 = new float[] { (byte) 1, (short) 10 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a', 0, (int) (byte) 0);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', 29, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 29");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 10.0f + "'", float7 == 10.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 10.0f + "'", float8 == 10.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification", "\n/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification" + "'", str2.equals("al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification1.0410.0al Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "100a-1a100a1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }
}

