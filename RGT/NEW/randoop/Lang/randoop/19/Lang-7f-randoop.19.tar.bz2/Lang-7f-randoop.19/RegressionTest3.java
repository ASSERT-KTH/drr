import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 25, 35.0d, (double) 16L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 16.0d + "'", double3 == 16.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/uSERS/SOPHIE/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.52A10A32A0A100A1/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.0A100A1A100A10A0/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.oRACLE cORPORATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.52A10A32A0A100A1/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.0A100A1A100A10A0/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.oRACLE cORPORATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE" + "'", str1.equals("/uSERS/SOPHIE/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.52A10A32A0A100A1/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.0A100A1A100A10A0/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.oRACLE cORPORATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str1.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a", 13, "/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a" + "'", str3.equals("h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo", (java.lang.CharSequence) "4x.CP44");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.040.0                                                                                            1.7.0_80", "aa32.0a97.0a0.0a100.0a1.0a10.0aa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "en", "                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("a", "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ", (int) (short) 100, 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "a                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                " + "'", str4.equals("a                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                "));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 12, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "aa32.0a97.0a0.0a100.0a1.0a10.0aa", (java.lang.CharSequence) "4x.CP44", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                 xed mode", "tmp/run", "100#0#0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                 xed 0ode" + "'", str3.equals("                 xed 0ode"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.5", charSequence1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("51.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("x86_64", 97, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/Use...", (java.lang.CharSequence) "44a444#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", 100);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "52a10a32a0a100a1", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("aa32.0a97.0a0.0a100.0a1.0a10.0aa", "24.80-b11", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aa32.0a97.0a0.0a100.0a1.0a10.0aa" + "'", str3.equals("aa32.0a97.0a0.0a100.0a1.0a10.0aa"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U", (java.lang.CharSequence) "51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("      ", "4x.CP44");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("mixed mod", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mod" + "'", str2.equals("mixed mod"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java(TM) SE Runtime Environment" + "'", str1.equals("java(TM) SE Runtime Environment"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.4", (java.lang.CharSequence) ":##################################", (int) (short) 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) (byte) 7, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "5241043240410041");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "############################################################xed mode", "5241043240410041");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", (float) 16L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 16.0f + "'", float2 == 16.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0a1.0a100.0a0.0a97.0a32.0", "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7 1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Platform API Specification", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Java Platform API Specification" + "'", str5.equals("Java Platform API Specification"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) -1, (long) (byte) 10, (long) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sop..." + "'", str2.equals("/Users/sop..."));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("       ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "10.14.3", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "xed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 75 + "'", int2 == 75);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("-1 32", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 32" + "'", str2.equals("-1 32"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "CPrinterJo", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        long[] longArray2 = new long[] { (short) -1, ' ' };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', 97, (int) 'a');
        java.lang.Class<?> wildcardClass8 = longArray2.getClass();
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.Class<?> wildcardClass10 = longArray2.getClass();
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "       ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Oracle Corporation" + "'", charSequence2.equals("Oracle Corporation"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "24.80-B11");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("http...", 4, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http..." + "'", str3.equals("http..."));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("tmp/run");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TMP/RUN" + "'", str1.equals("TMP/RUN"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("100#0#0", "boJr/boJre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#0#0" + "'", str2.equals("100#0#0"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("asun.lwawt.macosx.CPrinterJob52a1aa", 6, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "32.0...", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444411", (java.lang.CharSequence) "1.040.0                                                                                            1.7.0_80", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("14100", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/USERS/SOPHIE", (int) (byte) 1, "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE" + "'", str3.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1", (java.lang.CharSequence) "-1.0 1.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        int[] intArray6 = new int[] { '4', (short) 10, ' ', 0, (byte) 100, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', (int) (short) 100, 97);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', 0, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52a10a32a0a100a1" + "'", str8.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/", 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob", "       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("############################################################xed mode", (int) '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############################################################xed mode" + "'", str3.equals("############################################################xed mode"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "asun.lwawt.macosx.CPrinterJob52a1aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("-1.0 1.0 100.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1.0 1.0 100.0" + "'", str1.equals("-1.0 1.0 100.0"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "35.0", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 7, (byte) 0, (byte) 7);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 7 + "'", byte3 == (byte) 7);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("sophie          ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("4x.CP44", (int) (short) 1, ":##################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4x.CP44" + "'", str3.equals("4x.CP44"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("aaaaaaa", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 28.0f, (double) (byte) 1, (-1.0d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.0d + "'", double3 == 28.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        try {
            double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(14, 49, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("x86_64", (int) (short) 0, 52);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "-1.0 1.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 14100, '4');
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(7, (int) (short) 1, 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 49 + "'", int3 == 49);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        char[] charArray4 = new char[] { '#' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray4);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray4, 'a', 16, (int) (byte) 10);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                hi!                ", "            mAC os x                                           -1 32", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "10.0A1.0A100.0A0.0A97.0A32.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "32.0497.040.04100.041.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("97.041.0497.04100.0410.0", "100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0", "/Users/sophie/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.52a10a32a0a100a1/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0a100a1a100a10a0/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Oracle Corporation/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Maaca aOSa aXa444444444444444444444444", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Maaca aOSa aXa444444444444444444444444" + "'", str2.equals("Maaca aOSa aXa444444444444444444444444"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("hi!", "/Users/sophie", "h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("sun.lwawt.macosx.CPrinterJob52a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob52a" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob52a"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a100" + "'", str1.equals("1a100"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("############################################################xed mode", "", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(":");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \":\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ', (int) (byte) 10, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.00.0                                                                                            1.7.0_80", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "32.0#97.0#0.0#100.0#1.0#10.0", "Mac OS X444444444444444444444444", 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Java Platform API Specification", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", "/Users/sop...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 7, (short) 0, (short) 7);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                            -1 32", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                            -1 32" + "'", str2.equals("                                                                                            -1 32"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("       ", "52A10A32A0A100A1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 14);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "       " + "'", str4.equals("       "));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 7, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 179 + "'", int1 == 179);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "aa32.0a97.0a0.0a100.0a1.0a10.0aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "-1.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "14100");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(5, 68, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 68 + "'", int3 == 68);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "x.CPrinterJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Use...", "       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Use..." + "'", str2.equals("/Use..."));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '#');
        try {
            double double5 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                            -1 32", (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/", 14100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "5241043240410041");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("        ", "      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) " ", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                 xed 0ode");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", (java.lang.CharSequence) "-1a32", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) (byte) 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("100a0a0");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "444444444444444444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(75, (int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4" + "'", str2.equals("4"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "boJr/boJre", 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                        52a10a32a0a100a1                                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                        52A10A32A0A100A1                                         " + "'", str1.equals("                                        52A10A32A0A100A1                                         "));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("524104324...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "524104324..." + "'", str1.equals("524104324..."));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "24.80-B11", "boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("32.0a97.0a0.0a100.0a1.0a10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32.0a97.0a0.0a100.0a1.0a10.0" + "'", str1.equals("32.0a97.0a0.0a100.0a1.0a10.0"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ', 1, (int) (short) -1);
        try {
            double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.6", "", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS X", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 165, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1a100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "51.0");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1a100" + "'", str3.equals("1a100"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h0a100a1a100a10a" + "'", str2.equals("h0a100a1a100a10a"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("          ", (int) ' ', "CPRINTERJO");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CPRINTERJOCPRINTERJOCP          " + "'", str3.equals("CPRINTERJOCPRINTERJOCP          "));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "\n", 14100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444" + "'", str2.equals("4444444444"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Oracle Corporation", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("32.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.0", 25, "      http://java.oracle.com/      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "32.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.0" + "'", str3.equals("32.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.0"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n", 0, 75);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Oracle Corporation", 68, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#########################Oracle Corporation#########################" + "'", str3.equals("#########################Oracle Corporation#########################"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "32.0497.040.04100.041.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "32.0#97.0#0.0#100.0#1.0#10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("5241043240410041");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/USERS/SOPHIE", 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("24.80-b11", "1.040.0                                                                                            /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80", "                 xed 0ode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "     " + "'", str3.equals("     "));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("                                                                                            -1 32", "h0a100a1a100a10a h0a100a197h0a100a1a100a10a h");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1 32" + "'", str2.equals("-1 32"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                                                            -1 32", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ', 1, (int) (short) -1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4', (int) 'a', (int) (byte) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '#');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '#');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "xed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 10, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("35.0", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.Class<?> wildcardClass5 = byteArray2.getClass();
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) (short) 10, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("24.80-B11", "############################################################xed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-B11" + "'", str2.equals("24.80-B11"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("sophie", 8, 165);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("         #");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "         #" + "'", str1.equals("         #"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("http...", 0, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http..." + "'", str3.equals("http..."));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "44a444#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("h0a100a1a100a10a h0a100a197h0a100a1a100a10a h0a100a1", "                 xed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                 xed mode" + "'", str2.equals("                 xed mode"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects" + "'", str2.equals("/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("CPRINTERJOCPRINTERJOCP          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CPRINTERJOCPRINTERJOCP" + "'", str1.equals("CPRINTERJOCPRINTERJOCP"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "         #", (java.lang.CharSequence) "java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "         #" + "'", charSequence2.equals("         #"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "524104324...");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "L524104324...b524104324...y524104324...J524104324...v524104324...J524104324...v524104324...V524104324...M524104324...k524104324...k524104324...C524104324...H524104324...b" + "'", str4.equals("L524104324...b524104324...y524104324...J524104324...v524104324...J524104324...v524104324...V524104324...M524104324...k524104324...k524104324...C524104324...H524104324...b"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a", (java.lang.CharSequence) "mixed mod", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D", (java.lang.CharSequence) "CPRINTERJO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("a                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ", "TMP/RUN", 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 97L, (double) (byte) 0, 52.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.040.0                                                                                            1.7.0_80");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.040.0                                                                                            /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaa5241043240410041", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("4444444444", "CPRINTERJOCPRINTERJOCP", "0 100 1 100 10 0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444" + "'", str3.equals("4444444444"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1L, (double) 179, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) ":##################################", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "      http://java.oracle.com/      ", (java.lang.CharSequence) "100#0#0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "35.0", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("#########################Oracle Corporation#########################", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#########################Oracle Corporation#########################" + "'", str2.equals("#########################Oracle Corporation#########################"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils1 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils2 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils3 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils4 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils5 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray6 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils0, numberUtils1, numberUtils2, numberUtils3, numberUtils4, numberUtils5 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray6);
        org.junit.Assert.assertNotNull(numberUtilsArray6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("524104324041004152410432404100415241043240          ", (int) 'a', "xed mod");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "xed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxe" + "'", str3.equals("xed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxe"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("en", "97#-1#-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("US", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("xed mode");
        java.lang.String[] strArray3 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray2, strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', 14100);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("100", "xed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100" + "'", str2.equals("100"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/uSERS/SOPHIE/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.52A10A32A0A100A1/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.0A100A1A100A10A0/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.oRACLE cORPORATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE", '4', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.52A10A32A0A100A1/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.0A100A1A100A10A0/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.oRACLE cORPORATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE" + "'", str3.equals("/uSERS/SOPHIE/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.52A10A32A0A100A1/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.0A100A1A100A10A0/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.oRACLE cORPORATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.stripAll(strArray0);
        org.junit.Assert.assertNull(strArray1);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("        ", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                                                            -1 32", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                            -1 32" + "'", str2.equals("                                                                                            -1 32"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 32, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        float[] floatArray5 = new float[] { 10.0f, (-1.0f), 97, '#', '#' };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', 0, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 97.0f + "'", float6 == 97.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 68.0f, (float) 4);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                   ", (java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "4x.CP44", (java.lang.CharSequence) "############################################################xed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 0, (short) (byte) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 165);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("4444444444444444444444444444444444444444444444444444", (int) (byte) 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "524104324041004152410432404100415241043240          ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(10L, (long) (short) 10, (long) (byte) 7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.4", 14, "h0a100a1a100a10a h0a100a197h0a100a1a100a10a h0a100a1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "h0a101.4h0a100" + "'", str3.equals("h0a101.4h0a100"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 13, 28.0f, 12.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 12.0f + "'", float3 == 12.0f);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.040.040.0", (java.lang.CharSequence) "/Users/sophie", 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "Mac OS X444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/d" + "'", str2.equals("/Users/sophie/Documents/d"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "############################################################xed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("32.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.0", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        char[] charArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(6, (int) (short) 0, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "h", 49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "32.0a97.0a0.0a100.0a1.0a10.0", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob52a1", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "xed mode", charArray6);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray6, '#', (-1), 14100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.4", (int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Documents/d", (int) (byte) 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/" + "'", str2.equals("/Users/"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "boJr/boJre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.74444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                        52a10a32a0a100a1                                         ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                        52a10a32a0a100a1                                         \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "1.7.0_80-b15");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "h", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "en", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!               ", "                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!" + "'", str2.equals("hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "97.041.0497.04100.0410.0", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob52a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob52a1", (java.lang.CharSequence) "xed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxe", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "h0a100a1a100a10a h0a100a197h0a100a1a100a10a h");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.744444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("1.744444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("aaaaaaaaaaaaaaaa5241043240410041");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.7444445f + "'", float1 == 1.7444445f);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D", (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.040.040.0", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.7.0_80", (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("x8s_s4", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100a0a0", (java.lang.CharSequence) "1.040.040.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("            mAC os x                                           -1 32", (int) (byte) 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  -1 32" + "'", str2.equals("  -1 32"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) (byte) 0, (double) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("sophie          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "\n", (java.lang.CharSequence) "-1.041.04100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                                                                            1.7.0_80", "h0a101.4h0a100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "h");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("UTF-8", (int) (short) -1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTF-8" + "'", str3.equals("UTF-8"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("############################################################xed mode", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "########################xed mode" + "'", str2.equals("########################xed mode"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "32.0497.040.04100.041.0410.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        int[] intArray6 = new int[] { '4', (short) 10, ' ', 0, (byte) 100, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52a10a32a0a100a1" + "'", str8.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(97L, (long) ' ', 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444411", "/Users/sophie/Documents/d", "http://java.oracle.com/", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444411" + "'", str4.equals("1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444411"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                            1.7.0_80", '4');
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/Users/sophie", 0);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("100#0#0", strArray3, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n", "CPRINTERJO");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "#########################Oracle Corporation#########################", (java.lang.CharSequence) "      http://java.oracle.com/     ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence5, charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U", charArray8);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "#" + "'", str17.equals("#"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophi");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("a", (double) 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("         #", "CPrinterJo");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         #" + "'", str2.equals("         #"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0a100a1a100a10a0");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("24.80-B11", strArray3, strArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "32.0a97.0a0.0a100.0a1.0a10.0", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "24.80-B11" + "'", str8.equals("24.80-B11"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "/Users/sophie", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("        ", "/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "        " + "'", str3.equals("        "));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("7", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 7 + "'", short2 == (short) 7);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("\n", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("#", "", (int) (short) 7, 16);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#" + "'", str4.equals("#"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/", 179, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#", "", 10);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "                                   ");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "#" + "'", str5.equals("#"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("7", "         #", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "########################xed mode", (java.lang.CharSequence) "h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                 xed mode");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 25 + "'", int1 == 25);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("  -1 32", 8, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("a                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("ahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "/", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80", (double) 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) " ", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "10.0a1.0a100.0a0.0a97.0a32.0", (int) (short) 1, (int) (byte) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("7", "1.74444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7" + "'", str2.equals("7"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporation", "", 16);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("97#-1#-1", 68, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachi97#-1#-1/Library/Java/JavaVirtualMachi" + "'", str3.equals("/Library/Java/JavaVirtualMachi97#-1#-1/Library/Java/JavaVirtualMachi"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "\n", (java.lang.CharSequence) "/Users/sophie/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.52a10a32a0a100a1/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0a100a1a100a10a0/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Oracle Corporation/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("/Library/Java/JavaVirtualMachi97#-1#-1/Library/Java/JavaVirtualMachi", "1a100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachi97#-1#-1/Library/Java/JavaVirtualMachi" + "'", str2.equals("/Library/Java/JavaVirtualMachi97#-1#-1/Library/Java/JavaVirtualMachi"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 13, "CPRINTERJOCPRINTERJOCP");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CPRINTERJOCPR" + "'", str3.equals("CPRINTERJOCPR"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray4 = new char[] { '#' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "32.0a97.0a0.0a100.0a1.0a10.0", charArray4);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ', (int) ' ', 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray4, '4');
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "#" + "'", str13.equals("#"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("100#0#0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/", charSequence1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "4x.CP44");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str2.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "tmp/run");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("sophie          ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("-1 32", "100", "1.2");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 100, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U", (java.lang.CharSequence) "10.0a1.0a100.0a0.0a97.0a32.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("7", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "CPRINTERJOCPRINTERJOCP");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("xed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxe", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "xed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxe" + "'", str2.equals("xed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxe"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "UTF-8", "0 100 1 100 10 0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Mac OS X444444444444444444444444", (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "########################xed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str4 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("xed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxe", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "xed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxe" + "'", str2.equals("xed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxe"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0", (java.lang.CharSequence) "########################xed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, ' ', (int) (short) 0, 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("524104324...", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("CPRINTERJO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CPRINTERJ" + "'", str1.equals("CPRINTERJ"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) ":", (java.lang.CharSequence) "sophie", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("tmp/run", (short) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        char[] charArray2 = new char[] { 'a' };
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray2, ' ', 0, 0);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("24.80-B11", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-B11" + "'", str2.equals("24.80-B11"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.040.040.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        float[] floatArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(floatArray0, 'a', 7, 75);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("hi!");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 10, (short) 100, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("52A10A32A0A100A1", "4", "0a100a1a100a10a0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "############################################################xed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        short[] shortArray6 = new short[] { (short) 0, (byte) 100, (byte) 1, (short) 100, (short) 10, (short) 0 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a100a1a100a10a0" + "'", str8.equals("0a100a1a100a10a0"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0 100 1 100 10 0" + "'", str11.equals("0 100 1 100 10 0"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 165);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java(TM) SE Runtime Environment", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("97#-1#-1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "44a444#", 14100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("#########################Oracle Corporation#########################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#########################Oracle Corporation#########################" + "'", str1.equals("#########################Oracle Corporation#########################"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("51.0", "        ", "/Users/sophie/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.52a10a32a0a100a1/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0a100a1a100a10a0/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Oracle Corporation/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0" + "'", str3.equals("51.0"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase(":", "97#-1#-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "-1.0 1.0 100.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "1.7.0_80-b15");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (int) (byte) 1, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str3.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100", "boJr/boJre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                " + "'", str2.equals("                "));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("5241043240410041", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "UTF-8", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             " + "'", str2.equals("             "));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 100, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                    " + "'", str3.equals("                                                                                                    "));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedJava HotSpot(TM) 64-", "32.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.0", (int) '4');
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.2", "########################xed mode", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("      http://java.oracle.com/      ", "       ", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MMMMMMhttp://java.oracle.com/MMMMMM" + "'", str3.equals("MMMMMMhttp://java.oracle.com/MMMMMM"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, ' ', 7, 12);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray4 = new char[] { '#' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray4, '#');
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#" + "'", str8.equals("#"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("xed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxe", "51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "xed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxe" + "'", str2.equals("xed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxe"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("100#0#0", "sun.awt.CGraphicsEnvironment", "-1.041.04100.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("      http://java.oracle.com/      ", "                                                                                                   ", "524104324...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "      http://java.oracle.com/      " + "'", str3.equals("      http://java.oracle.com/      "));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("100#0#0", 49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49 + "'", int2 == 49);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("1");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "                 xed mode", 25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run", (java.lang.CharSequence) "hiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("asun.lwawt.macosx.CPrinterJob52a1aa", "x8s_s4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "asun.lwawt.macosx.CPrinterJob52a1aa" + "'", str2.equals("asun.lwawt.macosx.CPrinterJob52a1aa"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "32.0#97.0#0.0#100.0#1.0#10.0", (-1), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals(charSequence0, (java.lang.CharSequence) "      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("44a444#");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"44a444#\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "aaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java(TM) SE Runtime Environment", (double) 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                            -1 32", (long) 68);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 68L + "'", long2 == 68L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4444444444444444444444444444444444444444444444444444", "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7 1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/uSERS/SOPHIE/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.52A10A32A0A100A1/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.0A100A1A100A10A0/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.oRACLE cORPORATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE", 6);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "32.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1.041.04100.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        float[] floatArray3 = new float[] { (-1), 1, 100.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.Class<?> wildcardClass5 = floatArray3.getClass();
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedJava HotSpot(TM) 64-", "1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                " + "'", charSequence2.equals("                "));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "hi!", 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "US", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 100, (int) '4', 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("boJr/boJre", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        double[] doubleArray3 = new double[] { (byte) 1, 0L, 0.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#', 32, (int) (short) 1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.040.040.0" + "'", str6.equals("1.040.040.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.040.040.0" + "'", str12.equals("1.040.040.0"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", 28, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str3.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 100, (double) 35, (double) 7L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "100#0#0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophi", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophi" + "'", str3.equals("/Users/sophi"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("a", (double) 68);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 68.0d + "'", double2 == 68.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 7, (byte) 7, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("      ", "10.0a1.0a100.0a0.0a97.0a32.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      " + "'", str2.equals("      "));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("-1.041.04100.0", 25, 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.040.040.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.7f + "'", float1 == 1.7f);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("10.0a1.0a100.0a0.0a97.0a32.0", "                                                                                                 ", 68);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: sophie is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Mac OS X444444444444444444444444", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "x8s_s4", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "CPRINTERJO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("35.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"35.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("xed mod", 28);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          xed mod           " + "'", str2.equals("          xed mod           "));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '#', 35, 99);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 99 + "'", int3 == 99);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                        52A10A32A0A100A1                                         ", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/" + "'", str1.equals("/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Maaca aOSa aXa444444444444444444444444", 32, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Maaca aOSa aXa444444444444444444444444" + "'", str3.equals("Maaca aOSa aXa444444444444444444444444"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        float[] floatArray3 = new float[] { '#', 0.0f, 0L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', (int) (byte) 100, (int) (byte) -1);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 35.0f + "'", float8 == 35.0f);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1#100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#100" + "'", str1.equals("1#100"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "CPRINTERJO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Mac OS X", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("35.0");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "      http://java.oracle.com/     ", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("444444444444444444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "24.80-b11", (int) (short) -1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", strArray3, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1#32", 49, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("7", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7" + "'", str2.equals("7"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("a                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ", 0, "boJretnirPC.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                " + "'", str3.equals("a                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                "));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("100", "                 xed 0ode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100" + "'", str2.equals("100"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("-1432");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1432" + "'", str1.equals("-1432"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachi97#-1#-1/Library/Java/JavaVirtualMachi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("52A10A32A0A100A1", "", "mixed mode", 25);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "52A10A32A0A100A1" + "'", str4.equals("52A10A32A0A100A1"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.2", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1a100", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", 179);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        short[] shortArray6 = new short[] { (short) 0, (byte) 100, (byte) 1, (short) 100, (short) 10, (short) 0 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a100a1a100a10a0" + "'", str8.equals("0a100a1a100a10a0"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 100 + "'", short12 == (short) 100);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "/Users/sophie/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.52a10a32a0a100a1/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0a100a1a100a10a0/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Oracle Corporation/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie", "/Use...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", (java.lang.CharSequence) "ahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("7", "/uSERS/SOPHIE/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.52A10A32A0A100A1/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.0A100A1A100A10A0/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.oRACLE cORPORATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "h0a100a1a100a10a h0a100a197h0a100a1a100a10a h", 7, 75);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (short) 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /Users/sophie");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a100" + "'", str7.equals("1a100"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 0, (byte) 7);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U", "h", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "############################################################xed mode", (java.lang.CharSequence) "Mixed mode", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle.", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0      " + "'", str2.equals("51.0      "));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("h0a100a1a100a10a h0a100a197h0a100a1a100a10a h0a100a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"h0a100a1a100a10a h0a100a197h0a100a1a100a10a h0a100a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.lwawt.macosx.CPrinterJob52a1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n", 35, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob52a1", (java.lang.CharSequence) "100");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "10.0a1.0a100.0a0.0a97.0a32.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("1a100");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 100, (float) (short) 100, (float) (byte) 7);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 7.0f + "'", float3 == 7.0f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                hi!                ", 'a');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                hi!                " + "'", str4.equals("                hi!                "));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                   " + "'", str1.equals("                                                                                                   "));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.040.040.0", "L524104324...b524104324...y524104324...J524104324...v524104324...J524104324...v524104324...V524104324...M524104324...k524104324...k524104324...C524104324...H524104324...b", 16);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "          ", (java.lang.CharSequence) "-1#32");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "################", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 8, (float) 32L, (float) 10L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", "97 -1 -1", (int) (byte) -1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "            mAC os x                                           -1 32", (int) ' ', (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        int[] intArray6 = new int[] { '4', (short) 10, ' ', 0, (byte) 100, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', (int) (short) 100, 97);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        int int16 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int17 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(intArray6, '#', 10, 75);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52a10a32a0a100a1" + "'", str8.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "5241043240410041" + "'", str15.equals("5241043240410041"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "-1.0", 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "US", (java.lang.CharSequence) "/uSERS/SOPHIE/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.52A10A32A0A100A1/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.0A100A1A100A10A0/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.oRACLE cORPORATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1a100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1A100" + "'", str1.equals("1A100"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.CPrinterJob52a1", (-1), "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob52a1" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob52a1"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str2.equals("HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("hi", "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!               " + "'", str2.equals("                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!               "));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(1L, (long) (short) 7, (long) 8);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        short[] shortArray3 = new short[] { (byte) 100, (short) 0, (short) 0 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100#0#0" + "'", str7.equals("100#0#0"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 0 + "'", short8 == (short) 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = null;
        try {
            boolean boolean5 = javaVersion0.atLeast(javaVersion4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }
}

