import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 14100, 68);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("32.0497.040.04100.041.0410.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "10.0A1.0A100.0A0.0A97.0A32.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("            mAC os x                                           -1 32", 14100, "x.CPrinterJ");
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("1a52a32", "en", "52a10a32a0a100a1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1a52a32" + "'", str3.equals("1a52a32"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, ' ');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100" + "'", str6.equals("100"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1#100", "524104324...", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("CPRINTERJ4444444", "35.0 0.0 0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CPRINTERJ4444444" + "'", str2.equals("CPRINTERJ4444444"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test011");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.040.0                                                                                            /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.040.0                                                                                            /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80" + "'", str2.equals("1.040.0                                                                                            /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR SUN.LWAWT.MACOSX.cpRINTERjOB MIXED MODE MIXED MODE 0A100A1A100A10A0 SUN.LWAWT.MACOSX.cpRINTERjOB", "########################xed mode");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", 10);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "                                                                                           1.7.0_80");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "TMP/RUN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a", '4');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "a" + "'", str4.equals("a"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray5 = new char[] { '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray5, '4');
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "44a444#", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "#" + "'", str10.equals("#"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(16, (int) (short) 100, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.Class<?> wildcardClass5 = byteArray2.getClass();
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', 52, 16);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', (int) (short) 100, 298);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        char[] charArray6 = new char[] { '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray6);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D", charArray6);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "51.0", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "#" + "'", str10.equals("#"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test021");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "xed mode");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "BOJRETNIRPC.XSOCAM.TWAWL.NUS/USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../U", 14, 86);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 14");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        char[] charArray6 = new char[] { 'a', 'a' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "http://java.oracle.com/", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                    ", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specification", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "asun.lwawt.macosx.CPrinterJob52a1aa", "sun.lwawt.macosx.LWCToolkit", 25);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str4.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle.", "mAC os x                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle." + "'", str2.equals("51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle."));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/Users/", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/" + "'", str2.equals("/Users/"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "4444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "ahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie", 12, "/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("5241043240410041", "444444x.CP444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5241043240410041" + "'", str2.equals("5241043240410041"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("ahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        float[] floatArray5 = new float[] { 'a', 1, 97L, 100.0f, (short) 10 };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ', 18, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 18");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str4 = javaVersion0.toString();
        java.lang.String str5 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.2" + "'", str4.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.2" + "'", str5.equals("1.2"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Mixed mode", "sun.lwawt.macosx.CPrinterJob52a1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mixed mode" + "'", str2.equals("Mixed mode"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                                                                                   ", (float) 7L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.0f + "'", float2 == 7.0f);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "          h0a101.4h0a100           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 8L, (double) 8, (double) 14);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.0d + "'", double3 == 14.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "32.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.0", "5241043240410041");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("32.0...");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "h0a100a1a100a10a h0a100a197h0a100a1a100a10a h0a100a1", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "p...", "Mac OS X444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("\n", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("51.0      ", (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", (java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.744444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "Java(TM) SE Runtime Environment", "aa32.0a97.0a0.0a100.0a1.0a10.0aa");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "        ", (java.lang.CharSequence) "TMP/RUN#########");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("####");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("      http://java.oracle.com/     ", (int) '#', "h0a101.4h0a100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "      http://java.oracle.com/     h" + "'", str3.equals("      http://java.oracle.com/     h"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "        ", (java.lang.CharSequence) "BOJRETNIRPC.XSOCAM.TWAWL.NUS/USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../U", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("tmp/run");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tmp/run" + "'", str1.equals("tmp/run"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.040.040.0", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        java.lang.CharSequence charSequence1 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "h", charSequence1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.4", "", 298);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("5241043240410041", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5241043240410041" + "'", str2.equals("5241043240410041"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("97#-1#-1", "java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97#-1#-1" + "'", str2.equals("97#-1#-1"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("h", "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h" + "'", str2.equals("h"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("sun.lwawt.macosx.CPrinterJo", "aAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "51.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "32.0a97.0a0.0a100.0a1.0a10.0", charArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray6, ' ', (int) ' ', 0);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                        52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                         ", charArray6);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                            1.7.0_80", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.Class<?> wildcardClass5 = byteArray2.getClass();
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1#100" + "'", str8.equals("1#100"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1 100" + "'", str10.equals("1 100"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) ' ', (long) ' ', (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("97");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Oracle Corporation");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("aaaaaaa", strArray2, strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 5");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 298);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("tmp/run");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "tmp/run" + "'", str1.equals("tmp/run"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "4444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("100#0#0", "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ", 7);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "0.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.23", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "aAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        java.lang.String[] strArray6 = new java.lang.String[] { "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob", "                                                                                                    ", "/Use...", "-1.0#1.0#100.0", "4444444444444444444444444444444444444444444444444444", "/Use..." };
        java.lang.String[] strArray13 = new java.lang.String[] { "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob", "                                                                                                    ", "/Use...", "-1.0#1.0#100.0", "4444444444444444444444444444444444444444444444444444", "/Use..." };
        java.lang.String[] strArray20 = new java.lang.String[] { "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob", "                                                                                                    ", "/Use...", "-1.0#1.0#100.0", "4444444444444444444444444444444444444444444444444444", "/Use..." };
        java.lang.String[] strArray27 = new java.lang.String[] { "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob", "                                                                                                    ", "/Use...", "-1.0#1.0#100.0", "4444444444444444444444444444444444444444444444444444", "/Use..." };
        java.lang.String[] strArray34 = new java.lang.String[] { "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob", "                                                                                                    ", "/Use...", "-1.0#1.0#100.0", "4444444444444444444444444444444444444444444444444444", "/Use..." };
        java.lang.String[] strArray41 = new java.lang.String[] { "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob", "                                                                                                    ", "/Use...", "-1.0#1.0#100.0", "4444444444444444444444444444444444444444444444444444", "/Use..." };
        java.lang.String[][] strArray42 = new java.lang.String[][] { strArray6, strArray13, strArray20, strArray27, strArray34, strArray41 };
        java.lang.String str43 = org.apache.commons.lang3.StringUtils.join(strArray42);
        java.lang.String str44 = org.apache.commons.lang3.StringUtils.join((java.lang.CharSequence[][]) strArray42);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertNotNull(strArray27);
        org.junit.Assert.assertNotNull(strArray34);
        org.junit.Assert.assertNotNull(strArray41);
        org.junit.Assert.assertNotNull(strArray42);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("444444x.CP444444", "/Liarary/Java/JavaVirtualMachines/jdka7a_ajdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("97.0a1.0a97.0a100.0a10.0", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97.0a1.0a97.0a100.0a10.0" + "'", str2.equals("97.0a1.0a97.0a100.0a10.0"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "24.80-b11", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("32.0...", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0..." + "'", str2.equals("32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0..."));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.74444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.74444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("1.74444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        float[] floatArray3 = new float[] { '#', 0.0f, 0L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', (int) (byte) 100, (int) (byte) -1);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("mixed mode", (int) (short) 10, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("            mAC os x                                           -1 32                                ", "", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...", (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Library/Java/JavaVirtualMachi97#-1#-1/Library/Java/JavaVirtualMachi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("4x.CP44", "51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle.", 0, 86);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle." + "'", str4.equals("51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle."));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test097");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("52a10a32a0a100a1");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("35.0", "sophie          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35.0" + "'", str2.equals("35.0"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) '4', 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 0.0f, (float) 16L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 16.0f + "'", float3 == 16.0f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "35.0", (java.lang.CharSequence) "                 xed mode");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "35.0" + "'", charSequence2.equals("35.0"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "1.040.040.0", 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '4', (int) 'a', (int) (byte) 0);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", "4444444444444444444444444444444444444444444444444444");
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", strArray4, strArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 10 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "java(TM) SE Runtime Environment", "############################################################xed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("7.1", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7.1" + "'", str2.equals("7.1"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D", "a", (int) (byte) 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "-1a32", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x8s_s4", "d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "BOJRETNIRPC.XSOCAM.TWAWL.NUS/USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../U", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("-1.0 1.0 100.0", "444444x.CP444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0 1.0 100.0" + "'", str2.equals("-1.0 1.0 100.0"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("x.CPrinterJ", (int) (byte) 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x.CPrinterJ" + "'", str2.equals("x.CPrinterJ"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad(":##################################", (int) (short) 7, "/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":##################################" + "'", str3.equals(":##################################"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("524104324...", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.040.0                                                                                            /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80", "44a444#");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                 xed mode", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 7, (short) 0, (short) (byte) 7);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 7 + "'", short3 == (short) 7);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("TMP/RUN#########");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 7, (short) (byte) 0, (short) (byte) 7);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 7 + "'", short3 == (short) 7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 298);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test122");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(16.0d, (double) 13.0f, 68.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 68.0d + "'", double3 == 68.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test123");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: sun.lwawt.macosx.CPrinterJob");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test124");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 0, (float) ' ', (float) 97L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test125");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test126");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "TMP/RUN");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test127");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test128");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test129");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("          ", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test130");
        int[] intArray6 = new int[] { '4', (short) 10, ' ', 0, (byte) 100, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', (int) (short) -1, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52a10a32a0a100a1" + "'", str8.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test131");
        int[] intArray6 = new int[] { '4', (short) 10, ' ', 0, (byte) 100, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int15 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52a10a32a0a100a1" + "'", str8.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52a10a32a0a100a1" + "'", str10.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("      http://java.oracle.com/     h", (int) (byte) 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "    ..." + "'", str2.equals("    ..."));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test133");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/a01a001a1a001a0hur/pmt/j4stcefed/stnemucoD/eihpos/sresU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test134");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Oracle Corporation", (short) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test135");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Java(TM) SE Runtime Environment", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("x8s_s4", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4" + "'", str2.equals("x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test137");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a100" + "'", str7.equals("1a100"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test138");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "mAC os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test139");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("                                   ", 10, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  " + "'", str3.equals("  "));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test140");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4, (int) (byte) -1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test141");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("  ", "x.CPrinterJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  " + "'", str2.equals("  "));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test142");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "35.0 0.0 0.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x4x4x4x4x4x4x4x4" + "'", str3.equals("x4x4x4x4x4x4x4x4"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.00.0                                                                                            1.7.0_80", "97.041.0497.04100.0410.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.00.0                                                                                            1.7.0_80" + "'", str2.equals("1.00.0                                                                                            1.7.0_80"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test144");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test145");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJo", 179);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("x86_64", "", 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1A100", 18, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test148");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("ahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("ahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test150");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test151");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test152");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str3 = javaVersion2.toString();
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean5 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str6 = javaVersion2.toString();
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        java.lang.String str10 = javaVersion7.toString();
        boolean boolean11 = javaVersion2.atLeast(javaVersion7);
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.5" + "'", str6.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.2" + "'", str10.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("            mAC os x                                           -1 32", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            mAC os x                                           -1 32" + "'", str2.equals("            mAC os x                                           -1 32"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test154");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "Java Platform API Specification", "sophie");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test155");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = null;
        try {
            boolean boolean2 = javaVersion0.atLeast(javaVersion1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test156");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test157");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Oracle Corporation", 13);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test159");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("a", "524104324041004152410432404100415241043240          ", (int) (short) 7);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 4, (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("      http://java.oracle.com/     ", "1a52a32");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      http://java.oracle.com/     " + "'", str2.equals("      http://java.oracle.com/     "));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test162");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "      ", (java.lang.CharSequence) "-1.0 1.0 100.0", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test163");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test164");
        short[] shortArray6 = new short[] { (short) 0, (byte) 100, (byte) 1, (short) 100, (short) 10, (short) 0 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short12 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', 13, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 13");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a100a1a100a10a0" + "'", str8.equals("0a100a1a100a10a0"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 0 + "'", short10 == (short) 0);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 100 + "'", short11 == (short) 100);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 0 + "'", short12 == (short) 0);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test166");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("############################################################xed mode", "0.23A0.79A0.0A0.001A0.1A0.01");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "############################################################xed mode" + "'", str2.equals("############################################################xed mode"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Librar..." + "'", str2.equals("/Librar..."));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test169");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test170");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("UTF-8", (double) 68L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 68.0d + "'", double2 == 68.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test171");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("      http://java.oracle.com/     ", (int) (short) 100, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "      http://java.oracle.com/     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278" + "'", str3.equals("      http://java.oracle.com/     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test173");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ", "100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0", "h0a101.4h0a100", (int) (byte) 7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                " + "'", str4.equals("                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                "));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test174");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test175");
        float[] floatArray6 = new float[] { ' ', 'a', 0.0f, 100.0f, (byte) 1, (short) 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', (int) (short) 100, 99);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "32.0a97.0a0.0a100.0a1.0a10.0" + "'", str11.equals("32.0a97.0a0.0a100.0a1.0a10.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test176");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("rtual Machine Specification", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "rtual Machine Specification" + "'", str3.equals("rtual Machine Specification"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test177");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "CPRINTERJ4444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test178");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test179");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("51.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test180");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "CPRINTERJ", (int) (short) 7);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test181");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "32.0 97.0 0.0 100.0 1.0 10.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test184");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "7", (java.lang.CharSequence) "x8s_s4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test185");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) (byte) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) -1, "x.CPrinterJ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test187");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("hiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test188");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(7.0f, (float) 7, (float) 28);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 28.0f + "'", float3 == 28.0f);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test189");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", charSequence2.equals("Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a", '#', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a" + "'", str3.equals("h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test191");
        java.lang.CharSequence charSequence6 = null;
        char[] charArray9 = new char[] { '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence6, charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "h0a100a1a100a10a", charArray9);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test192");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(":##################################", "", 18, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":##########################" + "'", str4.equals(":##########################"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test193");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "ahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test194");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("      http://java.oracle.com/      ", "MMMMMMhttp://java.oracle.com/MMMMMM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      http://java.oracle.com/      " + "'", str2.equals("      http://java.oracle.com/      "));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test195");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "h0a100a1a100a10a h0a100a197h0a100a1a100a10a h0a100a1", "x.CPrinterJLibraryx.CPrinterJJavax.CPrinterJJavaVirtualMachinesx.CPrinterJjdk1.7.0_80.jdkx.CPrinterJContentsx.CPrinterJx.CPrinterJomex.CPrinterJjrex.CPrinterJlibx.CPrinterJendorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR SUN.LWAWT.MACOSX.cpRINTERjOB MIXED MODE MIXED MODE 0A100A1A100A10A0 SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("      http://java.oracle.com/      ", "Maaca aOSa aXa444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      http://java.oracle.com/      " + "'", str2.equals("      http://java.oracle.com/      "));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test198");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus", (java.lang.CharSequence) "/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects", 14100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 86 + "'", int3 == 86);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test199");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4', 10, 6);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test200");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4', 14100, 5);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test201");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7.0_80-b15", (int) (byte) 10);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test202");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1a100", (java.lang.CharSequence) "rtual Machine Specification", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444" + "'", str2.equals("4444444444"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test204");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("52a10a32a0a100a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test205");
        int[] intArray6 = new int[] { '4', (short) 10, ' ', 0, (byte) 100, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52a10a32a0a100a1" + "'", str8.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test206");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Sun.awt.CGraphicsEnvironment", "L524104324...b524104324...y524104324...J524104324...v524104324...J524104324...v524104324...V524104324...M524104324...k524104324...k524104324...C524104324...H524104324...b", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Sunaawta/GraphicsEnnironment" + "'", str3.equals("Sunaawta/GraphicsEnnironment"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test207");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "                                                                                           1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test208");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("44a444#");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test209");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("97#-1#-1", 12.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 12.0f + "'", float2 == 12.0f);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("mAC os x", "########################xed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AC os x" + "'", str2.equals("AC os x"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test211");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 4, 99);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test212");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Mac OS X444444444444444444444444");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("xed mode", "1.5");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray2, strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test213");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("################");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test214");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("      ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test215");
        int[] intArray6 = new int[] { '4', (short) 10, ' ', 0, (byte) 100, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52a10a32a0a100a1" + "'", str8.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("#########################Oracle Corporation#########################", "sun.lwawt.macosx.CPrinterJob52a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#########################Oracle Corporation#########################" + "'", str2.equals("#########################Oracle Corporation#########################"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test217");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 16.0d, (double) 68L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test218");
        char[] charArray4 = new char[] { '#' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(charArray4, ' ');
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "97.0a1.0a97.0a100.0a10.0", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#" + "'", str8.equals("#"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test219");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "             ", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test220");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "mAC os x                                                                                                                                                             ", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test221");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(":##################################", (double) 28);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 28.0d + "'", double2 == 28.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test222");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("Sunaawta/GraphicsEnnironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Sunaawta/GraphicsEnnironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test223");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test224");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("asun.lwawt.macosx.CPrinterJob52a1aa", "", "################", 14);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "asun.lwawt.macosx.CPrinterJob52a1aa" + "'", str4.equals("asun.lwawt.macosx.CPrinterJob52a1aa"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test225");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("0.23A0.79A0.0A0.001A0.1A0.01", (int) (byte) -1, 13);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.23A0.79A..." + "'", str3.equals("0.23A0.79A..."));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("1.8", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("BOJRETNIRPC.XSOCAM.TWAWL.NUS/USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../U", "sun.lwawt.macosx.LWCToolkit", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BOJRETNIRPC.XSOCAM.TWAWL.NUS/USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../U" + "'", str3.equals("BOJRETNIRPC.XSOCAM.TWAWL.NUS/USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../U"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test228");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("rtual Machine Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test229");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("#########################Oracle Corporation#########################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#########################Oracle Corporation#########################" + "'", str1.equals("#########################Oracle Corporation#########################"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                 xed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "xed mode" + "'", str1.equals("xed mode"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test231");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("\n", '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("boJretnirPC.xsocam.twawl.nus", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (short) 1);
        java.lang.Class<?> wildcardClass9 = strArray8.getClass();
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.74444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence[]) strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach(".7", strArray3, strArray8);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, 'a', 68, 8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + ".7" + "'", str11.equals(".7"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test232");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("     ", "1a100");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/uSERS/SOPHIE/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.52A10A32A0A100A1/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.0A100A1A100A10A0/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.oRACLE cORPORATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE", "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.52A10A32A0A100A1/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.0A100A1A100A10A0/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.oRACLE cORPORATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE" + "'", str2.equals("/uSERS/SOPHIE/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.52A10A32A0A100A1/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.0A100A1A100A10A0/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.oRACLE cORPORATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test234");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test235");
        float[] floatArray3 = new float[] { (-1), 1, 100.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', 35, 8);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1.0#1.0#100.0" + "'", str6.equals("-1.0#1.0#100.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test236");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 0.0d, 10.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test237");
        double[] doubleArray3 = new double[] { (byte) 1, 0L, 0.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", "asun.lwawt.macosx.CPrinterJob52a1aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str2.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test239");
        byte[] byteArray4 = new byte[] { (byte) 1, (byte) -1, (byte) -1, (byte) 0 };
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray4);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray4);
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) -1 + "'", byte5 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 1 + "'", byte6 == (byte) 1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test240");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test241");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("1.2", (long) 95);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 95L + "'", long2 == 95L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test242");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test243");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test244");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("4x.CP44");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4x.CP44" + "'", str1.equals("4x.CP44"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test245");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "32.0...", (java.lang.CharSequence) "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test246");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("     ");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test247");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "mAC os x", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test248");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("rtual Machine Specification", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar#sun.lwawt.macosx.CPrinterJob#mixed mode#mixed mode#0a100a1a100a10a0#sun.lwawt.macosx.CPrinterJob", 14);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test249");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("32.0a97.0a0.0a100.0a1.0a10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32.0a97.0a0.0a100.0a1.0a10.0" + "'", str1.equals("32.0a97.0a0.0a100.0a1.0a10.0"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("h0a100a1a100a10a h0a100a197h0a100a1a100a10a h0a100a1", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h0a100a1a100a10a h0a100a197h0a100a1a100a10a h0a100a1" + "'", str2.equals("h0a100a1a100a10a h0a100a197h0a100a1a100a10a h0a100a1"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test251");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split(":##########################", "Maaca aOSa aXa444444444444444444444444", 49);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test252");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "sun.lwawt.macosx.CPrinterJob");
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("35.0");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("    ...", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "    ..." + "'", str8.equals("    ..."));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("h0a100a1a100a10a", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test254");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate(".0                                                                                            1", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test255");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sophie", "4x.CP44", "boJr/boJre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test257");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1432", (double) 165L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1432.0d) + "'", double2 == (-1432.0d));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test258");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("boJretnirPC.xsocam.twawl.nus", (int) (byte) 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "boJretnirPC.xsocam.twawl.nus" + "'", str3.equals("boJretnirPC.xsocam.twawl.nus"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sop...", "1.0 0.0 0.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sop" + "'", str2.equals("/Users/sop"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test260");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 100, 52.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test261");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 100L, (float) 10, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test262");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("35.0");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test263");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Mixed mode", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("-1432");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1432" + "'", str1.equals("-1432"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedJava HotSpot(TM) 64-", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedJava HotSpot(TM) 64-" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedJava HotSpot(TM) 64-"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test266");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test267");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 1.7f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7000000476837158d + "'", double2 == 1.7000000476837158d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test268");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "1a100", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test269");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("          h0a101.4h0a100           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h0a101.4h0a100" + "'", str1.equals("h0a101.4h0a100"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test270");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay(":##########################", "4", 0, (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4:##########################" + "'", str4.equals("4:##########################"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test271");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 18, "hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!" + "'", str3.equals("hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("a", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                 a                 " + "'", str2.equals("                 a                 "));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str2.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test274");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("1 100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1 100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test275");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 0, 0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test276");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", "32.0...");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80-b15", 0, "1a52a32");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test278");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test279");
        float[] floatArray5 = new float[] { 10.0f, (-1.0f), 97, '#', '#' };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a', (int) (short) 0, (int) (byte) 0);
        float float11 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 97.0f + "'", float6 == 97.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 97.0f + "'", float11 == 97.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test280");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "x.CPrinterJ", (java.lang.CharSequence) "ahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("en", 14100, 49);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test282");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str5 = javaVersion4.toString();
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str7 = javaVersion6.toString();
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        boolean boolean9 = javaVersion4.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean11 = javaVersion6.atLeast(javaVersion10);
        boolean boolean12 = javaVersion0.atLeast(javaVersion6);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.5" + "'", str5.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.5" + "'", str7.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart(":##################################", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":##################################" + "'", str2.equals(":##################################"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test284");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test285");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "ahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test286");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 0, 1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1#100" + "'", str10.equals("1#100"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test287");
        short[] shortArray6 = new short[] { (short) 0, (byte) 100, (byte) 1, (short) 100, (short) 10, (short) 0 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ');
        short short14 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a100a1a100a10a0" + "'", str8.equals("0a100a1a100a10a0"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0 100 1 100 10 0" + "'", str11.equals("0 100 1 100 10 0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0 100 1 100 10 0" + "'", str13.equals("0 100 1 100 10 0"));
        org.junit.Assert.assertTrue("'" + short14 + "' != '" + (short) 0 + "'", short14 == (short) 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test288");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sop", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test289");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 0, (long) 49, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test290");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("-1 32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 32" + "'", str1.equals("-1 32"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.8", 179, "5241043240410041");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52410432404100415241043240410041524104324041004152410432404100415241043240410041524104321.85241043240410041524104324041004152410432404100415241043240410041524104324041004152410432" + "'", str3.equals("52410432404100415241043240410041524104324041004152410432404100415241043240410041524104321.85241043240410041524104324041004152410432404100415241043240410041524104324041004152410432"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test292");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 178 + "'", int1 == 178);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test293");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "-1 32", (java.lang.CharSequence) "1 100", 99);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test294");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.6", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/", 75);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "32.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test297");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "/USERS/SOPHIE", (int) (byte) 100);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "x.CPrinterJ");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/", "/Users/sophie", (int) (short) 10);
        java.lang.String[] strArray19 = new java.lang.String[] { "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "sun.lwawt.macosx.CPrinterJob", "mixed mode", "mixed mode", "0a100a1a100a10a0", "sun.lwawt.macosx.CPrinterJob" };
        java.lang.String[] strArray26 = new java.lang.String[] { "/Users/sophie", "52a10a32a0a100a1", "", "0a100a1a100a10a0", "Oracle Corporation", "/Users/sophie" };
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray19, strArray26);
        int int28 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray19);
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray11, strArray19);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray19, '#');
        try {
            java.lang.String str32 = org.apache.commons.lang3.StringUtils.replaceEach("c...aOr", strArray4, strArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 11 vs 6");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "x.CPrinterJLibraryx.CPrinterJJavax.CPrinterJJavaVirtualMachinesx.CPrinterJjdk1.7.0_80.jdkx.CPrinterJContentsx.CPrinterJx.CPrinterJomex.CPrinterJjrex.CPrinterJlibx.CPrinterJendorsed" + "'", str6.equals("x.CPrinterJLibraryx.CPrinterJJavax.CPrinterJJavaVirtualMachinesx.CPrinterJjdk1.7.0_80.jdkx.CPrinterJContentsx.CPrinterJx.CPrinterJomex.CPrinterJjrex.CPrinterJlibx.CPrinterJendorsed"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hi!" + "'", str27.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar#sun.lwawt.macosx.CPrinterJob#mixed mode#mixed mode#0a100a1a100a10a0#sun.lwawt.macosx.CPrinterJob" + "'", str31.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar#sun.lwawt.macosx.CPrinterJob#mixed mode#mixed mode#0a100a1a100a10a0#sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test298");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJob52a1", "-1a32");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test299");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("c...aOr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C...AOR" + "'", str1.equals("C...AOR"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test300");
        float[] floatArray6 = new float[] { ' ', 'a', 0.0f, 100.0f, (byte) 1, (short) 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', 0, 0);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        float float18 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "32.0#97.0#0.0#100.0#1.0#10.0" + "'", str9.equals("32.0#97.0#0.0#100.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "32.0a97.0a0.0a100.0a1.0a10.0" + "'", str15.equals("32.0a97.0a0.0a100.0a1.0a10.0"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "32.0497.040.04100.041.0410.0" + "'", str17.equals("32.0497.040.04100.041.0410.0"));
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test301");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                 a                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                 a                 " + "'", str1.equals("                 a                 "));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test302");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                                        52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                         ", (java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test303");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "mixed mode", (int) (byte) 1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test304");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 7, (short) (byte) 1, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("  -1 32", "97.041.0497.04100.0410.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  -1 32" + "'", str2.equals("  -1 32"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test306");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "100", 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test307");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1a100", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a100" + "'", str2.equals("1a100"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test309");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("http...", 14100);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test311");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test312");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 99, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test313");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "0.23A0.79A...", (java.lang.CharSequence) "TMP/RUN");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "0.23A0.79A..." + "'", charSequence2.equals("0.23A0.79A..."));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test314");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "hiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test316");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("  -1 32", 14, 13);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test317");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.0A1.0A100.0A0.0A97.0A32.0", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test318");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(13, 86, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 86 + "'", int3 == 86);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test319");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Liarary/Java/JavaVirtualMachines/jdka7a_ajdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/lIARARY/jAVA/jAVAvIRTUALmACHINES/JDKA7A_AJDK/cONTENTS/hOME/JRE" + "'", str1.equals("/lIARARY/jAVA/jAVAvIRTUALmACHINES/JDKA7A_AJDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test320");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                 a                 ", 97, "a                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a                hi!                                hi!                        a                 " + "'", str3.equals("a                hi!                                hi!                        a                 "));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test321");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test322");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 1 + "'", byte5 == (byte) 1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test323");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aa32.0a97.0a0.0a100.0a1.0a10.0aa", (int) (byte) 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test324");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test325");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob52a1", (java.lang.CharSequence) "-1.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test326");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("            mAC os x                                           -1 32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "            MAC OS X                                           -1 32" + "'", str1.equals("            MAC OS X                                           -1 32"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test327");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("CPRINTERJOCPRINTERJOCP");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CPRINTERJOCPRINTERJOCP" + "'", str1.equals("CPRINTERJOCPRINTERJOCP"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test328");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("h0a100a1a100a10a h0a100a197h0a100a1a100a10a h0a100a1", "");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test329");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444411", (java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test330");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test331");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Librar...", "                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob.0_80 0a100a1a100a10a0 mode mixed mode d" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob.0_80 0a100a1a100a10a0 mode mixed mode d"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4", "1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.8" + "'", str2.equals("1.8"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U", "1#100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U" + "'", str2.equals("boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test335");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("24.80-B11");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test336");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test337");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "32.0497.040.04100.041.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test338");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.Class<?> wildcardClass5 = byteArray2.getClass();
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ', 165, 4);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test339");
        float[] floatArray3 = new float[] { (-1), 1, 100.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.Class<?> wildcardClass5 = floatArray3.getClass();
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1.0 1.0 100.0" + "'", str7.equals("-1.0 1.0 100.0"));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test340");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("51.0      ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0      " + "'", str2.equals("51.0      "));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test342");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444411");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444411" + "'", str1.equals("1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444411"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test343");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "-1432");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test344");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test345");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE", (java.lang.CharSequence) "CPRINTERJOCPRINTERJOCP");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test346");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                                                                    ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test347");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test348");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "51.0      ", (java.lang.CharSequence) "       ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test349");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "524104324...", (java.lang.CharSequence) "97 -1 -1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test350");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test351");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test352");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Use..");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test353");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "                                                                                                    ", "HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test354");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("hi!hi!hi!hi!hi!hi!", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!" + "'", str3.equals("hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("mixed mode", "CPRINTERJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test357");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) ".0                                                                                            1", (java.lang.CharSequence) "  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("7", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                        7                        " + "'", str2.equals("                        7                        "));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test359");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Java Platform API Specification", 75, (int) (short) 7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/LibrarJava Platform API Specificationorsed" + "'", str4.equals("/LibrarJava Platform API Specificationorsed"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test360");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str3 = javaVersion2.toString();
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean5 = javaVersion0.atLeast(javaVersion2);
        java.lang.Class<?> wildcardClass6 = javaVersion0.getClass();
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        java.lang.String str8 = javaVersion7.toString();
        boolean boolean9 = javaVersion0.atLeast(javaVersion7);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.6" + "'", str8.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test361");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("x8s_s4", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x8s_s4" + "'", str2.equals("x8s_s4"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test362");
        double[] doubleArray3 = new double[] { (byte) 1, 0L, 0.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#', 32, (int) (short) 1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ', (int) '4', (int) (short) 1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.040.040.0" + "'", str6.equals("1.040.040.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test363");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) (short) 100, (int) (byte) -1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Java(TM) SE Runtime Environment");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test364");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("TMP/RUN", (int) (short) 100, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test365");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444", "ahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test366");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                " + "'", str2.equals("                "));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test367");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("32.0497.040.04100.041.0410.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test368");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test369");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "h0a100a1a100a10a h0a100a197h0a100a1a100a10a h0a100a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test370");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("boJretnirPC.xsocam.twawl.nus", "CPRINTERJ4444444", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 179);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "boJretnirPC.xsocam.twawl.nus" + "'", str4.equals("boJretnirPC.xsocam.twawl.nus"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test371");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "                 xed 0ode", 75);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("      http://java.oracle.com/     ", "", (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "      http://java.oracle.com/     " + "'", str3.equals("      http://java.oracle.com/     "));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test373");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("asun.lwawt.macosx.CPrinterJob52a1aa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test374");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean6 = javaVersion0.atLeast(javaVersion3);
        java.lang.String str7 = javaVersion3.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.4" + "'", str7.equals("1.4"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test375");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test376");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.6", (java.lang.CharSequence) "32.0#97.0#0.0#100.0#1.0#10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test377");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test378");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test379");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100 1 -1 100 100 -1", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test380");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0..." + "'", str1.equals("32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0..."));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test382");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "", (java.lang.CharSequence) "32.0497.040.04100.041.0410.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test384");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str1.equals("Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test385");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!", "h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!" + "'", str2.equals("hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test387");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "Mixed mode/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test388");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("    ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "    ..." + "'", str1.equals("    ..."));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run", (int) (byte) 1, "      http://java.oracle.com/      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test390");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace(".0                                                                                            1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".01" + "'", str1.equals(".01"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test391");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 10, (float) 1, 52.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test392");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1a100", "  ", "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!               ", 4);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1a100" + "'", str4.equals("1a100"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test393");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("xed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxe");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test394");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test395");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("                                        52a10a32a0a100a1                                         ", "1a100", 25);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("en", 'a');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("524104324...", strArray5, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test397");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test398");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("524104324041004152410432404100415241043240          ", "         #", (-1), 35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "         #1043240          " + "'", str4.equals("         #1043240          "));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("########################xed mode", "  ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test400");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                        52A10A32A0A100A1                                         ", "10.0A1.0A100.0A0.0A97.0A32.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                        52A10A32A0A100A1                                         " + "'", str2.equals("                                        52A10A32A0A100A1                                         "));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test401");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("             ", 99, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                   " + "'", str3.equals("                                                                                                   "));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test402");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) ' ', "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("h0a100a1a100a10a", "java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java(TM) SE Runtime Environment" + "'", str2.equals("java(TM) SE Runtime Environment"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test404");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "", "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test406");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(".01", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test407");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mod", charArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "524104324041004152410432404100415241043240          ", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#" + "'", str12.equals("#"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test408");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("h", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "97.041.0497.04100.0410.0");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "h" + "'", str4.equals("h"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test409");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("      http://java.oracle.com/      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "      http://java.oracle.com/      " + "'", str1.equals("      http://java.oracle.com/      "));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test410");
        float[] floatArray3 = new float[] { (-1), 1, 100.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.Class<?> wildcardClass5 = floatArray3.getClass();
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', 1, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test411");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("4444444", "                                                                                            -1 32", "            mAC os x                                           -1 32");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test412");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test413");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U", "      http://java.oracle.com/      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test414");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.Class<?> wildcardClass5 = byteArray2.getClass();
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "Maaca aOSa aXa444444444444444444444444");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Maaca aOSa aXa444444444444444444444444");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1#100" + "'", str8.equals("1#100"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test415");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("c...aOr");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "C...aOr" + "'", str1.equals("C...aOr"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("sun.lwawt.macosx.CPrinterJo", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJo" + "'", str2.equals("sun.lwawt.macosx.CPrinterJo"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("BOJRETNIRPC.XSOCAM.TWAWL.NUS/USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../U", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BOJRETNIRPC.XSOCAM.TWAWL.NUS/USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../U" + "'", str2.equals("BOJRETNIRPC.XSOCAM.TWAWL.NUS/USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../USE.../U"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test419");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test420");
        short[] shortArray6 = new short[] { (short) 0, (byte) 100, (byte) 1, (short) 100, (short) 10, (short) 0 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a', 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a100a1a100a10a0" + "'", str8.equals("0a100a1a100a10a0"));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test421");
        long[] longArray3 = new long[] { 'a', (short) -1, (short) -1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "97 -1 -1" + "'", str6.equals("97 -1 -1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "97#-1#-1" + "'", str8.equals("97#-1#-1"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "97a-1a-1" + "'", str12.equals("97a-1a-1"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test422");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar#sun.lwawt.macosx.CPrinterJob#mixed mode#mixed mode#0a100a1a100a10a0#sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test423");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.5", '4');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test424");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("97", (float) 95L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("h0a100a1a100a10a", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h0a100a1a100a10a" + "'", str2.equals("h0a100a1a100a10a"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test426");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "524104324041004152410432404100415241043240          ", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test427");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                hi!                ", (java.lang.CharSequence) "                 xed mode", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test428");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ", "mixed mod", 0);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test429");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "0.23A0.79A...", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test430");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) (short) -1, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a100" + "'", str7.equals("1a100"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1#100" + "'", str9.equals("1#100"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 1 + "'", byte10 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test431");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("x.CP", "1.7.0_80");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test432");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray7 = new char[] { '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence4, charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U", charArray7);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a', 99, (int) (byte) 7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test433");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "524104324...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str2.equals("HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("52410432404100415241043240410041524104324041004152410432404100415241043240410041524104321.85241043240410041524104324041004152410432404100415241043240410041524104324041004152410432");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52410432404100415241043240410041524104324041004152410432404100415241043240410041524104321.85241043240410041524104324041004152410432404100415241043240410041524104324041004152410432" + "'", str1.equals("52410432404100415241043240410041524104324041004152410432404100415241043240410041524104321.85241043240410041524104324041004152410432404100415241043240410041524104324041004152410432"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4", "ahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("x.CPrinterJLibraryx.CPrinterJJavax.CPrinterJJavaVirtualMachinesx.CPrinterJjdk1.7.0_80.jdkx.CPrinterJContentsx.CPrinterJx.CPrinterJomex.CPrinterJjrex.CPrinterJlibx.CPrinterJendorsed", "Orac...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x.CPrinterJLibraryx.CPrinterJJavax.CPrinterJJavaVirtualMachinesx.CPrinterJjdk1.7.0_80.jdkx.CPrinterJContentsx.CPrinterJx.CPrinterJomex.CPrinterJjrex.CPrinterJlibx.CPrinterJendorsed" + "'", str2.equals("x.CPrinterJLibraryx.CPrinterJJavax.CPrinterJJavaVirtualMachinesx.CPrinterJjdk1.7.0_80.jdkx.CPrinterJContentsx.CPrinterJx.CPrinterJomex.CPrinterJjrex.CPrinterJlibx.CPrinterJendorsed"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test437");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 2, (long) 35, (long) 13);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test438");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "                                        52a10a32a0a100a1                                         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test439");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "      http://java.oracle.com/     ", (java.lang.CharSequence) "####");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test440");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "/uSERS/SOPHIE/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.52A10A32A0A100A1/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.0A100A1A100A10A0/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.oRACLE cORPORATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE", 97);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "a                hi!                                hi!                        a                 ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test441");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "          h0a101.4h0a100           ", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test442");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("97.0a1.0a97.0a100.0a10.0", "1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444411");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test444");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test445");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "xed mode", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test446");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.14.3", "                                                                                                    ", (int) (short) 0);
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("################", strArray4, strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "################" + "'", str6.equals("################"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test447");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "14100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test448");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "10.0a1.0a100.0a0.0a97.0a32.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test449");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "CPRINTERJOCPRINTERJOCP", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "sophie          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip(":##################################", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":##################################" + "'", str2.equals(":##################################"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test452");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("boJretnirPC.xsocam.twawl.nus", "hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!", 13, (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!socam.twawl.nus" + "'", str4.equals("hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!socam.twawl.nus"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test453");
        long[] longArray2 = new long[] { (short) -1, ' ' };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1a32" + "'", str7.equals("-1a32"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1a32" + "'", str9.equals("-1a32"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1a32" + "'", str11.equals("-1a32"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test454");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ".01", 298);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "444444444444444444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test456");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80", (float) 68);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 68.0f + "'", float2 == 68.0f);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test457");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ", (java.lang.CharSequence) "1.0 0.0 0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test458");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                                        52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                         ", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test459");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "CPRINTERJ4444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("10.0A1.0A100.0A0.0A97.0A32.0", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0A1.0A100.0A0.0A97.0A32.0" + "'", str2.equals("10.0A1.0A100.0A0.0A97.0A32.0"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test461");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("97.0a1.0a97.0a100.0a10.0", "L524104324...b524104324...y524104324...J524104324...v524104324...J524104324...v524104324...V524104324...M524104324...k524104324...k524104324...C524104324...H524104324...b", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "97.0a1.0a97.0a100.0a10.0" + "'", str3.equals("97.0a1.0a97.0a100.0a10.0"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test463");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("524104324...", "a                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ", "hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!socam.twawl.nus");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test464");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(10.0d, 35.0d, 97.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test465");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "en", (java.lang.CharSequence) "-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test466");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", ".01");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test467");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "tmp/run", "                                                                                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test468");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("      http://java.oracle.com/      ", "      ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test469");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/LibrarJava Platform API Specificationorsed", (int) (short) 100, "/lIARARY/jAVA/jAVAvIRTUALmACHINES/JDKA7A_AJDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/lIARARY/jAVA/jAVAvIRTUALmAC/LibrarJava Platform API Specificationorsed/lIARARY/jAVA/jAVAvIRTUALmACH" + "'", str3.equals("/lIARARY/jAVA/jAVAvIRTUALmAC/LibrarJava Platform API Specificationorsed/lIARARY/jAVA/jAVAvIRTUALmACH"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test470");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 7, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test471");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "      ", (java.lang.CharSequence) "97.0a1.0a97.0a100.0a10.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "97.0a1.0a97.0a100.0a10.0" + "'", charSequence2.equals("97.0a1.0a97.0a100.0a10.0"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test472");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence6 = null;
        char[] charArray9 = new char[] { '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence6, charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "US", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                                           1.7.0_80", charArray9);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test473");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("14100", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test474");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "h0a100a1a100a10a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test476");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "      http://java.oracle.com/     ", 14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.7.0_80-b15", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test478");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("97 -1 -1", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                        52A10A32A0A100A1                                         ", 86, "asun.lwawt.macosx.CPrinterJob52a1aa                                                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                        52A10A32A0A100A1                                         " + "'", str3.equals("                                        52A10A32A0A100A1                                         "));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test481");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) ":##########################", (java.lang.CharSequence) "/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test482");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaa", 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test483");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '#', 95L, (long) 14100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar#sun.lwawt.macosx.CPrinterJob#mixed mode#mixed mode#0a100a1a100a10a0#sun.lwawt.macosx.CPrinterJob", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar#sun.lwawt.macosx.CPrinterJob#mixed mode#mixed mode#0a100a1a100a10a0#sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar#sun.lwawt.macosx.CPrinterJob#mixed mode#mixed mode#0a100a1a100a10a0#sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test485");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test486");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "c...aOr", "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "sun.awt.CG");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("sun.lwawt.macosx.CPrinterJo", "/LibrarJava Platform API Specificationorsed", "Mac OS X444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "u.4wSw4.4S44x.C4Oc44OX4" + "'", str3.equals("u.4wSw4.4S44x.C4Oc44OX4"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test489");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence5, charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "h0a100a1a100a10a", charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, ' ');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "#" + "'", str17.equals("#"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test490");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 10, 1.0f, 1.7f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test491");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ', (int) (short) 100, 8);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test492");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("####");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test493");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "4444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test494");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk.0_80.jdk/Contents/Home/jre/lib/endorse", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", "                                   ", "xed mode");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test496");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test497");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Librar...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test498");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Sunaawta/GraphicsEnnironment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 28 + "'", int1 == 28);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test499");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("52A10A32A0A100A1", "CPRINTERJOCPRINTERJOCP");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) ":##################################", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test500");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#", "hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertNotNull(strArray2);
    }
}

