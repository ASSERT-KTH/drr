import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test001");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test002");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1 100", (int) (byte) 10, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test003");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("h0a101.4h0a100", "                                                                                           1.7.0_80", "hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "h0a101.4h0a100" + "'", str4.equals("h0a101.4h0a100"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test004");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\n", "                                                                                                    ");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "5241043240410041", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "\n" + "'", str5.equals("\n"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0" + "'", str1.equals("100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test006");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray6, '4');
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "52a10a32a0a100a1", charArray6);
        java.lang.Class<?> wildcardClass14 = charArray6.getClass();
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#" + "'", str12.equals("#"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test007");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR SUN.LWAWT.MACOSX.cpRINTERjOB MIXED MODE MIXED MODE 0A100A1A100A10A0 SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test008");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/LibrarJava Platform API Specificationorsed");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test009");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                                                                                ", "c...aO");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test010");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("         #", "/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (int) (byte) 100);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test011");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.14.3", "                                                                                                    ", (int) (short) 0);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10.14.3" + "'", str5.equals("10.14.3"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test012");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test013");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("CPRINTERJ4444444", '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4', 2, 0);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test014");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a', 97, 7);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test015");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaa5241043240410041", (java.lang.CharSequence) "Sunaawta/GraphicsEnnironment", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sophie" + "'", str1.equals("Sophie"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test017");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("100#0#0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#0#0" + "'", str2.equals("100#0#0"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test019");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("  ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  " + "'", str2.equals("  "));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test020");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test021");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52, (double) 16L, (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test022");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("########################xed mode", "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "########################xed mode" + "'", str2.equals("########################xed mode"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test023");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("mACosx-132");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mACosx-132" + "'", str1.equals("mACosx-132"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test025");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa0#100#1#100#10#0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", "444444x.CP444444", 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaa0#100#1#100#10#0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaa0#100#1#100#10#0aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test026");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray6, '4', (int) '#', 25);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray6);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.2", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test027");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("rtual Machine Specification", (short) 7);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 7 + "'", short2 == (short) 7);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test028");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("ahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 178);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                  " + "'", str2.equals("                                                                                                                                                                                  "));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test030");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test031");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob", (-1), 28);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defe" + "'", str3.equals("/Users/sophie/Documents/defe"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test032");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "51.0      ", 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test033");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 12, 165L, (long) 5);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5L + "'", long3 == 5L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test034");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test035");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "0a100a1a100a10a0", (java.lang.CharSequence) "32.0a97.0a0.0a100.0a1.0a10.0");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "0a100a1a100a10a0" + "'", charSequence2.equals("0a100a1a100a10a0"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test036");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 8L, (double) 'a');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("444444x.CP444444", "1a52a32");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444x.CP444444" + "'", str2.equals("444444x.CP444444"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test038");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("h", '#');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "tmp/run", (java.lang.CharSequence[]) strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedJava HotSpot(TM) 64-", (int) (short) 1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedJava HotSpot(TM) 64-" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedJava HotSpot(TM) 64-"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test040");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test041");
        long[] longArray2 = new long[] { (short) -1, ' ' };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', 18, 0);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1#32" + "'", str5.equals("-1#32"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "100#0#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test043");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) ".0                                                                                            1", (java.lang.CharSequence) "    ...", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test044");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test045");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("97a-1a-1", 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test046");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str6 = javaVersion5.toString();
        boolean boolean7 = javaVersion4.atLeast(javaVersion5);
        boolean boolean8 = javaVersion0.atLeast(javaVersion5);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean10 = javaVersion5.atLeast(javaVersion9);
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean12 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        java.lang.String str13 = javaVersion5.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.4" + "'", str6.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.4" + "'", str13.equals("1.4"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test047");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "####", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test048");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray7 = new char[] { '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence4, charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charArray7);
        java.lang.Class<?> wildcardClass14 = charArray7.getClass();
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test049");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 0.0d, (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test050");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test051");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test052");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray4 = new char[] { 'a' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence1, charArray4);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1#100", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test053");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("97 -1 -1", (float) 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test054");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(8, (int) (short) 1, 75);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test055");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 13, (long) 12, 10L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test056");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "             ", (java.lang.CharSequence) "aa32.0a97.0a0.0a100.0a1.0a10.0aa", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("h", "32.0a97.0a0.0a100.0a1.0a10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.0a97.0a0.0a100.0a1.0a10.0" + "'", str2.equals("32.0a97.0a0.0a100.0a1.0a10.0"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test058");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("444444x.CP444444", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444x.CP444444" + "'", str3.equals("444444x.CP444444"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("MMMMMMhttp://java.oracle.com/MMMMMM", "Java(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "MMMMMMhttp://java.oracle.com/" + "'", str2.equals("MMMMMMhttp://java.oracle.com/"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7 1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7", (-1), ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7 1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7" + "'", str3.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7 1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test061");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "524104324...", (java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test062");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "1#100", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test063");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "10.0a1.0a100.0a0.0a97.0a32.", (java.lang.CharSequence) "1#100", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test064");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                 a                 ", (java.lang.CharSequence) "CPri...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) (short) 10, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test066");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test067");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "52a10a32a0a100a1", (int) (byte) 0, 178);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test068");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test069");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444411");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                hi!                ");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly(":", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test070");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test071");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("h0a100a1a100a10a0", "hi", (int) (short) 100);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "");
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "24.80-B11", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, ".0                                                                                            1");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "h0a100a1a100a10a0" + "'", str8.equals("h0a100a1a100a10a0"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test072");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "32.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test073");
        java.lang.CharSequence charSequence1 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "                hi!                ", charSequence1);
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                hi!                " + "'", charSequence2.equals("                hi!                "));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test074");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("####", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test075");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "14100" + "'", str5.equals("14100"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("32.0...", 18);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.0..." + "'", str2.equals("32.0..."));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test077");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-1432", "#########################Oracle Corporation#########################");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                          US", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test078");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "############################################################xed mode", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test079");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 75, 0L, (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test080");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("      http://java.oracle.com/     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278", 96, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0278" + "'", str3.equals("0278"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test081");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("c...aOr", "  ", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test082");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) 7, "/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/" + "'", str3.equals("/Users/"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test083");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "        ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("1.5", "/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5" + "'", str2.equals("1.5"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test085");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("p...", "          xed mod           ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "p..." + "'", str2.equals("p..."));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test086");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Liarary/Java/JavaVirtualMachines/jdka7a_ajdk/Contents/Home/jre", 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test087");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1.040.0                                                                                            1.7.0_80", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test088");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", ' ');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "mixed mod");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java HotSpot(TM) 64-Bit Server VM", "boJretnirPC.xsocam.twawl.nus", 1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444411", strArray7, strArray11);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.Class<?> wildcardClass14 = strArray7.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str5.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444411" + "'", str12.equals("1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444411"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test089");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", ' ');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "mixed mod");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "sun.lwawt.macosx.CPrinterJo", 68, (int) (short) 7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "100#0#0", (java.lang.CharSequence[]) strArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str5.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str13.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test090");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) ":", (java.lang.CharSequence) "h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test091");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("      ", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      " + "'", str2.equals("      "));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test093");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test094");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test095");
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence7 = null;
        char[] charArray10 = new char[] { '#' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence7, charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "US", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi", charArray10);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray10);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "en", charArray10);
        boolean boolean19 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "        ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test096");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test097");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "http...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test098");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.Class<?> wildcardClass5 = byteArray2.getClass();
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', 52, 16);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1a100" + "'", str11.equals("1a100"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test099");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Oracle Corporation", (int) (byte) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test101");
        float[] floatArray3 = new float[] { (-1), 1, 100.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', (int) (short) 0, (int) (byte) 1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', 7, 0);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1.0#1.0#100.0" + "'", str6.equals("-1.0#1.0#100.0"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1.0" + "'", str10.equals("-1.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test102");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("            mAC os x                                           -1 32", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test103");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("a", "524104324041004152410432404100415241043240          ", (int) (short) 7);
        java.lang.Class<?> wildcardClass5 = strArray4.getClass();
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test104");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("sun.awt.CG", " ", (-1), 25);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " " + "'", str4.equals(" "));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test105");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("CPRINTERJOCPR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CPRINTERJOCPR" + "'", str1.equals("CPRINTERJOCPR"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test106");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("52a10a32a0a100a1", 0, "MIXED MODE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52a10a32a0a100a1" + "'", str3.equals("52a10a32a0a100a1"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("############################################################xed mode", "97.0a1.0a97.0a100.0a10.0", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############################################################xed mode" + "'", str3.equals("############################################################xed mode"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test108");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4x.CP44", (int) (byte) 10, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test109");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (byte) 0, 6, 14100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test110");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", 100);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test111");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test112");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "100#0#0", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("java(TM) SE Runtime Environment", "Java(TM)SERuntimeEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java(TM) SE Runtime Environment" + "'", str2.equals("java(TM) SE Runtime Environment"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test114");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test115");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test116");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 16, 179);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test117");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle.", (java.lang.CharSequence) "/lIARARY/jAVA/jAVAvIRTUALmACHINES/JDKA7A_AJDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test118");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) ".0                                                                                            1", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test119");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "1.7.0_80", 68);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test120");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 49);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test122");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("100", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100" + "'", str2.equals("100"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test123");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "52A10A32A0A100A1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("      http://java.oracle.com/     1a1001a1001a1001a1", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_156:##################################", "51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "      http://java.oracle.com/     1a1001a1001a1001a1" + "'", str3.equals("      http://java.oracle.com/     1a1001a1001a1001a1"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test126");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                        52a10a32a0a100a1                                         ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test127");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ahi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!" + "'", str2.equals("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("mixed mod");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mixedmod" + "'", str1.equals("mixedmod"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test130");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk.0_80.jdk/Contents/Home/jre/lib/endorse", (java.lang.CharSequence) "                                                                                           1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test131");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) -1, (long) 52, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("32.0#97.0#0.0#100.0#1.0#10.0", "1a100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.0#97.0#0.0#100.0#1.0#10.0" + "'", str2.equals("32.0#97.0#0.0#100.0#1.0#10.0"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test133");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("         #1043240          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "         #1043240          " + "'", str1.equals("         #1043240          "));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                                                                                                                                                ", "10.0a1.0a100.0a0.0a97.0a32.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                " + "'", str2.equals("                                                                                                                                                                "));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test135");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/USERS/SOPHIE", 75);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test136");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/USERS/SOPHIE", "C...aOr", "      http://java.oracle.com/      ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPHIE" + "'", str3.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test137");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sophie          ", (java.lang.CharSequence) "CPRINTERJOCPR", 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test138");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob.0_80 0a100a1a100a10a0 mode mixed mode d", (java.lang.CharSequence) "1452432", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 67 + "'", int3 == 67);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b1" + "'", str1.equals("1.7.0_80-b1"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test140");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("x.CPrinterJ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test141");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 0, 97L, (long) 97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test142");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("524104324...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("32.0 97.0 0.0 100.0 1.0 10.0tmp/", 96);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.0 97.0 0.0 100.0 1.0 10.0tmp/" + "'", str2.equals("32.0 97.0 0.0 100.0 1.0 10.0tmp/"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/", "Mac OS X", ":");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Douments/defets4jJvHotpot(T:)64-BiterverV:/Users/sophie/Douments/defets4j/" + "'", str3.equals("/Users/sophie/Douments/defets4jJvHotpot(T:)64-BiterverV:/Users/sophie/Douments/defets4j/"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test145");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("p...", 14, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "p...##########" + "'", str3.equals("p...##########"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test146");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("CPRINTERJ4444444");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test147");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 0, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test148");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("-1#32");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test149");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "a                hi!                                hi!                        a                 ", 68);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("32.0 97.0 0.0 100.0 1.0 10.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test151");
        int[] intArray6 = new int[] { '4', (short) 10, ' ', 0, (byte) 100, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', (int) (short) 100, 97);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52a10a32a0a100a1" + "'", str8.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "5241043240410041" + "'", str15.equals("5241043240410041"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "52a10a32a0a100a1" + "'", str17.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "52 10 32 0 100 1" + "'", str19.equals("52 10 32 0 100 1"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test152");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test153");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0 100 1 100 10 0", "1.5                                                                                            1.7.");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test154");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(".0                                                                                            1", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test155");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test156");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.744444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "100#0#0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test157");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "52 10 32 0 100 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test158");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("nur/pmt/j4stcefed/stnemucoD/eihpos/sresU/a01a001a1a001a0hur/pmt/j4stcefed/stnemucoD/eihpos/sresU/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test159");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("35.0");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "#########################Oracle Corporation#########################");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "35.0" + "'", str3.equals("35.0"));
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test160");
        long[] longArray3 = new long[] { 1L, '4', ' ' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', (int) (byte) 0, (int) (short) 1);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1a52a32" + "'", str10.equals("1a52a32"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1452432" + "'", str12.equals("1452432"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 52L + "'", long13 == 52L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test161");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "", "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!               ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test162");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7.0_80-b15", (int) (byte) 10);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "http...", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test163");
        int[] intArray0 = new int[] {};
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.min(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test164");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 99);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test166");
        double[] doubleArray3 = new double[] { (byte) 1, 0L, 0.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '#', 68, 35);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test167");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat(".0                                                                                            1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \".0                                                                                            1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test168");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "      http://java.oracle.com/     h", (java.lang.CharSequence) "x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test169");
        long[] longArray2 = new long[] { (short) -1, ' ' };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', 97, (int) 'a');
        java.lang.Class<?> wildcardClass8 = longArray2.getClass();
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test170");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test171");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("4444444444", 68.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.444444444E9d + "'", double2 == 4.444444444E9d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("97", 68, 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("32.0...", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.0..." + "'", str2.equals("32.0..."));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test174");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                                                                                            1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test175");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) (byte) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sop...", ".7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sop" + "'", str2.equals("/Users/sop"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("51.0      ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0      " + "'", str1.equals("51.0      "));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test178");
        int[] intArray6 = new int[] { '4', (short) 10, ' ', 0, (byte) 100, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int14 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52a10a32a0a100a1" + "'", str8.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52a10a32a0a100a1" + "'", str10.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test179");
        int[] intArray5 = new int[] { (byte) 100, 1, ' ', '4', (-1) };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ', (int) (short) 1, 1);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ', (int) (byte) 100, (int) (byte) 7);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100a1a32a52a-1" + "'", str12.equals("100a1a32a52a-1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test180");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test181");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("          xed mod           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "xed mod" + "'", str1.equals("xed mod"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test182");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "awt.macosx.CPrinterJob52a1aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test183");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("MMMMMMhttp://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test184");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/Users/sophie", 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test185");
        float[] floatArray6 = new float[] { ' ', 'a', 0.0f, 100.0f, (byte) 1, (short) 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32.0497.040.04100.041.0410.0" + "'", str10.equals("32.0497.040.04100.041.0410.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "32.0a97.0a0.0a100.0a1.0a10.0" + "'", str12.equals("32.0a97.0a0.0a100.0a1.0a10.0"));
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "32.0a97.0a0.0a100.0a1.0a10.0" + "'", str15.equals("32.0a97.0a0.0a100.0a1.0a10.0"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test186");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/Users/sop", (java.lang.CharSequence) "a                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("32.0a97.0a0.0a100.0a1.0a10.0", "-1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.0a97.0a0.0a100.0a1.0a10.0" + "'", str2.equals("32.0a97.0a0.0a100.0a1.0a10.0"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test188");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test189");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("51.0      ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test190");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.Class<?> wildcardClass5 = byteArray2.getClass();
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 13, (int) (byte) 1);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', 1, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1#100" + "'", str8.equals("1#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 1 + "'", byte13 == (byte) 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test191");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("sun.lwawt.macosx.CPrinterJob52a", "sun.lwawt.macosx.CPrinterJob", "-1 32aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1 32aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-1 32");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test192");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("14100", "CPRINTERJ", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test193");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "97 -1 -1", "                hi!                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test194");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "0a100a1a100a10a0", (java.lang.CharSequence) "1.0 0.0 0.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test195");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str4.equals("HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("TMP/RUN", '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TMP/RUN" + "'", str3.equals("TMP/RUN"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test197");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.a");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test198");
        float[] floatArray6 = new float[] { ' ', 'a', 0.0f, 100.0f, (byte) 1, (short) 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', 8, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test199");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("          h0a101.4h0a100           ", (byte) 7);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 7 + "'", byte2 == (byte) 7);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test200");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 12, (long) (short) 0, (long) ' ');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test201");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test202");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test203");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "52 10 32 0 100 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test204");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("97 -1 -1");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "############################################################xed mode", (java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "MMMMMMhttp://java.oracle.com/", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test205");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", "4444444444444444444444444444444444444444444444444444");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "0 100 1 100 10 0");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#', (int) (short) 100, (int) (short) 7);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "32.0#97.0#0.0#100.0#1.0#10.0", 14, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 14");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test206");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.00.0                                                                                            1.7.0_80");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.00.0 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test207");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("         #1043240          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test208");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("10.14.3", "d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80", 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3" + "'", str3.equals("10.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test209");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((-1), 13, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test210");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str4 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.5" + "'", str4.equals("1.5"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test211");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "51.0      ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test212");
        int[] intArray6 = new int[] { '4', (short) 10, ' ', 0, (byte) 100, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52a10a32a0a100a1" + "'", str8.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "52a10a32a0a100a1" + "'", str14.equals("52a10a32a0a100a1"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test213");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "mAC os x                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test214");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("XED MODXED MODXED MODX524104324041004152410432404100415241043240          XED MODXED MODXED MODXE");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test215");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "         #1043240          ", (int) (byte) 7);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test216");
        char[] charArray5 = new char[] { '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                                    ", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test217");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                                                                            1.7.0_80", "-1.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                            1.7.0_80" + "'", str2.equals("                                                                                            1.7.0_80"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test218");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("boJretnirPC.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "boJretnirPC.xsocam.twawl.nus" + "'", str1.equals("boJretnirPC.xsocam.twawl.nus"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test219");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "52 10 32 0 100 1", 67, 32);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test220");
        long[] longArray2 = new long[] { (short) -1, ' ' };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, '#');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1 32" + "'", str5.equals("-1 32"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#32" + "'", str7.equals("-1#32"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test221");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "x.CP");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("####################################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/Users/sop");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("1#100", "CPri...", 6);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1#100CPri...1#100CPri...1#100CPri...1#100CPri...1#100CPri...1#100" + "'", str3.equals("1#100CPri...1#100CPri...1#100CPri...1#100CPri...1#100CPri...1#100"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test224");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("XED MODXED MODXED MODX524104324041004152410432404100415241043240          XED MODXED MODXED MODXE", (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test225");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.hi!hi!hi!hi!hi!hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test226");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...", "1.5", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0..." + "'", str3.equals("32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0..."));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test227");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("-1a32");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a32\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Liarary/Java/JavaVirtualMachines/jdka7a_ajdk/Contents/Home/jre", 16, 14);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...vaVirtua..." + "'", str3.equals("...vaVirtua..."));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("32.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.0", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.0" + "'", str2.equals("32.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.0"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test230");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.14.3", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("100", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("hi!hi!hi!hi!hi!hi!hi!hi!hi!hi!", "1.040.0                                                                                            /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80", "100");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "!!!!!!!!!!" + "'", str3.equals("!!!!!!!!!!"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("                                                                                                                                                                ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test234");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test235");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "14100", 3, 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1a100", "CPRINTERJ4444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CPRINTERJ4444444" + "'", str2.equals("CPRINTERJ4444444"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test237");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "1.040.0                                                                                            /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", charSequence2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("CPRINTERJO", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "CPRINTERJO" + "'", str2.equals("CPRINTERJO"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test239");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                        52A10A32A0A100A1                                         ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test240");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("32.0...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test241");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("                                                                                                                                                                ", 6, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                                                                                " + "'", str3.equals("                                                                                                                                                                "));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test242");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run", "1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444411", 16);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0#0#100", "sun.lwawt.macosx.CPrinterJob.0_80 0a100a1a100a10a0 mode mixed mode d");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test244");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\n", "");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("Mac OS X", "sun.lwawt.macosx.CPrinterJob.0_80 0a100a1a100a10a0 mode mixed mode d");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test245");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test246");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U" + "'", str4.equals("boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test247");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("C...AOR", "1.8", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test248");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("         #");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test249");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("h0a100a1a100a10a", "524104324041004152410432404100415241043240");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test250");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("boJretnirPC.xsocam.twawl.nus", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (short) 1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '#', 68, (int) ' ');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "mixed mode", (int) (byte) 1);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects", strArray5, strArray15);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects" + "'", str16.equals("/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test252");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 2, (float) 32L, (float) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test253");
        float[] floatArray3 = new float[] { (-1), 1, 100.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1.041.04100.0" + "'", str8.equals("-1.041.04100.0"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test254");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) ":##########################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test255");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test256");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "x", "52a10a32a0a100a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("x4x4x4x4x4x4x4x4", "x.CPrinterJLibraryx.CPrinterJJavax.CPrinterJJavaVirtualMachinesx.CPrinterJjdk1.7.0_80.jdkx.CPrinterJContentsx.CPrinterJx.CPrinterJomex.CPrinterJjrex.CPrinterJlibx.CPrinterJendorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x4x4x4x4x4x4x4x4" + "'", str2.equals("x4x4x4x4x4x4x4x4"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test258");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 12, (double) 28L, 95.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 95.0d + "'", double3 == 95.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaa5241043240410041", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5241043240410041" + "'", str2.equals("5241043240410041"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("524104324...", (int) (short) 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24..." + "'", str2.equals("24..."));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test261");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("CPRINTERJOCPRINTERJOCP");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"CPRINTERJOCPRINTERJOCP\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test262");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "awt.macosx.CPrinterJob52a1aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test263");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("32.0497.040.04100.041.0410.0", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.0497.040.04100.041.0410.0" + "'", str2.equals("32.0497.040.04100.041.0410.0"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("asun.lwawt.macosx.CPrinterJob52a1aa", "        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "asun.lwawt.macosx.CPrinterJob52a1aa" + "'", str2.equals("asun.lwawt.macosx.CPrinterJob52a1aa"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test265");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/lIARARY/jAVA/jAVAvIRTUALmACHINES/JDKA7A_AJDK/cONTENTS/hOME/JRE", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test266");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test267");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/lIARARY/jAVA/jAVAvIRTUALmACHINES/JDKA7A_AJDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test268");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("#########################Oracle Corporation#########################", 99, 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#########################Oracle Corporation#########################" + "'", str3.equals("#########################Oracle Corporation#########################"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test269");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test270");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("32.0 97.0 0.0 100.0 1.0 10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32.0 97.0 0.0 100.0 1.0 10.0" + "'", str1.equals("32.0 97.0 0.0 100.0 1.0 10.0"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test271");
        int[] intArray6 = new int[] { '4', (short) 10, ' ', 0, (byte) 100, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', 49, (int) (byte) 0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52a10a32a0a100a1" + "'", str8.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test272");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("32.0 97.0 0.0 100.0 1.0 10.0tmp/");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test273");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Librar...", (java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test274");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 0, 0, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4..." + "'", str2.equals("/Users/sophie/Documents/defects4..."));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test276");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) (byte) 100, 0);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', 99, 67);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test277");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("444444444444444444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "TMP/RUN");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test278");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 8L, (float) (byte) -1, (float) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test279");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80-b1", 5, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test280");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("      http://java.oracle.com/     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test281");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", "4444444444444444444444444444444444444444444444444444");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "0 100 1 100 10 0");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.split("xed mode", "1.5");
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("32.0#97.0#0.0#100.0#1.0#10.0", strArray4, strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "32.0#97.0#0.0#100.0#1.0#10.0" + "'", str11.equals("32.0#97.0#0.0#100.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test282");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-1432", 16);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Mac OS X444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X444444444444444444444444" + "'", str1.equals("Mac OS X444444444444444444444444"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("      http://java.oracle.com/     ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      http://jv.orcle.com/     " + "'", str2.equals("      http://jv.orcle.com/     "));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test285");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "44a444#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test286");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("0.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.23", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.23" + "'", str2.equals("0.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.230.01a0.1a0.001a0.0a0.79a0.23"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited(" ", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test289");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test290");
        short[] shortArray3 = new short[] { (byte) 100, (short) 0, (short) 0 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) (short) 1, (int) (byte) 1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100a0a0" + "'", str11.equals("100a0a0"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test291");
        long[] longArray2 = new long[] { (short) -1, ' ' };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, '#', 97, (int) 'a');
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 32L + "'", long8 == 32L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1a32" + "'", str10.equals("-1a32"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test292");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "/Use..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Use.." + "'", str2.equals("/Use.."));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test294");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence5, charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "US", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "hi", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100 1 -1 100 100 -1", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("0.23A0.79A0.0A0.001A0.1A0.01");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.23A0.79A0.0A0.001A0.1A0.0" + "'", str1.equals("0.23A0.79A0.0A0.001A0.1A0.0"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test296");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("x.CPrinterJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JretnirPC.x" + "'", str1.equals("JretnirPC.x"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test298");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test299");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Users/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "CPri...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test301");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("444444444444444444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "24.80-b11", (int) (short) -1);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "0a100a1a100a10a0", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", ' ');
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.split("xed mode", "1.5");
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("                                                                                           1.7.0_80", strArray10, strArray13);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("1a52a32", strArray5, strArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray10);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "                                                                                           1.7.0_80" + "'", str14.equals("                                                                                           1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1a52a32" + "'", str15.equals("1a52a32"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test302");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", ' ');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("52A10A32A0A100A1", "CPRINTERJOCPRINTERJOCP");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", strArray4, strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "aAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str8.equals("aAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test303");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ".01", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test304");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("p...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "P..." + "'", str1.equals("P..."));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test305");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 10, (int) (byte) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test306");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.5", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test307");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("a                hi!                                hi!                        a                 ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (short) 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#######" + "'", str2.equals("#######"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test309");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", (double) 86);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 86.0d + "'", double2 == 86.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test310");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test311");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a', (int) 'a', (-1));
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ', 7, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test312");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#######", (java.lang.CharSequence) "0.23A0.79A...", 165);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test313");
        double[] doubleArray3 = new double[] { (byte) 1, 0L, 0.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray3, 'a', 100, 75);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test314");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test315");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 86);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test316");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("http://java.oracle.com/", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test317");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "-1a32", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str3.equals("HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test318");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "CPrinterJo", 3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test319");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "####################################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test320");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("sun.lwawt.macosx.CPrinterJob52a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.CPrinterJob52a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Orac...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test322");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "################", (java.lang.CharSequence) "  -1 32");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test323");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Java Virtual Machine Specification", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/uSERS/SOPHIE/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.52A10A32A0A100A1/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.0A100A1A100A10A0/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.oRACLE cORPORATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/users/sophie/users/sophie/library/java/extsun.lwawt.macosx.cprinterjobsions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.52a10a32a0a100a1/users/sophie/library/java/extsun.lwawt.macosx.cprinterjobsions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:./users/sophie/library/java/extsun.lwawt.macosx.cprinterjobsions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.0a100a1a100a10a0/users/sophie/library/java/extsun.lwawt.macosx.cprinterjobsions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.oracle corporation/users/sophie/library/java/extsun.lwawt.macosx.cprinterjobsions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:./users/sophie" + "'", str1.equals("/users/sophie/users/sophie/library/java/extsun.lwawt.macosx.cprinterjobsions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.52a10a32a0a100a1/users/sophie/library/java/extsun.lwawt.macosx.cprinterjobsions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:./users/sophie/library/java/extsun.lwawt.macosx.cprinterjobsions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.0a100a1a100a10a0/users/sophie/library/java/extsun.lwawt.macosx.cprinterjobsions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.oracle corporation/users/sophie/library/java/extsun.lwawt.macosx.cprinterjobsions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:./users/sophie"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("CPRINTERJOCPRINTERJOCP          ", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test326");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaa5241043240410041", "java Platform API Specification", "1.5                                                                                            1.7.");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test327");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test328");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("35.0");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test329");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "-1.0", (java.lang.CharSequence) "-1.041.04100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                hi!                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                hi!                " + "'", str1.equals("                hi!                "));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test331");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test332");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("asun.lwawt.macosx.CPrinterJob52a1aa", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test333");
        long[] longArray2 = new long[] { (short) -1, ' ' };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray2, 'a');
        java.lang.Class<?> wildcardClass8 = longArray2.getClass();
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1a32" + "'", str7.equals("-1a32"));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1432" + "'", str10.equals("-1432"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test334");
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray0 = new org.apache.commons.lang3.SystemUtils[] {};
        org.apache.commons.lang3.SystemUtils[][] systemUtilsArray1 = new org.apache.commons.lang3.SystemUtils[][] { systemUtilsArray0 };
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray2 = new org.apache.commons.lang3.SystemUtils[] {};
        org.apache.commons.lang3.SystemUtils[][] systemUtilsArray3 = new org.apache.commons.lang3.SystemUtils[][] { systemUtilsArray2 };
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray4 = new org.apache.commons.lang3.SystemUtils[] {};
        org.apache.commons.lang3.SystemUtils[][] systemUtilsArray5 = new org.apache.commons.lang3.SystemUtils[][] { systemUtilsArray4 };
        org.apache.commons.lang3.SystemUtils[][][] systemUtilsArray6 = new org.apache.commons.lang3.SystemUtils[][][] { systemUtilsArray1, systemUtilsArray3, systemUtilsArray5 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray6);
        org.junit.Assert.assertNotNull(systemUtilsArray0);
        org.junit.Assert.assertNotNull(systemUtilsArray1);
        org.junit.Assert.assertNotNull(systemUtilsArray2);
        org.junit.Assert.assertNotNull(systemUtilsArray3);
        org.junit.Assert.assertNotNull(systemUtilsArray4);
        org.junit.Assert.assertNotNull(systemUtilsArray5);
        org.junit.Assert.assertNotNull(systemUtilsArray6);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test335");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar#sun.lwawt.macosx.CPrinterJob#mixed mode#mixed mode#0a100a1a100a10a0#sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test336");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("444444444444444444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: 444444444444444444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test337");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("24", "4x.CP44", 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24" + "'", str3.equals("24"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test338");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("      http://java.oracle.com/     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      http://java.oracle.com/     /Users/sophie/Docu" + "'", str2.equals("      http://java.oracle.com/     /Users/sophie/Docu"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test340");
        org.apache.commons.lang3.JavaVersion javaVersion0 = null;
        try {
            boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test341");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/", "1.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/" + "'", str2.equals("/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test342");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_156:##################################", (java.lang.CharSequence) "1.040.0                                                                                            1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test343");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "x.CPrinterJ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 11 + "'", int1 == 11);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test344");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("0.23A0.79A0.0A0.001A0.1A0.01", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "      http://java.oracle.com/     1a1001a1001a1001a1", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0.23A0.79A0.0A0.001A0.1A0.01" + "'", str4.equals("0.23A0.79A0.0A0.001A0.1A0.01"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test345");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "32.0a97.0a0.0a100.0a1.0a10.0", 95);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test346");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1452432", "TMP/RUN#########");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test347");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Douments/defets4jJvHotpot(T:)64-BiterverV:/Users/sophie/Douments/defets4j/", (int) (byte) -1, "                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Douments/defets4jJvHotpot(T:)64-BiterverV:/Users/sophie/Douments/defets4j/" + "'", str3.equals("/Users/sophie/Douments/defets4jJvHotpot(T:)64-BiterverV:/Users/sophie/Douments/defets4j/"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test348");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("24.80-B11", (int) (byte) 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4.80-B11" + "'", str3.equals("4.80-B11"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test349");
        long[] longArray0 = null;
        try {
            long long1 = org.apache.commons.lang3.math.NumberUtils.max(longArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test350");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "http...", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob.0_80 0a100a1a100a10a0 mode mixed mode d");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("", "1a100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test352");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("52 10 32 0 100 1");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "/users/sophie/users/sophie/library/java/extsun.lwawt.macosx.cprinterjobsions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.52a10a32a0a100a1/users/sophie/library/java/extsun.lwawt.macosx.cprinterjobsions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:./users/sophie/library/java/extsun.lwawt.macosx.cprinterjobsions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.0a100a1a100a10a0/users/sophie/library/java/extsun.lwawt.macosx.cprinterjobsions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:.oracle corporation/users/sophie/library/java/extsun.lwawt.macosx.cprinterjobsions:/library/java/extensions:/network/library/java/extensions:/system/library/java/extensions:/usr/lib/java:./users/sophie", (int) (short) 0, (int) (short) 0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test353");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/", 1.5f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.5f + "'", float2 == 1.5f);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test354");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("          h0a101.4h0a100           ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          h0a101.4h0a100          " + "'", str1.equals("          h0a101.4h0a100          "));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test355");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "1a52a32");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test356");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                        7                        ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test357");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 16L, (float) (byte) 10, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 16.0f + "'", float3 == 16.0f);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test358");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#', (int) (byte) 100, 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray2, ' ');
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1 100" + "'", str12.equals("1 100"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test359");
        long[] longArray2 = new long[] { (short) -1, ' ' };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test360");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.a", (java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7 1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test361");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("52a10a32a0a100a1", (byte) 7);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 7 + "'", byte2 == (byte) 7);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1452432");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("p...", 165);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "p..." + "'", str2.equals("p..."));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test364");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 28, (float) 298L, (float) 49);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 28.0f + "'", float3 == 28.0f);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test365");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test366");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "####################################/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "                hi!                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("      http://java.oracle.com/     h", 99);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h" + "'", str2.equals("      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h      http://java.oracle.com/     h"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test368");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("x.CPrinterJLibraryx.CPrinterJJavax.CPrinterJJavaVirtualMachinesx.CPrinterJjdk1.7.0_80.jdkx.CPrinterJContentsx.CPrinterJx.CPrinterJomex.CPrinterJjrex.CPrinterJlibx.CPrinterJendorsed", "52a10a32a0a100a1", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x.CPrinterJLibraryx.CPrinterJJavax.CPrinte52a10a32a0a100a1interJjrex.CPrinterJlibx.CPrinterJendorsed" + "'", str3.equals("x.CPrinterJLibraryx.CPrinterJJavax.CPrinte52a10a32a0a100a1interJjrex.CPrinterJlibx.CPrinterJendorsed"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test369");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("mAC os x                                                                                                                                                             ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test370");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray1, 'a', 49, 12);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4', 49, 0);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test371");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#########################Oracle Corporation#########################", "      ", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test372");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("      http://java.oracle.com/      ", ' ');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                 xed 0ode", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                 xed 0ode" + "'", str2.equals("                 xed 0ode"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar#sun.lwawt.macosx.CPrinterJob#mixed mode#mixed mode#0a100a1a100a10a0#sun.lwawt.macosx.CPrinterJob", 14, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar#sun.lwawt.macosx.CPrinterJob#mixed mode#mixed mode#0a100a1a100a10a0#sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar#sun.lwawt.macosx.CPrinterJob#mixed mode#mixed mode#0a100a1a100a10a0#sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test375");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "MIXED MODE", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test376");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("524104324041004152410432404100415241043240", (float) 49L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test377");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("            mAC os x                                           -1 32                                ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test378");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.4", "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7 1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test379");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Use..", (java.lang.CharSequence) "p...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test380");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.Class<?> wildcardClass5 = byteArray2.getClass();
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test381");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "e/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D", (java.lang.CharSequence) "TMP/RUN", 49);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test382");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("          h0a101.4h0a100          ", "1.a");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("4.80-B11", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4.80-B11" + "'", str2.equals("4.80-B11"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test384");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence5, charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "US", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                                    ", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.8", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test385");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mACosx-132", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test386");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/Library/Java/JavaVirtualMachi97#-1#-1/Library/Java/JavaVirtualMachi", "                                        52A10A32A0A100A1                                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachi97#-1#-1/Library/Java/JavaVirtualMachi" + "'", str2.equals("/Library/Java/JavaVirtualMachi97#-1#-1/Library/Java/JavaVirtualMachi"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test387");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "x4x4x4x4x4x4x4x4", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test388");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, 14100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test389");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "############################################################xed mode", (java.lang.CharSequence) "100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test390");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Liarary/Java/JavaVirtualMachines/jdka7a_ajdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Liarary/Java/JavaVirtualMachines/jdka7a_ajdk/Contents/Home/jre" + "'", str1.equals("/Liarary/Java/JavaVirtualMachines/jdka7a_ajdk/Contents/Home/jre"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test391");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("7", "Java Virtual Machine Specification", 97);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "7" + "'", str5.equals("7"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test392");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("en");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test393");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "          ", 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test394");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "x.CP");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test395");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Jav", (java.lang.CharSequence) "h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test396");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.Class<?> wildcardClass5 = byteArray2.getClass();
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 13, (int) (byte) 1);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 100 + "'", byte6 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1#100" + "'", str8.equals("1#100"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) 1 + "'", byte13 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test397");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) (short) 100, (int) (byte) -1);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', (int) (byte) 1, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test398");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("-1.0", "1.74444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "x4x4x4x4x4x4x4x4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-x40" + "'", str3.equals("-x40"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test399");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test400");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4x8s_s4");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("p...", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test402");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("UTF-8", "Java(TM)SERuntimeEnvironment", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UaF-8" + "'", str3.equals("UaF-8"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test404");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("4x.CP44", (long) 49);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 49L + "'", long2 == 49L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test406");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "    ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test407");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 32L, 0.0f, 1.5f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test408");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "      http://java.oracle.com/     ", 298, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test410");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "1.6", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 18 + "'", int3 == 18);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test411");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "TMP/RUN", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test412");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("35.0");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "      http://java.oracle.com/     ", (java.lang.CharSequence[]) strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "35.0" + "'", str5.equals("35.0"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test413");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "-1#32", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test414");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ', 0, 13);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test416");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("100a1a32a52a-1", "sun.awt.CG");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a1a32a52a-1" + "'", str2.equals("100a1a32a52a-1"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test417");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("10.0a1.0a100.0a0.0a97.0a32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0a1.0a100.0a0.0a97.0a32.0" + "'", str1.equals("10.0a1.0a100.0a0.0a97.0a32.0"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test418");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("a                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ", "1.7");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test419");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        java.lang.Class<?> wildcardClass5 = byteArray2.getClass();
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 7, 0);
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test420");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "24...", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test421");
        float[] floatArray3 = new float[] { (-1), 1, 100.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.Class<?> wildcardClass5 = floatArray3.getClass();
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 100.0f + "'", float6 == 100.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + (-1.0f) + "'", float7 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1.0 1.0 100.0" + "'", str9.equals("-1.0 1.0 100.0"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test422");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platform API Specificatio" + "'", str1.equals("Java Platform API Specificatio"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test423");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray5 = new char[] { '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence2, charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, ' ');
        java.lang.Class<?> wildcardClass12 = charArray5.getClass();
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "#" + "'", str11.equals("#"));
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test424");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '#', 52, 68);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 68 + "'", int3 == 68);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test425");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3", 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test426");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "mixed mod");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test427");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test428");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("C...AOR", "      http://java.oracle.com/     1a1001a1001a1001a1", 0, 179);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "      http://java.oracle.com/     1a1001a1001a1001a1" + "'", str4.equals("      http://java.oracle.com/     1a1001a1001a1001a1"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("100#0#0", "32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...32.0...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100#0#0" + "'", str2.equals("100#0#0"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test430");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test431");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test432");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedJava HotSpot(TM) 64-", 25);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test433");
        long[] longArray2 = new long[] { (short) -1, ' ' };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1432" + "'", str6.equals("-1432"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test434");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("10.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_8010.14.3");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test435");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray5 = new char[] { '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray5, 'a', 16, (int) (byte) 10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence1, charArray5);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "####", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test436");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(100L, (long) (short) 1, 95L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test437");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test438");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" ", "", (int) ' ');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "UTF-8");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray11, strArray14);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray5, strArray14);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.split("35.0");
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray18, '4');
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", strArray5, strArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "a" + "'", str7.equals("a"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str15.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "35.0" + "'", str20.equals("35.0"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test439");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", "Sunaawta/GraphicsEnnironment", 68);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/DocumeSunaawta/GraphicsEnnironmentn/randoop-current.ja" + "'", str3.equals("/Users/sophie/DocumeSunaawta/GraphicsEnnironmentn/randoop-current.ja"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "0.040.040.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test441");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob.0_800a100a1a100a10a0modemixedmoded", (java.lang.CharSequence) "                                        52a10a32a0a100a1                                         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test442");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "        ", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test443");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "        ", (java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test444");
        float[] floatArray3 = new float[] { '#', 0.0f, 0L };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ', (int) (byte) 100, (int) (byte) -1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', 0, 1);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray3, '4', 100, 0);
        float float16 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "35.0" + "'", str11.equals("35.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Mixed mode", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mixed mode" + "'", str2.equals("Mixed mode"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test446");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("97 -1 -1", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test447");
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray0);
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test448");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', (int) (short) 100, (int) ' ');
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray0, ' ', 0, 68);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test449");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1 100");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1 100" + "'", str1.equals("1 100"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test451");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                                            -1 32", (long) 18);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 18L + "'", long2 == 18L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("xed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxe");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "xed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxe" + "'", str1.equals("xed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxexed modxed modxed modx524104324041004152410432404100415241043240          xed modxed modxed modxe"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test453");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) ":##########################", (java.lang.CharSequence) "524104324041004152410432404100415241043240", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test454");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) ".0                                                                                            1", (java.lang.CharSequence) "mAC os x                                                                                                                                                             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test455");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test456");
        java.lang.CharSequence charSequence7 = null;
        char[] charArray10 = new char[] { '#' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence7, charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "US", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Mac OS X", charArray10);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "xed mode", charArray10);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaaaaaa", charArray10);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100#0#0", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test457");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test458");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ', 1, (int) (short) -1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4', (int) 'a', (int) (byte) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4', 67, (-1));
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test459");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("111111111111111111111197 -1 -11111111111111111111111", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test460");
        long[] longArray3 = new long[] { 'a', (short) -1, (short) -1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray3, ' ');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, '#');
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "97 -1 -1" + "'", str6.equals("97 -1 -1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "97#-1#-1" + "'", str8.equals("97#-1#-1"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "974-14-1" + "'", str12.equals("974-14-1"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test461");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                        52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                         ", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test462");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        try {
            double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test463");
        int[] intArray6 = new int[] { '4', (short) 10, ' ', 0, (byte) 100, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray6);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        int int13 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray6, '4');
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52a10a32a0a100a1" + "'", str8.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "52a10a32a0a100a1" + "'", str10.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "5241043240410041" + "'", str15.equals("5241043240410041"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test464");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("AC os x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ac os x" + "'", str1.equals("ac os x"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test465");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Sunaawta/GraphicsEnnironment", (java.lang.CharSequence) "1.040.040.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test466");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ', 1, (int) (short) -1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4', (int) 'a', (int) (byte) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4', 179, (int) (short) 10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test467");
        org.apache.commons.lang3.math.NumberUtils numberUtils0 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils1 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils2 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils3 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils4 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray5 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils0, numberUtils1, numberUtils2, numberUtils3, numberUtils4 };
        org.apache.commons.lang3.math.NumberUtils numberUtils6 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils7 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils8 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils9 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils numberUtils10 = new org.apache.commons.lang3.math.NumberUtils();
        org.apache.commons.lang3.math.NumberUtils[] numberUtilsArray11 = new org.apache.commons.lang3.math.NumberUtils[] { numberUtils6, numberUtils7, numberUtils8, numberUtils9, numberUtils10 };
        org.apache.commons.lang3.math.NumberUtils[][] numberUtilsArray12 = new org.apache.commons.lang3.math.NumberUtils[][] { numberUtilsArray5, numberUtilsArray11 };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(numberUtilsArray12);
        org.junit.Assert.assertNotNull(numberUtilsArray5);
        org.junit.Assert.assertNotNull(numberUtilsArray11);
        org.junit.Assert.assertNotNull(numberUtilsArray12);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test468");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "HIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test469");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("java(TM) SE Runtime Environment", (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test470");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("51.0", "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!               ");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "ac os x", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test471");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "-1.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test472");
        int[] intArray5 = new int[] { (byte) 100, 1, ' ', '4', (-1) };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray5, ' ', (int) (short) 1, 1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray5, 'a', 99, (int) (byte) 0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test473");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test474");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0#0#100", (java.lang.CharSequence) "                                                                                            -1 32", 14100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test475");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("32.0#97.0#0.0#100.0#1.0#10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test476");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("7", "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!               ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test477");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h" + "'", str1.equals("h"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test478");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1#100CPri...1#100CPri...1#100CPri...1#100CPri...1#100CPri...1#100");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("http://java.oracle.com/", 14100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test480");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test481");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("111111111111111111111197 -1 -11111111111111111111111");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce(".0                                                                                            1", "97#-1#-1", "C...AOR");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".0                                                                                            1" + "'", str3.equals(".0                                                                                            1"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test483");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray8 = new char[] { '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence5, charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U", charArray8);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, charArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray8, '4');
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "#" + "'", str17.equals("#"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test484");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test485");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test486");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("CPri...", 16, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test488");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 1, (double) 5L, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test489");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test490");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "35.0", (java.lang.CharSequence) "/Users/sophie/Documents/d");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test491");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("sun.awt52a10a32a0a100a1", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt52a10a32a0a100a1" + "'", str2.equals("sun.awt52a10a32a0a100a1"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test493");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "32.0...", (java.lang.CharSequence) "Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 162 + "'", int2 == 162);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("                                   ", "52 10 32 0 100 1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test496");
        long[] longArray2 = new long[] { (short) -1, ' ' };
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long5 = org.apache.commons.lang3.math.NumberUtils.max(longArray2);
        long long6 = org.apache.commons.lang3.math.NumberUtils.min(longArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray2, ' ', 13, 11);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray2, '4');
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 32L + "'", long4 == 32L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 32L + "'", long5 == 32L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1432" + "'", str12.equals("-1432"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test497");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b1" + "'", str1.equals("1.7.0_80-b1"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "/Use..");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test499");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("########################xed mode", "", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest7.test500");
        long[] longArray3 = new long[] { 'a', (short) -1, (short) -1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 14100, 100);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray3, '4', 178, 8);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-1L) + "'", long4 == (-1L));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 97L + "'", long13 == 97L);
    }
}

