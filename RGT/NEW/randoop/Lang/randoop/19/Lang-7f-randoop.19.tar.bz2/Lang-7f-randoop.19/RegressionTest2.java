import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("aa32.0a97.0a0.0a100.0a1.0a10.0aa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        short[] shortArray6 = new short[] { (short) 0, (byte) 100, (byte) 1, (short) 100, (short) 10, (short) 0 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ', 25, 7);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a100a1a100a10a0" + "'", str8.equals("0a100a1a100a10a0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 100 + "'", short13 == (short) 100);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ', 1, (int) (short) -1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4', (int) 'a', (int) (byte) -1);
        try {
            double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("xed mode", 68, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "############################################################xed mode" + "'", str3.equals("############################################################xed mode"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Java Platform API Specification", "", "hi");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("35.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35.0" + "'", str2.equals("35.0"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", charArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray6, '#');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray6, 'a', 7, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "#" + "'", str13.equals("#"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("32.0a97.0a0.0a100.0a1.0a10.0", "http://java.oracle.com/", "-1 32");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "aa32.0a97.0a0.0a100.0a1.0a10.0aa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                                            -1 32", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("7", "10.14.3");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80" + "'", str2.equals("d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(" ", "", (int) ' ');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "/", 6, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                                                                            1.7.0_80", "100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0100#0#0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                            1.7.0_80" + "'", str2.equals("                                                                                            1.7.0_80"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                                                                                                 ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        int[] intArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("################", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################" + "'", str3.equals("################"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("boJr/boJre", "################", 49);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "boJr/boJre" + "'", str3.equals("boJr/boJre"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, 0.0d, (double) 7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("10.0a1.0a100.0a0.0a97.0a32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0a1.0a100.0a0.0a97.0a32.0" + "'", str1.equals("10.0a1.0a100.0a0.0a97.0a32.0"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("32.0497.040.04100.041.0410.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("Oracle Corporation", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str2.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "100a0a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("sun.lwawt.macosx.CPrinterJob52a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("32.0#97.0#0.0#100.0#1.0#10.0", "5241043240410041");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.0#97.0#0.0#100.0#1.0#10.0" + "'", str2.equals("32.0#97.0#0.0#100.0#1.0#10.0"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("24.80-B11", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "tmp/run");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", "", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h" + "'", str1.equals("h"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "32.0497.040.04100.041.0410.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("x86_64", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x86_64" + "'", str2.equals("x86_64"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.040.0                                                                                            /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80", 14, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Oracle Corporation", (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 0, "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.040.0                                                                                            1.7.0_80", "", 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "1.7.0_80-b15", (int) (byte) 10);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "h0a100a1a100a10a");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                                                                            -1 32", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("0a100a1a100a10a0", "      http://java.oracle.com/     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a100a1a100a10a0" + "'", str2.equals("0a100a1a100a10a0"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        int[] intArray6 = new int[] { '4', (short) 10, ' ', 0, (byte) 100, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray6, ' ', (int) (short) 7, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52a10a32a0a100a1" + "'", str8.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h" + "'", str1.equals("h"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        int[] intArray4 = new int[] { 0, 28, 7, 52 };
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', (int) (byte) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("51.0", 97, "      http://java.oracle.com/     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle." + "'", str3.equals("51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle."));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "x.CP");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("52a10a32a0a100a1", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                        52a10a32a0a100a1                                         " + "'", str2.equals("                                        52a10a32a0a100a1                                         "));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "24.80-B11", (java.lang.CharSequence) "10.0a1.0a100.0a0.0a97.0a32.0", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("h0a100a1a100a10a0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\n", "");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "1.7", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "10.0a1.0a100.0a0.0a97.0a32.0", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.5", 16.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.5f + "'", float2 == 1.5f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("hi", (int) '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("hiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("32.0a97.0a0.0a100.0a1.0a10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32.0a97.0a0.0a100.0a1.0a10.0" + "'", str1.equals("32.0a97.0a0.0a100.0a1.0a10.0"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("32.0#97.0#0.0#100.0#1.0#10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"32.0#97.0#0.0#100.0#1.0#10.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.apache.commons.lang3.StringUtils stringUtils0 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils1 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils2 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils3 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils4 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils stringUtils5 = new org.apache.commons.lang3.StringUtils();
        org.apache.commons.lang3.StringUtils[] stringUtilsArray6 = new org.apache.commons.lang3.StringUtils[] { stringUtils0, stringUtils1, stringUtils2, stringUtils3, stringUtils4, stringUtils5 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(stringUtilsArray6);
        org.junit.Assert.assertNotNull(stringUtilsArray6);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("sun.lwawt.macosx.LWCToolkit", (int) (short) 0, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("hi", "32.0#97.0#0.0#100.0#1.0#10.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi" + "'", str2.equals("hi"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 8, (float) 8, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.awt.CGraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.awt.CGraphicsEnvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", (int) (byte) 1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("52a10a32a0a100a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52A10A32A0A100A1" + "'", str1.equals("52A10A32A0A100A1"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("97", (int) '4', "h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "h0a100a1a100a10a h0a100a197h0a100a1a100a10a h0a100a1" + "'", str3.equals("h0a100a1a100a10a h0a100a197h0a100a1a100a10a h0a100a1"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x.CP", (int) (byte) 100, (int) (short) 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        float[] floatArray6 = new float[] { ' ', 'a', 0.0f, 100.0f, (byte) 1, (short) 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#');
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "32.0#97.0#0.0#100.0#1.0#10.0" + "'", str9.equals("32.0#97.0#0.0#100.0#1.0#10.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ', 1, (int) (short) -1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4', (int) 'a', (int) (byte) -1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4');
        try {
            double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "sun.lwawt.macosx.CPrinterJob52a1", 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "7");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str2.equals("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "x.CPrinterJ", charSequence1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("10.0a1.0a100.0a0.0a97.0a32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0A1.0A100.0A0.0A97.0A32.0" + "'", str1.equals("10.0A1.0A100.0A0.0A97.0A32.0"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D", "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Platform API Specification", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Java Platform API Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "7");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java HotSpot(TM) 64-Bit Server VM", (int) (short) 100, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/" + "'", str3.equals("/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophi" + "'", str1.equals("/Users/sophi"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        int[] intArray6 = new int[] { '4', (short) 10, ' ', 0, (byte) 100, (byte) 1 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a');
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray6);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray6, 'a', (int) (byte) 0, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "52a10a32a0a100a1" + "'", str8.equals("52a10a32a0a100a1"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "1.040.0                                                                                            1.7.0_80", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str3.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                                                                                    ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                   " + "'", str2.equals("                                                                                                   "));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("UTF-8");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("CPrinterJo");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CPRINTERJO" + "'", str1.equals("CPRINTERJO"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "32.0#97.0#0.0#100.0#1.0#10.0", (java.lang.CharSequence) "/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "mAC os x", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/", "                                                                                            -1 32");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "xed mode", (int) (short) 7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("                                                                                                   ", "52A10A32A0A100A1", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                   " + "'", str3.equals("                                                                                                   "));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "5241043240410041", (java.lang.CharSequence) "############################################################xed mode");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (int) (byte) 100, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "10.0A1.0A100.0A0.0A97.0A32.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("         #", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         #" + "'", str2.equals("         #"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", 0, "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "52a10a32a0a100a1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                                                                                            -1 32", ":", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                            -1 32" + "'", str3.equals("                                                                                            -1 32"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle.");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip(":##################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":##################################" + "'", str1.equals(":##################################"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("97 -1 -1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie", "mixed mod", 1);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "1.040.040.0", 0);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, '4', (int) 'a', (int) (byte) 0);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "en", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "h0a100a1a100a10a", "1a100");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("\n", "                                                                                                    ");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.040.0                                                                                            /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80", (java.lang.CharSequence) "100a0a0", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h" + "'", str1.equals("h"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(52, 0, 68);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 68 + "'", int3 == 68);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("hi!", "      http://java.oracle.com/     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                hi!                ", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                " + "'", str2.equals("                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                "));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        int[] intArray1 = new int[] { 25 };
        int[] intArray3 = new int[] { 25 };
        int[] intArray5 = new int[] { 25 };
        int[][] intArray6 = new int[][] { intArray1, intArray3, intArray5 };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray6);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 7L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.0f + "'", float2 == 7.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double[] doubleArray3 = new double[] { (byte) 1, 0L, 0.0d };
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray3, '4');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray3, ' ', 49, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 49");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.040.040.0" + "'", str6.equals("1.040.040.0"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils1 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils2 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils3 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils4 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray5 = new org.apache.commons.lang3.SystemUtils[] { systemUtils0, systemUtils1, systemUtils2, systemUtils3, systemUtils4 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) systemUtilsArray5, "############################################################xed mode");
        org.junit.Assert.assertNotNull(systemUtilsArray5);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 7, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "1.5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "4x.CP44", (java.lang.CharSequence) "Mac OS X444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("7", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "7" + "'", str2.equals("7"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("x86_64", "", "                                        52a10a32a0a100a1                                         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", "4444444444444444444444444444444444444444444444444444");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "0 100 1 100 10 0");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("      http://java.oracle.com/     ", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "      http://java.oracle.com/     " + "'", str7.equals("      http://java.oracle.com/     "));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "\n", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "100#0#0", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase(":", "14100");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1.0#1.0#100.0", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D", "a", (int) (byte) 0);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 0, (int) (byte) 0);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7 1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7 1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7" + "'", str1.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7 1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("52a10a32a0a100a1", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "CPRINTERJO", (java.lang.CharSequence) "d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("0a100a1a100a10a0", "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0a100a1a100a10a0" + "'", str2.equals("0a100a1a100a10a0"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray2);
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a');
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "100a0a0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 100a0a0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 1 + "'", byte4 == (byte) 1);
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 100 + "'", byte5 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1a100" + "'", str7.equals("1a100"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob52a1", 7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Mac OS X444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "          ", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("          ", (int) '4', "5241043240410041");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "524104324041004152410432404100415241043240          " + "'", str3.equals("524104324041004152410432404100415241043240          "));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "x.CPrinterJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        float[] floatArray3 = new float[] { (-1), 1, 100.0f };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 100.0f + "'", float4 == 100.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + (-1.0f) + "'", float5 == (-1.0f));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 28, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sophie", (int) (short) 1, "5241043240410041");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 14, (float) 0, (float) 32L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 28, (long) 68, (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28L + "'", long3 == 28L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("h0a100a1a100a10a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h0a100a1a100a10a" + "'", str1.equals("h0a100a1a100a10a"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "        ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase(":", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("4x.CP44", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        byte[] byteArray0 = new byte[] {};
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', (int) (short) 100, (int) ' ');
        try {
            byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(byteArray0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        short[] shortArray6 = new short[] { (short) 0, (byte) 100, (byte) 1, (short) 100, (short) 10, (short) 0 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        java.lang.Class<?> wildcardClass9 = shortArray6.getClass();
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray6);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray6);
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a100a1a100a10a0" + "'", str8.equals("0a100a1a100a10a0"));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) 0 + "'", short11 == (short) 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("h0a100a1a100a10a0", "hi", (int) (short) 100);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(16.0f, (float) (short) 0, (float) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "-1.0#1.0#100.0", (java.lang.CharSequence) "      http://java.oracle.com/      ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray6 = new char[] { '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence3, charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray6);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray6, ' ');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                   ", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#" + "'", str12.equals("#"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("", "1.040.0                                                                                            /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80" + "'", str1.equals("d mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob.0_80"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("boJretnirPC.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "boJr/boJre", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(7, 68, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Orac...", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("boJretnirPC.xsocam.twawl.nus", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (short) 1);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "boJretnirPC.xsocam.twawl.nus" + "'", str5.equals("boJretnirPC.xsocam.twawl.nus"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("mixed mode", 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 28, (long) 28, 100L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 28L + "'", long3 == 28L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0 100 1 100 10 0", "Mac OS X");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, 0.0d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "", (java.lang.CharSequence) "                                                                                            1.7.0_80", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("mixed mod");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0a100a1a100a10a0", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("h0a100a1a100a10a0", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h0a100a1a100a10a0" + "'", str2.equals("h0a100a1a100a10a0"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("5241043240410041", (int) ' ', "a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaa5241043240410041" + "'", str3.equals("aaaaaaaaaaaaaaaa5241043240410041"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U" + "'", str3.equals("boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("                                                                                            1.7.0_80", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle.", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                            1.7.0_80" + "'", str4.equals("                                                                                            1.7.0_80"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.4", ":##################################", "hiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.4" + "'", str4.equals("1.4"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "52A10A32A0A100A1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str2.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("4444444444444444444444444444444444444444444444444444", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "      http://java.oracle.com/      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) ":##################################", (java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + ":##################################" + "'", charSequence2.equals(":##################################"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "51.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 7, 10.0f, (float) 7);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("-1 32");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1 32" + "'", str1.equals("-1 32"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        try {
            double double3 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("h", "boJretnirPC.xsocam.twawl.nus");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h" + "'", str2.equals("h"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7 1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7 1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7" + "'", str1.equals("1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7 1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("0 100 1 100 10 0", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                hi!                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                hi!                \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "US");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("US", "10.0a1.0a100.0a0.0a97.0a32.0");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/USERS/SOPHIE", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) " ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("mAC os x", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mAC os x" + "'", str2.equals("mAC os x"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("x.CPrinterJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x.CPrinterJ" + "'", str1.equals("x.CPrinterJ"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "10.0a1.0a100.0a0.0a97.0a32.0");
        java.lang.String[] strArray5 = null;
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0a100a1a100a10a0");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, ' ', 68, (int) (short) 1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach("                                                                                            1.7.0_80", strArray5, strArray7);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("CPrinterJo", strArray3, strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "                                                                                            1.7.0_80" + "'", str14.equals("                                                                                            1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "CPrinterJo" + "'", str15.equals("CPrinterJo"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D", 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                   ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                   \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1#100", (java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse(":");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ":" + "'", str1.equals(":"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "http://java.oracle.com/" + "'", charSequence2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob", "", "boJr/boJre");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       " + "'", str2.equals("       "));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("       ", (float) 28L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 28.0f + "'", float2 == 28.0f);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("-1.0#1.0#100.0", "Oracle Corporation", "51.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1.0#1.0#100.0" + "'", str3.equals("-1.0#1.0#100.0"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "97#-1#-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("24.80-b11", (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.6", "10.14.3");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/Users/sophie", 28, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 16);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("10.0a1.0a100.0a0.0a97.0a32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0a1.0a100.0a0.0a97.0a32." + "'", str1.equals("10.0a1.0a100.0a0.0a97.0a32."));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "aaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "en", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str1.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("10.0a1.0a100.0a0.0a97.0a32.0", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.0a1.0a100.0a0.0a97.0a32.0" + "'", str2.equals("10.0a1.0a100.0a0.0a97.0a32.0"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.040.0                                                                                            1.7.0_80", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.00.0                                                                                            1.7.0_80" + "'", str2.equals("1.00.0                                                                                            1.7.0_80"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "h0a100a1a100a10a h0a100a197h0a100a1a100a10a h0a100a1", (java.lang.CharSequence) "h0a100a1a100a10a h0a100a197h0a100a1a100a10a h0a100a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 0, "10.0A1.0A100.0A0.0A97.0A32.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("hiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "en", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        short[] shortArray3 = new short[] { (byte) 100, (short) 0, (short) 0 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) (short) 1, (int) (byte) 1);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 100 + "'", short10 == (short) 100);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", (java.lang.CharSequence) "boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.CPrinterJob52a1", (int) '#', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "asun.lwawt.macosx.CPrinterJob52a1aa" + "'", str3.equals("asun.lwawt.macosx.CPrinterJob52a1aa"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("http://java.oracle.com/", (float) 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "24.80-B11", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) " ", 49, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.74444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str1.equals("1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "mAC os x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10.0a1.0a100.0a0.0a97.0a32.0", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("5241043240410041");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5241043240410041" + "'", str1.equals("5241043240410041"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1a100\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        short[] shortArray3 = new short[] { (byte) 100, (short) 0, (short) 0 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 0, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 0 + "'", short5 == (short) 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "100#0#0" + "'", str7.equals("100#0#0"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "10.0a1.0a100.0a0.0a97.0a32.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (int) (short) 100, "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedJava HotSpot(TM) 64-" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedJava HotSpot(TM) 64-"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "a", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("524104324041004152410432404100415241043240          ", 0, 12);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "524104324..." + "'", str3.equals("524104324..."));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 28.0f, (double) 100L, 49.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.0d + "'", double3 == 28.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "mixed mode", (int) (byte) 1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "en", 97, 8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "1.00.0                                                                                            1.7.0_80", (java.lang.CharSequence) "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "1.00.0                                                                                            1.7.0_80" + "'", charSequence2.equals("1.00.0                                                                                            1.7.0_80"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 13 + "'", int1 == 13);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("hi", "sophie          ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("aaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: aaaaaaaaaaaaaaaa is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "CPrinterJo");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "7" + "'", str1.equals("7"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/", "4444444444444444444444444444444444444444444444444444");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "0 100 1 100 10 0");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a', 8, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("10.0A1.0A100.0A0.0A97.0A32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.0a1.0a100.0a0.0a97.0a32.0" + "'", str1.equals("10.0a1.0a100.0a0.0a97.0a32.0"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("1#100", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) 'a', 97, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (byte) 100, 35.0d, (double) 28L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.0d + "'", double3 == 28.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("32.0#97.0#0.0#100.0#1.0#10.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32.0#97.0#0.0#100.0#1.0#10.0" + "'", str1.equals("32.0#97.0#0.0#100.0#1.0#10.0"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "x.CPrinterJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "xed mod", (java.lang.CharSequence) "52a10a32a0a100a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.0A1.0A100.0A0.0A97.0A32.0", "524104324...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", (int) (short) 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(68, 52, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 68 + "'", int3 == 68);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sophie          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie          " + "'", str1.equals("sophie          "));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4', (int) (short) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("0 100 1 100 10 0", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0 100 1 100 10 0" + "'", str2.equals("0 100 1 100 10 0"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("mixed mod");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 97, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("444444444444444444444444444444/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("10.0A1.0A100.0A0.0A97.0A32.0", "Orac...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0a100a1a100a10a0", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                   ", (java.lang.CharSequence) "-1.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixed mode");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("100a0a0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100a0a0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("52a10a32a0a100a1", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 165 + "'", int1 == 165);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "                                                                                            1.7.0_80", (java.lang.CharSequence) "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        byte[] byteArray2 = new byte[] { (byte) 1, (byte) 100 };
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.max(byteArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray2, 'a', 7, 7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray2, '4');
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray2, "51.0");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 51.0");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 100 + "'", byte4 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "14100" + "'", str10.equals("14100"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("97");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97" + "'", str1.equals("97"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase(":##################################", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":##################################" + "'", str2.equals(":##################################"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("52A10A32A0A100A1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52a10a32a0a100a1" + "'", str1.equals("52a10a32a0a100a1"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.0a1.0a100.0a0.0a97.0a32.0", "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7 1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("97", strArray3, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 14");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.4", (-1), "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "97");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("5241043240410041", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/USERS/SOPHIE", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Use...", "x.CP");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("35.0", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35.0" + "'", str2.equals("35.0"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("      http://java.oracle.com/     ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) (byte) 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       " + "'", str2.equals("       "));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Use...", "x8s_s4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "                                                                                                   ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                        52a10a32a0a100a1                                         ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("      http://java.oracle.com/      ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "524104324041004152410432404100415241043240          ", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("          ", "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("10.0A1.0A100.0A0.0A97.0A32.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("32.0#97.0#0.0#100.0#1.0#10.0", 'a', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "32.0#97.0#0.0#100.0#1.0#10.0" + "'", str3.equals("32.0#97.0#0.0#100.0#1.0#10.0"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Oracle Corporation", "97 -1 -1", (int) (byte) -1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mixed mode" + "'", str1.equals("Mixed mode"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 8, (-1L), (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8L + "'", long3 == 8L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("                                                                                                    ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ', 1, (int) (short) -1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4', (int) 'a', (int) (byte) -1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '#', 12, (int) (short) 1);
        try {
            double double15 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run", (java.lang.CharSequence) "-1.0#1.0#100.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("boJretnirPC.xsocam.twawl.nus");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("4444444444444444444444444444444444444444444444444444", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse" + "'", str2.equals("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.5", (java.lang.CharSequence) ":##################################", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aa32.0a97.0a0.0a100.0a1.0a10.0aa", (int) (byte) 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 7, (byte) 7);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 7 + "'", byte3 == (byte) 7);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "a", 28, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "      " + "'", str1.equals("      "));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "asun.lwawt.macosx.CPrinterJob52a1aa", 97);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("xed mode", 25, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                 xed mode" + "'", str3.equals("                 xed mode"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("h0a100a1a100a10a h0a100a197h0a100a1a100a10a h0a100a1", "10.0a1.0a100.0a0.0a97.0a32.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h0a100a1a100a10a h0a100a197h0a100a1a100a10a h" + "'", str2.equals("h0a100a1a100a10a h0a100a197h0a100a1a100a10a h"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("a");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray7 = new char[] { '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence4, charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "32.0a97.0a0.0a100.0a1.0a10.0", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob52a1", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "xed mode", charArray7);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sophie", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        float[] floatArray6 = new float[] { ' ', 'a', 0.0f, 100.0f, (byte) 1, (short) 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32.0#97.0#0.0#100.0#1.0#10.0" + "'", str10.equals("32.0#97.0#0.0#100.0#1.0#10.0"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("boJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../UenboJretnirPC.xsocam.twawl.nus/Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../Use.../U", (int) '#');
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (short) 7, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str3.equals("1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("44a444#", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "100a0a0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!               " + "'", str1.equals("                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!               "));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedJava HotSpot(TM) 64-", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/" + "'", str3.equals("/Users/sophie/Documents/defects4jJava HotSpot(TM) 64-Bit Server VM/Users/sophie/Documents/defects4j/"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("Java(TM) SE Runtime Environment", "x.CP", "1.4", 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str4.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "#", "                                   ", 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10.0a1.0a100.0a0.0a97.0a32.0", "aa32.0a97.0a0.0a100.0a1.0a10.0aa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) -1, 28.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.0d + "'", double3 == 28.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "x8s_s4", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "mixed mod", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Orac...", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Mixed mode", 165, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mixed mode/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51" + "'", str3.equals("Mixed mode/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("14100");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 14100 + "'", number1.equals(14100));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("mixed mode", 0, "5241043240410041");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', (int) (short) -1, (int) (short) 7);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        double[] doubleArray0 = new double[] {};
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray0, '4');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a');
        try {
            double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("35.0", "7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "35.0" + "'", str2.equals("35.0"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("10.0a1.0a100.0a0.0a97.0a32.0", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.0a97.0a0.0a100.0a1.0a10.0" + "'", str2.equals("32.0a97.0a0.0a100.0a1.0a10.0"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("hiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "52A10A32A0A100A1", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', 6, 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", 68L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 68L + "'", long2 == 68L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("                                        52a10a32a0a100a1                                         ", 14);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                        52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                         " + "'", str2.equals("                                        52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                                                                 52a10a32a0a100a1                                         "));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", 14100, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", (java.lang.CharSequence) "Mixed mode/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/" + "'", str1.equals("/"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a h0a100a1a100a10a");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(shortArray1, '4');
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "100" + "'", str5.equals("100"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 32, (long) ' ', (-1L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0a100a1a100a10a0");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("24.80-B11", strArray2, strArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "24.80-B11" + "'", str7.equals("24.80-B11"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a100a1a100a10a0" + "'", str8.equals("0a100a1a100a10a0"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0a100a1a100a10a0" + "'", str9.equals("0a100a1a100a10a0"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 0.0f, 28.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 28.0f + "'", float3 == 28.0f);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("http://java.oracle.com/", "h0a100a1a100a10a0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, '#', 97, 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "                                                                                            1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        short[] shortArray6 = new short[] { (short) 0, (byte) 100, (byte) 1, (short) 100, (short) 10, (short) 0 };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray6, 'a');
        java.lang.Class<?> wildcardClass9 = shortArray6.getClass();
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray6, ' ', 0, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a100a1a100a10a0" + "'", str8.equals("0a100a1a100a10a0"));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 28, (long) (short) 1, 68L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "1.7.0_80-b15");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "51.0");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                 xed mode", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", (int) ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" + "'", str3.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("sun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.LWCToolkit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1#100", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 7, (byte) 7, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) '#', (double) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444411", 0, 28);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(97, 4, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "US");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "mAC os x", (java.lang.CharSequence) "32.0497.040.04100.041.0410.0", 165);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################" + "'", str1.equals("################"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 100, 0.0f, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaa" + "'", str2.equals("aaaaaaa"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1a100");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a', (-1), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob", "                                        52a10a32a0a100a1                                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (short) 1, (long) ' ', 16L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(12, 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle.", (int) (short) -1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle." + "'", str3.equals("51.0      http://java.oracle.com/           http://java.oracle.com/           http://java.oracle."));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("xed mode", "97");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97" + "'", str2.equals("97"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("aaaaaaaaaaaaaaaa", "tmp/run", "                                                                                                   ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("32.0#97.0#0.0#100.0#1.0#10.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("boJretnirPC.xsocam.twawl.nus", 8, (int) (short) 7);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Mixed mode/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/D/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("aaaaaaaaaaaaaaaa5241043240410041", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0a100a1a100a10a0");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "asun.lwawt.macosx.CPrinterJob52a1aa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "tmp/run", (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("x.CP", "aaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x.CP" + "'", str2.equals("x.CP"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Mac OS X444444444444444444444444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Maaca aOSa aXa444444444444444444444444" + "'", str3.equals("Maaca aOSa aXa444444444444444444444444"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray7 = new char[] { '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Oracle Corporation", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence4, charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "7", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "US", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Mac OS X", charArray7);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "#" + "'", str15.equals("#"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "97.041.0497.04100.0410.0", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsedJava HotSpot(TM) 64-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("en", (long) (short) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run", (int) (byte) 0, "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/ruh0a100a1a100a10a/Users/sophie/Documents/defects4j/tmp/run"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.00.0                                                                                            1.7.0_80", (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        java.lang.String[] strArray7 = new java.lang.String[] { "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "sun.lwawt.macosx.CPrinterJob", "mixed mode", "mixed mode", "0a100a1a100a10a0", "sun.lwawt.macosx.CPrinterJob" };
        java.lang.String[] strArray14 = new java.lang.String[] { "/Users/sophie", "52a10a32a0a100a1", "", "0a100a1a100a10a0", "Oracle Corporation", "/Users/sophie" };
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray7, strArray14);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray14, "/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "/Users/sophie/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.52a10a32a0a100a1/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0a100a1a100a10a0/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Oracle Corporation/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie" + "'", str17.equals("/Users/sophie/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.52a10a32a0a100a1/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0a100a1a100a10a0/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Oracle Corporation/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                 xed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "tmp/run", charSequence1, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("10.0a1.0a100.0a0.0a97.0a32.", (long) (byte) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse" + "'", str1.equals("ava/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("h0a100a1a100a10a0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"h0a100a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("-1 32", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n", "sun.lwawt.macosx.CPrinterJob52a1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1 32" + "'", str3.equals("-1 32"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!               ", (java.lang.CharSequence) "Java(TM) SE Runtime Environment", 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.040.040.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.040.040.0", (int) (short) 7, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.52a10a32a0a100a1/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0a100a1a100a10a0/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Oracle Corporation/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.52A10A32A0A100A1/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.0A100A1A100A10A0/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.oRACLE cORPORATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE" + "'", str1.equals("/uSERS/SOPHIE/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.52A10A32A0A100A1/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.0A100A1A100A10A0/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.oRACLE cORPORATION/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:./uSERS/SOPHIE"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.2", (java.lang.CharSequence) "44a444#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "524104324041004152410432404100415241043240          ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mixed mode", "x.CP");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("\n", "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7 1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7", "524104324041004152410432404100415241043240          ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("44a444#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44a444#" + "'", str1.equals("44a444#"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "97.041.0497.04100.0410.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                                                                            -1 32", "mAC os x", 12, 49);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "            mAC os x                                           -1 32" + "'", str4.equals("            mAC os x                                           -1 32"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (byte) -1, "7");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", "524104324...", 13);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str3.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.524104324.../uSERS/SOPHIE/lIBRARY/jAVA/eXTSUN.LWAWT.MACOSX.cpRINTERjOBSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 32L, (float) (byte) 1, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "        ", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1#100", (float) 12);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 12.0f + "'", float2 == 12.0f);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("32.0a97.0a0.0a100.0a1.0a10.0", (int) (short) 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.0..." + "'", str2.equals("32.0..."));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "10.0a1.0a100.0a0.0a97.0a32.0", (java.lang.CharSequence) "http...");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "10.0a1.0a100.0a0.0a97.0a32.0" + "'", charSequence2.equals("10.0a1.0a100.0a0.0a97.0a32.0"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        boolean boolean6 = javaVersion1.atLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4" + "'", str2.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar sun.lwawt.macosx.CPrinterJob mixed mode mixed mode 0a100a1a100a10a0 sun.lwawt.macosx.CPrinterJob", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        char[] charArray5 = new char[] { '4', 'a', '4', '#' };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(charArray5, '4');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                                hi!                ", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "44a444#" + "'", str7.equals("44a444#"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(4, (int) ' ', 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "32.0a97.0a0.0a100.0a1.0a10.0", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "32.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.0" + "'", str3.equals("32.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.032.0a97.0a0.0a100.0a1.0a10.0"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80-b15", "1.7.0_80-b15");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "51.0");
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_51503_1560278642/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.ja", (java.lang.CharSequence[]) strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_51503_1560278642/TARGET/CLASSES:/uSERS/SOPHIE/dOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorse", (int) (byte) 7);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Users/sophie/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.52a10a32a0a100a1/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0a100a1a100a10a0/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Oracle Corporation/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.52a10a32a0a100a1/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0a100a1a100a10a0/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Oracle Corporation/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie" + "'", str1.equals("/Users/sophie/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.52a10a32a0a100a1/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.0a100a1a100a10a0/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Oracle Corporation/Users/sophie/Library/Java/Extsun.lwawt.macosx.CPrinterJobsions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("-1.0 1.0 100.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "US", (java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("aa32.0a97.0a0.0a100.0a1.0a10.0aa", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa32.0a97.0a0.0a100.0a1.0a10.0aa" + "'", str2.equals("aa32.0a97.0a0.0a100.0a1.0a10.0aa"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "h0a100a1a100a10a h0a100a197h0a100a1a100a10a h0a100a1", (java.lang.CharSequence) "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("mixed mod", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "14100");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation", "\n");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', (-1), (int) (byte) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.7444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444411", "Mac OS X", "-1.0 1.0 100.0");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "hi", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("a");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                hi!                ", "/Users/sophie");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("            mAC os x                                           -1 32", strArray2, strArray6);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "            mAC os x                                           -1 32" + "'", str7.equals("            mAC os x                                           -1 32"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "1.74444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNull(str2);
    }
}

