import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 6, (byte) 6);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########PvavaJ         #########:PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("noitar", "Java HotSpot(TM) 64-Bit Server VM", 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "noitar" + "'", str3.equals("noitar"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (-1), (float) 15L, (float) 15L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("http://java.oracle.com/", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT", "/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "24.80-b112", (java.lang.CharSequence) "                                             sophie                                              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("HI");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI" + "'", str1.equals("HI"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("oitacificepS enihcaM lautriV avaJ", "        M71_O_X", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOBLASS JAVA.IO.fILECLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS JAVA.IO.fILECLASS [[", (java.lang.CharSequence) "USERS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("24.80-b11", (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        short[] shortArray2 = new short[] { (short) 100, (byte) 100 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EX", "oracle corporation", 0, 23);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "oracle corporationALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EX" + "'", str4.equals("oracle corporationALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EX"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("        M71_O_X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "        M71_O_X" + "'", str1.equals("        M71_O_X"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("LIBRARY/JAVA/JAVAVIRTUA");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                                                    ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: empty String");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        long[] longArray5 = new long[] { ' ', (short) 10, '#', 100, 10 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long11 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 100L + "'", long11 == 100L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/USERS/SOPHIE", (java.lang.CharSequence) "                1.0 0                1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("US", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "###1.7#######1.7#######1hi!###1.7#######1.7#######1.", (java.lang.CharSequence) "Mac");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("aaa", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("[[j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[[j" + "'", str1.equals("[[j"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "aaahi!aaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("SUN.LWAWT.MACOSX.cpRINTERjOBLASS JAVA.IO.fILECLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS JAVA.IO.fILECLASS [[", (int) (short) 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOBLASS JAVA.IO.fILECLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS JAVA.IO.fILECLASS [[" + "'", str3.equals("SUN.LWAWT.MACOSX.cpRINTERjOBLASS JAVA.IO.fILECLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS JAVA.IO.fILECLASS [["));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EX", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        int[] intArray4 = new int[] { 66, (short) 1, (short) 10, 0 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        java.lang.Class<?> wildcardClass9 = intArray4.getClass();
        int int10 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 66 + "'", int6 == 66);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("h ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "h" + "'", str1.equals("h"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj[[aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636                                                                      ", 51);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636                                                                      " + "'", str2.equals("                                                                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636                                                                      "));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#Mac OS#", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, (float) 6, (float) 0L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 6.0f + "'", float3 == 6.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("class [Ljava.lang.String;", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "va/javavirtualmachines/jdk#.0_");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("   ss      i  Fi     ss [L       ng S  ing;   ss [L       ng S  ing;   ss      i  Fi     ss [[J", 121, "4444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   ss      i  Fi     ss [L       ng S  ing;   ss [L       ng S  ing;   ss      i  Fi     ss [[J44444444444444444444444444" + "'", str3.equals("   ss      i  Fi     ss [L       ng S  ing;   ss [L       ng S  ing;   ss      i  Fi     ss [[J44444444444444444444444444"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "NOITAROPRO", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        short[] shortArray2 = new short[] { (short) 100, (byte) 100 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short8 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 100 + "'", short8 == (short) 100);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 100 + "'", short9 == (short) 100);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("http://java.oracle.com/1.7.0_801.7.0_801.7.0_801.7.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.7.108_0.7.108_0.7.108_0.7.1/moc.elcaro.avaj//:ptth" + "'", str1.equals("0.7.108_0.7.108_0.7.108_0.7.1/moc.elcaro.avaj//:ptth"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        boolean boolean10 = javaVersion6.atLeast(javaVersion7);
        boolean boolean11 = javaVersion5.atLeast(javaVersion7);
        java.lang.String str12 = javaVersion7.toString();
        boolean boolean13 = javaVersion0.atLeast(javaVersion7);
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str15 = javaVersion14.toString();
        java.lang.String str16 = javaVersion14.toString();
        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
        boolean boolean18 = javaVersion0.atLeast(javaVersion14);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.9" + "'", str12.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.2" + "'", str15.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.2" + "'", str16.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("VA/JAVAVIRTUALMACHINES/JDK1.7.0_", "################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################" + "'", str2.equals("################################"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############" + "'", str1.equals("###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("ONLIBRARY/JA", "/Users/sophie/Documents/defects4");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ONLIBRARY/JA" + "'", str2.equals("ONLIBRARY/JA"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "PvavaJ         ##########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "SUN.LWAWT.MACOSX.CPRINTERJOBLASS JAVA.IO.FILECLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS JAVA.IO.FILECLASS [[");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.ja" + "'", str1.equals("/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.ja"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "oRACLEa...", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("va/javavirtualmachines/jdk1.7.0_");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "va/javavirtualmachines/jdk1.7.0_" + "'", str1.equals("va/javavirtualmachines/jdk1.7.0_"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.0 0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 0" + "'", str1.equals("1.0 0"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("####S#", "SUN.LWAWT.MACOSX.CPRINTERJOBLASS JAVA.IO.FILECLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS JAVA.IO.FILECLASS [[", 10);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("                                                                                                    ", (short) 3);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 3 + "'", short2 == (short) 3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("MAC OS ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"MAC OS\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a" + "'", str1.equals("a"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("[[ java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass sun.lwawt.macosx.cprinterjoblass", "                                   ");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "platform API Specification", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/JAVAVP4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.4                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("oracle Corporation/Users/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '4');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Javav", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Javav" + "'", str2.equals("Javav"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10.0f, (double) 7, (double) 15L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.0d + "'", double3 == 7.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) ' ', 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Documents/defects", "va/javavirtualmachines/jdk                               sophie.0_");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar", 0, 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("M#c OS ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS #M" + "'", str2.equals("c OS #M"));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("##########", "...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOBnoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaropro", (java.lang.CharSequence) "aJava HotSpot(TM) 6 -Bit Server VMa         JavavP         JavavP           JavavP         JavavP           JavavP         JavavP           JavavP         JavavP           JavavP         JavavP");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.7.0_80" + "'", str1.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1.7.0_80"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/moc.elcaro.avaj//:ptth", "24.80-b112");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("...eneration/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...eneration/randoop-current.jar" + "'", str1.equals("...eneration/randoop-current.jar"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "Mac OS X");
        java.lang.String[] strArray12 = null;
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaahi!aaaa", "AAAHI!AAAA");
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("AAAHI!AAAA", strArray12, strArray15);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence[]) strArray15);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "###1.7###", (java.lang.CharSequence[]) strArray15);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("PVAVAJESU/", strArray4, strArray15);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi#!" + "'", str6.equals("hi#!"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hiMac OS X!" + "'", str8.equals("hiMac OS X!"));
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "AAAHI!AAAA" + "'", str16.equals("AAAHI!AAAA"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PVAVAJESU/" + "'", str19.equals("PVAVAJESU/"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi!", 51);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("                                          ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("http://java.oracle.com/", 52);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/http://java.oracle.com/"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE/DOCUMLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRETS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96328_1560211636/TARGET/CLASSES:/USERS/SOPHIE/DOCUMLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRETS/DEFECTS4J/FRAMEWORK/LIB/TEST_GLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREERATION/GLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREERATION/RANDOOP-CURRLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRET.JAR", "1.6");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("noitaroproC elcaro", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproC elcaro" + "'", str2.equals("noitaroproC elcaro"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("LIBRARY/JoRACLE cORPORATIONLIBRARY/JA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LIBRARY/JORACLE CORPORATIONLIBRARY/JA" + "'", str1.equals("LIBRARY/JORACLE CORPORATIONLIBRARY/JA"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(97, 3, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/usr/lib/java", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                                                                           oRACLE cORPORATION                                                                                           ", "                                                                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                         oRACLE cORPORATION                                                                                           " + "'", str2.equals("                         oRACLE cORPORATION                                                                                           "));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaahi!aaaa                                                                                          ", (java.lang.CharSequence) "#Mac OS#", 200);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 98 + "'", int3 == 98);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 32, (float) (short) 3, (float) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "USERS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "            ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[J", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 59);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                           " + "'", str2.equals("                                                           "));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("va/javavirtualmachines/jdk#.0_", "x86_6class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[", "                         oRACLE cORPORATION                                                                                           ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "  /       Nu  m  h A  / dk# 0 " + "'", str3.equals("  /       Nu  m  h A  / dk# 0 "));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Virtual Machine Specification                                ", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(200L, (long) 98, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 200L + "'", long3 == 200L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "JavavPJavavP", (java.lang.CharSequence) "/USERS/SOPNEE/D");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("  /       Nu  m  h A  / dk# 0 ", "aaaaaaaaaaaaaaaaaaaaaaa...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  /       Nu  m  h A  / dk# 0 " + "'", str2.equals("  /       Nu  m  h A  / dk# 0 "));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 30, 0.0d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java Virtual Machine Specification");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "aHaaSaaa(TM)a6a-BaaaSaavaaa");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JaHaaSaaa(TM)a6a-BaaaSaavaaaavaaHaaSaaa(TM)a6a-BaaaSaavaaa aHaaSaaa(TM)a6a-BaaaSaavaaaVaHaaSaaa(TM)a6a-BaaaSaavaaairtualaHaaSaaa(TM)a6a-BaaaSaavaaa aHaaSaaa(TM)a6a-BaaaSaavaaaMaHaaSaaa(TM)a6a-BaaaSaavaaaachineaHaaSaaa(TM)a6a-BaaaSaavaaa aHaaSaaa(TM)a6a-BaaaSaavaaaSaHaaSaaa(TM)a6a-BaaaSaavaaapecification" + "'", str6.equals("JaHaaSaaa(TM)a6a-BaaaSaavaaaavaaHaaSaaa(TM)a6a-BaaaSaavaaa aHaaSaaa(TM)a6a-BaaaSaavaaaVaHaaSaaa(TM)a6a-BaaaSaavaaairtualaHaaSaaa(TM)a6a-BaaaSaavaaa aHaaSaaa(TM)a6a-BaaaSaavaaaMaHaaSaaa(TM)a6a-BaaaSaavaaaachineaHaaSaaa(TM)a6a-BaaaSaavaaa aHaaSaaa(TM)a6a-BaaaSaavaaaSaHaaSaaa(TM)a6a-BaaaSaavaaapecification"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        char[] charArray4 = new char[] { '#', '#' };
        boolean boolean5 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray4);
        java.lang.Class<?> wildcardClass6 = charArray4.getClass();
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/USERS/SOPNEE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", 59, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaropro" + "'", str3.equals("elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaropro"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaropro", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "elcro                 noitroproC elcroJAVA VIRTUAL MACHINE SPECIFICATION            noitropro" + "'", str2.equals("elcro                 noitroproC elcroJAVA VIRTUAL MACHINE SPECIFICATION            noitropro"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "             ", (java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("ne");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ne" + "'", str1.equals("ne"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" ", "SPlatform API SpecificationWT.MACOSX.cpRINTERjOBSPlatform API Specificationn4_v31cq2n2x1n4fc0000gn/T", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween(" Platform API Specificatio", "noitar", "LIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JA");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean5 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        boolean boolean7 = javaVersion3.atLeast(javaVersion4);
        boolean boolean8 = javaVersion2.atLeast(javaVersion4);
        boolean boolean9 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean13 = javaVersion10.atLeast(javaVersion12);
        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        java.lang.String str16 = javaVersion12.toString();
        boolean boolean17 = javaVersion2.atLeast(javaVersion12);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.6" + "'", str16.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("SUN.LWAWT.MACOSX.cpRINTERjOBLASS JAVA.IO.fILECLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS JAVA.IO.fILECLASS [[", "1.3", 66);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "0.25", (java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "      ", charSequence1, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("x86_6");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x86_6\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("ORACLE CORPORATION/USERS", "Mac", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", "###1.7####");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro" + "'", str2.equals("            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("SUN.LWAWT.MACOSX.cpRINTERjOBnoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaropro");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJOBNOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPRO" + "'", str1.equals("SUN.LWAWT.MACOSX.CPRINTERJOBNOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPRO"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray9 = new char[] { '4', '4', '#', '#', ' ' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "AAAHI!AAAA", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence2, charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAV####S#", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "SPlatform API SpecificationWT.MACOSX.cpRINTERjOBoracle Corporation/Usersoracle Corporation/Usersorac", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "SPlatform API SpecificationWT.MACOSX.cpRINTERjOBoracle Corporation/Usersoracle Corporation/UsersoracSPlatform API SpecificationWT.MACOSX.cpRINTERjOBoracle Corporation/Usersoracle Corporation/UsersoracSPlatform API SpecificationWT.MACOSX.cpRINTERjOBoracle Corporation/Usersoracle Corporation/Usersorac", (java.lang.CharSequence) "/LIBRARM/LIB/EX");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("M OS X                                                          Mac OS X", 30);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "M OS X                     ..." + "'", str2.equals("M OS X                     ..."));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("          24.8/-b11                     sophie", (double) 42.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 42.0d + "'", double2 == 42.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "MAC OS ##############", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("L", "elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaropro", "oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "L" + "'", str3.equals("L"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro", "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "[[ java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass sun.lwawt.macosx.cprinterjoblass");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("###################################################:", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################################:" + "'", str2.equals("###################################################:"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 59);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###########################################################" + "'", str2.equals("###########################################################"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("24.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 24.0f + "'", float1.equals(24.0f));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("UTF-8", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 1);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAV####S#", (java.lang.CharSequence[]) strArray5);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UTF-8" + "'", str7.equals("UTF-8"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "LIBRARY/JAVA/JAVAVIRTUA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("1.5                                                 ", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5                                                 " + "'", str2.equals("1.5                                                 "));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "oracle corporationALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EX", (java.lang.CharSequence) "Mac OS X10.14.10.14.10.14.10.14.10.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("E/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GE", "sun.lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("h ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#fication");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie" + "'", str1.equals("                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("MAC OS ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " SO CAM" + "'", str1.equals(" SO CAM"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("LIBRARY/JORACLE CORPORATIONLIBRARY/JA", "SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Javav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javav" + "'", str1.equals("javav"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("#############################################################################################lass [[#############################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("noitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro", (double) 17L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 17.0d + "'", double2 == 17.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "oRACLEa...", 31, 59);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong(":");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "j:tjtt3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 59, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray9 = new char[] { '#', 'a' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence4, charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mac OS X", charArray9);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "noitaroproC elcaro", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "TF-8", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("         JavavP         JavavP  ", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         JavavP         JavavP  " + "'", str2.equals("         JavavP         JavavP  "));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("################################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "SPlatform API SpecificationWT.MACOSX.cpRINTERjOBSPlatform API Specificationn4_v31cq2n2x1n4fc0000gn/T", (java.lang.CharSequence) "aJava HotSpot(TM) 6 -Bit Server VMa         JavavP         JavavP           JavavP         JavavP           JavavP         JavavP           JavavP         JavavP           JavavP         JavavP");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java(TM) SE Runtime Environment", (int) (short) 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        int[] intArray3 = new int[] { 0, ' ', 6 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("LIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JA", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " HotSpot(TM) 6 -Bit Server ", "javahotspot(tm)64-bitservervm");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip(":", "L");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("h ", (int) (short) 0, 98);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "h " + "'", str3.equals("h "));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/SUN", (java.lang.CharSequence) "4.80-b112");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Javav", (int) (short) 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("10.14.", "Mac OS X10.14.10.14.10.14.10.14.10.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14." + "'", str2.equals("10.14."));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("24.8/-B11");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean5 = javaVersion1.atLeast(javaVersion2);
        boolean boolean6 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str7 = javaVersion2.toString();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str11 = javaVersion10.toString();
        boolean boolean12 = javaVersion9.atLeast(javaVersion10);
        boolean boolean13 = javaVersion8.atLeast(javaVersion10);
        boolean boolean14 = javaVersion2.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion15 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion16 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean17 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion16);
        boolean boolean18 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion16);
        boolean boolean19 = javaVersion15.atLeast(javaVersion16);
        org.apache.commons.lang3.JavaVersion javaVersion20 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion21 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion22 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean23 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion22);
        boolean boolean24 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion22);
        boolean boolean25 = javaVersion21.atLeast(javaVersion22);
        boolean boolean26 = javaVersion20.atLeast(javaVersion22);
        java.lang.String str27 = javaVersion22.toString();
        org.apache.commons.lang3.JavaVersion javaVersion28 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion29 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean30 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion29);
        boolean boolean31 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion29);
        boolean boolean32 = javaVersion28.atLeast(javaVersion29);
        boolean boolean33 = javaVersion22.atLeast(javaVersion29);
        boolean boolean34 = javaVersion15.atLeast(javaVersion29);
        boolean boolean35 = javaVersion8.atLeast(javaVersion29);
        boolean boolean36 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        boolean boolean37 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.2" + "'", str11.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + javaVersion15 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion15.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion16 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion16.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + javaVersion20 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion20.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion21 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion21.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion22 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion22.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0.9" + "'", str27.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion28 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion28.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion29 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion29.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.6", '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.6" + "'", str3.equals("1.6"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/users/sophie/documlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrets/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/users/sophie/documlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrets/defects4j/framework/lib/test_glibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreeration/glibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreeration/randoop-currlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jret.jar");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("SPlatform API SpecificationWT.MACOSX.cpRINTERjOBoracle Corporation/Usersoracle Corporation/Usersorac");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SPlatform API SpecificationWT.MACOSX.cpRINTERjOBoracle Corporation/Usersoracle Corporation/Usersorac\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("###################################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL" + "'", str1.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/users/sopnee/d/users");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPNEE/D/USERS" + "'", str1.equals("/USERS/SOPNEE/D/USERS"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 34, (float) (short) 3, (float) 8L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 34.0f + "'", float3 == 34.0f);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("oracle Corporation                 ", (float) 34);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("0", "24.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                           oRACLE cORPORATION                                                                                           ", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        short[] shortArray4 = new short[] { (byte) 10, (byte) 10, (byte) 1, (short) 1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                               sophie", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("c OS XaM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"c OS XaM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "                                                           ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 59 + "'", int1 == 59);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ", (java.lang.CharSequence) "                                                           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 0L, 66L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 66L + "'", long3 == 66L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("aJava HotSpot(TM) 6 -Bit Server VMa         JavavP         JavavP           JavavP         JavavP           JavavP         JavavP           JavavP         JavavP           JavavP         JavavP", "                                             sophie                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aJava HotSpot(TM) 6 -Bit Server VMa         JavavP         JavavP           JavavP         JavavP           JavavP         JavavP           JavavP         JavavP           JavavP         JavavP" + "'", str2.equals("aJava HotSpot(TM) 6 -Bit Server VMa         JavavP         JavavP           JavavP         JavavP           JavavP         JavavP           JavavP         JavavP           JavavP         JavavP"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("0.7.108_0.7.108_0.7.108_0.7.1/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/USR/LIB/JAVA", charSequence1, 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636", "Java Virtual Machine Specification", 0, 15);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java Virtual Machine Specificationocuments/defects4j/tmp/run_randoop.pl_96328_1560211636" + "'", str4.equals("Java Virtual Machine Specificationocuments/defects4j/tmp/run_randoop.pl_96328_1560211636"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "               1.7.0_80      Mac OS X", (java.lang.CharSequence) "PlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("oracle Corporation/UsersJAVAVP");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Platform API Specification", 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51 + "'", int2 == 51);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "PLATFORM api sPECIFICATION", charSequence1, 98);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("hi#!", 17);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi#!" + "'", str2.equals("hi#!"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("mode mixed");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java Platfor", (java.lang.CharSequence) "PLATFORM api sPECIFICATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj[[aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "aaahi!aaaa                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 0, (int) (short) 0, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "JvHotPot(U)64-itPerverV");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 23 + "'", int1 == 23);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("TnemnorivnE emitnuR ES )MT(avaJ", 17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("        M71_O_X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "M71_O_X" + "'", str1.equals("M71_O_X"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Mac O", "4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac O" + "'", str2.equals("Mac O"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Ora1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa", "noitacificepS IPA mroftalP");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Ora1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa" + "'", str2.equals("Ora1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "aaa", (java.lang.CharSequence) "####################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("va/javavirtualmachines/jdk1.7.0_", "JavaPlatfor", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[", 5, 17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("               ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "LIBRARY/JAVA/JAVAVIRTUA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "sophie");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "VA/JAVAVIRTUALMACHINES/JDK1.7.0_", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE" + "'", str7.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 23, (long) (byte) 6, (long) 121);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 121L + "'", long3 == 121L);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("###########################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"##########################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("nOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "nOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRO" + "'", str1.equals("nOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRO"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aJava HotSpot(TM) 6 -Bit Server VMa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aJava HotSpot(TM) 6 -Bit Server VMa" + "'", str1.equals("aJava HotSpot(TM) 6 -Bit Server VMa"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        long[] longArray5 = new long[] { ' ', (short) 10, '#', 100, 10 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long12 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 100L + "'", long9 == 100L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 10L + "'", long11 == 10L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 100L + "'", long12 == 100L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "", "M OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("nOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRO", "/USERS/SOPNEE/D/USERS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "nOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRO" + "'", str2.equals("nOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRO"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 0, " SO CAM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        double[] doubleArray1 = new double[] { 0 };
        double double2 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        java.lang.Class<?> wildcardClass3 = doubleArray1.getClass();
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray1);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "J/v/ HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("#############################################################################################lass [[#############################################################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#############################################################################################lass [[#############################################################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "PLATFORM pi sPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/Users/sophie/Documents/defects4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Users/sophie/Documents/defects4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(4.0f, (float) 5, (float) 42);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 42.0f + "'", float3 == 42.0f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        int[] intArray1 = new int[] { 10 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("OCUMENTS/DEFECTS4J/FRAMEWORK/LIB/T", "noitaroproC elcaro", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Mac");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ma" + "'", str1.equals("Ma"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("caro", "PvavaJ         ##########");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', 300, 2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED/lIBRARY/jAVA/jAVAvIRTUALmACHINES", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("NOITAROPRO");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        int[] intArray1 = new int[] { 10 };
        int int2 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray1);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "  /       Nu  m  h A  / dk# 0 ", (java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                                                                                       /Users/sophie", "TF-8", "...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                       /Users/sophie" + "'", str3.equals("                                                                                       /Users/sophie"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "0.25");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaahi!aaaa", "AAAHI!AAAA");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Oracle ...", (java.lang.CharSequence[]) strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "         JavavP");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "aaahi         JavavPaaaa" + "'", str6.equals("aaahi         JavavPaaaa"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                                                                                                                                                                                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "j:tjtt3", (java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "", 8);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("#Mac OS#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#Mac OS#" + "'", str1.equals("#Mac OS#"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                                          Mac OS X", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaSPlatform API SpecificationWT.MACOSX.cpRINTERjOBaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa[[jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa[[jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa[[jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("   ss      i  Fi     ss [L       ng S  ing;   ss [L       ng S  ing;   ss      i  Fi     ss [[J44444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ss      i  Fi     ss [L       ng S  ing;   ss [L       ng S  ing;   ss      i  Fi     ss [[J44444444444444444444444444" + "'", str1.equals("ss      i  Fi     ss [L       ng S  ing;   ss [L       ng S  ing;   ss      i  Fi     ss [[J44444444444444444444444444"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("             ", "/USERS/SOPNEE/D", 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "             " + "'", str3.equals("             "));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("ORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRPORATION" + "'", str1.equals("oRPORATION"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 0, 10, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "1.1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("SPlatform API SpecificationWT.MACOSX.cpRINTERjOBSPlatform API Specificationn4_v31cq2n2x1n4fc0000gn/T", "/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SPlatform API SpecificationWT.MACOSX.cpRINTERjOBSPlatform API Specificationn4_v31cq2n2x1n4fc0000gn/T" + "'", str2.equals("SPlatform API SpecificationWT.MACOSX.cpRINTERjOBSPlatform API Specificationn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "mixed mode", "                                                                                       /Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("c OS #M", "                                   ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "c OS #M" + "'", str2.equals("c OS #M"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "...k1.7.0_...", 25);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("x86_6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_6" + "'", str1.equals("x86_6"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Oracle Corporation", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Corporation Oracle" + "'", str2.equals("Corporation Oracle"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("mode mixed", 51, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "PvavaJ         ##########", (java.lang.CharSequence) "/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[" + "'", str2.equals("class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [["));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                                    ", "4_V31CQ2N2X1N4FC0000GN/t");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "                     ", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOBLASS JAVA.IO.FILECLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS JAVA.IO.FILECLASS [[", "noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", (int) '4', 26);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("noitacificepS IPA mroftalP", (float) 4);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie", strArray1, strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie" + "'", str4.equals("                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#fication", 32, "                                                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#fication" + "'", str3.equals("sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#fication"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        float[] floatArray1 = new float[] { '4' };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 52.0f + "'", float4 == 52.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "4.80-b112", (java.lang.CharSequence) "                                          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("mode mixed", "24.8/-B11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aJava HotSpot(TM) 6 -Bit Server VMa", (int) (byte) -1, "4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aJava HotSpot(TM) 6 -Bit Server VMa" + "'", str3.equals("aJava HotSpot(TM) 6 -Bit Server VMa"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        java.lang.CharSequence charSequence5 = null;
        char[] charArray9 = new char[] { '4', ' ' };
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone(charSequence5, charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                          Mac OS X", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "SPlatform API SpecificationWT.MACOSX.cpRINTERjOB", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "x86_6", charArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0.25", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("http://java.oracle.com/1.7.0_801.7.0_801.7.0_801.7.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "MAC OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 12, (float) 2L, Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.POSITIVE_INFINITY + "'", float3 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("elcro                 noitroproC elcroJAVA VIRTUAL MACHINE SPECIFICATION            noitropro", "Javav", (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "elcro                 noitroproC elcroJAVA VIRTUAL MACHINE SPECIFICATION            noitropro" + "'", str3.equals("elcro                 noitroproC elcroJAVA VIRTUAL MACHINE SPECIFICATION            noitropro"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        char[] charArray8 = new char[] { '#', '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "5", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "##################################################################", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aJava HotSpot(TM) 64-Bit Serv...", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("x86_64", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("http://java.oracle.com/1.4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/1.4" + "'", str1.equals("http://java.oracle.com/1.4"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java HotSpot( M) 64 Bit Serv...", "class [Ljava.lang.String;", ":");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java HotSpot( M) 64 Bit Serv..." + "'", str3.equals("Java HotSpot( M) 64 Bit Serv..."));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("                                                                                           oRACLE cORPORATION                                                                                           ", "http://java.oracle.com/1.7.0_801.7.0_801.7.0_801.7.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                           oRACLE cORPORATION                                                                                           " + "'", str2.equals("                                                                                           oRACLE cORPORATION                                                                                           "));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", ":", 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar", "VA/JAVAVIRTUALMACHINES/JDK1.7.0_");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80", strArray4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 6");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 6, 34L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                          Mac OS X", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("UTF-8", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 1);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "PVAVAJESU/");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTF-8" + "'", str6.equals("UTF-8"));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("11", 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "11" + "'", str3.equals("11"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                               sophie", "aaahi!aaaa");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "################################", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaa" + "'", str1.equals("aaa"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/usr/lib/java", "eihpo", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("                                                                   Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("TF-8", "   ss      i  Fi     ss [L       ng S  ing;   ss [L       ng S  ing;   ss      i  Fi     ss [[J44444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TF-8" + "'", str2.equals("TF-8"));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                1.0 0                ", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJoblass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(6.0f, (float) 3, (float) 3374);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaa", "1.7.0_80");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "oracl\ntion", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("###1.7#######1.7#######1hi!###1.7#######1.7#######1.", 59);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1." + "'", str2.equals("###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1.###1.7#######1.7#######1hi!###1.7#######1.7#######1."));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4Mac OS 44", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                1.0 0                ", "/USR/LIB/JAVA##", 12);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "oRPORATION");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("        M71_O_X", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EX", 98);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 1, (byte) 10, (byte) -1, (byte) 100, (byte) 1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 100 + "'", byte9 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "4.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   ..." + "'", str2.equals("   ..."));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "1.4                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("NE", "   ss      i  Fi     ss [L       ng S  ing;   ss [L       ng S  ing;   ss      i  Fi     ss [[J", 121);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                                    ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("aaaaaaaaaaaaaaaaaaaaaaaaaa", "HI!");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "###1.7####", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                                           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("Java Platform API Specification", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) -1, (float) (short) 100, (float) 37);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '#', 0, (int) (byte) 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("sun.lwawt.macosx.CPrinterJob", 0, "1.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str3.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines", "class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "   ss      i  Fi     ss [L       ng S  ing;   ss [L       ng S  ing;   ss      i  Fi     ss [[J44444444444444444444444444", (java.lang.CharSequence) "0.7.108_0.7.108_0.7.108_0.7.1/moc.elcaro.avaj//:ptth", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ##########     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "noitar", (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest8.test330");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
//        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean5 = javaVersion0.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str7 = javaVersion6.toString();
//        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        boolean boolean9 = javaVersion4.atLeast(javaVersion6);
//        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
//        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
//        java.lang.String str13 = javaVersion12.toString();
//        boolean boolean14 = javaVersion11.atLeast(javaVersion12);
//        boolean boolean15 = javaVersion10.atLeast(javaVersion11);
//        boolean boolean16 = javaVersion6.atLeast(javaVersion11);
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.8" + "'", str7.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
//        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.2" + "'", str13.equals("1.2"));
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring(":", (-1), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "/SUN", "/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(" x86_64  ", (short) (byte) 6);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 6 + "'", short2 == (short) 6);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "24.8/-b11aaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "aJava HotSpot(TM) 64-Bit Server VMa");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "24.8/-b11aaaaaaaaaaaaaaaaaaaaaa" + "'", charSequence2.equals("24.8/-b11aaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "11", (java.lang.CharSequence) "oracle Corporation                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                            1.7.0_80                                             ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("  /       Nu  m  h A  / dk# 0 ", "###############################", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "javahotspot(tm)64-bitservervm", 193);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                          Mac OS ", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                          Mac OS " + "'", str2.equals("                                                          Mac OS "));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "E/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GE", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "va/javavirtualmachines/jdk1.7.0_", (java.lang.CharSequence) "Ma", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aaahi         JavavPaaaa", (java.lang.CharSequence) "/USERS/SOPNEE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#fication");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("...k1.7.0_...", "TF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...k1.7.0_..." + "'", str2.equals("...k1.7.0_..."));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9", (java.lang.CharSequence) "6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("noitaroproC elcaro");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproC elcaro" + "'", str1.equals("noitaroproC elcaro"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("###################################", "                                                                   Java HotSpot(TM) 64-Bit Server VM", 193);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################" + "'", str3.equals("###################################"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("oracle Corporation                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle Corporation" + "'", str1.equals("oracle Corporation"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        java.lang.CharSequence charSequence2 = null;
        java.lang.CharSequence charSequence5 = null;
        char[] charArray10 = new char[] { '#', 'a' };
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence5, charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "0.9", charArray10);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray10);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#################################################################################################", charArray10);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi#!", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa");
        java.lang.Class<?> wildcardClass4 = strArray1.getClass();
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "va/javavirtualmachines/jdk1.7.0_");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray6);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########PvavaJ         #########:PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("aJava HotSpot(TM) 64-Bit Serv...", "/users/sophie/documlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrets/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/users/sophie/documlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrets/defects4j/framework/lib/test_glibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreeration/glibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreeration/randoop-currlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jret.jar", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "AAAHI!AAAA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("fc0000gn/T/#_v31cq2n2x1n#/var/folders/_v/6v597zmn");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '#', 32, 4);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.3", (java.lang.CharSequence) "MAC OS X", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Java HotSpot( M) 64 Bit Serv...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0", "1.2");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", "oracle Corporation");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("24.80-b11", strArray4, strArray7);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "24.8/-b11" + "'", str8.equals("24.8/-b11"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("5", "JAVAVP", (int) (short) 10);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "        M71_O_X", 26, 2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(1, 5, (int) (byte) 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_80", (int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "   ss      i  Fi     ss [L       ng S  ing;   ss [L       ng S  ing;   ss      i  Fi     ss [[J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        char[] charArray11 = new char[] { '#', '#' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "5", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "JavavP", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "####################################################", charArray11);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "oracl\ntion", charArray11);
        int int20 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#fication", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aJava HotSpot(TM) 6 -Bit Server VMa         JavavP         JavavP           JavavP         JavavP           JavavP         JavavP           JavavP         JavavP           JavavP         JavavP", "Java Virtual Machine Specificatio", 7, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aJava HJava Virtual Machine Specificatio        JavavP         JavavP           JavavP         JavavP           JavavP         JavavP" + "'", str4.equals("aJava HJava Virtual Machine Specificatio        JavavP         JavavP           JavavP         JavavP           JavavP         JavavP"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("SUN.LWAWT.MACOSX.cpRINTERjOBnoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaropro", (double) 34L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.0d + "'", double2 == 34.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        java.lang.String[] strArray4 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray8 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(strArray8);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray4, strArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", (java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.split("x86_6", "", 0);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray8, strArray16);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.stripAll(strArray16, "                1.0 0                1.7.0_80");
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray16, "aaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7.0_80" + "'", str5.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.7.0_80" + "'", str9.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "x86_6" + "'", str21.equals("x86_6"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str3 = javaVersion2.toString();
        boolean boolean4 = javaVersion1.atLeast(javaVersion2);
        boolean boolean5 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str9 = javaVersion8.toString();
        boolean boolean10 = javaVersion7.atLeast(javaVersion8);
        boolean boolean11 = javaVersion6.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
        boolean boolean16 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
        boolean boolean17 = javaVersion13.atLeast(javaVersion14);
        boolean boolean18 = javaVersion12.atLeast(javaVersion14);
        boolean boolean19 = javaVersion8.atLeast(javaVersion12);
        boolean boolean20 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        boolean boolean21 = javaVersion0.atLeast(javaVersion8);
        org.apache.commons.lang3.JavaVersion javaVersion22 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion23 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str24 = javaVersion23.toString();
        boolean boolean25 = javaVersion22.atLeast(javaVersion23);
        java.lang.String str26 = javaVersion23.toString();
        org.apache.commons.lang3.JavaVersion javaVersion27 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean28 = javaVersion23.atLeast(javaVersion27);
        boolean boolean29 = javaVersion0.atLeast(javaVersion27);
        java.lang.String str30 = javaVersion27.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.2" + "'", str9.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + javaVersion22 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion22.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion23 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion23.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1.2" + "'", str24.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1.2" + "'", str26.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion27 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion27.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1.1" + "'", str30.equals("1.1"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "TF-8", (java.lang.CharSequence) "/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.ja");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("4444444444444444444444444444444", "          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("aaaaaaaaaaalaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java Virtual Machine Specificationocuments/defects4j/tmp/run_randoop.pl_96328_1560211636", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specificationocuments/defects4j/tmp/run_randoop.pl_96328_1560211636" + "'", str2.equals("Java Virtual Machine Specificationocuments/defects4j/tmp/run_randoop.pl_96328_1560211636"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Java4HotSpot(TM)464-Bit4Server4V", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 7, 0.0d, (double) 21L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 21.0d + "'", double3 == 21.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) " x86_64  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        double[] doubleArray4 = new double[] { (byte) 1, (byte) -1, '#', (-1.0f) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("MAC OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS X" + "'", str1.equals("MAC OS X"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("NOITAROPRO", "                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOITAROPRO" + "'", str2.equals("NOITAROPRO"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("pnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "eihpos", 13);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "pnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("pnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jareihpospnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("eihpos");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split(":", "/USERS/SOPHIE");
        java.lang.String[] strArray11 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(strArray11);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray11);
        java.lang.String[] strArray15 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(strArray15);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray15);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray11, strArray15);
        java.lang.String[] strArray20 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(strArray20);
        java.lang.String[] strArray22 = org.apache.commons.lang3.StringUtils.stripAll(strArray20);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray20);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray15, strArray20);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("                               sophie", strArray7, strArray15);
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.Class<?> wildcardClass27 = strArray26.getClass();
        java.lang.String str28 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/users/sopnee/d/users", strArray3, strArray26);
        int int29 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "oitacificepS enihcaM lautriV avaJ", (java.lang.CharSequence[]) strArray26);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.7.0_80" + "'", str12.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.7.0_80" + "'", str16.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1.7.0_80" + "'", str21.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1.7.0_80" + "'", str23.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "hi!" + "'", str24.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "                               sophie" + "'", str25.equals("                               sophie"));
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "/users/sopnee/d/users" + "'", str28.equals("/users/sopnee/d/users"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("aaaaaaaaaaavaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaavaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaavaaaaaaaaaaa"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("JavaVirtualMachineSpecification", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecification" + "'", str2.equals("JavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecificationJavaVirtualMachineSpecification"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "OracleCorporation" + "'", str1.equals("OracleCorporation"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "6" + "'", str1.equals("6"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4", (java.lang.CharSequence) "platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "oRACLE ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("4Mac OS 44", "sun");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4Mac OS 44" + "'", str2.equals("4Mac OS 44"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "1.1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(193, (int) ' ', 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("...k1.7.0_...", "SUN.LWAWT.MACOSX.lwctOOLKIT", "JavavP", 29);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "...k1.7.0_..." + "'", str4.equals("...k1.7.0_..."));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("0.9", "                                                    ", (-1), 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                    " + "'", str4.equals("                                                    "));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("O caM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "O caM" + "'", str1.equals("O caM"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("eihpos");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "nOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRO", 34, (int) (byte) 6);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specification                                ", "UTF-8");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1.7.0_80-B15");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "oracle Corporation/Users/");
        boolean boolean8 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "hi#!", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "###########################################################", (java.lang.CharSequence) "24.8/-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("MAC OS X");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOBNOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPROC ELCARONOITAROPRO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "oracl\ntion");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "#################################################################################################", 3374);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac OS X10.14.10.14.10.14.10.14.10.", "Java(TM) SE Runtime Environment", 34);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("[[j", "c OS #M");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[[j" + "'", str2.equals("[[j"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR4J/TMP/RUN_RANDOOP.PL_96328_1560211636/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4/USERS/SOPHIE/DOCUMENTS/DEFECTS", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("x86_6", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("##########     ", "HI");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########     " + "'", str2.equals("##########     "));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("\n");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("[[j", "/USERS/SOPHIE/DOCUMLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRETS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96328_1560211636/TARGET/CLASSES:/USERS/SOPHIE/DOCUMLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRETS/DEFECTS4J/FRAMEWORK/LIB/TEST_GLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREERATION/GLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREERATION/RANDOOP-CURRLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRET.JAR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[[j" + "'", str2.equals("[[j"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 10, (byte) 6);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("javav", "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "javav" + "'", str2.equals("javav"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        byte[] byteArray0 = null;
        try {
            byte byte1 = org.apache.commons.lang3.math.NumberUtils.max(byteArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Mac", "   ss      i  Fi     ss [L       ng S  ing;   ss [L       ng S  ing;   ss      i  Fi     ss [[J");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        java.lang.CharSequence charSequence4 = null;
        char[] charArray8 = new char[] { '4', ' ' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone(charSequence4, charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                          Mac OS X", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "SPlatform API SpecificationWT.MACOSX.cpRINTERjOB", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "v", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/USERS/SOPNEE/D", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPNEE/D" + "'", str2.equals("/USERS/SOPNEE/D"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############", '#');
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray3, strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "1.3", 2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("J/v/ HotSpot(TM) 6-Bit Server VM", "hiMac OS X!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J/v/ HotSpot(TM) 6-Bit Server VM" + "'", str2.equals("J/v/ HotSpot(TM) 6-Bit Server VM"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str3 = javaVersion2.toString();
        boolean boolean4 = javaVersion1.atLeast(javaVersion2);
        boolean boolean5 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str6 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.2" + "'", str6.equals("1.2"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "SPlatform API SpecificationWT.MACOSX.cpRINTERjOBSPlatform API Specificationn4_v31cq2n2x1n4fc0000gn/T", 98);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "j:tjtt3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                                                   java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                   JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str1.equals("                                                                   JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("Oracle ...", "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle ..." + "'", str2.equals("Oracle ..."));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/usr/lib/java", (java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("##########     ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        java.lang.CharSequence charSequence2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "oracle Corporation");
        int int6 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence2, (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "VA/JAVAVIRTUALMACHINES/JDK1.7.0_", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray14 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(strArray14);
        java.lang.String[] strArray16 = org.apache.commons.lang3.StringUtils.stripAll(strArray14);
        java.lang.String[] strArray18 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(strArray18);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.stripAll(strArray18);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray14, strArray18);
        int int22 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", (java.lang.CharSequence[]) strArray18);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.split("AAAHI!AAAA");
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.replaceEach("AAAHI!AAAA", strArray18, strArray24);
        java.lang.String str27 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray24, ' ');
        boolean boolean28 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...", (java.lang.CharSequence[]) strArray24);
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.replaceEach(" ", strArray5, strArray24);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.7.0_80" + "'", str15.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray16);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1.7.0_80" + "'", str19.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "AAAHI!AAAA" + "'", str25.equals("AAAHI!AAAA"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "AAAHI!AAAA" + "'", str27.equals("AAAHI!AAAA"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + " " + "'", str29.equals(" "));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8AAAAAAAAAA", 4, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8AAAAAAAAAA" + "'", str3.equals("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8AAAAAAAAAA"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("0", "", 15);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("SUN.LWAWT.MACOSX.cpRINTERjOBnoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaropro", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("24.8/-b11aaaaaaaaaaaaaaaaaaaaaa", "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.8/-b11aaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("24.8/-b11aaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("JaHaaSaaa(TM)a6a-BaaaSaavaaaavaaHaaSaaa(TM)a6a-BaaaSaavaaa aHaaSaaa(TM)a6a-BaaaSaavaaaVaHaaSaaa(TM)a6a-BaaaSaavaaairtualaHaaSaaa(TM)a6a-BaaaSaavaaa aHaaSaaa(TM)a6a-BaaaSaavaaaMaHaaSaaa(TM)a6a-BaaaSaavaaaachineaHaaSaaa(TM)a6a-BaaaSaavaaa aHaaSaaa(TM)a6a-BaaaSaavaaaSaHaaSaaa(TM)a6a-BaaaSaavaaapecification", 66, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JaHaaSaaa(TM)a6a-BaaaSaavaaaavaaHaaSaaa(TM)a6a-BaaaSaavaaa aHaaSaaa(TM)a6a-BaaaSaavaaaVaHaaSaaa(TM)a6a-BaaaSaavaaairtualaHaaSaaa(TM)a6a-BaaaSaavaaa aHaaSaaa(TM)a6a-BaaaSaavaaaMaHaaSaaa(TM)a6a-BaaaSaavaaaachineaHaaSaaa(TM)a6a-BaaaSaavaaa aHaaSaaa(TM)a6a-BaaaSaavaaaSaHaaSaaa(TM)a6a-BaaaSaavaaapecification" + "'", str3.equals("JaHaaSaaa(TM)a6a-BaaaSaavaaaavaaHaaSaaa(TM)a6a-BaaaSaavaaa aHaaSaaa(TM)a6a-BaaaSaavaaaVaHaaSaaa(TM)a6a-BaaaSaavaaairtualaHaaSaaa(TM)a6a-BaaaSaavaaa aHaaSaaa(TM)a6a-BaaaSaavaaaMaHaaSaaa(TM)a6a-BaaaSaavaaaachineaHaaSaaa(TM)a6a-BaaaSaavaaa aHaaSaaa(TM)a6a-BaaaSaavaaaSaHaaSaaa(TM)a6a-BaaaSaavaaapecification"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        char[] charArray5 = new char[] { '#', '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Javav", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("oracle corporationALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EX");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: oracle corporationALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EX is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "sun", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.4", (java.lang.CharSequence) "         JavavP", (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("platform API Specification", "sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "platform API Specification" + "'", str2.equals("platform API Specification"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray7 = new char[] { '#', '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "5", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "oracle Corporation                 ", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 3, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("MAC OS X");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("###1.7###", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("##########...", "4Mac OS 44", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                     " + "'", str1.equals("                     "));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9", (int) (short) 1, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("4Mac OS 44");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4mac os 44" + "'", str1.equals("4mac os 44"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("aHaaSaaa(TM)a6a-BaaaSaavaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aHaaSaaa(TM)a6a-BaaaSaavaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest8.test452");
//        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
//        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
//        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
//        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
//        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
//        boolean boolean5 = javaVersion0.atLeast(javaVersion4);
//        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
//        java.lang.String str7 = javaVersion6.toString();
//        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
//        boolean boolean9 = javaVersion4.atLeast(javaVersion6);
//        java.lang.String str10 = javaVersion4.toString();
//        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.8" + "'", str7.equals("1.8"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.5" + "'", str10.equals("1.5"));
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                     ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                     " + "'", str1.equals("                     "));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("44444", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "###1.7###");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "##########         JavavP", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("        M71_O_X", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "        M71_O_X" + "'", str2.equals("        M71_O_X"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "NE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("noitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro" + "'", str1.equals("noitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "          ", (java.lang.CharSequence) "va/javavirtualmachines/jdk                               sophie.0_", 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 121.0f, (double) 12.0f, 35.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.0d + "'", double3 == 12.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("NOITAROPRO");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOITAROPRO" + "'", str1.equals("NOITAROPRO"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("####S#                                                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ", "##################################################################", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                " + "'", str3.equals("...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                "));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray8 = new char[] { '#', 'a' };
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", charArray8);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence3, charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "0.9", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/users/sophie/documlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrets/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/users/sophie/documlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrets/defects4j/framework/lib/test_glibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreeration/glibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreeration/randoop-currlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jret.jar", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 300L, (float) 121, (float) 33);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 33.0f + "'", float3 == 33.0f);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "        M71_O_X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "eihpos", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "/LIBRARM/LIB/EX", (int) (short) 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj[[aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "PlatformAPISpecification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "j[[aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("j[[aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "0.7.108_0.7.108_0.7.108_0.7.1/moc.elcaro.avaj//:ptth");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", (java.lang.CharSequence) "M OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.1", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.11.11.11.11.11.11.1" + "'", str2.equals("1.11.11.11.11.11.11.1"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "PVAVAJESU/", "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("...k1.7.0_...", "5");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "...k1.7.0_..." + "'", str4.equals("...k1.7.0_..."));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("platform API Specification");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("0.25", "noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", 66, "aaahi!aaaa                                                                                          ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro" + "'", str3.equals("            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        char[] charArray5 = new char[] { '#', '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray5);
        java.lang.Class<?> wildcardClass7 = charArray5.getClass();
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaSPlatform API SpecificationWT.MACOSX.cpRINTERjOBaaaaaaaaaaaaaaaaaaaaaaaaa", charArray5);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:./Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#", "####S#", 98);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ".lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[", (java.lang.CharSequence) "3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("0.25", 42.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.25d + "'", double2 == 0.25d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro" + "'", str1.equals("noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("va/javavirtualmachines/jdk#.0_");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "va/javavirtualmachines/jdk#.0_" + "'", str1.equals("va/javavirtualmachines/jdk#.0_"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR4J/TMP/RUN_RANDOOP.PL_96328_1560211636/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4/USERS/SOPHIE/DOCUMENTS/DEFECTS", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR4J/TMP/RUN_RANDOOP.PL_96328_1560211636/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4/USERS/SOPHIE/DOCUMENTS/DEFECTS" + "'", str2.equals("J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR4J/TMP/RUN_RANDOOP.PL_96328_1560211636/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4/USERS/SOPHIE/DOCUMENTS/DEFECTS"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "/Users/sophie/Documents/defects4");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "            ...");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 15 + "'", int1 == 15);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("hi!", 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("####S#", (int) (short) 100, "Mac");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MacMacMacMacMacMacMacMacMacMacMacMacMacMacMacMa####S#MacMacMacMacMacMacMacMacMacMacMacMacMacMacMacMa" + "'", str3.equals("MacMacMacMacMacMacMacMacMacMacMacMacMacMacMacMa####S#MacMacMacMacMacMacMacMacMacMacMacMacMacMacMacMa"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) (byte) 100, 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        int[] intArray2 = new int[] { 97, 2 };
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray2);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("#######sun.lwawt.macosx.CPrinterJoblass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[##########");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        long[] longArray6 = new long[] { (-1), 2, 300, ' ', ' ', (byte) 0 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 300L + "'", long8 == 300L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(33.0f, (float) 15, 192.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 192.0f + "'", float3 == 192.0f);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                                                                                                                                ", (java.lang.CharSequence) "Mac O");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_4;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_4 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_4));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("24.80-b112");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }
}

