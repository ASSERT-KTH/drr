import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("Java(TM) SE Runtime Environment", "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test002");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("         JavavP         JavavP  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavavP         JavavP" + "'", str1.equals("JavavP         JavavP"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test003");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("         JavavP         JavavP  ", (double) 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test004");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 10, (short) (byte) 6);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test005");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4_V31CQ2N2X1N4FC0000GN/t" + "'", str1.equals("4_V31CQ2N2X1N4FC0000GN/t"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test006");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test007");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("noitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro", "LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro" + "'", str2.equals("noitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test009");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("va/javavirtualmachines/jdk#.0_", "              [[j              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "va/javavirtualmachines/jdk#.0_" + "'", str2.equals("va/javavirtualmachines/jdk#.0_"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test010");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("USERS", (long) 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test011");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "[[j", (java.lang.CharSequence) "aaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test012");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("SUN.LWAWT.MACOSX.lwctOOLKIT", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test013");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test014");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa");
        java.lang.Class<?> wildcardClass6 = strArray3.getClass();
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.5", (java.lang.CharSequence[]) strArray3);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        int int9 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "ORPORATION                                                                                                                                                                                       ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test015");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "MAC OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("...                                ", "LIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "..." + "'", str2.equals("..."));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test017");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "###################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test018");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS ", (java.lang.CharSequence) "ORPORATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test019");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[J", "http://java.oracle.com/", "                                                          Mac OS ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   ss      i  Fi     ss [L       ng S  ing;   ss [L       ng S  ing;   ss      i  Fi     ss [[J" + "'", str3.equals("   ss      i  Fi     ss [L       ng S  ing;   ss [L       ng S  ing;   ss      i  Fi     ss [[J"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test020");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("LIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JA");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test021");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("1.7", "            ...", 121);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7" + "'", str3.equals("1.7"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test022");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (java.lang.CharSequence) " x86_64  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test023");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specification                                ", "UTF-8");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1.7.0_80-B15");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, '4', 97, (int) (byte) -1);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test024");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(":", (int) '4', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################################:" + "'", str3.equals("###################################################:"));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test025");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.7.0_80", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test026");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("0.25", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.25" + "'", str2.equals("0.25"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test027");
        int[] intArray5 = new int[] { (short) 100, 'a', 7, 15, (short) -1 };
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test028");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(21, 51, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 51 + "'", int3 == 51);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test029");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test030");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 15, (float) 4, (float) 9L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 4.0f + "'", float3 == 4.0f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test031");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean7 = javaVersion2.atLeast(javaVersion5);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test032");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 6, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 6 + "'", byte3 == (byte) 6);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test033");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test034");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("                                                          Mac OS ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                   Java HotSpot(TM) 6-Bit Server VM", (java.lang.CharSequence) "[[j");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test036");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaa", "                                                                                           oRACLE cORPORATION                                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test037");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "hiMac OS X!", (java.lang.CharSequence) "/Users/sophie/Documents/defects4", 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test038");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("Java Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Platform API Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test039");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test040");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("Java Platform API Specification", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sun.awt.CGraphicsEnvironment", "mode mixed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test042");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("NOITAROPRO", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test043");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "                                                                                                                                                                                                                ", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                                                                                                                                                                                                                " + "'", charSequence2.equals("                                                                                                                                                                                                                "));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test044");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.7.0_80");
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aJava HotSpot(TM) 64-Bit Server VMa", (java.lang.CharSequence[]) strArray3);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/SUN", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test045");
        char[] charArray6 = new char[] { '#', 'a' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "###1.7###", charArray6);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test046");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("M71_O_X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test047");
        float[] floatArray5 = new float[] { 10, (byte) 1, 66, 1, 97 };
        float float6 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 97.0f + "'", float7 == 97.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test048");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa[[jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 200, 23);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa[[jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa[[jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test049");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("x86_64");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "PVAVAJESU/", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.1", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test051");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("H", "/USR/LIB/JAVA");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test052");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("[[ java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass sun.lwawt.macosx.cprinterjoblass", "                                   ");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ');
        java.lang.String[] strArray6 = null;
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("24.", strArray3, strArray6);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[[ java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass sun.lwawt.macosx.cprinterjoblass" + "'", str5.equals("[[ java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass sun.lwawt.macosx.cprinterjoblass"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "24." + "'", str7.equals("24."));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test053");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "", 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test054");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects", (java.lang.CharSequence) "Ora1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test055");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("oracle Corporation/Users/", 193.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 193.0f + "'", float2 == 193.0f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test056");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test057");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test058");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "1.4                          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test059");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str3 = javaVersion2.toString();
        boolean boolean4 = javaVersion1.atLeast(javaVersion2);
        boolean boolean5 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        boolean boolean11 = javaVersion7.atLeast(javaVersion8);
        boolean boolean12 = javaVersion6.atLeast(javaVersion8);
        boolean boolean13 = javaVersion2.atLeast(javaVersion6);
        boolean boolean14 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        java.lang.String str15 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.2" + "'", str15.equals("1.2"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test060");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test061");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.2", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test062");
        char[] charArray7 = new char[] { '#', '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "5", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "oracle Corporation                 ", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mixed mode", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/JAVAVP", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/JAVAVP" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/JAVAVP"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS ", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS " + "'", str2.equals("SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS "));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test065");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar", "", (int) '4');
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn#_v31cq2n2x1n#fc0000gn/T/", (java.lang.CharSequence[]) strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, 'a');
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...", (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar" + "'", str8.equals("/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.4", (int) (byte) 100, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4#################################################################################################" + "'", str3.equals("1.4#################################################################################################"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test067");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', 97, 15);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test068");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("24.8/-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.8/-B11" + "'", str1.equals("24.8/-B11"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test069");
        char[] charArray6 = new char[] { '#', '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "VA/JAVAVIRTUALMACHINES/JDK1.7.0_", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "JavavP", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test070");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("[[J", "...eneration/randoop-current.jar", 34);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test071");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.4                          ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test072");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(0L, 0L, (long) 200);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 200L + "'", long3 == 200L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test073");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test074");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test075");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(":", 200, "PvavaJ         ##########");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########PvavaJ         #########:PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########" + "'", str3.equals("PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########PvavaJ         #########:PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test076");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (float) 34L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test077");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 6);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test078");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("M71_O_X", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test079");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) (byte) 10, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test080");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test081");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.7.0_80");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test082");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "JAVAVP");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("Platform API Specification", "1.4#################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Platform API Specification" + "'", str2.equals("Platform API Specification"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test084");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EX", charSequence1, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test085");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test086");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '4', 200, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 200 + "'", int3 == 200);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "1.4#################################################################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test088");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("aaa", 8, 97);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test089");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                 noitaroproC elcaro", (java.lang.CharSequence) "MAC OS ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test090");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4.80-b112", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test091");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("###1.7###");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###1.7###" + "'", str1.equals("###1.7###"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test092");
        char[] charArray7 = new char[] { '#', '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "VA/JAVAVIRTUALMACHINES/JDK1.7.0_", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test093");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "MAC OS X", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("sun.lwawt.macosx.CPrinterJob", "ORACLE CORPORATION/USERS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test095");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.8", (int) (byte) 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test097");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("1.4                          ", "E/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GE", "/users/sophie/documlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrets/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/users/sophie/documlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrets/defects4j/framework/lib/test_glibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreeration/glibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreeration/randoop-currlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jret.jar");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test098");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("24.8/-B11", "...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.8/-B11" + "'", str2.equals("24.8/-B11"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test099");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.7.0_80-b15", (int) (byte) -1, 193);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80-b15" + "'", str3.equals("1.7.0_80-b15"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test100");
        char[] charArray7 = new char[] { '#', 'a' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaa", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "         JavavP", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "        M71_O_X", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test101");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test102");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test103");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "oracle Corporation/UsersJAVAVP");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test104");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("J/v/ HotSpot(TM) 6-Bit Server VM", (int) (short) -1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "M" + "'", str3.equals("M"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test105");
        char[] charArray9 = new char[] { '#', '#' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "5", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "JavavP", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray9);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "j:tjtt3", charArray9);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "PVAVAJESU/", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test106");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96328_1560211636/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", (java.lang.CharSequence) "hi!", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test107");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("http://java.oracle.com/1.7.0_801.7.0_801.7.0_801.7.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test108");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "j", 193);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test109");
        char[] charArray5 = new char[] { '#', 'a' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/USERS/SOPNEE/D/USERS", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test110");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test111");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("###1.7####", "...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ", 0, 15);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                " + "'", str4.equals("...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                "));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("oracle Corporation/Users", "/USR/LIB/JAVA##");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle Corporation/Users" + "'", str2.equals("oracle Corporation/Users"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test113");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 97, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#################################################################################################" + "'", str3.equals("#################################################################################################"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test114");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test115");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/", "oracle Corporation");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "Oracle ...", 300, 17);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test116");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test117");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("VA/JAVAVIRTUALMACHINES/JDK1.7.0_", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "PVAVAJESU/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test119");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "0.9");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "0.9" + "'", charSequence2.equals("0.9"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test120");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) (byte) 10, (double) 34);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 34.0d + "'", double3 == 34.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test121");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("[[j");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"[[j\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test122");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "0.4.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test123");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aJava HotSpot(TM) 6 -Bit Server VMa", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " HotSpot(TM) 6 -Bit Server " + "'", str2.equals(" HotSpot(TM) 6 -Bit Server "));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "1.2", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test126");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test127");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", (java.lang.CharSequence) "...                          ...", 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test128");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.4                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test129");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test130");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 42, (float) 17, (float) 31);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 42.0f + "'", float3 == 42.0f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test131");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("H", "", 29);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test132");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                                                                       /Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                       /Users/sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test133");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80", "ORACLE CORPORATION/USERS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Oracle ...", (int) (short) 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle ..." + "'", str2.equals("Oracle ..."));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test135");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java HotSpot(TM) 64-Bit Server VM", '#');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aJava HotSpot(TM) 6 -Bit Server VMa", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test136");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar", "   ss      i  Fi     ss [L       ng S  ing;   ss [L       ng S  ing;   ss      i  Fi     ss [[J");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar" + "'", str2.equals("/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test138");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "O caM", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test139");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("VA/JAVAVIRTUALMACHINES/JDK1.7.0_");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        java.lang.reflect.Type[] typeArray3 = new java.lang.reflect.Type[] { wildcardClass2 };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(typeArray3);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(typeArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "class [Ljava.lang.String;" + "'", str4.equals("class [Ljava.lang.String;"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test140");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 10, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test141");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96328_1560211636/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test142");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "TnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test143");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("E/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GE", (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test144");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "L", (java.lang.CharSequence) "/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test145");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test146");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Mac OS ", 'a', '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "M#c OS " + "'", str3.equals("M#c OS "));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test147");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.6", 300);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test148");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str3 = javaVersion2.toString();
        java.lang.String str4 = javaVersion2.toString();
        boolean boolean5 = javaVersion0.atLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2" + "'", str3.equals("1.2"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.2" + "'", str4.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test149");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("              [[j              ", "ORPORATION                                                                                                                                                                                       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORPORATION                                                                                                                                                                                       " + "'", str2.equals("ORPORATION                                                                                                                                                                                       "));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test150");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.8" + "'", str1.equals("1.8"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "h ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("fc0000gn/T/#_v31cq2n2x1n#/var/folders/_v/6v597zmn", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "fc0000gn/T/#_v31cq2n2x1n#/var/folders/_v/6v597zmn" + "'", str2.equals("fc0000gn/T/#_v31cq2n2x1n#/var/folders/_v/6v597zmn"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test153");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "            ...", charSequence1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test154");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "J/v/ HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test155");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.                                                    Mac OS X");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test156");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("hi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test157");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) " HotSpot(TM) 6 -Bit Server ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test158");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                               sophie");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test159");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("          24.8/-b11                     sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          24.8/-b11                     sophie" + "'", str1.equals("          24.8/-b11                     sophie"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test160");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("SUN.LWAWT.MACOSX.cpRINTERjOBLASS JAVA.IO.fILECLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS JAVA.IO.fILECLASS [[", "x86_6class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UN.LWAWT.MACOSX.cpRINTERjOBLASS JAVA.IO.fILECLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS JAVA.IO.fILECLA" + "'", str2.equals("UN.LWAWT.MACOSX.cpRINTERjOBLASS JAVA.IO.fILECLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS JAVA.IO.fILECLA"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test161");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#" + "'", str1.equals("sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test162");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "   ", 8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test163");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "x86_6", (int) '4');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "noitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro", 5, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test164");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test165");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test166");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                        oracle Corporation                        ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test167");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) ".7.0_801.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test168");
        long[] longArray1 = new long[] { 0 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(longArray1);
        long long4 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test169");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "         " + "'", str1.equals("         "));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test170");
        long[] longArray5 = new long[] { ' ', (short) 10, '#', 100, 10 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long10 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 100L + "'", long7 == 100L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 10L + "'", long9 == 10L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 100L + "'", long10 == 100L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test171");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("javahotspot(tm)64-bitservervm", "                                                          Mac OS ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("/USERS/SOP3E/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GE3RATION/GE3RATION/RANDOOP-CURRENT.JAR", "                                                                   Java HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test174");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("                1.0 0                1.7.0_80", "Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                1.0 0                1.7.0_80" + "'", str2.equals("                1.0 0                1.7.0_80"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("lass [[", 193, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#############################################################################################lass [[#############################################################################################" + "'", str3.equals("#############################################################################################lass [[#############################################################################################"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test176");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("24.", (int) (short) 1, (int) (short) 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4." + "'", str3.equals("4."));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa[[jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "c OS XaM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa[[jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa[[jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test178");
        short[] shortArray2 = new short[] { (short) 100, (byte) 100 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test179");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 3, (short) (byte) 6, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 6 + "'", short3 == (short) 6);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test180");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("hiMac OS X!", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hiMac OS X!" + "'", str2.equals("hiMac OS X!"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test181");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "...71_O_X", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test182");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.4");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test183");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) 5, (float) 2L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test184");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "MAC OS X", (java.lang.CharSequence) "              [[j              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test185");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 100, 34L, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test186");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "PVAVAJESU/", (java.lang.CharSequence) "Java Platform API Specification", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "PVAVAJESU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test188");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Java Platform API Specification", "sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#", (int) (short) -1, 23);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#fication" + "'", str4.equals("sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#fication"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test189");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java(TM) SE Runtime Environment");
        java.lang.String[] strArray5 = null;
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEach("ne", strArray4, strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkit", "Java Virtual Machine Specification                                ");
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (java.lang.CharSequence[]) strArray11);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEach("[[j", strArray4, strArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 10 vs 700");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ne" + "'", str6.equals("ne"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test190");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "Java Virtual Machine Specification                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.7.0_80", (int) 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                            1.7.0_80                                             " + "'", str2.equals("                                            1.7.0_80                                             "));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test192");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS ", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS " + "'", str2.equals("SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS "));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test193");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) " Platform API Specification", (java.lang.CharSequence) "         ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test194");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 8L, (float) (short) 0, (float) 9);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test196");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test197");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PLATFORM api sPECIFICATION" + "'", str1.equals("PLATFORM api sPECIFICATION"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "aaaaaaaaaaavaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test200");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                            1.7.0_80                                             ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("MAC OS X", "j", "sun.lwawt.macosx.CPrinterJoblass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test202");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("##########     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test203");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", 'a');
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test204");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 1, (short) 0, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test205");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) " Platform API Specificatio", (java.lang.CharSequence) "va/javavirtualmachines/jdk1.7.0_");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test206");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "###################################################:", 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test207");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "                        oracle Corp         JavavP         JavavP  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test208");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.7.0_80-b15", 35, 3);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test209");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 100, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test210");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "v", (int) (byte) 100);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test211");
        double[] doubleArray4 = new double[] { (byte) 1, (byte) -1, '#', (-1.0f) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test212");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test213");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("          24.8/-b11                     sophie", (float) 25);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 25.0f + "'", float2 == 25.0f);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test214");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "X86_6", (java.lang.CharSequence) "...71_O_X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test215");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("#############################################################################################lass [[#############################################################################################", "Java HotSpot(TM) 64-Bit Server V");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#############################################################################################lass [[#############################################################################################" + "'", str2.equals("#############################################################################################lass [[#############################################################################################"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test216");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("24.8/-b11aaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"24.8/-b11aaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test217");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence) "Ora1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test218");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("va/javavirtualmachines/jdk1.7.0_", "1.7", 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#', 10, 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "                               sophie");
        boolean boolean11 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "va/javavirtualmachines/jdk                               sophie.0_" + "'", str10.equals("va/javavirtualmachines/jdk                               sophie.0_"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test219");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("                                                          Mac OS ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS" + "'", str1.equals("Mac OS"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test220");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "SUN.LWAWT.MACOSX.lwctOOLKIT", (java.lang.CharSequence) "####################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9", 10, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test222");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "####################################################", (java.lang.CharSequence) "                                                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "aJava HotSpot(TM) 64-Bit Server VMa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test224");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("http://java.oracle.com/1.7.0_801.7.0_801.7.0_801.7.0");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test225");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "####################################################");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test226");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("LIBRARY/JoRACLE cORPORATIONLIBRARY/JA", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ONLIBRARY/JA" + "'", str2.equals("ONLIBRARY/JA"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test227");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "oracle Corporation", charSequence1, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore(".lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[", "              [[j              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[" + "'", str2.equals(".lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [["));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("...eneration/randoop-current.jar", (int) (short) -1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...eneration/randoop-current.jar" + "'", str3.equals("...eneration/randoop-current.jar"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                            1.7.0_80                                             ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                            1.7.0_80                                             " + "'", str2.equals("                                            1.7.0_80                                             "));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test231");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaavaaaaaaaaaaa", "J/v/ HotSpot(TM) 64-Bit Server VM", "SPlatform API SpecificationWT.MACOSX.cpRINTERjOBoracle Corporation/Usersoracle Corporation/UsersoracSPlatform API SpecificationWT.MACOSX.cpRINTERjOBoracle Corporation/Usersoracle Corporation/UsersoracSPlatform API SpecificationWT.MACOSX.cpRINTERjOBoracle Corporation/Usersoracle Corporation/Usersorac");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaalaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaalaaaaaaaaaaa"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle(".7.0_801.", "[[ java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass sun.lwawt.macosx.cprinterjoblass", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".7.0_801." + "'", str3.equals(".7.0_801."));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test233");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#fication");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#fication" + "'", str1.equals("sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#fication"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test234");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("1.6");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "0.9");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray5);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("/SUN", strArray2, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "hi!" + "'", str6.equals("hi!"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test235");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("\n", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "\n" + "'", str3.equals("\n"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test236");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("##################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test237");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                   Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test238");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/", (java.lang.CharSequence) "M OS X", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test239");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.CPrinterJoblass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTF-8" + "'", str2.equals("UTF-8"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test241");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaahi!aaaa", 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaahi!aaaa" + "'", str3.equals("aaahi!aaaa"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test242");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray7 = new char[] { '#', 'a' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", charArray7);
        java.lang.Class<?> wildcardClass10 = charArray7.getClass();
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                1.0 0                1.7.0_80", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[", charArray7);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test243");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.LWCToolkit", "...71_O_X", (int) (byte) 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test244");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#", (java.lang.CharSequence) "1.4#################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test245");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(21.0f, (float) (short) 100, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/users/sophie/documlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrets/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/users/sophie/documlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrets/defects4j/framework/lib/test_glibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreeration/glibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreeration/randoop-currlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jret.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/DOCUMLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRETS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96328_1560211636/TARGET/CLASSES:/USERS/SOPHIE/DOCUMLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRETS/DEFECTS4J/FRAMEWORK/LIB/TEST_GLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREERATION/GLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREERATION/RANDOOP-CURRLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRET.JAR" + "'", str1.equals("/USERS/SOPHIE/DOCUMLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRETS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96328_1560211636/TARGET/CLASSES:/USERS/SOPHIE/DOCUMLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRETS/DEFECTS4J/FRAMEWORK/LIB/TEST_GLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREERATION/GLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREERATION/RANDOOP-CURRLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRET.JAR"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test247");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/JAVAVP");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test248");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize(" x86_64  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " x86_64  " + "'", str1.equals(" x86_64  "));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test249");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Virtual Machine Specification                                ", 66, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ", "         JavavP         JavavP  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                " + "'", str2.equals("...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                "));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test251");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) 6, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test252");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "JavavP");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("##########     ", " Platform API Specificatio Platform API Specificatio", "###################################################:");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########     " + "'", str3.equals("##########     "));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test254");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "##########...", (java.lang.CharSequence) "##################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("SUN.LWAWT.MACOSX.lwctOOLKIT", (int) (short) -1, "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.lwctOOLKIT" + "'", str3.equals("SUN.LWAWT.MACOSX.lwctOOLKIT"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test256");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Java Platfor");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test257");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("NOITAROPRO", "          ", 7);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test259");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "\n");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test260");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("ORACLE CORPORATION/USERS");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ORACLE CORPORATION/USERS\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test261");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("hi!", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test262");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/SUN", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test263");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "JAVA VIRTUAL MACHINE SPECIFICATION", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test264");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                               sophie", "sun");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test265");
        float[] floatArray6 = new float[] { (short) 1, 10, 66, 0, (short) 1, (byte) 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 66.0f + "'", float7 == 66.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 66.0f + "'", float9 == 66.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test266");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "         ", (java.lang.CharSequence) "UN.LWAWT.MACOSX.cpRINTERjOBLASS JAVA.IO.fILECLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS JAVA.IO.fILECLA", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test267");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test268");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EX", "M", 15);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/LIBRARM/LIB/EX" + "'", str3.equals("/LIBRARM/LIB/EX"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test269");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                                                                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636                                                                      ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test270");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(97.0f, (float) 2, 42.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test271");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Platform API Specification" + "'", str1.equals("Platform API Specification"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test272");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 42, (float) 200, (float) 29);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 200.0f + "'", float3 == 200.0f);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test273");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment", "HI", 193);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test274");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(7L, 0L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test275");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "                                                                   Java HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test276");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(4, (int) (byte) 6, 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test277");
        char[] charArray5 = new char[] { '#', 'a' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "             ", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test278");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 1, 66.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 66.0f + "'", float3 == 66.0f);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/SUN", "mode mixed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/SUN" + "'", str2.equals("/SUN"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test280");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                                                                       /Users/sophie");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test281");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "oRACLE ...", (java.lang.CharSequence) "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar" + "'", str2.equals("/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test283");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test284");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars(" HotSpot(TM) 6 -Bit Server ", "Oracle Corporation", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aHaaSaaa(TM)a6a-BaaaSaavaaa" + "'", str3.equals("aHaaSaaa(TM)a6a-BaaaSaavaaa"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test285");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean4 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion7);
        boolean boolean10 = javaVersion6.atLeast(javaVersion7);
        boolean boolean11 = javaVersion5.atLeast(javaVersion7);
        java.lang.String str12 = javaVersion7.toString();
        org.apache.commons.lang3.JavaVersion javaVersion13 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion14 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
        boolean boolean16 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
        boolean boolean17 = javaVersion13.atLeast(javaVersion14);
        boolean boolean18 = javaVersion7.atLeast(javaVersion14);
        boolean boolean19 = javaVersion0.atLeast(javaVersion14);
        boolean boolean20 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
        boolean boolean21 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion14);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.9" + "'", str12.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion13 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion13.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion14 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion14.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test286");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("sun.lwawt.macosx.CPrinterJob", "/SUN");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test288");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn#_v31cq2n2x1n#fc0000gn/T/", "form API Specificatio", 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test289");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 32, (float) 100, 200.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test290");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "/", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test291");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', 12, 2);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test292");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.8");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test293");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("HI", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test294");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj[[aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa[[jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa[[jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test295");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 200);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test297");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("form API Specificatio");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "form API Specificatio" + "'", str1.equals("form API Specificatio"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("         JavavP         JavavP  ", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         JavavP         JavavP  " + "'", str2.equals("         JavavP         JavavP  "));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/USEJAVAVP", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USEJAVAVP" + "'", str2.equals("/USEJAVAVP"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test300");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/users/sophie/documlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrets/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/users/sophie/documlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jrets/defects4j/framework/lib/test_glibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreeration/glibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jreeration/randoop-currlibrary/java/javavirtualmachines/jdk1.7.0_80.jdk/contents/home/jret.jar");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test301");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED/lIBRARY/jAVA/jAVAvIRTUALmACHINES" + "'", str1.equals("/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED/lIBRARY/jAVA/jAVAvIRTUALmACHINES"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test302");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "...71_O_X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaaaaaaaaa", 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaa" + "'", str3.equals("aaaaaaaaaa"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("JAVA VIRTUAL MACHINE SPECIFICATION", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str2.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("24.", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24." + "'", str2.equals("24."));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test307");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", "JAVA VIRTUAL MACHINE SPECIFICATION", 21);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro" + "'", str3.equals("            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test308");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("SUN.LWAWT.MACOSX.cpRINTERjOB", 200, "noitaroproC elcaro");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOBnoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaropro" + "'", str3.equals("SUN.LWAWT.MACOSX.cpRINTERjOBnoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaropro"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test309");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar", "", (int) '4');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn#_v31cq2n2x1n#fc0000gn/T/", (java.lang.CharSequence[]) strArray4);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#', (int) (short) 6, (int) (byte) 6);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test310");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("            ...", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("J/v/ HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J/v/ HotSpot(TM) 6-Bit Server VM" + "'", str1.equals("J/v/ HotSpot(TM) 6-Bit Server VM"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test312");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "SPlatform API SpecificationWT.MACOSX.cpRINTERjOBoracle Corporation/Usersoracle Corporation/UsersoracSPlatform API SpecificationWT.MACOSX.cpRINTERjOBoracle Corporation/Usersoracle Corporation/UsersoracSPlatform API SpecificationWT.MACOSX.cpRINTERjOBoracle Corporation/Usersoracle Corporation/Usersorac");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test313");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("51.0", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test314");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "NE", (java.lang.CharSequence) "/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test315");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#" + "'", str1.equals("SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test316");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("noitacificepS IPA mroftalP", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test318");
        double[] doubleArray4 = new double[] { (byte) 1, (byte) -1, '#', (-1.0f) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 35.0d + "'", double6 == 35.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test319");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa", 97, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width with offset is 7");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test320");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "3", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test321");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.4#################################################################################################", (java.lang.CharSequence) "                                                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test322");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "oracle Corporation");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test323");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1.7", "UTF-8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test324");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test325");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/var/folders/_v/6v597zmn#_v31cq2n2x1n#fc0000gn/T/", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.                                                    Mac OS X", 15);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/USR/LIB/JAVA##", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test326");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str4 = javaVersion3.toString();
        boolean boolean5 = javaVersion2.atLeast(javaVersion3);
        boolean boolean6 = javaVersion0.atLeast(javaVersion3);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str9 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.2" + "'", str4.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.2" + "'", str9.equals("1.2"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test327");
        char[] charArray8 = new char[] { '#', '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "VA/JAVAVIRTUALMACHINES/JDK1.7.0_", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test328");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7.0_80-b1", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test329");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("####################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################" + "'", str1.equals("####################################################"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test331");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                   ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/USR/LIB/JAVA", "M");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USR/LIB/JAVA" + "'", str2.equals("/USR/LIB/JAVA"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test333");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EX", "                                ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test334");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 6, (short) 3, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########PvavaJ         #########:PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########", "                                                          Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########PvavaJ         #########:PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########" + "'", str2.equals("PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########PvavaJ         #########:PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########PvavaJ         ##########"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test336");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4.", "SUNLLWAWTLMACOSXLcpRINTERjOBLASS JAVALIOLfILECLASS [lJAVALLANGLsTRING;CLASS [lJAVALLANGLsTRING;CLASS JAVALIOLfILECLASS [[");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test337");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("mixed mode", (int) (short) 6, "TnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test338");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "O caM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test339");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "###1.7####");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test340");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test341");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("1.2");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.2\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test342");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("###1.7#                                                                                                 ", "aaahi!aaaa                                                                                          ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test343");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                                                   java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                   JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str1.equals("                                                                   JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test344");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("M OS X");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test345");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 10, (byte) 10, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test346");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("10.14.", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test347");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.4                          ", (java.lang.CharSequence) "noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.5                                                 ", "PvavaJ         ##########");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5                                                 " + "'", str2.equals("1.5                                                 "));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test349");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS ", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS " + "'", str2.equals("SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS "));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test350");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("NE", 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 21, (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test351");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "oracle Corporation/Users/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test352");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "6", (java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test353");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, "4.80-b112", 2, 42);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test354");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test355");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "0.25", (java.lang.CharSequence) "SPlatform API SpecificationWT.MACOSX.cpRINTERjOBoracle Corporation/Usersoracle Corporation/Usersorac");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "0.25" + "'", charSequence2.equals("0.25"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test356");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "JavaVirtualMachineSpecification", 97, 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 26 + "'", int3 == 26);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("", "oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("1.6", "1.7.0_80-b15");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test359");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "..." + "'", str1.equals("..."));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test360");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split(" ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test361");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "Oracle ...");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '4');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test362");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EX");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: /LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EX is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test363");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("va/javavirtualmachines/jdk                               sophie.0_");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "va/javavirtualmachines/jdk                               sophie.0_" + "'", str1.equals("va/javavirtualmachines/jdk                               sophie.0_"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test364");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server V", 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test365");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test366");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("        M71_O_X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:         M71_O_X is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test367");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("O caM", "24.80-b11");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test368");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636", "");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "               ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test369");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("              [[j              ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test370");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                     ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test371");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test372");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test373");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("tnemnorivnE emitnuR ES )MT(avaJ", "ORPORATION", 23);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle(":", "SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":" + "'", str3.equals(":"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test375");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("h ", "aJava HotSpot(TM) 64-Bit Server VMa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test376");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "hi#!", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test377");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("SUN.LWAWT.MACOSX.lwctOOLKIT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test378");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(66, 300, 15);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test379");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "va/javavirtualmachines/jdk                               sophie.0_");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test380");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "###1.7#                                                                                                 ", (java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("1.7.0_80", "5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test382");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "JAVAVP", (java.lang.CharSequence) "                                                                  ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test383");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test384");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                  ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test385");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("aaahi!aaaa                                                                                          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: aaahi!aaaa                                                                                           is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test386");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "USERS", (java.lang.CharSequence) "US", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test387");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "NE", "/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSED/lIBRARY/jAVA/jAVAvIRTUALmACHINES");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test388");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.7.0_80-B15", "###1.7#######1.7#######1hi!###1.7#######1.7#######1.", (int) (byte) 6, 12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_###1.7#######1.7#######1hi!###1.7#######1.7#######1." + "'", str4.equals("1.7.0_###1.7#######1.7#######1hi!###1.7#######1.7#######1."));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("   ", 0, 300);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "   " + "'", str3.equals("   "));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test390");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("SUN.LWAWT.MACOSX.lwctOOLKIT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: SUN.LWAWT.MACOSX.lwctOOLKIT is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test391");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test392");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "SPlatform API SpecificationWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test393");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence) "                               sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test394");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(21, 0, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("1.4                          ", "eihpos");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eihpos" + "'", str2.equals("eihpos"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test396");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Mac", (java.lang.CharSequence) "/Users/sophie/Documents/defects");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test397");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("1.5                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.5" + "'", str1.equals("1.5"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test398");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test399");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkit", ":", 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "          24.8/-b11                     sophie");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str5.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test400");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("hi#!", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test401");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("...                                ", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test402");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("noitacificepS IPA mroftalP");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"noitacif\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test403");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test404");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("[[j");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[[j" + "'", str1.equals("[[j"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test405");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(" Platform API Specificatio", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test406");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test407");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/SUN");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test408");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/SUN", (long) 300);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 300L + "'", long2 == 300L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test409");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaroJAVA VIRTUAL MACHINE SPECIFICATION            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test410");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("24.8/-b11", "/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar", "1.7.0_80-b1", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "24.8/-b11" + "'", str4.equals("24.8/-b11"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test411");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java Virtual Machine Specification                                ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 66 + "'", int1 == 66);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test412");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 10, 8, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("h", "aaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "h" + "'", str2.equals("h"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test414");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "MAC OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test415");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test416");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str4 = javaVersion1.toString();
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean6 = javaVersion1.atLeast(javaVersion5);
        java.lang.String str7 = javaVersion1.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.2" + "'", str4.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.2" + "'", str7.equals("1.2"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test417");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str1.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test418");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test419");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMc OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test420");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test421");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("52.0", "M", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test422");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80", 52, 9);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "aaaaaaaaa1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str4.equals("aaaaaaaaa1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test423");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ", 21);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                " + "'", str2.equals("              ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                "));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test424");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test425");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("...k1.7.0_...", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test426");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean5 = javaVersion1.atLeast(javaVersion2);
        boolean boolean6 = javaVersion0.atLeast(javaVersion2);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        java.lang.String str8 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.9" + "'", str8.equals("0.9"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test427");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("Java Platfor");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Platfor" + "'", str1.equals("Java Platfor"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test428");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie", "SUN.LWAWT.MACOSX.cpRINTERjOBLASS JAVA.IO.fILECLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS JAVA.IO.fILECLASS [[");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test429");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("4_V31CQ2N2X1N4FC0000GN/t");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4_V31CQ2N2X1N4FC0000GN/t" + "'", str1.equals("4_V31CQ2N2X1N4FC0000GN/t"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test430");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "x86_6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test431");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "sophie");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "VA/JAVAVIRTUALMACHINES/JDK1.7.0_", (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa");
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Mac OS X10.14.10.14.10.14.10.14.10.", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test432");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "noitaroproCelcaroaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test433");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Mac OS ", "va/javavirtualmachines/jdk#.0_", " HotSpot(TM) 6 -Bit Server ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test434");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "1.4#################################################################################################", (java.lang.CharSequence) "h");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test435");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                     ", "               ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                                                          Mac OS ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                          Mac OS " + "'", str2.equals("                                                          Mac OS "));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test437");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                                                                  ", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test438");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "eihpos", (java.lang.CharSequence) "6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test439");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("", "0.25");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0.25" + "'", str2.equals("0.25"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "JavavP         JavavP");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test441");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/LIBRARY/JAVA/JAVAV####S#", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test442");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "                                                          Mac OS ", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test443");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "             " + "'", str1.equals("             "));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("oRACLE ...", "         ", 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ..." + "'", str3.equals("oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ...         oRACLE ..."));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test445");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 32, (double) 42, (double) 2L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test446");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("ne");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"ne\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("3", "http://java.oracle.com/1.4");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test448");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj[[aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "JavavP         JavavP", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test449");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Java HotSpot(TM) 64-Bit Server V", "SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS ", "PVAVAJESU/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JvHotPot(U)64-itPerverV" + "'", str3.equals("JvHotPot(U)64-itPerverV"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test450");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("PVAVAJESU/", 6, "ORACLE CORPORATION/USERS");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PVAVAJESU/" + "'", str3.equals("PVAVAJESU/"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test451");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("SUN.LWAWT.MACOSX.cpRINTERjOBnoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaropro", (int) (byte) -1, "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOBnoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaropro" + "'", str3.equals("SUN.LWAWT.MACOSX.cpRINTERjOBnoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaroproC elcaronoitaropro"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test452");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("################################", "aHaaSaaa(TM)a6a-BaaaSaavaaa", (int) (short) 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("                        oracle Corp         JavavP         JavavP  ", "eihpo");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                        oracle Corp         JavavP         JavavP  " + "'", str2.equals("                        oracle Corp         JavavP         JavavP  "));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test454");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("####S#                                                                                                                                                                                                          ", "                1.0 0                1.7.0_80", "1.4", 37);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "####S#                                                                                                                                                                                                          " + "'", str4.equals("####S#                                                                                                                                                                                                          "));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test455");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Mac OS X10.14.10.14.10.14.10.14.10.", (java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test456");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 34, (float) 4, 3.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.0f + "'", float3 == 3.0f);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("OCUMENTS/DEFECTS4J/FRAMEWORK/LIB/T", 3, "1.4");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "OCUMENTS/DEFECTS4J/FRAMEWORK/LIB/T" + "'", str3.equals("OCUMENTS/DEFECTS4J/FRAMEWORK/LIB/T"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test458");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test459");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) -1, 0.0f, (float) 0L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test460");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "M OS X", (java.lang.CharSequence) "...                          ...", 300);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 30 + "'", int3 == 30);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test461");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " ", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test462");
        java.lang.String[] strArray2 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(strArray2);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        java.lang.String[] strArray6 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(strArray6);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray2, strArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, "                                                                                       /Users/sophie", 300, 25);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.7.0_80" + "'", str7.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test463");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "ONLIBRARY/JA", 8, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test464");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test465");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("aHaaSaaa(TM)a6a-BaaaSaavaaa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test466");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("####S#");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test467");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("###1.7#######1.7#######1hi!###1.7#######1.7#######1.");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test468");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("sun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test469");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("JavaVirtualMachineSpecification", "", "va/javavirtualmachines/jdk#.0_", 193);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JavaVirtualMachineSpecification" + "'", str4.equals("JavaVirtualMachineSpecification"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test470");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/JAVAVP4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test471");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/USERS/SOPNEE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", (int) (short) 10, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USERS/SOPNEE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str3.equals("/USERS/SOPNEE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test472");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 1, (byte) 10, (byte) -1, (byte) 100, (byte) 1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 100 + "'", byte12 == (byte) 100);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test473");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test474");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "24.80-b112");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test475");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "...                          ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test476");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Mac OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test477");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 200, (long) 5, 300L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 300L + "'", long3 == 300L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test478");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "\n", (java.lang.CharSequence) "oracle corporation", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test479");
        java.lang.CharSequence charSequence3 = null;
        char[] charArray7 = new char[] { '4', ' ' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone(charSequence3, charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                                                          Mac OS X", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "3", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1.7", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test480");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "pnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("pnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test481");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("Oracle ...");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test482");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("NOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRO", "/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test483");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Mac OS", "OCUMENTS/DEFECTS4J/FRAMEWORK/LIB/T", 52);
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test484");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java(TM) SE Runtime Environment");
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("ne", strArray3, strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java Virtual Machine Specification");
        boolean boolean12 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence[]) strArray11);
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.substringsBetween("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "aaa");
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "          24.8/-b11                     sophie", (java.lang.CharSequence[]) strArray17);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("oracle Corporation", strArray11, strArray17);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("6", strArray3, strArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 10 vs 11");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ne" + "'", str5.equals("ne"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str7.equals("Java(TM) SE Runtime Environment"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "oracle Corporation" + "'", str19.equals("oracle Corporation"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("################################", "ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test486");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 1, (long) 13, (long) 7);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test487");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444" + "'", str1.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("LIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JA", (int) (short) -1, (int) ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test490");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("JavavP", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Javav" + "'", str2.equals("Javav"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("noitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitar" + "'", str2.equals("noitar"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test493");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("oracle Corporation/Users");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporation/users" + "'", str1.equals("oracle corporation/users"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test494");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("oracle corporation/users", "ORACLE CORPORATION/USERS", "PvavaJ         ##########");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test495");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("VA/JAVAVIRTUALMACHINES/JDK1.7.0_", (long) 121);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 121L + "'", long2 == 121L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test496");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aJava HotSpot(TM) 64-Bit Serv...", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test497");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 2.0f, (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test498");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                                                   JAVA HOTSPOT(TM) 64-BIT SERVER VM", 42, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                   JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str3.equals("                                                                   JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test499");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("oracle Corporation/Users", 0, "ORPORATION                                                                                                                                                                                       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracle Corporation/Users" + "'", str3.equals("oracle Corporation/Users"));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test500");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("n4_v31cq2n2x1n4fc0000gn/T", 51, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa[[jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaan4_v31cq2n2x1n4fc0000gn/Taaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaan4_v31cq2n2x1n4fc0000gn/Taaaaaaaaaaaaa"));
    }
}

