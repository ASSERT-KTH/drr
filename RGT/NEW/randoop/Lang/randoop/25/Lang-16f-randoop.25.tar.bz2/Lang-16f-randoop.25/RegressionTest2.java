import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Oracle ...", (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("x86_64", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.7.0_80-B15", (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("aaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("aJava HotSpot(TM) 64-Bit Server VMa", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aJava HotSpot(TM) 64-Bit Serv..." + "'", str2.equals("aJava HotSpot(TM) 64-Bit Serv..."));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("h");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "H" + "'", str1.equals("H"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aJava HotSpot(TM) 64-Bit Server VMa", 0, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aJava HotSpot(TM) 64-Bit Server VMa" + "'", str3.equals("aJava HotSpot(TM) 64-Bit Server VMa"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ", (java.lang.CharSequence) "aaahi!aaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 1, (long) 'a', (long) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("5", "JAVAVP", (int) (short) 10);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...");
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", strArray3, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 2 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro" + "'", str1.equals("noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "3", 97);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("sun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkit");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"sun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkit\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 10, 0.0f, (float) '4');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray8 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(strArray8);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String[] strArray12 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(strArray12);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray12);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray8, strArray12);
        java.lang.String[] strArray17 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(strArray17);
        java.lang.String[] strArray19 = org.apache.commons.lang3.StringUtils.stripAll(strArray17);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray17);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray12, strArray17);
        java.lang.String[] strArray23 = org.apache.commons.lang3.StringUtils.stripAll(strArray12, "51.0");
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("JAVAVP", strArray3, strArray12);
        java.lang.String[] strArray26 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String[] strArray28 = org.apache.commons.lang3.StringUtils.stripAll(strArray26, "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa");
        try {
            java.lang.String str29 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Java Virtual Machine Specification", strArray12, strArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.7.0_80" + "'", str9.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.7.0_80" + "'", str13.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1.7.0_80" + "'", str18.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1.7.0_80" + "'", str20.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hi!" + "'", str21.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "JAVAVP" + "'", str24.equals("JAVAVP"));
        org.junit.Assert.assertNotNull(strArray26);
        org.junit.Assert.assertNotNull(strArray28);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) -1, (int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        java.lang.String[] strArray1 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(strArray1);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80" + "'", str4.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("va/javavirtualmachines/jdk1.7.0_");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "va/javavirtualmachines/jdk1.7.0_" + "'", str1.equals("va/javavirtualmachines/jdk1.7.0_"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "##################################################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("1.7");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                               sophie", "0.9", "sun.lwawt.macosx.CPrinterJoblass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                               sophie" + "'", str3.equals("                               sophie"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, ' ', 0, 10);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 7, (long) 32, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " Platform API Specification", "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("JAVAVP", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JAVAVP" + "'", str2.equals("JAVAVP"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("oRACLE cORPORATION", 1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oRACLE cORPORATION" + "'", str3.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong(" Platform API Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" Platform API Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "JavaVirtualMachineSpecification", (java.lang.CharSequence) ".7.0_801.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", (java.lang.CharSequence) "Oracle ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("JAVAVP", 25, (int) 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JAVAVP" + "'", str3.equals("JAVAVP"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############" + "'", str2.equals("###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("5", "oracle Corporation                 ", "M OS X");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "", (java.lang.CharSequence) "x86_6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("oracle Corporation                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle Corporation" + "'", str1.equals("oracle Corporation"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "##################################################################", (java.lang.CharSequence) "ne", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mixed mode", "1.2", 35);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("5");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "5" + "'", str1.equals("5"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("UTF-8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"UTF-8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS ", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.7.0_80-b1", "1.2", (int) ' ', (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.2" + "'", str4.equals("1.2"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/", "sun.lwawt.macosx.CPrinterJob", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/" + "'", str3.equals("/"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 6, 0L, (long) 200);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa");
        java.lang.Class<?> wildcardClass4 = strArray1.getClass();
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "va/javavirtualmachines/jdk1.7.0_");
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray6, '#', (-1), 15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("en", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#", "en");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#" + "'", str2.equals("SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/USERS/SOPHIE", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE" + "'", str2.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Mac OS ", (java.lang.CharSequence) "10.14.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "####S#", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0", "1.2");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("                1.0 0                ", 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("aaahi!aaaa", strArray4, strArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "aaahi!aaaa" + "'", str8.equals("aaahi!aaaa"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("oRACLE cORPORATION", "va/javavirtualmachines/jdk1.7.0_", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oRACLE cORPORATION" + "'", str3.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10, (double) 10.0f, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[J");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[J" + "'", str1.equals("class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[J"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3" + "'", str1.equals("3"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("1.7.0_80-b15", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 31, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar", (java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("Java Virtual Machine Specification                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java Virtual Machine Specification" + "'", str1.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double[] doubleArray4 = new double[] { (byte) 1, (byte) -1, '#', (-1.0f) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("J/v/ HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"J/v/ HotSpot(TM) 64-Bit Server VM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("J/v/ HotSpot(TM) 64-Bit Server VM", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J/v/ HotSpot(TM) 6-Bit Server VM" + "'", str2.equals("J/v/ HotSpot(TM) 6-Bit Server VM"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) ":", 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/var/folders/_v/6v597zmn#_v31cq2n2x1n#fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "4444444444444444444444444444444", (java.lang.CharSequence) "Java(TM) SE Runtime Environment", 193);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("Java HotSpot(TM) 64-Bit Server VM", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                   Java HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("                                                                   Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        long[] longArray5 = new long[] { ' ', (short) 10, '#', 100, 10 };
        long long6 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray5);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray5);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "aaahi!aaaa", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("                               sophie", 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) '4', (long) 32, (long) 37);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 32L + "'", long3 == 32L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", 97, 66);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "                1.0 0                ", (java.lang.CharSequence) "Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("JavavP", "                                                          Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("1.7", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort(":2", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "aJava HotSpot(TM) 64-Bit Serv...", "1.7.0_80-b1");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("va/javavirtualmachines/jdk1.7.0_", "5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "va/javavirtualmachines/jdk1.7.0_" + "'", str2.equals("va/javavirtualmachines/jdk1.7.0_"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 1, (byte) 10, (byte) -1, (byte) 100, (byte) 1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80-b15" + "'", str1.equals("1.7.0_80-b15"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("24.8/-b11", "SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.8/-b11" + "'", str2.equals("24.8/-b11"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "oracle Corporation                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("oracle Corporation", 25, "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracle Corporation/Users/" + "'", str3.equals("oracle Corporation/Users/"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", "oracle Corporation/Users/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro" + "'", str2.equals("                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 66);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("Mac OS ", "LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                          Mac OS X", 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                          Mac OS X" + "'", str3.equals("                                                          Mac OS X"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X" + "'", str1.equals("Mac OS X"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaaaaaaaaa", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "5", (java.lang.CharSequence) "SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("                1.0 0                ", 'a');
        java.lang.String[] strArray8 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(strArray8);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        java.lang.String[] strArray12 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(strArray12);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray12);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray8, strArray12);
        int int16 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray12);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("24.8/-b11", strArray3, strArray12);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.7.0_80" + "'", str9.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.7.0_80" + "'", str13.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 37 + "'", int16 == 37);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "24.8/-b11" + "'", str18.equals("24.8/-b11"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("", "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "J/v/ HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) ":", (java.lang.CharSequence) "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa", (java.lang.CharSequence) "1.1", 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("sun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                                   Java HotSpot(TM) 64-Bit Server VM", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                   Java HotSpot(TM) 6-Bit Server VM" + "'", str2.equals("                                                                   Java HotSpot(TM) 6-Bit Server VM"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/USEJAVAVP");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("10.14.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14." + "'", str1.equals("10.14."));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("US", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("###################################", "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###################################" + "'", str2.equals("###################################"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.7.0_80-b15", "                                                                   Java HotSpot(TM) 64-Bit Server VM", "/USERS/SOPHIE");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("mixed mode", (int) (short) 0, "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("JavaVirtualMachineSpecification", "http://java.oracle.com/1.7.0_801.7.0_801.7.0_801.7.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("5", "sun.lwawt.macosx.CPrinterJoblass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5" + "'", str2.equals("5"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "Java Virtual Machine Specification                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4" + "'", str2.equals("/Users/sophie/Documents/defects4"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", 51.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 51.0f + "'", float2 == 51.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                1.0 0                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message:                 1.0 0                 is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE cORPORATION" + "'", str1.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "VA/JAVAVIRTUALMACHINES/JDK1.7.0_");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/USEJAVAVP", 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("ne");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NE" + "'", str1.equals("NE"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Mac OS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "0", "mixed mode");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.5", "H", "");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("1.7", (int) (short) 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###1.7####" + "'", str3.equals("###1.7####"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("4444444444444444444444444444444", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("                               sophie", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            ..." + "'", str2.equals("            ..."));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("            ...", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 66 + "'", int1 == 66);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle Corporation" + "'", str1.equals("oracle Corporation"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("http://java.oracle.com/", "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("Oracle ...", "J/v/ HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle ..." + "'", str2.equals("Oracle ..."));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("0", "####S#", 200, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "####S#" + "'", str4.equals("####S#"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8AAAAAAAAAA" + "'", str1.equals("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8AAAAAAAAAA"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[J", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase(".7.0_801.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "                                   ", "/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("http://java.oracle.com/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"http://java.oracle.com/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "                                                                   Java HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro", "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro" + "'", str2.equals("noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Virtual Machine Specification", (java.lang.CharSequence) "va/javavirtualmachines/jdk1.7.0_", 200);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", (int) (byte) 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("x86_64", "J/v/ HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[" + "'", str1.equals("class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [["));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) " Platform API Specification", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("oracle Corporation                 ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "                                                          Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Ora1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Ora1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa" + "'", str2.equals("Ora1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("J/v/ HotSpot(TM) 6-Bit Server VM", " Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Platform API Specification" + "'", str2.equals(" Platform API Specification"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "M OS X", charSequence1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.2", "                                ...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("JavavP", "M OS X", "Oracle Corporation");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("VA/JAVAVIRTUALMACHINES/JDK1.7.0_");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "          ", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1.7.0_80", 200, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("JAVAVP");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: JAVAVP is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("0.9");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.9" + "'", str1.equals("0.9"));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) '#', 13);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...k1.7.0_..." + "'", str3.equals("...k1.7.0_..."));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("sun.lwawt.macosx.CPrinterJob", 193);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean5 = javaVersion1.atLeast(javaVersion2);
        boolean boolean6 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str7 = javaVersion2.toString();
        java.lang.String str8 = javaVersion2.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0.9" + "'", str8.equals("0.9"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Mac OS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("10.14.", "Mac OS");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "AAAHI!AAAA", charSequence1, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "VA/JAVAVIRTUALMACHINES/JDK1.7.0_");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("AAAHI!AAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAHI!AAAA" + "'", str1.equals("AAAHI!AAAA"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, (long) 3, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#" + "'", str1.equals("sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[J", 15, "1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[J" + "'", str3.equals("class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[J"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("en", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihpos" + "'", str1.equals("eihpos"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.0 0", 15, 200);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.0 0" + "'", str3.equals("1.0 0"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        short[] shortArray1 = new short[] { (byte) 100 };
        short short2 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray1);
        org.junit.Assert.assertNotNull(shortArray1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB", (java.lang.CharSequence) " Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "####S#", (java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1.6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJoblass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("oracle Corporation", 66, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                        oracle Corporation                        " + "'", str3.equals("                        oracle Corporation                        "));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.                                                    Mac OS X", "VA/JAVAVIRTUALMACHINES/JDK1.7.0_");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("mixed mode");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"m\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                               sophie", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                               sophie" + "'", str2.equals("                               sophie"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.7.0_80-B15", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-B15" + "'", str2.equals("1.7.0_80-B15"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(31, 0, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("oRACLE cORPORATION", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORPORATION" + "'", str2.equals("ORPORATION"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.0 0", "VA/JAVAVIRTUALMACHINES/JDK1.7.0_");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("JavavP", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavavP" + "'", str2.equals("JavavP"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("LIBRARY/JoRACLE cORPORATIONLIBRARY/JA", 31);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "LIBRARY/JoRACLE cORPORATIONLIBRARY/JA" + "'", str2.equals("LIBRARY/JoRACLE cORPORATIONLIBRARY/JA"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 1L, (double) 35.0f, (double) '#');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("1.6", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.6f + "'", float2 == 1.6f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (byte) 10, (long) '#', (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("          ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[J", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[[J" + "'", str2.equals("[[J"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", 'a');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("###1.7####");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###1.7####\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                        oracle Corporation                        ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle Corporation" + "'", str1.equals("oracle Corporation"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("sun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.7.0_80", "                1.0 0                ", (int) (short) 0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                1.0 0                1.7.0_80" + "'", str4.equals("                1.0 0                1.7.0_80"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("sun.lwawt.macosx.CPrinterJoblass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[" + "'", str1.equals("sun.lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [["));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        org.apache.commons.lang3.JavaVersion javaVersion0 = null;
        try {
            boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("oracle Corporation", "Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle Corporation" + "'", str2.equals("oracle Corporation"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("                                ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...                                " + "'", str1.equals("...                                "));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("                                                          Mac OS X", "1.7.0_80", 37);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               1.7.0_80      Mac OS X" + "'", str3.equals("               1.7.0_80      Mac OS X"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "j:tjtt3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#", 32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.5", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.5                                                 " + "'", str2.equals("1.5                                                 "));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Users/sophie", "JAVAVP", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie" + "'", str3.equals("/Users/sophie"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############" + "'", str1.equals("###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USR/LIB/JAVA" + "'", str2.equals("/USR/LIB/JAVA"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (float) (short) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "oracle Corporation");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "24.80-b11", (int) '#', (int) (short) 3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("                        oracle Corporation                        ", "h", "tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                        oracle Corporation                        " + "'", str3.equals("                        oracle Corporation                        "));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("aJava HotSpot(TM) 64-Bit Server VMa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("1.0 0", 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#", (java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "/USR/LIB/JAVA", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        float[] floatArray6 = new float[] { (short) 1, 10, 66, 0, (short) 1, (byte) 10 };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 66.0f + "'", float7 == 66.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 66.0f + "'", float8 == 66.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.0f + "'", float9 == 0.0f);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("###################################", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("oracle Corporation/Users/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle Corporation/Users" + "'", str1.equals("oracle Corporation/Users"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) -1, 0L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", charSequence2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1.6f, (-1.0d), (double) (-1));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.600000023841858d + "'", double3 == 1.600000023841858d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3" + "'", str1.equals("3"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "H");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        float[] floatArray4 = new float[] { 1.0f, 3, 7, 66L };
        float[] floatArray9 = new float[] { 1.0f, 3, 7, 66L };
        float[] floatArray14 = new float[] { 1.0f, 3, 7, 66L };
        float[] floatArray19 = new float[] { 1.0f, 3, 7, 66L };
        float[][] floatArray20 = new float[][] { floatArray4, floatArray9, floatArray14, floatArray19 };
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(floatArray20);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "x86_64", (int) (short) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("UTF-8", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 1);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByCharacterType("Java(TM) SE Runtime Environment");
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("###################################", strArray4, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 13");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", 25);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "n4_v31cq2n2x1n4fc0000gn/T" + "'", str2.equals("n4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                                                   Java HotSpot(TM) 64-Bit Server VM", "j:tjtt3");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("AAAHI!AAAA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAHI!AAAA" + "'", str1.equals("AAAHI!AAAA"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "", 37);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "          24.8/-b11                     sophie", (java.lang.CharSequence) "J/v/ HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("##################################################################", 0, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "################################" + "'", str3.equals("################################"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        char[] charArray4 = new char[] { '4', ' ' };
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.6", charArray4);
        org.junit.Assert.assertNotNull(charArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/", (java.lang.CharSequence) "/USR/LIB/JAVA", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("LIBRARY/JoRACLE cORPORATIONLIBRARY/JA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LIBRARY/JoRACLE cORPORATIONLIBRARY/JA" + "'", str1.equals("LIBRARY/JoRACLE cORPORATIONLIBRARY/JA"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("1.2", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########" + "'", str2.equals("##########"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "US", "sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "###1.7####", (java.lang.CharSequence) "n4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("##################################################################", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########..." + "'", str2.equals("##########..."));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: A blank string is not a valid number");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween(".7.0_801.", "NE");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("               1.7.0_80      Mac OS X", (int) (byte) 1, "                                                          Mac OS X");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               1.7.0_80      Mac OS X" + "'", str3.equals("               1.7.0_80      Mac OS X"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "aaa", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MAC OS X" + "'", str1.equals("MAC OS X"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaa", 13, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("aaa", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("/USERS/SOPHIE", "                        oracle Corporation                        ", "NE", 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/USERS/SOPHIE" + "'", str4.equals("/USERS/SOPHIE"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "AAAHI!AAAA", (java.lang.CharSequence) "ne");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specification                                ", "UTF-8");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1.7.0_80-B15");
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "oracle Corporation                 ", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8AAAAAAAAAA");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 100, (long) (byte) -1, (long) 25);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7", "aaahi!aaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("Ora1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie", "", (int) 'a');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "", 15, 2);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) 10, "24.80-b11");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b112" + "'", str3.equals("24.80-b112"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(35, 10, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sun.lwawt.macosx.CPrinterJob", "UTF-8", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa", (java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 32.0f, (-1.0d), (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "oRACLE cORPORATION", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("24.80-b11", "sun.lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[", 6);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                   Java HotSpot(TM) 6-Bit Server VM", (java.lang.CharSequence) "LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Virtual Machine Specificatio", 15, "            ...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Virtual Machine Specificatio" + "'", str3.equals("Java Virtual Machine Specificatio"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str1.equals("SUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "1.5                                                 ", "##########...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                                                          Mac OS X", "JavavP", "...                                ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "################################" + "'", str2.equals("################################"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("11");
        org.junit.Assert.assertNotNull(bigInteger1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", "0.9");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", ":", (int) (short) 10);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", strArray3, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("hi!", (int) (byte) 100, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("aJava HotSpot(TM) 64-Bit Server VMa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("oracle Corporation                 ", 25, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "oracle Corporation                 " + "'", str3.equals("oracle Corporation                 "));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) (byte) 100, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                1.0 0                ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("aaa", (int) (byte) 0, "ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaa" + "'", str3.equals("aaa"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", charSequence1, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("sophie", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie" + "'", str3.equals("sophie"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("51.0", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "##########...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "a", (java.lang.CharSequence) "Ora1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (java.lang.CharSequence) ".7.0_801.", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "x86_64", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("H", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "####S#");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "ne", 10, 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str4.equals("/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace(" Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Platform API Specification" + "'", str1.equals("Platform API Specification"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ":2", (java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                                                   Java HotSpot(TM) 64-Bit Server VM", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "                               sophie");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[", (java.lang.CharSequence) "Mac OS ", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPNEE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR" + "'", str1.equals("/USERS/SOPNEE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1.5", 0, " Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5" + "'", str3.equals("1.5"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 35.0f, (double) 100L, (double) 3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("US");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("JavaVirtualMachineSpecification", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JavaVirtualMachineSpecification" + "'", str2.equals("JavaVirtualMachineSpecification"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("10.14.3", "Java Platform API Specification");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10.14.3" + "'", str4.equals("10.14.3"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("...k1.7.0_...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...k1.7.0_..." + "'", str1.equals("...k1.7.0_..."));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro" + "'", str1.equals("noitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("x86_64");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x86_64\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (int) (byte) 0, 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java(TM) SE Runtime Environment", "51.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("aaahi!aaaa", "0", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (java.lang.CharSequence) "                1.0 0                ", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aJava HotSpot(TM) 64-Bit Serv...");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("24.80-b112", 1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4.80-b112" + "'", str3.equals("4.80-b112"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/USERS/SOPNEE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", (java.lang.CharSequence) "eihpos");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("/", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Java Virtual Machine Specification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...", "                                                                                       /Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension..." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension..."));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Platform API Specification", 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "n4_v31cq2n2x1n4fc0000gn/T", 193);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("24.8/-b11", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "...                                ", (java.lang.CharSequence) "24.80-b112", 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 34 + "'", int3 == 34);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.7.0_80-b1", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sun.lwawt.macosx.CPrinterJob", "J/v/ HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        double[] doubleArray4 = new double[] { (byte) 1, (byte) -1, '#', (-1.0f) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double10 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 35.0d + "'", double10 == 35.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1.5                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                                                   Java HotSpot(TM) 6-Bit Server VM", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepS IPA mroftalP" + "'", str1.equals("noitacificepS IPA mroftalP"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("oracle Corporation/Users");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORACLE CORPORATION/USERS" + "'", str1.equals("ORACLE CORPORATION/USERS"));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "...                                ", 193, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 35, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = null;
        char[] charArray7 = new char[] { '#', 'a' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "24.80-b11", charArray7);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence2, charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray7);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.7.0_80-b15", "1.8");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 100, (short) 0, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "UTF-8", "VA/JAVAVIRTUALMACHINES/JDK1.7.0_");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", "ORACLE CORPORATION/USERS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (-1.0d), 100.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("####S#", (-1), "51.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####S#" + "'", str3.equals("####S#"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "J/v/ HotSpot(TM) 6-Bit Server VM", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", ":", (int) (short) 10);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80" + "'", str6.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        char[] charArray7 = new char[] { '#', '#' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray7);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaahi!aaaa                                                                                          ", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "oracle Corporation                 ", charArray7);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8AAAAAAAAAA", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "a", charArray7);
        java.lang.Class<?> wildcardClass13 = charArray7.getClass();
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(1.0d, (double) 193, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("1.8");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.8\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("1.7.0_80-b1", "0.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b1" + "'", str2.equals("1.7.0_80-b1"));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("", 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "1.5                                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA", "11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA" + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "                                ...", "################################");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("aaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Ora1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("oracle Corporation/Users");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle Corporation/Users" + "'", str1.equals("oracle Corporation/Users"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("JavavP", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         JavavP" + "'", str2.equals("         JavavP"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "aaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "51.0", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar" + "'", str3.equals("/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Platform API Specification", 100, 2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("oracle Corporation/Users", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("[[J");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[[j" + "'", str1.equals("[[j"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "         JavavP", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "sun.lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("5", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5" + "'", str2.equals("5"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("/");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"noi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi" + "'", str1.equals("hi"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "################################" + "'", str1.equals("################################"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("H");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "H" + "'", str1.equals("H"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "            ...", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "en", (java.lang.CharSequence) "5");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("AAAHI!AAAA");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AAAHI!AAAA" + "'", str3.equals("AAAHI!AAAA"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        short[] shortArray2 = new short[] { (short) 100, (byte) 100 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "1.7.0_80-B15", (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("ne", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("          ", (int) (short) -1, 15);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "          " + "'", str3.equals("          "));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("10.14.", "24.8/-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10.14." + "'", str2.equals("10.14."));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("0.9", (int) 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("################################", "ORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORPORATION" + "'", str2.equals("ORPORATION"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("5", "JAVAVP", (int) (short) 10);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "Java Platform API Specification", (int) (short) 100, 31);
        java.lang.Class<?> wildcardClass10 = strArray5.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("a", "1.6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a" + "'", str2.equals("a"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java Virtual Machine Specificatio", (java.lang.CharSequence) "/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "j:tjtt3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("");
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("sun.lwawt.macosx.CPrinterJoblass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOBLASS JAVA.IO.fILECLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS JAVA.IO.fILECLASS [[" + "'", str1.equals("SUN.LWAWT.MACOSX.cpRINTERjOBLASS JAVA.IO.fILECLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS JAVA.IO.fILECLASS [["));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("tnemnorivnE emitnuR ES )MT(avaJ", "Oracle Corporation", (int) 'a');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.0 0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray2);
        java.lang.Class<?> wildcardClass4 = strArray2.getClass();
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.5", "5", 15);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("x86_64", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator(".7.0_801.", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str2 = javaVersion1.toString();
        boolean boolean3 = javaVersion0.atLeast(javaVersion1);
        java.lang.Class<?> wildcardClass4 = javaVersion0.getClass();
        java.lang.String str5 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.5" + "'", str5.equals("1.5"));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "oracle Corporation", (java.lang.CharSequence) "                                ...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("http://java.oracle.com/", "10.14.3", "JavaVirtualMachineSpecification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "http://java.oracle.com/" + "'", str3.equals("http://java.oracle.com/"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.4", (int) (short) 10, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("##########", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "##########     " + "'", str2.equals("##########     "));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.                                                    Mac OS X", 35);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "...k1.7.0_...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", " Platform API Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro" + "'", str2.equals("                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("oracle Corporation", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 3, (short) (byte) -1, (short) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 3 + "'", short3 == (short) 3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "noitacificepS IPA mroftalP", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi" + "'", str1.equals("hi"));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn#_v31cq2n2x1n#fc0000gn/T/", (java.lang.CharSequence) "Java Virtual Machine Specification", 37);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("SUN.LWAWT.MACOSX.cpRINTERjOBLASS JAVA.IO.fILECLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS JAVA.IO.fILECLASS [[");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.5                                                 ", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("Mac OS X", "class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[", "1.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "M71_O_X" + "'", str3.equals("M71_O_X"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("####S#", 25, "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/LIBRARY/JAVA/JAVAV####S#" + "'", str3.equals("/LIBRARY/JAVA/JAVAV####S#"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                   Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                   java hotspot(tm) 64-bit server vm" + "'", str1.equals("                                                                   java hotspot(tm) 64-bit server vm"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "oracle Corporation", (java.lang.CharSequence) "aaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("VA/JAVAVIRTUALMACHINES/JDK1.7.0_", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VA/JAVAVIRTUALMACHINES/JDK1.7.0_" + "'", str2.equals("VA/JAVAVIRTUALMACHINES/JDK1.7.0_"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("aJava HotSpot(TM) 64-Bit Serv...", "oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java HotSpot(TM) 64-Bit Serv..." + "'", str2.equals("Java HotSpot(TM) 64-Bit Serv..."));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }
}

