import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test01");
        char[] charArray8 = new char[] { '#', '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "5", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "JavavP", charArray8);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie", charArray8);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "LIBRARY/JAVA/JAVAVIRTUA", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test02");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/USERS/SOPHIE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/USERS/SOPHIE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test03");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Java HotSpot(TM) 64-Bit Server V");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java HotSpot(TM) 64-Bit Server V\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test04");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(121L, 0L, 2L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 121L + "'", long3 == 121L);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test05");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/users/sopnee/d/users", (java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test06");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 4.0f, (double) 51.0f, (double) 66.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 66.0d + "'", double3 == 66.0d);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test07");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 18 + "'", int1 == 18);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test08");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (short) 0, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test09");
        java.lang.String[] strArray2 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "aaahi!aaaa                                                                                          ");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "noitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro", (java.lang.CharSequence[]) strArray2);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, " HotSpot(TM) 6 -Bit Server ");
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "oracl\ntion");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7.0_80" + "'", str5.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.7.0_80" + "'", str8.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test10");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa");
        java.lang.Class<?> wildcardClass5 = strArray2.getClass();
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "va/javavirtualmachines/jdk1.7.0_");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(" ");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("/USR/LIB/JAVA##", strArray7, strArray9);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/USR/LIB/JAVA##" + "'", str10.equals("/USR/LIB/JAVA##"));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test11");
        int[] intArray4 = new int[] { 66, (short) 1, (short) 10, 0 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 66 + "'", int6 == 66);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 66 + "'", int10 == 66);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test12");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Corporation Oracle", 31, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test13");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", (java.lang.CharSequence) "   ", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test14");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("oracle Corporation/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Users/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/ENDORSED/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JAVAVP4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...K1.7.0_...                                                                                       /USERS/SOPHIE4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...K1.7.0_...                                                                                       /USERS/SOPHIE4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...K1.7.0_...                                                                                       /USERS/SOPHIE4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...K1.7.0_...                                                                                       /USERS/SOPHIE4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...K1.7.0_...                                                                                       /USERS/SOPHIE4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...K1.7.0_...                                                                                       /USERS/SOPHIE4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...K1.7.0_...                                                                                       /USERS/SOPHIE4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...K1.7.0_...                                                                                       /USERS/SOPHIE4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...K1.7.0_...                                                                                       /USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle Corporation/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Users/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str2.equals("oracle Corporation/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.Users/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test15");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("oracle Corporation                 ", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Corporation oracle" + "'", str2.equals("Corporation oracle"));
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test16");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("noitaroproCelcaroaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test17");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test18");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("PVAVAJESU/", "4.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test19");
        double[] doubleArray2 = new double[] { 0.0d, 0.0f };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test20");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("noitacificepS IPA mroftalP", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test21");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("H", "NOITAROPRO", "Mac O");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test22");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaa", "1.7.0_80");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test23");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "J/v/ HotSpot(TM) 6-Bit Server VM", (java.lang.CharSequence) "Java HotSpot( M) 64 Bit Serv...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test24");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test25");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring(" Platform API Specificatio Platform API Specificatio", 59, 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test26");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "[[J");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test27");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ..." + "'", str1.equals("...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ..."));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test28");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("MacMacMacMacMacMacMacMacMacMacMacMacMacMacMacMa####S#MacMacMacMacMacMacMacMacMacMacMacMacMacMacMacMa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MacMacMacMacMacMacMacMacMacMacMacMacMacMacMacMa####S#MacMacMacMacMacMacMacMacMacMacMacMacMacMacMacMa" + "'", str1.equals("MacMacMacMacMacMacMacMacMacMacMacMacMacMacMacMa####S#MacMacMacMacMacMacMacMacMacMacMacMacMacMacMacMa"));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test29");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Mac OS X10.14.10.14.10.14.10.14.10.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS X10.14.10.14.10.14.10.14.10." + "'", str1.equals("Mac OS X10.14.10.14.10.14.10.14.10."));
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test30");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("Mac OS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac OS" + "'", str1.equals("Mac OS"));
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test31");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("O caM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test32");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "...", (java.lang.CharSequence) "                                   ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test33");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("###1.7####", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test34");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "oracle corporation/users", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test35");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("...                          ...", " Platform API Specificatio");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test36");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("h ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " h" + "'", str1.equals(" h"));
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test37");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (byte) 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test38");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/Users/sophie");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "Oracle Corporation");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "MAC OS ", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray5);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test39");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 1, (byte) 10, (byte) -1, (byte) 100, (byte) 1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test40");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("oracle corporation", "LIBRARY/JORACLE CORPORATIONLIBRARY/JA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oracle corporation" + "'", str2.equals("oracle corporation"));
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test41");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "                               sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test42");
        short[] shortArray2 = new short[] { (short) 100, (byte) 100 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test43");
        short[] shortArray4 = new short[] { (byte) 10, (short) 3, (byte) 6, (short) -1 };
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray4);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray4);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 10 + "'", short5 == (short) 10);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test44");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 0, (byte) 1, (byte) 10, (byte) -1, (byte) 10 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 10 + "'", byte8 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) 10 + "'", byte9 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 10 + "'", byte11 == (byte) 10);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test45");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test46");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/users/sopnee/d/users", 31, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/users/sopnee/d/users##########" + "'", str3.equals("/users/sopnee/d/users##########"));
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test47");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 4, (float) 21L, (float) 23);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 23.0f + "'", float3 == 23.0f);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test48");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("PvavaJ         ##########");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test49");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean5 = javaVersion1.atLeast(javaVersion2);
        boolean boolean6 = javaVersion0.atLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str10 = javaVersion9.toString();
        boolean boolean11 = javaVersion8.atLeast(javaVersion9);
        boolean boolean12 = javaVersion7.atLeast(javaVersion8);
        java.lang.String str13 = javaVersion7.toString();
        boolean boolean14 = javaVersion2.atLeast(javaVersion7);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.2" + "'", str10.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.1" + "'", str13.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test50");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Mac");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mac" + "'", str1.equals("Mac"));
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test51");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.7.0_80-b15", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test52");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.80-b112", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 12);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test53");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1.7.0_80-b1", (java.lang.CharSequence) "                                                                                           oRACLE cORPORATION                                                                                           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test54");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.11.11.11.11.11.11.1", "TF-8", "sun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.11.11.11.11.11.11.1" + "'", str3.equals("1.11.11.11.11.11.11.1"));
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test55");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[", 33, "class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[" + "'", str3.equals("sun.lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [["));
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test56");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines", "oracl\ntion", "sun.lwawt.macosx.CPrinterJoblass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Lwbunuy/Jnvn/JnvnVwuaunlMn.hw.es/jdk1.7.0_80.jdk/Cs.ae.as/Hsme/jue/lwb/e.dsused/Lwbunuy/Jnvn/JnvnVwuaunlMn.hw.es/jdk1.7.0_80.jdk/Cs.ae.as/Hsme/jue/lwb/e.dsused/Lwbunuy/Jnvn/JnvnVwuaunlMn.hw.es" + "'", str3.equals("/Lwbunuy/Jnvn/JnvnVwuaunlMn.hw.es/jdk1.7.0_80.jdk/Cs.ae.as/Hsme/jue/lwb/e.dsused/Lwbunuy/Jnvn/JnvnVwuaunlMn.hw.es/jdk1.7.0_80.jdk/Cs.ae.as/Hsme/jue/lwb/e.dsused/Lwbunuy/Jnvn/JnvnVwuaunlMn.hw.es"));
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test57");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("                               sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test58");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Mac OS ", "VA/JAVAVIRTUALMACHINES/JDK1.7.0_");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS " + "'", str2.equals("Mac OS "));
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test59");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "oitacificepS enihcaM lautriV avaJ", (java.lang.CharSequence) "n4_v31cq2n2x1n4fc0000gn/T", 29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test60");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("SUN.LWAWT.MACOSX.CPRINTERJOBLASS JAVA.IO.FILECLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS JAVA.IO.FILECLASS [[", 12, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJOBLASS JAVA.IO.FILECLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS JAVA.IO.FILECLASS [[" + "'", str3.equals("SUN.LWAWT.MACOSX.CPRINTERJOBLASS JAVA.IO.FILECLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS JAVA.IO.FILECLASS [["));
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test61");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7" + "'", str1.equals("1.7"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test62");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 1, 3374);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test63");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("####S#                                                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####S#" + "'", str1.equals("####S#"));
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test64");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("oRACLE ...", "tnemnorivnE emitnuR ES )MT(avaJ", 13);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test65");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "LIBRARY/JAVA/JAVAVIRTUA", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test66");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("###############################");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test67");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaa1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PlatformAPISpecification1.7.0_80PHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test68");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray6 = new char[] { '#', '#' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ", charArray6);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "http://java.oracle.com/", charArray6);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test69");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "##################################################################", 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test70");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("oracle Corporation/Users/", 4, 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "l" + "'", str3.equals("l"));
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test71");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("4Mac OS 44");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test72");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 1, "24.80-b112");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2" + "'", str3.equals("2"));
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test73");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("LIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JA");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JA" + "'", str1.equals("LIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JA"));
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test74");
        float[] floatArray4 = new float[] { 100, 3, Float.POSITIVE_INFINITY, 97 };
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray4);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + Float.POSITIVE_INFINITY + "'", float5 == Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + Float.POSITIVE_INFINITY + "'", float6 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test75");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 3, (short) (byte) 10, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test76");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 100, 17L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test77");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                    " + "'", str2.equals("                                                                                                    "));
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test78");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "aaahi!aaaa                                                                                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test79");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "mode mixed", (int) (byte) -1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str5.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test80");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("###################################################:");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test81");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("sun.lwawt.macosx.CPrinterJob");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"s\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test82");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test83");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 6);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test84() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test84");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "                     ", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test85() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test85");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("http://java.oracle.com/1.7.0_801.7.0_801.7.0_801.7.0", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/1.7.0_801.7.0_801.7.0_801.7.0" + "'", str2.equals("http://java.oracle.com/1.7.0_801.7.0_801.7.0_801.7.0"));
    }

    @Test
    public void test86() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test86");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/"));
    }

    @Test
    public void test87() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test87");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("NOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRO", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRO" + "'", str2.equals("NOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRO"));
    }

    @Test
    public void test88() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test88");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", "sophie");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "VA/JAVAVIRTUALMACHINES/JDK1.7.0_", (java.lang.CharSequence[]) strArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS ", strArray1, strArray5);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS " + "'", str8.equals("SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS "));
    }

    @Test
    public void test89() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test89");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96328_1560211636/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "/USERS/SOPHIE/DOCUMLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRETS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96328_1560211636/TARGET/CLASSES:/USERS/SOPHIE/DOCUMLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRETS/DEFECTS4J/FRAMEWORK/LIB/TEST_GLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREERATION/GLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREERATION/RANDOOP-CURRLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRET.JAR");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test90() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test90");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("...                                ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"...                                \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test91() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test91");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("aJava HotSpot(TM) 6 -Bit Server VMa         JavavP         JavavP           JavavP         JavavP           JavavP         JavavP           JavavP         JavavP           JavavP         JavavP", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test92() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test92");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.substringsBetween("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "aaa");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("################################", strArray4, strArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray11 = null;
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.5                                                 ", strArray8, strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "################################" + "'", str9.equals("################################"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1.5                                                 " + "'", str12.equals("1.5                                                 "));
    }

    @Test
    public void test93() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test93");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_3;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean4 = javaVersion0.atLeast(javaVersion3);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_3 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_3));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.3" + "'", str1.equals("1.3"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test94() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test94");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("###################################", 208, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa###################################" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa###################################"));
    }
}

