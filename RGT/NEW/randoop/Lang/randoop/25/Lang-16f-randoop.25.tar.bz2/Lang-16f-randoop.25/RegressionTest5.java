import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("               1.7.0_80      Mac OS X", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.                                                    Mac OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "               1.7.0_80      Mac OS X" + "'", str2.equals("               1.7.0_80      Mac OS X"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "va/javavirtualmachines/jdk1.7.0_");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop(" Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " Platform API Specificatio" + "'", str1.equals(" Platform API Specificatio"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("mixed mode", "j:tjtt3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "...k1.7.0_...", (java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("PlatformAPISpecification", "                                                                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636                                                                      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PlatformAPISpecification" + "'", str2.equals("PlatformAPISpecification"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("SPlatform API SpecificationWT.MACOSX.cpRINTERjOBoracle Corporation/Usersoracle Corporation/UsersoracSPlatform API SpecificationWT.MACOSX.cpRINTERjOBoracle Corporation/Usersoracle Corporation/UsersoracSPlatform API SpecificationWT.MACOSX.cpRINTERjOBoracle Corporation/Usersoracle Corporation/Usersorac");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("oitacificepS enihcaM lautriV avaJ", "/USERS/SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oitacificepS enihcaM lautriV avaJ" + "'", str2.equals("oitacificepS enihcaM lautriV avaJ"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("aaahi!aaaa                                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaahi!aaaa" + "'", str1.equals("aaahi!aaaa"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("1.6", "                1.0 0                ", "ne");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test011");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("http://java.oracle.com/1.4");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"http://j\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "noitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro", 300, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("http://java.oracle.com/", ":", (int) (short) 10);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "hi#!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("4444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("               1.7.0_80      Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "               1.7.0_80      Mac OS X" + "'", str1.equals("               1.7.0_80      Mac OS X"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 35, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444" + "'", str3.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 10, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test021");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("x86_6", "", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[J");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("             ", "##########     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "             " + "'", str2.equals("             "));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#", "0.9");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#" + "'", str2.equals("SUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWT.MA##SX.##RINTERj#BSUN.LWAWTM####S#"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("aaaaaaaaaaavaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) " Platform API Specificatio", (java.lang.CharSequence) "1.6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...", 34, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_..." + "'", str3.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_..."));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Oracle Corporation", (int) (byte) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("####S#", "javahotspot(tm)64-bitservervm");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "javahotspot(tm)64-bitservervm" + "'", str2.equals("javahotspot(tm)64-bitservervm"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("###1.7###", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/JAVAVP");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###1.7###" + "'", str2.equals("###1.7###"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "            ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("6", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        java.lang.String[] strArray3 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray7 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(strArray7);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray7);
        java.lang.String[] strArray12 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(strArray12);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.stripAll(strArray12);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray12);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("hi!", strArray7, strArray12);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "51.0");
        try {
            java.lang.String str22 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray18, '#', 0, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80" + "'", str4.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.7.0_80" + "'", str8.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.7.0_80" + "'", str13.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.7.0_80" + "'", str15.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertNotNull(strArray18);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("NOITAROPRO", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "NOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRO" + "'", str2.equals("NOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRO"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("hi#!", "http://java.oracle.com/1.7.0_801.7.0_801.7.0_801.7.0", "                                                                                                                                                                                                                ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi#!" + "'", str3.equals("hi#!"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "Mac OS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "tnemnorivnE emitnuR ES )MT(avaJ", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "ORPORATION");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        float[] floatArray1 = new float[] { '4' };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        java.lang.Class<?> wildcardClass4 = floatArray1.getClass();
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("J/v/ HotSpot(TM) 6-Bit Server VM", "3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J/v/ HotSpot(TM) 6-Bit Server VM" + "'", str2.equals("J/v/ HotSpot(TM) 6-Bit Server VM"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/USR/LIB/JAVA##");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.5                                                 ", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.5                                                 " + "'", str3.equals("1.5                                                 "));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("24.80-b112", (long) 13);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 13L + "'", long2 == 13L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "O caM", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        java.lang.String[] strArray1 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(strArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "aaahi!aaaa                                                                                          ");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80" + "'", str2.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80" + "'", str4.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "5", "...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ...                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) 3);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("1.0 0");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "[[j");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 1, (short) 10, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) ".lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("####S#", "##########         JavavP");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("4444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "          24.8/-b11                     sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "j", (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        char[] charArray5 = new char[] { '#', 'a' };
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray5);
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaa", charArray5);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8AAAAAAAAAA");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java(TM) SE Runtime Environment");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar", "", (int) '4');
        boolean boolean8 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn#_v31cq2n2x1n#fc0000gn/T/", (java.lang.CharSequence[]) strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, 'a');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Oracle ...", strArray2, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 10 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar" + "'", str10.equals("/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "j", (java.lang.CharSequence) "1.1", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro", "6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro" + "'", str2.equals("noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("aaahi!aaaa                                                                                          ", "va/javavirtualmachines/jdk#.0_");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaahi!aaaa                                                                                          " + "'", str2.equals("aaahi!aaaa                                                                                          "));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("SPlatform API SpecificationWT.MACOSX.cpRINTERjOB", 97, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaSPlatform API SpecificationWT.MACOSX.cpRINTERjOBaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaSPlatform API SpecificationWT.MACOSX.cpRINTERjOBaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) 'a', "                               sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Platform API Specification", "JavaVirtualMachineSpecification", 34);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "a", (java.lang.CharSequence) "x86_6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("tnemnorivnE emitnuR ES )MT(avaJ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TnemnorivnE emitnuR ES )MT(avaJ" + "'", str1.equals("TnemnorivnE emitnuR ES )MT(avaJ"));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "oracle Corporation/Users/", (java.lang.CharSequence) "1.7.0_80", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkit", "         JavavP");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 66, 300);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 201");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mode mixed");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("oracle Corporation                 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: oracle Corporation                  is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Mac OS X10.14.10.14.10.14.10.14.10.", (int) (short) 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac" + "'", str2.equals("Mac"));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[" + "'", str2.equals("class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [["));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "M71_O_X", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/USEJAVAVP", "                        oracle Corporation                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USEJAVAVP" + "'", str2.equals("/USEJAVAVP"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("a", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1.4", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.4                          " + "'", str2.equals("1.4                          "));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        short[] shortArray2 = new short[] { (short) 100, (byte) 100 };
        short short3 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray2);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short6 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray2);
        org.junit.Assert.assertNotNull(shortArray2);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) 100 + "'", short4 == (short) 100);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 100 + "'", short5 == (short) 100);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) 100 + "'", short6 == (short) 100);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 100 + "'", short7 == (short) 100);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) '#', 208, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 208 + "'", int3 == 208);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro", 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "http://java.oracle.com/", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "SUN.LWAWT.MACOSX.CPRINTERJOBLASS JAVA.IO.FILECLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS JAVA.IO.FILECLASS [[");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("##########");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##########" + "'", str1.equals("##########"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 51.0f, (double) 13L, 52.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("24.80-b112", "/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "fc0000gn/T/#_v31cq2n2x1n#/var/folders/_v/6v597zmn", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("x86_64", "###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############", "################################");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x86_64" + "'", str3.equals("x86_64"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro" + "'", str2.equals("            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporation", "/Users/sophie/Documents/defects4", (int) (short) 1);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("fc0000gn/T/#_v31cq2n2x1n#/var/folders/_v/6v597zmn");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"fc0000gn/T/#_v31cq2n2x1n#/var/folders/_v/6v597zmn\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test097");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("US");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("10.14.", "        M71_O_X", "sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.4." + "'", str3.equals("0.4."));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("4444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test100");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("oRACLE ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oRACLE ..." + "'", str1.equals("oRACLE ..."));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 42L, (float) 200, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        int[] intArray3 = new int[] { 0, ' ', 6 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[", (java.lang.CharSequence) "PVAVAJESU/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 52, (long) 23, (long) '#');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("PvavaJ         ##########");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ORACLE CORPORATION/USERS", 12, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORACLE CORPORATION/USERS" + "'", str3.equals("ORACLE CORPORATION/USERS"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oracle corporation" + "'", str1.equals("oracle corporation"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("4Mac OS 44");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4Mac OS 44" + "'", str1.equals("4Mac OS 44"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        java.lang.CharSequence[] charSequenceArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "11", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("en", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA HOTSPOT(TM) 64-BIT SERVER VM" + "'", str1.equals("JAVA HOTSPOT(TM) 64-BIT SERVER VM"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aJava HotSpot(TM) 64-Bit Server VMa", (java.lang.CharSequence) "1.5                                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("SUN.LWAWT.MACOSX.cpRINTERjOB", 100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("1.4                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.4" + "'", str1.equals("1.4"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("oRACLE cORPORATION", 200);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                           oRACLE cORPORATION                                                                                           " + "'", str2.equals("                                                                                           oRACLE cORPORATION                                                                                           "));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/TMP/RUN_RANDOOP.PL_96328_1560211636/TARGET/CLASSES:/USERS/SOPHIE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("eihpos");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray2);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", 0, 23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "LIBRARY/JAVA/JAVAVIRTUA" + "'", str3.equals("LIBRARY/JAVA/JAVAVIRTUA"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                1.0 0                ", (java.lang.CharSequence) "LIBRARY/JoRACLE cORPORATIONLIBRARY/JA", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("ORACLE CORPORATION/USERS", "LIBRARY/JoRACLE cORPORATIONLIBRARY/JA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "USERS" + "'", str2.equals("USERS"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test122");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "va/javavirtualmachines/jdk#.0_", (java.lang.CharSequence) "            ...");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "va/javavirtualmachines/jdk#.0_" + "'", charSequence2.equals("va/javavirtualmachines/jdk#.0_"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test123");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test124");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 25, (long) 100, (long) 21);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 21L + "'", long3 == 21L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test125");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("52.0", 42);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42 + "'", int2 == 42);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("sun", "va/javavirtualmachines/jdk#.0_");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun" + "'", str2.equals("sun"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test127");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.7", (java.lang.CharSequence) "   ", 300);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test128");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8AAAAAAAAAA", "Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8AAAAAAAAAA" + "'", str2.equals("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8AAAAAAAAAA"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test129");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "0.9", 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test130");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("##########...", "ne", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test131");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "noitaroproC elcaro");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test132");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JAVA VIRTUAL MACHINE SPECIFICATION" + "'", str1.equals("JAVA VIRTUAL MACHINE SPECIFICATION"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test133");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        boolean boolean3 = javaVersion0.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion5);
        boolean boolean7 = javaVersion2.atLeast(javaVersion5);
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test134");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("n4_v31cq2n2x1n4fc0000gn/T", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4_v31cq2n2x1n4fc0000gn/T" + "'", str2.equals("4_v31cq2n2x1n4fc0000gn/T"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test135");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "1.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test136");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "aaaaaaaaaa", "http://java.oracle.com/1.7.0_801.7.0_801.7.0_801.7.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test137");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test138");
        float[] floatArray1 = new float[] { '4' };
        float float2 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray1);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray1);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 52.0f + "'", float4 == 52.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test139");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test140");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test141");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test142");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("   ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "   " + "'", str1.equals("   "));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test144");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test145");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "lass [[", (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test146");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("SUNLLWAWTLMACOSXLcpRINTERjOBLASS JAVALIOLfILECLASS [lJAVALLANGLsTRING;CLASS [lJAVALLANGLsTRING;CLASS JAVALIOLfILECLASS [[", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test147");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Java Virtual Machine Specificatio");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test148");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("javahotspot(tm)64-bitservervm");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "javahotspot(tm)64-bitservervm" + "'", str1.equals("javahotspot(tm)64-bitservervm"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test149");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test150");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("         JavavP         JavavP  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavavPJavavP" + "'", str1.equals("JavavPJavavP"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test151");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##########     ", "24.8/-b11");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test152");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("fc0000gn/T/#_v31cq2n2x1n#/var/folders/_v/6v597zmn", "SUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWT.MACOSX.cpRINTERjOBSUN.LWAWTMac OS ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test153");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('4', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test154");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) ".lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("", "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test156");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("                                                                  ", "         JavavP         JavavP  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                  " + "'", str2.equals("                                                                  "));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test157");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x86_6class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[", 29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test158");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) ".7.0_801.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test159");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sopnee/Documents/defects4j/framework/lib/test_generation/generation/randoop-currentjar", charSequence1, 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test160");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "0", (java.lang.CharSequence) "1.7", 25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test161");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("##########         JavavP");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("J/v/ HotSpot(TM) 6-Bit Server VM", "###################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "J/v/ HotSpot(TM) 6-Bit Server VM" + "'", str2.equals("J/v/ HotSpot(TM) 6-Bit Server VM"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test163");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "##########...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test164");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("SPlatform API SpecificationWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SPlatform API SpecificationWT.MACOSX.cpRINTERjOB" + "'", str1.equals("SPlatform API SpecificationWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test165");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.7.0_80", 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test166");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "###1.7#######1.7#######1hi!###1.7#######1.7#######1.", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "oracle Corporation/Users/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("hie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#" + "'", str2.equals("sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test169");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("", "sun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test170");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "eihpos", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test171");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("24.8/-b11");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test172");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                                                  ", "24.80-b112");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                  " + "'", str2.equals("                                                                  "));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test174");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                                                   Java HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test175");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("####S#", 208);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "####S#                                                                                                                                                                                                          " + "'", str2.equals("####S#                                                                                                                                                                                                          "));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("ORPORATION", 193);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORPORATION                                                                                                                                                                                       " + "'", str2.equals("ORPORATION                                                                                                                                                                                       "));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test177");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sun", "###1.7###");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun" + "'", str2.equals("sun"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test178");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test179");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 10, (short) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test180");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("va/javavirtualmachines/jdk1.7.0_", "1.7", 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, '#', 10, 0);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80-b1", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test181");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("###1.7###");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test182");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "0.25", (java.lang.CharSequence) "noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test183");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "aJava HotSpot(TM) 64-Bit Server VMa", (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "5");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test185");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                                          Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                          Mac OS " + "'", str1.equals("                                                          Mac OS "));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("sun.lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[", 15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[" + "'", str2.equals("sun.lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [["));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test187");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "/SUN");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test188");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test189");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1.6", (java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7", 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test190");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.0 0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test191");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("US");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "US" + "'", str1.equals("US"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test192");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("...                          ...", (int) (byte) 0, "noitacificepS IPA mroftalP");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...                          ..." + "'", str3.equals("...                          ..."));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test194");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "javahotspot(tm)64-bitservervm");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test195");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 300, 0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test196");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("LIBRARY/JoRACLE cORPORATIONLIBRARY/JA", "oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test197");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split(" ", "11");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test198");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "####################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test200");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "         JavavP         JavavP  ", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test201");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("MAC OS X");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test202");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                               sophie", "aaahi!aaaa");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.7.0_80-b15", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("3", "/LIBRARY/JAVA/JAVAV####S#", "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3" + "'", str3.equals("3"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test204");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test205");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("Oracle ...", "[[j");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle ..." + "'", str2.equals("Oracle ..."));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test206");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "1.7.0_80-b1", (java.lang.CharSequence) "javahotspot(tm)64-bitservervm");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test207");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "###1.7####", (int) (byte) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test208");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                ...", "sun");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun" + "'", str2.equals("sun"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test210");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "sophie", (java.lang.CharSequence) "H");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test211");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("         JavavP", "http://java.oracle.com/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "         JavavP" + "'", str2.equals("         JavavP"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("mixed mode", "SPlatform API SpecificationWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test213");
        long[] longArray1 = new long[] { 200 };
        long[][] longArray2 = new long[][] { longArray1 };
        long[] longArray4 = new long[] { 200 };
        long[][] longArray5 = new long[][] { longArray4 };
        long[] longArray7 = new long[] { 200 };
        long[][] longArray8 = new long[][] { longArray7 };
        long[] longArray10 = new long[] { 200 };
        long[][] longArray11 = new long[][] { longArray10 };
        long[][][] longArray12 = new long[][][] { longArray2, longArray5, longArray8, longArray11 };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray12);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) longArray12, 'a');
        try {
            java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) longArray12, ' ', (int) (byte) 100, 200);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertNotNull(longArray2);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray5);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
        org.junit.Assert.assertNotNull(longArray10);
        org.junit.Assert.assertNotNull(longArray11);
        org.junit.Assert.assertNotNull(longArray12);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test214");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("PVAVAJESU/");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test215");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("1.7.0_80", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test216");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("                                                          Mac OS X", 0, 21);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                     " + "'", str3.equals("                     "));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test217");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa", "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8AAAAAAAAAA", 17);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "Mac O", (java.lang.CharSequence) "          ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test219");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test220");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("J/v/ HotSpot(TM) 6-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test221");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "          " + "'", str1.equals("          "));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test222");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "################################", (java.lang.CharSequence) "Java Platform API Specification", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("E/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GE", "oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "E/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GE" + "'", str2.equals("E/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GE"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test224");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.8", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test226");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[", (int) (byte) 100, (int) (short) 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test227");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("###1.7###", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test228");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("n4_v31cq2n2x1n4fc0000gn/T");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"n4_v31cq2n2x1n4fc0000gn/T\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test229");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#######sun.lwawt.macosx.CPrinterJoblass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[##########", " Platform API Specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test230");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("hi!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI!" + "'", str1.equals("HI!"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test231");
        float[] floatArray3 = new float[] { 8L, (short) 1, 32 };
        float float4 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 1.0f + "'", float4 == 1.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test232");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                        oracle Corporation                        ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("Oracle Corporation", "noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("LIBRARY/JoRACLE cORPORATIONLIBRARY/JA", 29);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "LIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JA" + "'", str2.equals("LIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JALIBRARY/JoRACLE cORPORATIONLIBRARY/JA"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test235");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Java Virtual Machine Specification                                ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test236");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test237");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar", "", (int) '4');
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/var/folders/_v/6v597zmn#_v31cq2n2x1n#fc0000gn/T/", (java.lang.CharSequence[]) strArray4);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, 'a');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "             ", 6, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar" + "'", str7.equals("/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test238");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test239");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "H", (java.lang.CharSequence) "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test240");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("3", "NE", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "3" + "'", str3.equals("3"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test241");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) ".lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("Platform API Specification", 4, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "form API Specificatio" + "'", str3.equals("form API Specificatio"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test243");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sun", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test244");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "aaaaaaaaaaavaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test245");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("Platform API Specification", 208);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 208 + "'", int2 == 208);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test246");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("sun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test247");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJoblass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test248");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) " Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test249");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "noitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro", (java.lang.CharSequence) "0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test250");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("...k1.7.0_...");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test251");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                1.0 0                ", (java.lang.CharSequence) "1.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.71.7");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test252");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("http://java.oracle.com/1.7.0_801.7.0_801.7.0_801.7.0", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 10);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Platform API Specification", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test253");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("###1.7###", "                                                                                                 ", 7, 29);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "###1.7#                                                                                                 " + "'", str4.equals("###1.7#                                                                                                 "));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test254");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa[[jaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj[[aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj[[aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test255");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaa" + "'", str1.equals("aaa"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("x86_6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_6" + "'", str1.equals("X86_6"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test257");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("sun.lwawt.macosx.CPrinterJoblass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[", "/USERS/SOPNEE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.CPrinterJoblass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[" + "'", str3.equals("sun.lwawt.macosx.CPrinterJoblass java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [["));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test258");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "http://java.oracle.com/1.7.0_801.7.0_801.7.0_801.7.0", (java.lang.CharSequence) "va/javavirtualmachines/jdk#.0_", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test259");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa");
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.7.0_80-b1", 0, 1);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi" + "'", str8.equals("hi"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi#!" + "'", str10.equals("hi#!"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test260");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8AAAAAAAAAA", (short) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test261");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("24.8/-b11");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test262");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.7.0_80-B15", "Ora1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-B15" + "'", str2.equals("1.7.0_80-B15"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Platform API Specification");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "platform API Specification" + "'", str1.equals("platform API Specification"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test264");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                                                    ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test265");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("JavavP");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JavavP" + "'", str1.equals("JavavP"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test266");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "oracle Corporation");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":" + "'", str4.equals(":"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test267");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "J/v/ HotSpot(TM) 64-Bit Server VM", "");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test268");
        char[] charArray6 = new char[] { '#', '#', ' ' };
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charArray6);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "##########", charArray6);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test269");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "1.5", (java.lang.CharSequence) "HI!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test270");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) -1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test271");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test272");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                               sophie", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test273");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro" + "'", str1.equals("noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test274");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaj[[aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test275");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test276");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "Java Virtual Machine Specification                                ", (java.lang.CharSequence) "             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test277");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "[[ java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass sun.lwawt.macosx.cprinterjoblass", (java.lang.CharSequence) "noitaroproC elcaro");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test278");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test279");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.7.0_80", "   ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test280");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("SUN.LWAWT.MACOSX.CPRINTERJOBLASS JAVA.IO.FILECLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS JAVA.IO.FILECLASS [[", "mode mixed", "###1.7####");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test281");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("               1.7.0_80      Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test282");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("x86_64", "noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro", "", 37);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "x86_64" + "'", str4.equals("x86_64"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test283");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "h ", (java.lang.CharSequence) "http://java.oracle.com/1.7.0_801.7.0_801.7.0_801.7.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 51 + "'", int2 == 51);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test284");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("sun");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun" + "'", str1.equals("sun"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test285");
        java.lang.CharSequence charSequence1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(":", "oracle Corporation");
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence1, (java.lang.CharSequence[]) strArray4);
        int int6 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "VA/JAVAVIRTUALMACHINES/JDK1.7.0_", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "US");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test286");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "Mac O", 37);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test287");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test288");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("noitacificepS IPA mroftalP", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "noitacificepS IPA mroftalP" + "'", str2.equals("noitacificepS IPA mroftalP"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test289");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("24.8/-b11", 31, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.8/-b11aaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("24.8/-b11aaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test290");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber(".7.0_801.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test291");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "", 66);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test292");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.8");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test293");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaa", "hi#!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test294");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.1", (java.lang.CharSequence) "fc0000gn/T/#_v31cq2n2x1n#/var/folders/_v/6v597zmn");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test295");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("X86_6", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test296");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/var/folders/_v/6v597zmn#_v31cq2n2x1n#fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test297");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Mac OS X");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test298");
        double[] doubleArray2 = new double[] { 0.0d, 0.0f };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("tnemnorivnE emitnuR ES )MT(avaJ", "ORPORATION                                                                                                                                                                                       ", 13);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "tnemnorivnE emitnuR ES )MT(avaJ" + "'", str3.equals("tnemnorivnE emitnuR ES )MT(avaJ"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test300");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 12, 21.0f, 1.2f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.2f + "'", float3 == 1.2f);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test301");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(35.0f, (float) ' ', (float) 8);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test302");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                                                                 ", "MAC OS X");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test304");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[", "j", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test305");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 0, (short) 3);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 3 + "'", short3 == (short) 3);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test306");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("             ", "ORACLE CORPORATION/USERS", 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test307");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("Mac OS ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test308");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                               sophie", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test309");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                                          Mac OS X");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test310");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa", (java.lang.CharSequence) "/var/folders/_v/6v597zmn#_v31cq2n2x1n#fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test311");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("0.25");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.25" + "'", str1.equals("0.25"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test312");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("oracle Corporation/UsersJAVAVP");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test313");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("x86_64");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "x86_64" + "'", str1.equals("x86_64"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test314");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Mac", (java.lang.CharSequence) "                                                                   java hotspot(tm) 64-bit server vm");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test315");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("eihpos");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihpo" + "'", str1.equals("eihpo"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test316");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("eihpos");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihpos" + "'", str1.equals("eihpos"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("x86_64", 9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " x86_64  " + "'", str2.equals(" x86_64  "));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test318");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("[[ java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass sun.lwawt.macosx.cprinterjoblass", "/USERS/SOPNEE/DOCUMENTS/DEFECTS4J/FRAMEWORK/LIB/TEST_GENERATION/GENERATION/RANDOOP-CURRENT.JAR");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test319");
        java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("3");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.0f + "'", float1.equals(3.0f));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("ORPORATION                                                                                                                                                                                       ", "LIBRARY/JAVA/JAVAVIRTUA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ORPORATION                                                                                                                                                                                       " + "'", str2.equals("ORPORATION                                                                                                                                                                                       "));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test321");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "/USERS/SOPNEE/D", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test322");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("H", "                                                                     /Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636                                                                      ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "H" + "'", str2.equals("H"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test323");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                1.0 0                ", (java.lang.CharSequence) "...k1.7.0_...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test324");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("oracle Corporation/Users");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test325");
        double[] doubleArray2 = new double[] { 0.0d, 0.0f };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test326");
        java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("5");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1.equals(5));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test327");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean5 = javaVersion1.atLeast(javaVersion2);
        boolean boolean6 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str7 = javaVersion2.toString();
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_5;
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        java.lang.String str11 = javaVersion10.toString();
        boolean boolean12 = javaVersion9.atLeast(javaVersion10);
        boolean boolean13 = javaVersion8.atLeast(javaVersion10);
        boolean boolean14 = javaVersion2.atLeast(javaVersion8);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_5 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_5));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.2" + "'", str11.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter(" Platform API Specificatio Platform API Specificatio", "JAVA VIRTUAL MACHINE SPECIFICATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test329");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("###1.7###");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###1.7###" + "'", str1.equals("###1.7###"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test330");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("####################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "####################################################" + "'", str1.equals("####################################################"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test331");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "eihpo", (java.lang.CharSequence) "lass [[", 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test332");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/", (int) (short) -1, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test333");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("c OS XaM", "noitaroproCelcaroaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro", "Java HotSpot(TM) 64-Bit Serv...");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "c OS XaM" + "'", str3.equals("c OS XaM"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test334");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "[[ java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass sun.lwawt.macosx.cprinterjoblass", (java.lang.CharSequence) "noitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test335");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 1, (byte) 10, (byte) -1, (byte) 100, (byte) 1 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test336");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("sophie", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test337");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "4.80-b112");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test338");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("        M71_O_X", 10, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...71_O_X" + "'", str3.equals("...71_O_X"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test339");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "JavavP", 8, 300);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test340");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HI" + "'", str1.equals("HI"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test341");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("fc0000gn/T/#_v31cq2n2x1n#/var/folders/_v/6v597zmn");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test342");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", "mixed mode", "OCUMENTS/DEFECTS4J/FRAMEWORK/LIB/T");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro" + "'", str3.equals("                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test343");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                 noitaroproC elcaro", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test344");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/usr/lib/java");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test345");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase(charSequence0, (java.lang.CharSequence) "6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test346");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "ORPORATION                                                                                                                                                                                       ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test347");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("52.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52.0" + "'", str1.equals("52.0"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test348");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aJava HotSpot(TM) 64-Bit Server VMa", '4', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aJava HotSpot(TM) 6 -Bit Server VMa" + "'", str3.equals("aJava HotSpot(TM) 6 -Bit Server VMa"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test349");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test350");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test351");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(8.0f, (float) 8, (float) 21L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test352");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("6", (byte) 10);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 6 + "'", byte2 == (byte) 6);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test353");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("                                ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test354");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.4");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test355");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) -1, (long) 9, 8L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 9L + "'", long3 == 9L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ORPORATION", (int) (short) 1, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ORPORATION" + "'", str3.equals("ORPORATION"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test357");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("24.80-b112", "4Mac OS 44");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4Mac OS 44" + "'", str2.equals("4Mac OS 44"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test358");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hiMac OS X!", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test359");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 193, 1.6f, (float) 34L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.6f + "'", float3 == 1.6f);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test360");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test361");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "ORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test363");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Mac OS ", (float) 34L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test364");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Java Platform API Specification", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test365");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "SUN", (java.lang.CharSequence) "SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test366");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone(charSequence0, "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test367");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(37, (int) '4', 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("J/v/ HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "J/v/ HotSpot(TM) 6-Bit Server VM" + "'", str1.equals("J/v/ HotSpot(TM) 6-Bit Server VM"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test369");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "noitacificepS IPA mroftalP");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test370");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("###1.7#                                                                                                 ", "                        oracle Corporation                        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###1.7#                                                                                                 " + "'", str2.equals("###1.7#                                                                                                 "));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test371");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 1, (long) (byte) 0, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test372");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9", (java.lang.CharSequence) "Mac OS X10.14.10.14.10.14.10.14.10.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/LIBRARY/JAVA/JAVAV####S#", (int) (short) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/LIBRARY/JAVA/JAVAV####S#" + "'", str3.equals("/LIBRARY/JAVA/JAVAV####S#"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test374");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "24.80-b11", (java.lang.CharSequence) "aaa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test375");
        java.lang.String[] strArray2 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join(strArray2);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "aaahi!aaaa                                                                                          ");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "NOITAROPRO", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.7.0_80" + "'", str3.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1.7.0_80" + "'", str5.equals("1.7.0_80"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test376");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "11", "LIBRARY/JoRACLE cORPORATIONLIBRARY/JA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test377");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("SPlatform API SpecificationWT.MACOSX.cpRINTERjOB", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SPlatform API SpecificationWT.MACOSX.cpRINTERjOB" + "'", str2.equals("SPlatform API SpecificationWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test378");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("1.8", (double) 1.6f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8d + "'", double2 == 1.8d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test379");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("SUN.LWAWT.MACOSX.CPRINTERJOBLASS JAVA.IO.FILECLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS JAVA.IO.FILECLASS [[", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.CPRINTERJOBLASS JAVA.IO.FILECLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS JAVA.IO.FILECLASS [[" + "'", str2.equals("SUN.LWAWT.MACOSX.CPRINTERJOBLASS JAVA.IO.FILECLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS JAVA.IO.FILECLASS [["));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test380");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "a", (int) (byte) 1, (int) (byte) 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test381");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 4, 0L, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test382");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) '4', (double) 100L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test383");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 5, (long) (byte) 6, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test384");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro", (java.lang.CharSequence) "                        oracle Corporation                        ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro" + "'", charSequence2.equals("noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro noitaroproC elcaro"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test385");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test386");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "##########         JavavP", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test387");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test388");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("hi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi" + "'", str1.equals("hi"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...", "PVAVAJESU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension..." + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension..."));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test390");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "JavavP", (java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test391");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a', (int) (byte) 6, 13);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test392");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("class java.io.Fileclass [Ljava.lang.String;class [Ljava.lang.String;class java.io.Fileclass [[");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test393");
        double[] doubleArray4 = new double[] { (byte) 1, (byte) -1, '#', (-1.0f) };
        double double5 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double6 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double7 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray4);
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test394");
        int[] intArray4 = new int[] { 66, (short) 1, (short) 10, 0 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 66 + "'", int6 == 66);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 66 + "'", int9 == 66);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test395");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "va/javavirtualmachines/jdk1.7.0_");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test396");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "c OS XaM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test397");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "##################################################################");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test398");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("Java Virtual Machine Specification                                ", "x86_6", "Ers/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test399");
        java.lang.String[] strArray3 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(strArray3);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray7 = new java.lang.String[] { "1.7.0_80" };
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(strArray7);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray3, strArray7);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mode mixed", "aaa", 4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie", strArray7, strArray14);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.7.0_80" + "'", str4.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.7.0_80" + "'", str8.equals("1.7.0_80"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie" + "'", str15.equals("                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test400");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("hi!");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "1.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_801.7.0_8aaaaaaaaaa");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "Mac OS X");
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi#!" + "'", str5.equals("hi#!"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hiMac OS X!" + "'", str7.equals("hiMac OS X!"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test401");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("####################################################", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test402");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test403");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "Mac O");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test404");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server V" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server V"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test405");
        char[] charArray2 = new char[] {};
        boolean boolean3 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charArray2);
        boolean boolean4 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "44444444444444444444444444444444444", charArray2);
        org.junit.Assert.assertNotNull(charArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test406");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("...71_O_X", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test407");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/JAVAVP", 0, 193);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test408");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray8 = new char[] { '#', '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "5", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "##################################################################", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaahi!aaaa", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test409");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test410");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "                                                                                                                                                                                                                ", (int) 'a', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                                                                                                                                                                                                " + "'", str4.equals("                                                                                                                                                                                                                "));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test411");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test412");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("1.5                                                 ", 42, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "         " + "'", str3.equals("         "));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("", 12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test414");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("JAVA VIRTUAL MACHINE SPECIFICATION", 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test415");
        short[] shortArray4 = new short[] { (byte) 0, (short) 0, (short) 1, (byte) -1 };
        short[] shortArray9 = new short[] { (byte) 0, (short) 0, (short) 1, (byte) -1 };
        short[] shortArray14 = new short[] { (byte) 0, (short) 0, (short) 1, (byte) -1 };
        short[] shortArray19 = new short[] { (byte) 0, (short) 0, (short) 1, (byte) -1 };
        short[][] shortArray20 = new short[][] { shortArray4, shortArray9, shortArray14, shortArray19 };
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(shortArray20);
        org.junit.Assert.assertNotNull(shortArray4);
        org.junit.Assert.assertNotNull(shortArray9);
        org.junit.Assert.assertNotNull(shortArray14);
        org.junit.Assert.assertNotNull(shortArray19);
        org.junit.Assert.assertNotNull(shortArray20);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test416");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(193, 8, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 193 + "'", int3 == 193);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test417");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("sun");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun" + "'", str1.equals("sun"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test418");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("            noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test419");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test420");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) '4', (double) (-1.0f), (double) 8);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test421");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("X86_6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X86_6" + "'", str1.equals("X86_6"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test422");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase(charSequence0, (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test423");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("oracle Corporation                 ", (long) 66);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 66L + "'", long2 == 66L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test424");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("ORPORATION                                                                                                                                                                                       ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ORPORATION                                                                                                                                                                                       " + "'", str1.equals("ORPORATION                                                                                                                                                                                       "));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test425");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("1.4", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.4" + "'", str3.equals("1.4"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test426");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "...k1.7.0_...", (java.lang.CharSequence) "4_v31cq2n2x1n4fc0000gn/T", 7);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test427");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/JAVAVP", 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/JAVAVP4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie" + "'", str4.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/JAVAVP4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...                                                                                       /Users/sophie"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test428");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("SUN.LWAWT.MACOSX.cpRINTERjOBLASS JAVA.IO.fILECLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS JAVA.IO.fILECLASS [[");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: SUN.LWAWT.MACOSX.cpRINTERjOBLASS JAVA.IO.fILECLASS [lJAVA.LANG.sTRING;CLASS [lJAVA.LANG.sTRING;CLASS JAVA.IO.fILECLASS [[ is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test429");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.substringsBetween("", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", "aaa");
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "hiMac OS X!", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test430");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        boolean boolean5 = javaVersion1.atLeast(javaVersion2);
        boolean boolean6 = javaVersion0.atLeast(javaVersion2);
        java.lang.String str7 = javaVersion2.toString();
        boolean boolean8 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion2);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0.9" + "'", str7.equals("0.9"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("L", "              [[j              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test432");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(17, 0, 21);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test433");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("noitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro", "Mac O", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaahi!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test434");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("aaahi!aaaa", "AAAHI!AAAA");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("[[J", 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[[J" + "'", str2.equals("[[J"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test436");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("11", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test437");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("1.1", "                 noitaroproC elcaro");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test438");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 1, (byte) 0, (byte) 10, (byte) 6, (byte) 100 };
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.min(byteArray6);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test439");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("v", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test440");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 51.0f, (double) 42L, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 51.0d + "'", double3 == 51.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test441");
        char[] charArray7 = new char[] { '#', 'a' };
        int int8 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Oracle Corporation", charArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "aaaaaaaaaa", charArray7);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "         JavavP", charArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java(TM) SE Runtime Environment", charArray7);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "               ", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("LIBRARY/JAVA/JAVAVIRTUA", "aJava HotSpot(TM) 64-Bit Serv...", "24.8/-b11aaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "LIBRARY/JAVA/JAVAVIRTUA" + "'", str3.equals("LIBRARY/JAVA/JAVAVIRTUA"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test443");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(208, 6, 42);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 208 + "'", int3 == 208);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test444");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "oracle Corporation", (java.lang.CharSequence) "noitaroproCelcaroaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/USERS/SOPHIEaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaronoitaroproCelcaro");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test445");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test446");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("noitacificepS IPA mroftalP");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "noitacificepS IPA mroftalP" + "'", str1.equals("noitacificepS IPA mroftalP"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test447");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("c OS XaM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "c OS XaM" + "'", str1.equals("c OS XaM"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test448");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                        oracle Corporation                        ", "         JavavP         JavavP  ", 35, 193);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                        oracle Corp         JavavP         JavavP  " + "'", str4.equals("                        oracle Corp         JavavP         JavavP  "));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test449");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "1.7.0_80-B15", (java.lang.CharSequence) "JAVAVP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test450");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aJava HotSpot(TM) 6 -Bit Server VMa", 23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test451");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.1", 2, 51);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test452");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 10.0f, (double) 34L, (double) 200);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test453");
        char[] charArray8 = new char[] { '#', '#' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray8);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "5", charArray8);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "##################################################################", charArray8);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "aaahi!aaaa", charArray8);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "NOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRONOITAROPRO", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                   ", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extension...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                   " + "'", str2.equals("                                   "));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test455");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sun.lwawt.macosx.cprinterjoblass java.io.fileclass [ljava.lang.string;class [ljava.lang.string;class java.io.fileclass [[", (java.lang.CharSequence) "###1.7#                                                                                                 ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("24.80-b112", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b112" + "'", str2.equals("24.80-b112"));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test457");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("", (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test458");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) ":2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test459");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "VA/JAVAVIRTUALMACHINES/JDK1.7.0_", (java.lang.CharSequence) "1.5                                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test460");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "SUN.LWAWT.MACOSX.CPRINTERJOBLASS JAVA.IO.FILECLASS [LJAVA.LANG.STRING;CLASS [LJAVA.LANG.STRING;CLASS JAVA.IO.FILECLASS [[");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 121 + "'", int1 == 121);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test461");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                                                   Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test462");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "NE", (java.lang.CharSequence) "lass [[");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test463");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############" + "'", str1.equals("###############/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE###############"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test464");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) 10, (short) 3);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("0.4.", "6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test466");
        char[] charArray6 = new char[] { '4', ' ' };
        int int7 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", charArray6);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "oracle Corporation/Users/", charArray6);
        java.lang.Class<?> wildcardClass9 = charArray6.getClass();
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                                                                           oRACLE cORPORATION                                                                                           ", charArray6);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "oracle Corporation/Users/", charArray6);
        org.junit.Assert.assertNotNull(charArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test467");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("SUN.LWAWT.MACOSX.cpRINTERjOB");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.cpRINTERjOB" + "'", str1.equals("SUN.LWAWT.MACOSX.cpRINTERjOB"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test468");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("", "M OS X");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test469");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", "                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro                 noitaroproC elcaro", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE/LIB/EXT", 23);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test470");
        char[] charArray5 = new char[] { '#', '#' };
        boolean boolean6 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "hi!", charArray5);
        boolean boolean7 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", charArray5);
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9", charArray5);
        org.junit.Assert.assertNotNull(charArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test471");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa0.9");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test472");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("##################################################################");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##################################################################" + "'", str1.equals("##################################################################"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test473");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkitnesun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test474");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "J/v/ HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "oracle Corporation/UsersJAVAVP");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test475");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (short) 10, (int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test476");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("5");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, 'a');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "5" + "'", str3.equals("5"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test477");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("eihpos");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test478");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 100, (short) 1, (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("        M71_O_X", "http://java.oracle.com/1.7.0_801.7.0_801.7.0_801.7.0", "                                                                   Java HotSpot(TM) 6-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "        M71_O_X" + "'", str3.equals("        M71_O_X"));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test480");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JRE", (java.lang.CharSequence) "/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59 + "'", int2 == 59);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test481");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("aaahi!aaaa                                                                                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaahi!aaaa" + "'", str1.equals("aaahi!aaaa"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("JAVAVP", 100, (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test483");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawt.ma##sx.##rinterj#bsun.lwawtm####s#", "             ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test484");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "JAVA HOTSPOT(TM) 64-BIT SERVER VM", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test485");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636", "");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                                                                                    ", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test486");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "4Mac OS 44");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test487");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("va/javavirtualmachines/jdk#.0_", "va/javavirtualmachines/jdk1.7.0_");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test488");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                                                   Java HotSpot(TM) 64-Bit Server VM", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444...k1.7.0_...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test489");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "http://java.oracle.com/1.7.0_801.7.0_801.7.0_801.7.0", "4444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test490");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636", "####S#                                                                                                                                                                                                          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_96328_1560211636"));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test491");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 100, 0.0d, (double) 66L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test492");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "Mac OS X10.14.10.14.10.14.10.14.10.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test493");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test494");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Java(TM) SE Runtime Environment");
        java.lang.String[] strArray4 = null;
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("ne", strArray3, strArray4);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "1.3", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ne" + "'", str5.equals("ne"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test495");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("##################################################################", '#');
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.split("...k1.7.0_...");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/tmp/run_randoop.pl_96328_1560211636/target/classes:/Users/sophie/DocumLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREts/defects4j/framework/lib/test_gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/gLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREeration/randoop-currLIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CONTENTS/HOME/JREt.jar", strArray3, strArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 67 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "hi#!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test497");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "1.7.0_80-b1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test498");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("j:tjtt3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "j:tjtt3" + "'", str1.equals("j:tjtt3"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test499");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) (short) 10, 0, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "/USR/LIB/JAVA");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }
}

