import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test001");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("dk1.#aaa4a#a4aa", "                                .0_80-b1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "dk1.#aaa4a#a4aa" + "'", str2.equals("dk1.#aaa4a#a4aa"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test002");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "X SO caM", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test003");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils1 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils2 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils3 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils4 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray5 = new org.apache.commons.lang3.SystemUtils[] { systemUtils0, systemUtils1, systemUtils2, systemUtils3, systemUtils4 };
        org.apache.commons.lang3.SystemUtils systemUtils6 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils7 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils8 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils9 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils10 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray11 = new org.apache.commons.lang3.SystemUtils[] { systemUtils6, systemUtils7, systemUtils8, systemUtils9, systemUtils10 };
        org.apache.commons.lang3.SystemUtils[][] systemUtilsArray12 = new org.apache.commons.lang3.SystemUtils[][] { systemUtilsArray5, systemUtilsArray11 };
        org.apache.commons.lang3.SystemUtils systemUtils13 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils14 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils15 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils16 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils17 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray18 = new org.apache.commons.lang3.SystemUtils[] { systemUtils13, systemUtils14, systemUtils15, systemUtils16, systemUtils17 };
        org.apache.commons.lang3.SystemUtils systemUtils19 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils20 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils21 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils22 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils23 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray24 = new org.apache.commons.lang3.SystemUtils[] { systemUtils19, systemUtils20, systemUtils21, systemUtils22, systemUtils23 };
        org.apache.commons.lang3.SystemUtils[][] systemUtilsArray25 = new org.apache.commons.lang3.SystemUtils[][] { systemUtilsArray18, systemUtilsArray24 };
        org.apache.commons.lang3.SystemUtils systemUtils26 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils27 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils28 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils29 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils30 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray31 = new org.apache.commons.lang3.SystemUtils[] { systemUtils26, systemUtils27, systemUtils28, systemUtils29, systemUtils30 };
        org.apache.commons.lang3.SystemUtils systemUtils32 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils33 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils34 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils35 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils36 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray37 = new org.apache.commons.lang3.SystemUtils[] { systemUtils32, systemUtils33, systemUtils34, systemUtils35, systemUtils36 };
        org.apache.commons.lang3.SystemUtils[][] systemUtilsArray38 = new org.apache.commons.lang3.SystemUtils[][] { systemUtilsArray31, systemUtilsArray37 };
        org.apache.commons.lang3.SystemUtils systemUtils39 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils40 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils41 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils42 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils43 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray44 = new org.apache.commons.lang3.SystemUtils[] { systemUtils39, systemUtils40, systemUtils41, systemUtils42, systemUtils43 };
        org.apache.commons.lang3.SystemUtils systemUtils45 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils46 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils47 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils48 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils49 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray50 = new org.apache.commons.lang3.SystemUtils[] { systemUtils45, systemUtils46, systemUtils47, systemUtils48, systemUtils49 };
        org.apache.commons.lang3.SystemUtils[][] systemUtilsArray51 = new org.apache.commons.lang3.SystemUtils[][] { systemUtilsArray44, systemUtilsArray50 };
        org.apache.commons.lang3.SystemUtils systemUtils52 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils53 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils54 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils55 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils56 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray57 = new org.apache.commons.lang3.SystemUtils[] { systemUtils52, systemUtils53, systemUtils54, systemUtils55, systemUtils56 };
        org.apache.commons.lang3.SystemUtils systemUtils58 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils59 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils60 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils61 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils62 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray63 = new org.apache.commons.lang3.SystemUtils[] { systemUtils58, systemUtils59, systemUtils60, systemUtils61, systemUtils62 };
        org.apache.commons.lang3.SystemUtils[][] systemUtilsArray64 = new org.apache.commons.lang3.SystemUtils[][] { systemUtilsArray57, systemUtilsArray63 };
        org.apache.commons.lang3.SystemUtils[][][] systemUtilsArray65 = new org.apache.commons.lang3.SystemUtils[][][] { systemUtilsArray12, systemUtilsArray25, systemUtilsArray38, systemUtilsArray51, systemUtilsArray64 };
        java.lang.String str66 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray65);
        org.junit.Assert.assertNotNull(systemUtilsArray5);
        org.junit.Assert.assertNotNull(systemUtilsArray11);
        org.junit.Assert.assertNotNull(systemUtilsArray12);
        org.junit.Assert.assertNotNull(systemUtilsArray18);
        org.junit.Assert.assertNotNull(systemUtilsArray24);
        org.junit.Assert.assertNotNull(systemUtilsArray25);
        org.junit.Assert.assertNotNull(systemUtilsArray31);
        org.junit.Assert.assertNotNull(systemUtilsArray37);
        org.junit.Assert.assertNotNull(systemUtilsArray38);
        org.junit.Assert.assertNotNull(systemUtilsArray44);
        org.junit.Assert.assertNotNull(systemUtilsArray50);
        org.junit.Assert.assertNotNull(systemUtilsArray51);
        org.junit.Assert.assertNotNull(systemUtilsArray57);
        org.junit.Assert.assertNotNull(systemUtilsArray63);
        org.junit.Assert.assertNotNull(systemUtilsArray64);
        org.junit.Assert.assertNotNull(systemUtilsArray65);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test004");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "aaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test005");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("/", "4444444444444444444444444444444aaaaaaaaaa44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test006");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("US", "1.1S", "JV(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test007");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 1, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test008");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("0a100a-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"a100a-\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test009");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "oL.braryoJavaoJavaV.rtualMacj.n0sojdk1.7.0_80.jdkoCk", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test010");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("10 1 -1 -1", "                                  10.14.3", "hi!", 41);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10 1 -1 -1" + "'", str4.equals("10 1 -1 -1"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test011");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("100.0 32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "100.0 32.0" + "'", str1.equals("100.0 32.0"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test012");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("52.0#32.0", "", 87);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.0" + "'", str3.equals("52.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.0"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test013");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "hi!sophi");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test014");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("eihpos!i", (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test015");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("sun.awt.CGraphicsEnvironment", "01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test016");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("                            java HotSpot(TM) 64-Bit Server VM                             ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                            java HotSpot(TM) 64-Bit Server VM                             " + "'", str1.equals("                            java HotSpot(TM) 64-Bit Server VM                             "));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test017");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (short) 1, (float) (byte) 1, (float) 41L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 41.0f + "'", float3 == 41.0f);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test018");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "HI!SOPHIE", (java.lang.CharSequence) "RaphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test019");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(52, (int) (byte) 0, (-14041));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test020");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("97.0a35.0a-1.0a35.0a52.", "X   4 X 4  ", "                                     -1#0#1                                               ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "97.0a35.0a-1.0a35.0a52." + "'", str3.equals("97.0a35.0a-1.0a35.0a52."));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test021");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "                                .0_80-b15", (java.lang.CharSequence) "Java Virtual Machine Specification", 46);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test022");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str1.equals("brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test023");
        int[] intArray3 = new int[] { (byte) 0, 100, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0a100a-1" + "'", str8.equals("0a100a-1"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test024");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "51.051.051.051.051.051.05/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/51.051.051.051.051.051.051", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test025");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test026");
        byte[] byteArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(byteArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test027");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("#aaa4a#a4aa                                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#AAA4A#A4AA                                         " + "'", str1.equals("#AAA4A#A4AA                                         "));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test028");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "10 -1 10 32 -1 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test029");
        long[] longArray6 = new long[] { 100, (-1L), 0L, 1, 'a', 100L };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', (int) ' ', 0);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ', 4, (int) (short) 0);
        long long18 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long19 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long20 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a-1a0a1a97a100" + "'", str13.equals("100a-1a0a1a97a100"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test030");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a', 7, 11);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test031");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove(".io.Filecl", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".io.Filecl" + "'", str2.equals(".io.Filecl"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test033");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(4.4444444444444445E51d, 0.0d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.4444444444444445E51d + "'", double3 == 4.4444444444444445E51d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test034");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " -1 1", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 5);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaa" + "'", str2.equals("aaaaa"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test036");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ava HotSpo", "6_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test037");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("us                                                                ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test038");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "1.710.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test039");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("#a4a a4a ", "10");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test040");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("sophie", "100.0#32.0chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test041");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", " -1 1", "/Users/sophie");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("hi!", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test043");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("JV(TM) SE RUNTIME ENVIRONMENT");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test044");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("97.0 35.0 -1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("4444444...", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444...                                          " + "'", str2.equals("4444444...                                          "));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test046");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:" + "'", str1.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test047");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/Users", (java.lang.CharSequence) "#/sophie#/sophie#/sophie#/sophie#/sophie#/sox   4 x 4  #/sophie#/sophie#/sophie#/sophie#/sophie#/sop");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test048");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) ":");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test049");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test050");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "oc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test051");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test052");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ihpos!ih", "                                                        mixed mode");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test053");
        float[] floatArray2 = new float[] { '4', 'a' };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float5 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 97.0f + "'", float4 == 97.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 97.0f + "'", float6 == 97.0f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test054");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("97.0 35.0 -1.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test055");
        char[] charArray9 = new char[] { '#', 'a', '4', '#', '4', 'a' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "xaaa4axa4aa", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ava HotSpo", charArray9);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "10a1a-1a-14444444444444444444444", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "#aaa4a#a4aa" + "'", str11.equals("#aaa4a#a4aa"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test056");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment", (int) (short) 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#aaa4a#a4aa", "HTTP://JAVA.ORACLE.COM/");
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                  10.14.3", strArray4, strArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 43 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test057");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("HI!SOPHIE", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test058");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 0, 0);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test059");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("TIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION" + "'", str2.equals("ATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test060");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libr", "/Users", (int) (byte) 100);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "");
        boolean boolean7 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test061");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, '#');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("-14041", "                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-14041" + "'", str2.equals("-14041"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("ihpos!ih", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ihpos!ih" + "'", str2.equals("ihpos!ih"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test064");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:", "44", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test065");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444-14a41");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test066");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "       100a-1a0a1a97a100        ", "                                                                                                 hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test067");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 35L, (double) 1L, (double) 46L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test068");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 10, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test069");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("100.0#32.0", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test070");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("!ih                                                                                                 ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "!ih                                                                                                 " + "'", str2.equals("!ih                                                                                                 "));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test071");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(" ", "97.0 35.0 -1.0", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test072");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("ava HotSpot(TM) 64-Bit Server VM", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test073");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "97.0435.04-1.0435.0452.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test074");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/", 0);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "10.14.3");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", strArray6, strArray9);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "sun.lwawt.macosx.CPrinterJob", 0, 0);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "!ih                                                                                                 ", (java.lang.CharSequence[]) strArray9);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "-140     ", (java.lang.CharSequence[]) strArray9);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str10.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test075");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                  " + "'", str2.equals("                                                                  "));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test076");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("...esU", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "...esU" + "'", str2.equals("...esU"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test077");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (java.lang.CharSequence) "#######...");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", charSequence2.equals("ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test078");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("1.0#0.0#52.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#0.0#52.0" + "'", str2.equals("1.0#0.0#52.0"));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test079");
        float[] floatArray6 = new float[] { ' ', (short) 100, 0L, (-1L), 0, '#' };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        float float10 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#', (int) (byte) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "32.0a100.0a0.0a-1.0a0.0a35.0" + "'", str9.equals("32.0a100.0a0.0a-1.0a0.0a35.0"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("100.0432.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0.2340.001" + "'", str1.equals("0.2340.001"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test081");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                51.0                                                ", (java.lang.CharSequence) "10a1a97.0435.04-1.0435.045210a1a-");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test082");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean5 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        boolean boolean8 = javaVersion1.atLeast(javaVersion6);
        java.lang.String str9 = javaVersion6.toString();
        java.lang.String str10 = javaVersion6.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.7" + "'", str9.equals("1.7"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.7" + "'", str10.equals("1.7"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test083");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("DK1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "dK1.7.0_80" + "'", str1.equals("dK1.7.0_80"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test084");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "10A-1A10A32A-1A1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test085");
        long[] longArray6 = new long[] { 100, (-1L), 0L, 1, 'a', 100L };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', (int) ' ', 0);
        try {
            java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ', (int) '4', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("141041410", 33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "141041410                        " + "'", str2.equals("141041410                        "));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test087");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("RaphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RaphicsEnvironment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test088");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test089");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "              4Sophie4               ", (java.lang.CharSequence) "/librax86_6", 90);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test090");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444444444aaaaaaaaaa44444444444444444444444444444444.0#0.0#52.0", "aaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test091");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', (int) (short) 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) 'a', (int) (short) 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 6, 2);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', (int) (byte) 100, (-14041));
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', 6, (int) (short) 0);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test092");
        char[] charArray9 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sophie", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "# 4   #   a", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test093");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle(".0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDACHINES/JDKALmAvIRTUAVA/jAVARY/jA/lIBRAAAAAAAAAAAAAAAAAAAAAA", "hi!soph", (-14041));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ".0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDACHINES/JDKALmAvIRTUAVA/jAVARY/jA/lIBRAAAAAAAAAAAAAAAAAAAAAA" + "'", str3.equals(".0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDACHINES/JDKALmAvIRTUAVA/jAVARY/jA/lIBRAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("/eihpoSU/", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eihpoSU/" + "'", str2.equals("eihpoSU/"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test095");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', (int) (short) 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("phicsEnvironmentar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "phicsEnvironmentar" + "'", str1.equals("phicsEnvironmentar"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test097");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("0.2340.001");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test098");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("32.0#100.0#0.0#-1.0#0.0#35.0", 11, 13);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.0#-1.0#0.0#" + "'", str3.equals("0.0#-1.0#0.0#"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test099");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: multiple points");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test100");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("x86_64", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test101");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str1.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test102");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("100-1", (float) 52);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test103");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                h !");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test104");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("/USophie/U", ' ');
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "RaphicsEnvironment", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test105");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("-1#0#1", "1.7", 97);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test106");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 1, 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0432.0" + "'", str10.equals("100.0432.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 32.0d + "'", double11 == 32.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100.0#32.0" + "'", str13.equals("100.0#32.0"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File" + "'", str2.equals("class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test108");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 41L, (float) 6L, (float) 41L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 6.0f + "'", float3 == 6.0f);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test109");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test110");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("0", "97.0435.04-1.0435.0452.0", "44444444444444444444444444444444444Sophie");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test111");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (short) 0);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "US                                                                                                  ");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: US                                                                                                  ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1" + "'", str9.equals("-1"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test112");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("                                      100.0 32.0                                       ", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                      100.0 32.0                                       " + "'", str2.equals("                                      100.0 32.0                                       "));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("", "1.7");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7" + "'", str2.equals("1.7"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test114");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (byte) 0, (float) 100, (float) 2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test115");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ', 46, 8);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test116");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV" + "'", str1.equals("NS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test117");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("97.0a35.0a-1.0a35.0a52.0", (short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test118");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("eihpos!ih", "eihpos!ih");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test119");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "1 1 100 1 -1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test120");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "dk1j7j0_80", (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test121");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', (int) (short) 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) 'a', (int) (short) 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 6, 2);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#', (int) (byte) 100, (-14041));
        byte byte23 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + byte23 + "' != '" + (byte) -1 + "'", byte23 == (byte) -1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test122");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "10a1a-1a-1", (java.lang.CharSequence) "dk1.7.0_801a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test123");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/USophie/U", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", 10);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test124");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "####################################################");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie", strArray6, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence[]) strArray9);
        int int12 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "              Sophie               ", (java.lang.CharSequence[]) strArray9);
        java.lang.String[] strArray13 = null;
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("1.7", strArray9, strArray13);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/Users/sophie" + "'", str10.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1.7" + "'", str14.equals("1.7"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test125");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) -1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test126");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("DK1.7.0_80", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DK1.7.0_80" + "'", str2.equals("DK1.7.0_80"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test127");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("chines/jdk1.7.0_80.jdk/Contents/H");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test128");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test129");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "4", (java.lang.CharSequence) "100.0#32.0chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test130");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1", (java.lang.CharSequence) "0.2340.001");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test131");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("chines/jdk1.7.0_80.jdk/Contents/H");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test132");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        boolean boolean2 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str3 = javaVersion0.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test133");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("              Sophie               ", "hi!sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              Sophie               " + "'", str2.equals("              Sophie               "));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test134");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Dk1.7.0_80", (java.lang.CharSequence) "0.23#0.25", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test135");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test136");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test137");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test138");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("en");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test139");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("TIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", "NS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION" + "'", str2.equals("TIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test140");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("mixed mode");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test141");
        java.io.File file0 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.lang.Class<?> wildcardClass1 = file0.getClass();
        short[] shortArray5 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        java.lang.Class<?> wildcardClass7 = shortArray5.getClass();
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/", 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("4444444444444444444444444444444444444444444444444444", strArray11, strArray15);
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "dk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.Class<?> wildcardClass19 = strArray15.getClass();
        java.io.File file20 = org.apache.commons.lang3.SystemUtils.getJavaIoTmpDir();
        java.lang.Class<?> wildcardClass21 = file20.getClass();
        java.lang.Class[] classArray23 = new java.lang.Class[4];
        @SuppressWarnings("unchecked") java.lang.Class<?>[] wildcardClassArray24 = (java.lang.Class<?>[]) classArray23;
        wildcardClassArray24[0] = wildcardClass1;
        wildcardClassArray24[1] = wildcardClass7;
        wildcardClassArray24[2] = wildcardClass19;
        wildcardClassArray24[3] = wildcardClass21;
        java.lang.String str33 = org.apache.commons.lang3.StringUtils.join(wildcardClassArray24);
        java.lang.String str34 = org.apache.commons.lang3.StringUtils.join((java.lang.reflect.GenericDeclaration[]) wildcardClassArray24);
        java.lang.String str38 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) wildcardClassArray24, "Java(TM) SE Runtime", 46, 8);
        java.lang.String str39 = org.apache.commons.lang3.StringUtils.join((java.lang.reflect.AnnotatedElement[]) wildcardClassArray24);
        org.junit.Assert.assertNotNull(file0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str16.equals("4444444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(file20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(classArray23);
        org.junit.Assert.assertNotNull(wildcardClassArray24);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File" + "'", str33.equals("class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File"));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File" + "'", str34.equals("class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File" + "'", str39.equals("class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test142");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                 Java HotSpot(TM) 64-Bit Server VM                                  ", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test143");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("aaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaa" + "'", str1.equals("aaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaa"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test144");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("us                                                                ", "hi!sophie ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "u" + "'", str2.equals("u"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test145");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "4444444444444444444444444444444aaaaaaaaaa44444444444444444444444444444444.0#0.0#52.0", (java.lang.CharSequence) "97.0435.04-1.0435.0452", 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test146");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test147");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("52.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.0");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test148");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("4444444444444444444444444444444444444444444444-14041");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"4444444444444444444444444444444444444444444444-14041\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test149");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "                                                51.0                                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test150");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "1 1 100 1 -1", (java.lang.CharSequence) "Use...", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test151");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("                                                                  ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test152");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 0, 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 32.0d + "'", double9 == 32.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test153");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("hi!", 87, 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test154");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification-Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification", (int) '#', "0100-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification-Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification" + "'", str3.equals("Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification-Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test155");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(9, 97, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test156");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                            java HotSpot(TM) 64-Bit Server VM                             ", "X   4 X 4  ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test157");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "-1#0#1", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  4 x 4   x", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test158");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "#6", "/librax86_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test159");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "#", (java.lang.CharSequence) "Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification-Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test160");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) " o ", (java.lang.CharSequence) "141041410                                                                                           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test161");
        float[] floatArray6 = new float[] { ' ', (short) 100, 0L, (-1L), 0, '#' };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a', (int) '4', (int) (byte) 10);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#');
        float float15 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        float float16 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 100.0f + "'", float12 == 100.0f);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "32.0#100.0#0.0#-1.0#0.0#35.0" + "'", str14.equals("32.0#100.0#0.0#-1.0#0.0#35.0"));
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + (-1.0f) + "'", float15 == (-1.0f));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + (-1.0f) + "'", float16 == (-1.0f));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test162");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("10a1a97.0435.04-1.0435.045210a1a-", 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a1a97.0435.04-1.0435.045210a1a-" + "'", str3.equals("10a1a97.0435.04-1.0435.045210a1a-"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test163");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("1.6", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test164");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("us");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                  " + "'", str1.equals("                                                                  "));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test166");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("MV ro avaj", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test167");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) -1, (long) (short) 1, 35L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1L) + "'", long3 == (-1L));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test168");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "4444444...", "-140");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test169");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("6", 3, " -1 1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " 6 " + "'", str3.equals(" 6 "));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test170");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', (int) (short) 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "UTF-8");
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1" + "'", str14.equals("-1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "�" + "'", str16.equals("�"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test171");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) " o ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test172");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/", 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("4444444444444444444444444444444444444444444444444444", strArray3, strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "10.14.3");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str8.equals("4444444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str9.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("hi!", "97.0a35.0a-1.0a35.0a52.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test174");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(66, 46, 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 46 + "'", int3 == 46);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test175");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "ttttttttttttttttttttttttttttttttht!", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test176");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKIT", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test177");
        char[] charArray10 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100.0 32.0", charArray10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a', (int) (byte) 0, (int) (short) 1);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#4A444#444A", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "#" + "'", str17.equals("#"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Library/Java/JavaVirtualMachines/jdkaaaaaaaaaa.0_80.jdk/Contents/Home/jre/lib/endorsed", "http://java.oracle.com/");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test179");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("0.2340.001", "", "01.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0.2340.001" + "'", str3.equals("0.2340.001"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test180");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 1, 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double14 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0432.0" + "'", str10.equals("100.0432.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 32.0d + "'", double11 == 32.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100.0432.0" + "'", str13.equals("100.0432.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test181");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double7 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "100.0432.0" + "'", str6.equals("100.0432.0"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 32.0d + "'", double7 == 32.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test182");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/USophie/U", "1.7.0_80-b15");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "sophie", (java.lang.CharSequence[]) strArray3);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "######HTTP://JAVA.ORACLE.COM/######");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test184");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "NS:/lIBRARY/jAVA/jAVAvIRTUALmACHINES/JDK1.7.0_80.JDK/cONTENTS/hOME/JRE/LIB/EXT:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAV", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test185");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("dk1.#aaa4a#a4aa", "en");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test186");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/eihpoSU/", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU/" + "'", str2.equals("/eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU/"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test187");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "97.0435.04-1.0435.0452.0", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test188");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                                                                                 hi!", (int) '4', "######HTTP://JAVA.ORACLE.COM/######");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                 hi!" + "'", str3.equals("                                                                                                 hi!"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test189");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test190");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "4444444444444444444444444444444444444444444444-14041");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test191");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/", (int) (byte) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test192");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("mixed mode", "x   4 x 4  ", "ava HotSpo", 33);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "mixed mode" + "'", str4.equals("mixed mode"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("              Sophie               ", "hhi", 35);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "              Sophie               " + "'", str3.equals("              Sophie               "));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test194");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 13, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "             " + "'", str3.equals("             "));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test195");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "raphicsEnvironment", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test196");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#/sophie#/sophie#/sophie#/sophie#/sophie#/sox   4 x 4  #/sophie#/sophie#/sophie#/sophie#/sophie#/sop", (java.lang.CharSequence) "0a100a-", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test197");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("1a0a1a0", "eihpos!i");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a0a1a0" + "'", str2.equals("1a0a1a0"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test198");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "#/sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test199");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "10a-1a10a32a-1a1", (java.lang.CharSequence) "6_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test200");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("-1#0#1", "", "#AAA4A#A4AA                                         ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1#0#1" + "'", str3.equals("-1#0#1"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Dk1.7.0_80", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Dk1.7.0_80" + "'", str2.equals("Dk1.7.0_80"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test202");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip(" 6 ", "aaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 6 " + "'", str2.equals(" 6 "));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test203");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("       100a-1a0a1a97a100        ");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test204");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "!ih", (java.lang.CharSequence) "24.80-b11", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test205");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("DK1.7.0_80", "dk1j7j0_80", 35, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "DK1.7.0_80dk1j7j0_80" + "'", str4.equals("DK1.7.0_80dk1j7j0_80"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test206");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                .0_80-b1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                .0_80-b1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test207");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("141041410                                  ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "141041410                                  ..." + "'", str1.equals("141041410                                  ..."));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test208");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 0, 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0#32.0" + "'", str10.equals("100.0#32.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100.0432.0" + "'", str13.equals("100.0432.0"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test209");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "141041410                        ", (int) (short) -1, 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(":", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test211");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "...esU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test212");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/", 0);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "10.14.3");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", strArray4, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ', 11, 0);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str8.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Java(TM) SE Runtime", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM..." + "'", str2.equals("Java(TM..."));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi!sophi", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!sophi" + "'", str2.equals("hi!sophi"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test215");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test216");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "444444444444444444444444444444-1441", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("a4 4#4 444#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "A4 4#4 444#" + "'", str1.equals("A4 4#4 444#"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test218");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("                                                        mixed mode", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                        mixed mode" + "'", str2.equals("                                                        mixed mode"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test219");
        long[] longArray6 = new long[] { 10L, (byte) -1, (short) 10, ' ', (short) -1, (byte) 1 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', (int) '#', 0);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        long long16 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ', (int) '#', 10);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10a-1a10a32a-1a1" + "'", str15.equals("10a-1a10a32a-1a1"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10a-1a10a32a-1a1" + "'", str18.equals("10a-1a10a32a-1a1"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test220");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Libr", (float) 7);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.0f + "'", float2 == 7.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test221");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                               -1#0#1                                               ", "0100-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test222");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "mixed mode");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test223");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) 10, "-14041");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-14041-140" + "'", str3.equals("-14041-140"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test224");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "141041410                                                                                           ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test225");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Mac OS X", "##4# ### #a##4# ### #a##4# ### #a##4# ### #a##4# ### #a##4# ### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "32.04100.040.04-1.040.0435.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X" + "'", str3.equals("Mac OS X"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test226");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("#444 4#4 4a", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test227");
        java.lang.CharSequence charSequence0 = null;
        try {
            int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance(charSequence0, (java.lang.CharSequence) "24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Strings must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test228");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "#444 4#4 4a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java(TM...", "1a10a1a1044444444444444444444444444", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM..." + "'", str3.equals("Java(TM..."));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test230");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("                                 jAVA(tm) se rUNTIME eNVIRONMENT                                 ", "4");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test231");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000o" + "'", str1.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000o"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test232");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "hi!sophie", (java.lang.CharSequence) "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test233");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("/Users/sophie/Documents/defects4j/tmp/run_randoop...", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test234");
        int[] intArray4 = new int[] { 1, (byte) 10, (short) 1, 10 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, '#', (int) (byte) 100, (int) (byte) 10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 1, (int) (byte) 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray4, '#');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "141041410" + "'", str8.equals("141041410"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1#10#1#10" + "'", str18.equals("1#10#1#10"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test235");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("10a1a-1a-14444444444444444444444");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test236");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("-140     ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test237");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/Users", 0);
        java.lang.Class<?> wildcardClass4 = strArray3.getClass();
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test238");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("0 100 -1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0100-1" + "'", str1.equals("0100-1"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test239");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test240");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("phicsEnvironmentar", ' ');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "phicsEnvironmentar" + "'", str3.equals("phicsEnvironmentar"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test241");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("##########");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test242");
        char[] charArray9 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100.0 32.0", charArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', 0, 0);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("hi!soph", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test244");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "RaphicsEnvironment", (java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test245");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence) "#");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test246");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test247");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "32.0 100.0 0.0 -1.0 0.0 35.0", (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test248");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("141041410", " ...", "10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "141041410" + "'", str3.equals("141041410"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test249");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 0, 0);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#', (int) (short) 1, (int) (byte) 1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-14041" + "'", str12.equals("-14041"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 1 + "'", short13 == (short) 1);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test250");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("dk1.7.0_80", "dk1j7j0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "dk1.7.0_80" + "'", str2.equals("dk1.7.0_80"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test251");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("10 -1 10 32 -1 1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10 -1 10 32 -1 1" + "'", str1.equals("10 -1 10 32 -1 1"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("-140", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test253");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "97.0435.04-1.0435.0452.", "24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test254");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "dk1.#aaa4a#a4aa", (java.lang.CharSequence) "x   4 x 4  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test255");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test256");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("104-14104324-141");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("PHICSENVIRONMENTAR", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PHICSENVIRONMENTAR" + "'", str2.equals("PHICSENVIRONMENTAR"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test258");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.Class<?> wildcardClass5 = shortArray3.getClass();
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#0#1" + "'", str7.equals("-1#0#1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 1 + "'", short8 == (short) 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1a0a1" + "'", str11.equals("-1a0a1"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 1 + "'", short12 == (short) 1);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) -1 + "'", short13 == (short) -1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test259");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "eihpoS", "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test260");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 3, (double) 41.0f, 41.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test261");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.6", (java.lang.CharSequence) "32.04100.040.04-1.040.0435.0444444444444444444", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test262");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test263");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "RS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test264");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, (float) ' ', (float) (-1));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test265");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10 -1 10 32 -1 1", 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test266");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("A4 4#4 444#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a4 4#4 444#" + "'", str1.equals("a4 4#4 444#"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test267");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "0a100a-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test268");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("52.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.0", "", "                                     -1#0#1                                               ");
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test269");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("97.0435.04-1.0435.0452.", "Oracle Corporation", (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test270");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sophie                                                                                              ", "aa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test271");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "104-14104324-141", (java.lang.CharSequence) "97.0435.04-1.0435.0452.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test272");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("-1a0a1", "", (int) (short) 100);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "eihpoS");
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "A4 4#4 444#", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1a0a1" + "'", str6.equals("-1a0a1"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test273");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("Use...", "eihpoS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Use..." + "'", str2.equals("Use..."));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test274");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("US");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "Java(TM) SE Runtime", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test275");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("1.6", 23);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test276");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 1, (short) (byte) 10, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test277");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "sun.lwawt.macosx.LWCToolkit", (int) (byte) -1);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361", (int) (byte) 1);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("1.1", strArray4, strArray8);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, ' ');
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.1" + "'", str9.equals("1.1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "/ br ry/J v /J v V r M h e /jd 1 7 0_80 jd / e /H e/jre/ b/e d r ed" + "'", str11.equals("/ br ry/J v /J v V r M h e /jd 1 7 0_80 jd / e /H e/jre/ b/e d r ed"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test278");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "/", (java.lang.CharSequence) "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/" + "'", charSequence2.equals("/"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test279");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 5, (float) 13, (float) 8);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 13.0f + "'", float3 == 13.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test280");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#4A444#444A", 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test281");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "eihpos!i", "100.0#32.0chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test282");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "oL.braryoJavaoJavaV.rtualMacj.n0sojdk1.7.0_80.jdkoCk", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test283");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("100.0#32.0", "...esU");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0#32.0" + "'", str2.equals("100.0#32.0"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test284");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("sun.lwawt.macosx.LWCToolkit", "4444444444444444444444444444444444444444444444-1441", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str3.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test285");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51.0", "#", (int) 'a');
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "Java(TM) SE Runtime");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test286");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1a10a1a10", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a10" + "'", str2.equals("1a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a10"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test287");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("sun.lwawt.macosx.CPrinterJob", "X   4 X 4  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test288");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType(" ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test289");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("mv RO AVAJ", (int) (byte) 100, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########################################################################################mv RO AVAJ" + "'", str3.equals("##########################################################################################mv RO AVAJ"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test290");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.min(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test291");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("US");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "5241041");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test292");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                               -1#0#1                                               ", (java.lang.CharSequence) "phicsEnvironmentar", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test293");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("                            java HotSpot(TM) 64-Bit Server VM                             ", "4", (int) ' ', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4 HotSpot(TM) 64-Bit Server VM                             " + "'", str4.equals("4 HotSpot(TM) 64-Bit Server VM                             "));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test294");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test295");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test296");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (int) (short) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test297");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment", (java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test298");
        long[] longArray6 = new long[] { 10L, (byte) -1, (short) 10, ' ', (short) -1, (byte) 1 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', (int) '#', 0);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', 13, (int) (byte) 1);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10a-1a10a32a-1a1" + "'", str19.equals("10a-1a10a32a-1a1"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("Java Platform API Specification", "-1.0 1.0 1.0", "1 10 1 10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test300");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("UTF-8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTF-8" + "'", str1.equals("UTF-8"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test301");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(" -1 1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1 1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test302");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("!ih");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"!ih\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test303");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("##########################################################################################mv RO AVAJ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test304");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "0100-1", (java.lang.CharSequence) "eihpoS");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test305");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 10, "mv RO AVAJ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test306");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("5241041", "US", (int) (short) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("Java Platform API Specification", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "1a10a1a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase(".0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDACHINES/JDKALmAvIRTUAVA/jAVARY/jA/lIBRAAAAAAAAAAAAAAAAAAAAAA", "/Library/Java/JavaVirtualMachines/jdkaaaaaaaaaa.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDACHINES/JDKALmAvIRTUAVA/jAVARY/jA/lIBRAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals(".0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDACHINES/JDKALmAvIRTUAVA/jAVARY/jA/lIBRAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test310");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "# 4   #   a", (java.lang.CharSequence) "######HTTP://JAVA.ORACLE.COM/######");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("#aaaaa4aaa#aaa4aaaa                                         ", "US                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#aaaaa4aaa#aaa4aaaa                                         " + "'", str2.equals("#aaaaa4aaa#aaa4aaaa                                         "));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test312");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdkaaaaaaaaaa.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "6_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test313");
        long[] longArray6 = new long[] { 10L, (byte) -1, (short) 10, ' ', (short) -1, (byte) 1 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.Class<?> wildcardClass8 = longArray6.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', (int) (short) 100, (int) '4');
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test314");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa" + "'", str1.equals("xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test315");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test316");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 0, (double) (short) 10, (double) 73.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 73.0d + "'", double3 == 73.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test317");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("dk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test318");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt(" Users/sophie/Library/Java/Extensions:/Library", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test319");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("# 4   #   a", "4444444...", "                            java HotSpot(TM) 64-Bit Server VM                             ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "# 4   #   a" + "'", str3.equals("# 4   #   a"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test320");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_0_9;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion5 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean6 = javaVersion4.atLeast(javaVersion5);
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        boolean boolean8 = javaVersion3.atLeast(javaVersion4);
        boolean boolean9 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion4);
        java.lang.String str10 = javaVersion4.toString();
        boolean boolean11 = javaVersion1.atLeast(javaVersion4);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_0_9 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_0_9));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion5 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion5.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1.6" + "'", str10.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test321");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("-1#0#1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#0#1-" + "'", str1.equals("1#0#1-"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test322");
        short[] shortArray5 = new short[] { (short) 1, (short) 1, (short) 10, (short) 0, (byte) -1 };
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray5);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray5, ' ', 73, 7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray5, 'a');
        org.junit.Assert.assertNotNull(shortArray5);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 10 + "'", short7 == (short) 10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1a1a10a0a-1" + "'", str13.equals("1a1a10a0a-1"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test323");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "1a10a1a10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test324");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 1, 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double15 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double16 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0#32.0" + "'", str9.equals("100.0#32.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.0d + "'", double10 == 32.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100.0 32.0" + "'", str13.equals("100.0 32.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 32.0d + "'", double14 == 32.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test325");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("a                                aa", "4 HotSpot(TM) 64-Bit Server VM                             ", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "a                                aa" + "'", str3.equals("a                                aa"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test327");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment", (java.lang.CharSequence) "1.710.14.3");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test328");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "dk1j7j0_80", 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test329");
        float[] floatArray3 = new float[] { 10.0f, 2, 90 };
        float[] floatArray7 = new float[] { 10.0f, 2, 90 };
        float[] floatArray11 = new float[] { 10.0f, 2, 90 };
        float[][] floatArray12 = new float[][] { floatArray3, floatArray7, floatArray11 };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray12);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test330");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("104-14104324-141", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "104-141" + "'", str2.equals("104-141"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test331");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "dk1.#aaa4a#a4aa                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test332");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (int) 'a', 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...nsi..." + "'", str3.equals("...nsi..."));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test333");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test334");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("eihpoSU/", "104-141");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eihpoSU/" + "'", str2.equals("eihpoSU/"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test336");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("100.0432.0", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0432.0" + "'", str2.equals("100.0432.0"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test337");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 1, (byte) -1, (byte) -1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a', 4, 4);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray4, '#', (-14041), 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -14041");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10a1a-1a-1" + "'", str6.equals("10a1a-1a-1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10 1 -1 -1" + "'", str8.equals("10 1 -1 -1"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test338");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("141041410                                                                                           ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "141041410                                                                                           " + "'", str2.equals("141041410                                                                                           "));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test339");
        char[] charArray10 = new char[] { '#', 'a', '4', '#', '4', 'a' };
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "xaaa4axa4aa", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "ava HotSpo", charArray10);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "32.0a100.0a0.0a-1.0a0.0a35.0", charArray10);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-1", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#aaa4a#a4aa" + "'", str12.equals("#aaa4a#a4aa"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("10a-1a10a32a-1a1", "51.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test341");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 0, 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double13 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0a32.0" + "'", str11.equals("100.0a32.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 32.0d + "'", double12 == 32.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 32.0d + "'", double13 == 32.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test342");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("Ava HotSpo");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Ava HotSpo is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test343");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 35.0f, (double) 41, (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test344");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) 0, (float) (short) 10, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test345");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4', 7, 41);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1a0a1" + "'", str7.equals("-1a0a1"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test346");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("oRACLE cORPORATION", "              4Sophie4               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "              4Sophie4               " + "'", str2.equals("              4Sophie4               "));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("TIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", "US                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION" + "'", str2.equals("TIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test348");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("ihpos!ih", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ihpos!ih" + "'", str2.equals("ihpos!ih"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test349");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("UTF-8", 100, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                               UTF-8                                                " + "'", str3.equals("                                               UTF-8                                                "));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test350");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "0#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#10", (java.lang.CharSequence) "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test351");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test352");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "6_64", (java.lang.CharSequence) "ttttttttttttttttttttttttttttttttht!");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test353");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                                                                 hi!");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test354");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("10 1 -1 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test355");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 0, (int) (byte) 1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1" + "'", str8.equals("-1"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test356");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("raphicsEnvironment", "10 -1 10 32 -1 1");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "DK1.7.0_80", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test358");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean7 = javaVersion2.atLeast(javaVersion3);
        java.lang.String str8 = javaVersion3.toString();
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean10 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion9);
        java.lang.String str11 = javaVersion9.toString();
        org.apache.commons.lang3.JavaVersion javaVersion12 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion12);
        boolean boolean14 = javaVersion9.atLeast(javaVersion12);
        java.lang.String str15 = javaVersion12.toString();
        boolean boolean16 = javaVersion3.atLeast(javaVersion12);
        boolean boolean17 = javaVersion0.atLeast(javaVersion12);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.6" + "'", str8.equals("1.6"));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.2" + "'", str11.equals("1.2"));
        org.junit.Assert.assertTrue("'" + javaVersion12 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion12.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1.2" + "'", str15.equals("1.2"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test359");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Jv(TM) SE Runtime Environment", (java.lang.CharSequence) "                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test360");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CO", "dk1j7j0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CO" + "'", str2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CO"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test361");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("6");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6" + "'", str2.equals("6"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test362");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("0", "", "                                 Java HotSpot(TM) 64-Bit Server VM                                  ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test363");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:", (java.lang.CharSequence) "100.0#32.0", 23);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test364");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("us");
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", 0, 46);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test365");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "en", 10, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test366");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("              Sophie               ", 8, 73);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "      Sophie               " + "'", str3.equals("      Sophie               "));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test367");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1a0a1", "1a10a1a10", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test368");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HTTP://JAVA.ORACLE.COM/" + "'", str1.equals("HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test369");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("10a1a-1a-1", 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test370");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("1.710.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.710.14.3" + "'", str1.equals("1.710.14.3"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test371");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("a                                aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "a aa" + "'", str1.equals("a aa"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test372");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "hhi", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 27 + "'", int3 == 27);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test373");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o ", 32, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o " + "'", str3.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o "));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("######HTTP://JAVA.ORACLE.COM/######", 27, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "M/######" + "'", str3.equals("M/######"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test375");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aa", 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("##4# ### #a##4# ### #a##4# ### #a##4# ### #a##4# ### #a##4# ### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "-140");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test377");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (short) 0);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 90, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 90");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test378");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a');
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "52.xa32.x");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test379");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("ttttttttttttttttttttttttttttttttht!", (-14041), '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ttttttttttttttttttttttttttttttttht!" + "'", str3.equals("ttttttttttttttttttttttttttttttttht!"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test380");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("10A-1A10A32A-1A1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10a-1a10a32a-1a1" + "'", str1.equals("10a-1a10a32a-1a1"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("                                          1.7.0_80-b15                                           ", "1a10a1a10");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a10a1a10" + "'", str2.equals("1a10a1a10"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("dk1.#aaa4a#a4aa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DK1.#AAA4A#A4AA" + "'", str1.equals("DK1.#AAA4A#A4AA"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test383");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 0, 0);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.Class<?> wildcardClass11 = shortArray3.getClass();
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 1 + "'", short12 == (short) 1);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 1 + "'", short13 == (short) 1);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test384");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("Mac OS X");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test385");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                                51.0                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                51.0                                                " + "'", str1.equals("                                                51.0                                                "));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test386");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("10a-1a10a32a-1a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10a-1a10a32a-1a1" + "'", str1.equals("10a-1a10a32a-1a1"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test387");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("####################################################", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "DK1.7.0_80");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("Use...", strArray6, strArray8);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mixed mode", "####################################################", 0);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.replaceEach(".io.Filecl", strArray8, strArray13);
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.stripAll(strArray13);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Use..." + "'", str9.equals("Use..."));
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + ".io.Filecl" + "'", str14.equals(".io.Filecl"));
        org.junit.Assert.assertNotNull(strArray15);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test388");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "32.0 100.0 0.0 -1.0 0.0 35.0", (java.lang.CharSequence) "/USophie/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test389");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("", "                                h !");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test390");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("sophie                                                                                              ", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test391");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "32.0#100.0#0.0#-1.0#0.0#35.0", (java.lang.CharSequence) "24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1678 + "'", int2 == 1678);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test392");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "6_64");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test393");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("32.04100.040.04-1.040.0435.0", (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test394");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Jv(TM) ...", (java.lang.CharSequence) "01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b15", 90);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test395");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("                                .0_80-b15", "eihpoS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                .0_80-b15" + "'", str2.equals("                                .0_80-b15"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test396");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "              Sophie               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test397");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "/eihpoSU/", "Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test398");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("4444444444444444444444444444444aaaaaaaaaa44444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444aaaaaaaaaa44444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444aaaaaaaaaa44444444444444444444444444444444"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(".0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDACHINES/JDKALmAvIRTUAVA/jAVARY/jA/lIBRAAAAAAAAAAAAAAAAAAAAAA", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDACHINES/JDKALmAvIRTUAVA/jAVARY/jA/lIBRAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals(".0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDACHINES/JDKALmAvIRTUAVA/jAVARY/jA/lIBRAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test400");
        char[] charArray9 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.0#0.0#52.0", charArray9);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', (int) 'a', (int) (short) 1);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test401");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("141041410                        ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"141041410                        \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test402");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#6", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test403");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("#444 444 ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444 444 \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test404");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test405");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "32.0a100.0a0.0a-1.0a0.0a35.0", (java.lang.CharSequence) "x   4 x 4  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test406");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1 1 100 1 -1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test407");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("-14041");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-14041" + "'", str1.equals("-14041"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test408");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Documents/defects4j/tmp/run_randoop...", 9, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test409");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 1, 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double11 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0#32.0" + "'", str9.equals("100.0#32.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.0d + "'", double10 == 32.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100.0a32.0" + "'", str13.equals("100.0a32.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 32.0d + "'", double14 == 32.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "100.0 32.0" + "'", str16.equals("100.0 32.0"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test410");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test411");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test412");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "4444444444444444444444444444444444444444444444-1441", (java.lang.CharSequence) "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test413");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa", 73, "0.23#0.25");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa" + "'", str3.equals("xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test414");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "phicsEnvironmentar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("http://java.oracle.com/", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test416");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "xaaa4axa4aa              Sophie                     ", (java.lang.CharSequence) "-1.0 1.0 1.0", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test417");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("97.0 35.0 -1.0", ".io.Filecl", "DK1.7.0_80");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "97.0 35.0 -1.0" + "'", str3.equals("97.0 35.0 -1.0"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test418");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("Java(TM...", "97.0 35.0 -1.0 35.0 52.0", (int) (byte) 10, 32);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Java(TM...97.0 35.0 -1.0 35.0 52.0" + "'", str4.equals("Java(TM...97.0 35.0 -1.0 35.0 52.0"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test419");
        long[] longArray6 = new long[] { 10L, (byte) -1, (short) 10, ' ', (short) -1, (byte) 1 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', (int) '#', 0);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 32L + "'", long14 == 32L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test420");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("              Sophie               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sophie" + "'", str1.equals("Sophie"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test421");
        int[] intArray3 = new int[] { (byte) 0, 100, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int14 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int15 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a100a-1" + "'", str7.equals("0a100a-1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0#100#-1" + "'", str11.equals("0#100#-1"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test422");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("TIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test423");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "                                          1.7.0_80-b15                                           ", "                                h !");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test424");
        char[] charArray1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "DK1.#AAA4A#A4AA", charArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test425");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test426");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "      Sophie               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test427");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("141041410", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "110110" + "'", str2.equals("110110"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test428");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "52.0a32.0", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test429");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test430");
        byte[] byteArray1 = new byte[] { (byte) 10 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test431");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test432");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test433");
        int[] intArray3 = new int[] { (byte) 0, 100, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0#100#-1" + "'", str7.equals("0#100#-1"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "041004-1" + "'", str9.equals("041004-1"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test434");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test435");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp(".0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDACHINES/JDKALmAvIRTUAVA/jAVARY/jA/lIBRAAAAAAAAAAAAAAAAAAAAAA", "-14041-140");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDACHINES/JDKALmAvIRTUAVA/jAVARY/jA/lIBRAAAAAAAAAAAAAAAAAAAAAA" + "'", str2.equals(".0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDACHINES/JDKALmAvIRTUAVA/jAVARY/jA/lIBRAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test436");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "X   4 X 4  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test437");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libr", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test438");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 27);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 27.0f + "'", float2 == 27.0f);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test439");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble(" 6 ", (double) 66L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test440");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "10.14.3");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1#0#1", " ", 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation", strArray3, strArray7);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray9, "1.7");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Oracle Corporation" + "'", str8.equals("Oracle Corporation"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test441");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray10 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "x   4 x 4  ", charArray10);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray10, '4', (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test442");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("-1a0a1", "32.0 100.0 0.0 -1.0 0.0 35.0", "32.0a100.0a0.0a-1.0a0.0a35.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test443");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("aaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AAAAA" + "'", str1.equals("AAAAA"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("-1#0#1", "1a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a10", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test445");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361", "US", "eihpoS");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361" + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test446");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) ".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libraaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test447");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment", (int) (short) 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop...", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test448");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "0.0#-1.0#0.0#", (java.lang.CharSequence) " o ", 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test449");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Java(TM) SE Runtime Environment", "");
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, 'a', 35, 73);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test450");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        boolean boolean1 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        java.lang.String str2 = javaVersion0.toString();
        java.lang.Class<?> wildcardClass3 = javaVersion0.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.1" + "'", str2.equals("1.1"));
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test451");
        java.lang.Number[] numberArray1 = new java.lang.Number[] { 1 };
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(numberArray1);
        org.junit.Assert.assertNotNull(numberArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1" + "'", str2.equals("1"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test452");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDKs.7./_8/.JDK/COUS");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDKs.7./_8/.JDK/COUS" + "'", str1.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDKs.7./_8/.JDK/COUS"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test453");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  4 x 4   x");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test454");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "10a1a-1a-1", charSequence1, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test455");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean2 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion3 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion4 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean5 = javaVersion3.atLeast(javaVersion4);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion3);
        boolean boolean7 = javaVersion1.atLeast(javaVersion3);
        java.lang.String str8 = javaVersion3.toString();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + javaVersion3 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion3.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion4 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion4.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.6" + "'", str8.equals("1.6"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test456");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("#######...", "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#######..." + "'", str2.equals("#######..."));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test457");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 0, 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4', 97, 2);
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', (int) (short) 0, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test458");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            ", 1678, "                                 Java HotSpot(TM) 64-Bit Server VM                                  ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS                                             Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                              " + "'", str3.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS                                             Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                              "));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test459");
        char[] charArray10 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100.0#32.0", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "5241041", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test460");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("141041410                                  ...", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str2.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test461");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444444444aaaaaaaaaa44444444444444444444444444444444.0#0.0#52.0", "/ br ry/J v /J v V r M h e /jd 1 7 0_80 jd / e /H e/jre/ b/e d r ed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test462");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Oracle Corporation", (int) (short) 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Oracle Corporation" + "'", str3.equals("Oracle Corporation"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("#aaaaa4aaa#aaa4aaaa                                         ", "M/######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#aaaaa4aaa#aaa4aaaa                                         " + "'", str2.equals("#aaaaa4aaa#aaa4aaaa                                         "));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test464");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("oRACLE cORPORATION", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE cORPORATION" + "'", str2.equals("oRACLE cORPORATION"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test465");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test466");
        float[] floatArray3 = new float[] { 1, 0.0f, '4' };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', (int) '#', (int) (byte) 10);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 52.0f + "'", float4 == 52.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 52.0f + "'", float10 == 52.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.0a0.0a52.0" + "'", str13.equals("1.0a0.0a52.0"));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test467");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, 13, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 13 + "'", int3 == 13);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test468");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("####################################################", "10a32a97a0a-1a-1", "             ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "####################################################" + "'", str3.equals("####################################################"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test469");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "/librax86_6", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("44", "dk1j7j0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44" + "'", str2.equals("44"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test471");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test472");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("-1a0a1", "", (int) (short) 100);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "eihpoS");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("#aaa4a#a4aa                                         ");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray8);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("97.0435.04-1.0435.0452.0", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1a0a1" + "'", str6.equals("-1a0a1"));
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test473");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test474");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("444444444444444444444444444444-1441", (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test475");
        java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("1.6");
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + 1.6f + "'", number1.equals(1.6f));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test476");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Ava HotSpo", (java.lang.CharSequence) "Jv(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test477");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny(charSequence0, (java.lang.CharSequence) "1a10a1a10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test478");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("hi!sophi");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!sophi\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test479");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("32.0 100.0 0.0 -1.0 0.0 35.0");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.split("/", "Oracle Corporation", (int) (byte) 0);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                Java(TM) SE Runtime ", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 24 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test480");
        float[] floatArray2 = new float[] { '4', 'a' };
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray2);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, 'a');
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 97.0f + "'", float3 == 97.0f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 97.0f + "'", float4 == 97.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "52.0a97.0" + "'", str6.equals("52.0a97.0"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test481");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("JV(TM) SE RUNTIME ENVIRONMENT", 6, (int) '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " SE RUNTIME ENVIRONMENT" + "'", str3.equals(" SE RUNTIME ENVIRONMENT"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test482");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.710.14.3", ".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                h !");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                h !" + "'", str1.equals("                                h !"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("97.0435.04-1.0435.0452", "0 100 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97.0435.04-1.0435.0452" + "'", str2.equals("97.0435.04-1.0435.0452"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test485");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, charSequence1, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test486");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "             ", (java.lang.CharSequence) "                                h !");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test487");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/ br ry/J v /J v V r M h e /jd 1 7 0_80 jd / e /H e/jre/ b/e d r ed", "10.14.3");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/ br ry/J v /J v V r M h e /jd 1 7 0_80 jd / e /H e/jre/ b/e d r ed" + "'", str2.equals("/ br ry/J v /J v V r M h e /jd 1 7 0_80 jd / e /H e/jre/ b/e d r ed"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test488");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test489");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray9 = new char[] { '#', '4', ' ', '4', ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " ", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "#aaaaa4aaa#aaa4aaaa                                         ", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test490");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "                                               UTF-8                                                ", (java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/co", 32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("52.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.0" + "'", str2.equals("52.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.0"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test492");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("dk1.7.0_80.jdk/Contents/Home/jre");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"dk1.7.0_80.jdk/Contents/Home/jre\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test493");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "######HTTP://JAVA.ORACLE.COM/######");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test494");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "####################################################");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie", strArray6, strArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence[]) strArray9);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("Java Platform API Specification", strArray1, strArray9);
        java.lang.String[] strArray13 = org.apache.commons.lang3.StringUtils.stripAll(strArray9);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/Users/sophie" + "'", str10.equals("/Users/sophie"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Java Platform API Specification" + "'", str12.equals("Java Platform API Specification"));
        org.junit.Assert.assertNotNull(strArray13);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test495");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "#/SOPHIE", (int) (short) 100, 13);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test496");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 1, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 1 + "'", byte3 == (byte) 1);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test497");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "en", (java.lang.CharSequence) "                                               -1#0#1                                               ", 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test498");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("10", (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test499");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "32.0 100.0 0.0 -1.0 0.0 35.0", 90);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest6.test500");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10 -1 10 32 -1 1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}

