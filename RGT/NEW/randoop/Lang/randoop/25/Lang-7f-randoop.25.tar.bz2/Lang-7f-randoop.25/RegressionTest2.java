import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("HI!SOPHIE");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/Library/Java/JavaVirtualMachines/jdkaaaaaaaaaa.0_80.jdk/Contents/Home/jre/lib/endorsed", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libr" + "'", str2.equals(".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libr"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Sophie", "1.710.14.3");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("h !", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                h !" + "'", str2.equals("                                h !"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "100.0 32.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        byte[] byteArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray0, 'a', (int) (short) 1, (int) (short) 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("              Sophie               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sophie" + "'", str1.equals("Sophie"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("xaaa4axa4aa", "Java Virtual Machine Specification", 66);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa" + "'", str3.equals("xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (short) 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########" + "'", str3.equals("##########"));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", "1.710.14.3");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("0#100#-1", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#100#-1" + "'", str2.equals("0#100#-1"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', (int) (short) 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        byte[] byteArray0 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.toString(byteArray0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "xaaa4axa4aa", (java.lang.CharSequence) "xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.7.0_80", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("#");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 10L, (double) (byte) 10, (double) 97);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "                                 Java HotSpot(TM) 64-Bit Server VM                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (short) 1, 0.0d, 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", "4444444...", "0100-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("Oracle Corporation", "/USophie/U");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Oracle Corporation" + "'", str2.equals("Oracle Corporation"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("oRACLE cORPORATION", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Users", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("US                                                                                                 ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "##########");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "#aaa4a#a4aa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("1.710.14.3", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.710.14.3" + "'", str2.equals("1.710.14.3"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("100a-1a0a1a97a100", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100a-1a0a1a97a100" + "'", str2.equals("100a-1a0a1a97a100"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users" + "'", str2.equals("/Users"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Java Platform API Specification", "x   4 x 4  ", "######HTTP://JAVA.ORACLE.COM/######");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification" + "'", str3.equals("Java Platform API Specification"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        float[] floatArray2 = new float[] { (byte) 1, 0 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray2, '#', (int) ' ', (int) (byte) -1);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 8);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0f + "'", float2 == 8.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "ava HotSpo");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444...", "1.710.14.3");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("en", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/librax86_64");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/co", (-1), ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/co" + "'", str3.equals("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/co"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie", (int) '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", strArray4, strArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "", (int) 'a', 97);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/co");
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "aaaaaaaaaa", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str9.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str10.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str16.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("/librax86_64", 8);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6_64" + "'", str2.equals("6_64"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens(":", "1.7", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/", 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("4444444444444444444444444444444444444444444444444444", strArray3, strArray7);
        int int9 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "                                               -1#0#1                                               ");
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, "-1#0#1", 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str8.equals("4444444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(strArray11);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.6", "                                                51.0                                                ", 0);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/USophie/", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Jv(TM) SE Runtime Environment", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jv(TM) ..." + "'", str2.equals("Jv(TM) ..."));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        long[] longArray6 = new long[] { 10L, (byte) -1, (short) 10, ' ', (short) -1, (byte) 1 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "10 -1 10 32 -1 1" + "'", str9.equals("10 -1 10 32 -1 1"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "DK1.7.0_80", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "6", "/librax86_64");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("hi!", "####################################################", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C", 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("hi!sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!sophi" + "'", str1.equals("hi!sophi"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/", (java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 0L, 8.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                Java(TM) SE Runtime ", "/USophie/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41 + "'", int2 == 41);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "10.14.3");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1#0#1", " ", 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation", strArray3, strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, 'a');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Oracle Corporation" + "'", str8.equals("Oracle Corporation"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1#0#1" + "'", str10.equals("-1#0#1"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CO", 66, "US                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            " + "'", str3.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            "));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CO", (java.lang.CharSequence) "100.0 32.0", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, 'a', 10, 100);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("######HTTP://JAVA.ORACLE.COM/######");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "######HTTP://JAVA.ORACLE.COM/######" + "'", str1.equals("######HTTP://JAVA.ORACLE.COM/######"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) -1, (float) 100, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        char[] charArray10 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100.0 32.0", charArray10);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a', (int) (byte) 0, (int) (short) 1);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "Mac OS X", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "#" + "'", str17.equals("#"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "Jv(TM) ...", (java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("!ih                                                                                                 ", "                                               -1#0#1                                               ");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(" ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " " + "'", str1.equals(" "));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "java or VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 41);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "HI!SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 0, (long) 66, 0L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 66L + "'", long3 == 66L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("US                                                                                                  ", (int) ' ', "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US                                                                                                  " + "'", str3.equals("US                                                                                                  "));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100.0432.0", "-1#0#1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10" + "'", str1.equals("10"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.7.0_80" + "'", str1.equals("1.7.0_80"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str1.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment", 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "100.0#32.0", (java.lang.CharSequence) "0#100#-1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment", (java.lang.CharSequence) "Sophie", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 1, (byte) 100, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "#", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("java HotSpot(TM) 64-Bit Server VM", "#", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "0#100#-1", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str1.equals("ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US", ":", 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment", (int) (short) 0);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("24.80-b11", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 43");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (short) 0);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("Mac OS X");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("-1a0a1", 100, "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1a0a1sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.mac" + "'", str3.equals("-1a0a1sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.mac"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("mixed mode", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("\n", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 1, 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0432.0" + "'", str10.equals("100.0432.0"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "dk1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("                                 Java HotSpot(TM) 64-Bit Server VM                                  ", 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("0100-1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0100-1" + "'", str1.equals("0100-1"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(8.0f, (float) 97, (float) 100);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 8.0f + "'", float3 == 8.0f);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        java.lang.String[] strArray0 = null;
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "1.0#0.0#52.0", (java.lang.CharSequence) "hi!sophie", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(":", (int) (byte) 100, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "RaphicsEnvironment", (java.lang.CharSequence) "51.051.051.051.051.051.05/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/51.051.051.051.051.051.051");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "eihpoS", (java.lang.CharSequence) "-14041", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "10a1a-1a-1", (java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("6_64", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 100, (short) (byte) 1, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java(TM) SE Runtime Environment", "-14041", 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("1.0#0.0#52.0", ".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libr", 66);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("-1#0#1", " ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1#0#1" + "'", str2.equals("-1#0#1"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        int[] intArray4 = new int[] { 1, (byte) 10, (short) 1, 10 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 0, 41);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "sophie                                                                                              ", (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "####################################################", (java.lang.CharSequence) "-1a0a1");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "####################################################" + "'", charSequence2.equals("####################################################"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("sophie                                                                                              ", "HTTP://JAVA.ORACLE.COM/", (int) '#');
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444-14041", "/Library/Java/JavaVirtualMachines/jdkaaaaaaaaaa.0_80.jdk/Contents/Home/jre/lib/endorsed", 97);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("aaaaaaaaaa", strArray4, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 41, (double) 0.0f, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "US                                                                                                  ", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "x86_64", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Jv(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "6_64");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("# 4   #   a");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "# 4   #   a" + "'", str1.equals("# 4   #   a"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) -1, (short) (byte) 100, (short) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (short) 0);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) (byte) -1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "hi!sophi", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("HI!SOPHIE", "/USophie/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "Use...", charSequence1, 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) (byte) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (byte) 10, (double) 10.0f, (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("HTTP://JAVA.ORACLE.COM/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"HTTP://JAVA.ORACLE.COM/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("                                 Java HotSpot(TM) 64-Bit Server VM                                  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"                                 Java HotSpot(TM) 64-Bit Server VM                                  \"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("141041410");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "US", (java.lang.CharSequence) "xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("Jv(TM) ...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        char[] charArray9 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100.0 32.0", charArray9);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a', (int) (byte) 0, (int) (short) 1);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray9, '4');
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "#" + "'", str16.equals("#"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "#444 4#4 4a" + "'", str18.equals("#444 4#4 4a"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("HTTP://JAVA.ORACLE.COM/", "x86_64", "us");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "HTTP://JAVA.ORACLE.COM/" + "'", str3.equals("HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("                                .0_80-b15");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "DK1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        char[] charArray11 = new char[] { '#', 'a', '4', '#', '4', 'a' };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray11, 'a');
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specification", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ava HotSpo", charArray11);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray11);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "141041410", charArray11);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/Users/sophie", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "#aaa4a#a4aa" + "'", str13.equals("#aaa4a#a4aa"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("-14041", "/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("100a-1a0a1a97a100");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 1, (float) 8, 32.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("x86_64", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(100, 97, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "java or VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("01.7.0_80-b15", (int) (short) 10, "6");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "01.7.0_80-b15" + "'", str3.equals("01.7.0_80-b15"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "                                 Java(TM) SE Runtime Environment                                 ", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("xaaa4axa4aa              Sophie                     ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("sophie");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("ihpos!ih");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "xaaa4axa4aa              Sophie                     ", "141041410");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", (java.lang.CharSequence) "ava HotSpot(TM) 64-Bit Server VM", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        char[] charArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(charArray0, ' ', (int) (short) 0, (int) (short) 0);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (float) 35L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "us", (java.lang.CharSequence) "/USophie/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 1, (byte) -1, (byte) -1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ', (-1), 41);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10a1a-1a-1" + "'", str6.equals("10a1a-1a-1"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "10 -1 10 32 -1 1", (java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/co");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("100.0#32.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0#32.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("sophie", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("hi!sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!sophi" + "'", str1.equals("hi!sophi"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("hi!sophie", (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java Platform API Specification", "97.0435.04-1.0435.0452.0", 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification" + "'", str3.equals("Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 1, (byte) 100, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ', 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "RaphicsEnvironment", (java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("en", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#aaa4a#a4aa", 8, 8);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("0#100#-1", "/Users/sophie");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        float[] floatArray3 = new float[] { 1, 0.0f, '4' };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.Class<?> wildcardClass5 = floatArray3.getClass();
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 52.0f + "'", float4 == 52.0f);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie", (java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/co", 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 46 + "'", int3 == 46);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        float[] floatArray3 = new float[] { 1, 0.0f, '4' };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float7 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 52.0f + "'", float4 == 52.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 52.0f + "'", float6 == 52.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("", "                                .0_80-b15", "##########");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("4444444444444444444444444444444444444444444444444444", strArray4, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray8);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "                                               -1#0#1                                               ");
        java.lang.String[] strArray15 = org.apache.commons.lang3.StringUtils.split("####################################################", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray15, "DK1.7.0_80");
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CO", strArray8, strArray17);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str9.equals("4444444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertNotNull(strArray15);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CO" + "'", str18.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CO"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.Class<?> wildcardClass5 = shortArray3.getClass();
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a', 0, 3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#0#1" + "'", str7.equals("-1#0#1"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1a0a1" + "'", str11.equals("-1a0a1"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("                                 Java HotSpot(TM) 64-Bit Server VM                                  ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("6", 2, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#6" + "'", str3.equals("#6"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sophie                                                                                              ", "oRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("h !", "", 41);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "h !" + "'", str3.equals("h !"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "sophie                                                                                              ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("dk1.7.0_80");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("ava HotSpot(TM) 64-Bit Server VM", (int) (byte) 0, "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ava HotSpot(TM) 64-Bit Server VM" + "'", str3.equals("ava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("0100-1", ' ', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0100-1" + "'", str3.equals("0100-1"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("0#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#10", "en", "                                     -1#0#1                                               ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10.14.3" + "'", str1.equals("10.14.3"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            " + "'", str2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            "));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("24.80-b11");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "24.80-b11" + "'", str1.equals("24.80-b11"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa", (int) (short) -1, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa" + "'", str3.equals("xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("xaaa4axa4aa", "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "xaaa4axa4aa" + "'", str2.equals("xaaa4axa4aa"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("####################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "10 -1 10 32 -1 1", (java.lang.CharSequence) "#6");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("0a100a-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0a100a-1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("-1a0a1sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.mac", "hi!sophie");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("ava HotSpo", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava HotSpo" + "'", str2.equals("ava HotSpo"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "US                                                                                                 ", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("4444444...", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444..." + "'", str2.equals("4444444..."));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("100.0432.0", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0432.0" + "'", str2.equals("100.0432.0"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("141041410", "eihpoS");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "141041410" + "'", str2.equals("141041410"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        int[] intArray0 = null;
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("32.0a100.0a0.0a-1.0a0.0a35.0", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.0a100.0a0.0a-1.0a0.0a35.0" + "'", str2.equals("32.0a100.0a0.0a-1.0a0.0a35.0"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("-1a0a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a0a1" + "'", str1.equals("-1a0a1"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("1.1", "01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b15", ".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "####################################################");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie", strArray4, strArray7);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "raphicsEnvironment");
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "01.7.0_80-b15", (java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Users/sophie" + "'", str8.equals("/Users/sophie"));
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str1.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "                                 Java HotSpot(TM) 64-Bit Server VM                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("6", "x   4 x 4  ");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ');
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "6" + "'", str4.equals("6"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "eihpos!ih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", (int) 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("hi!sophi");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!soph" + "'", str1.equals("hi!soph"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "####################################################");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray5, "mixed mode");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("http://java.oracle.com/", strArray2, strArray5);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray5);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/", 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("4444444444444444444444444444444444444444444444444444", strArray14, strArray18);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray14);
        java.lang.String[] strArray24 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80");
        java.lang.String[] strArray28 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie", (int) '#');
        java.lang.String str29 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray28);
        java.lang.String str30 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", strArray24, strArray28);
        java.lang.String str31 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("", strArray14, strArray28);
        java.lang.String str32 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("eihpoS", strArray9, strArray14);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "http://java.oracle.com/" + "'", str8.equals("http://java.oracle.com/"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str19.equals("4444444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444" + "'", str20.equals("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strArray24);
        org.junit.Assert.assertNotNull(strArray28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str29.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str30.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "eihpoS" + "'", str32.equals("eihpoS"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 4, 100.0d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((-1.0d), (double) 32.0f, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("-1a0a1sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.mac", "x86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a0a1sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.mac" + "'", str2.equals("-1a0a1sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.mac"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("/Library/Java/JavaVirtualMachines/jdkaaaaaaaaaa.0_80.jdk/Contents/Home/jre/lib/endorsed", ":");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdkaaaaaaaaaa.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdkaaaaaaaaaa.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/" + "'", str2.equals("/"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 1, 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "4444444...", charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("", (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("x   4 x 4  ", "/librax86_64", 66);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "1.1");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "x   4 x 4  " + "'", str5.equals("x   4 x 4  "));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("", "hi!sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) ' ', 1.0f, (float) 41);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0f + "'", float3 == 1.0f);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("\n", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, '4', 0, 8);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Library/Java/JavaVirtualMachines/jdkaaaaaaaaaa.0_80.jdk/Contents/Home/jre/lib/endorsed", 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "eihpos!ih", "/");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", (java.lang.CharSequence) "-1a0a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "java or VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("oc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "oc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/" + "'", str1.equals("oc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                                               -1#0#1                                               ", (java.lang.CharSequence) "                                               -1#0#1                                               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("", 2, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44" + "'", str3.equals("44"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("##########", "Sophie", "x   4 x 4  ", 6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "##########" + "'", str4.equals("##########"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("100.0#32.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0#32.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "oRACLE cORPORATION", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("10 -1 10 32 -1 1", 10, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10 -1 10 32 -1 1" + "'", str3.equals("10 -1 10 32 -1 1"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lwawt.macosx.CPrinterJob", (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("phicsEnvironmentar", (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("97.0435.04-1.0435.0452.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97.0435.04-1.0435.0452.0" + "'", str1.equals("97.0435.04-1.0435.0452.0"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Virtual Machine Specification");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "java HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence[]) strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                h !", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                h !" + "'", str2.equals("                                h !"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(46, 100, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 46 + "'", int3 == 46);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("100.0#32.0", "ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361", (java.lang.CharSequence) "51.051.051.051.051.051.05/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/51.051.051.051.051.051.051");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", "44", "# 4   #   a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Jv(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("!ih                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                                                                 hi!" + "'", str1.equals("                                                                                                 hi!"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("#", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#" + "'", str2.equals("#"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("US", "                                     -1#0#1                                               ", "0100-1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("!ih");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie", (int) '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "sophie");
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "SUN.LWAWT.MACOSX.LWCTOOLKIT", 0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str4.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", 46);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/" + "'", str2.equals("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 6.0f, 100.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("Jv(TM) SE Runtime Environment", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(4.4444444444444445E51d, (double) 6.0f, (double) 1L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("us");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "us" + "'", str1.equals("us"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 2, 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("hi!", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("dk1.7.0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Dk1.7.0_80" + "'", str1.equals("Dk1.7.0_80"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.1", 3, (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "100.0 32.0", (java.lang.CharSequence) "1.6", 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min(0L, 0L, (long) 41);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("#6", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#6" + "'", str2.equals("#6"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "hi!", (java.lang.CharSequence) "32.0a100.0a0.0a-1.0a0.0a35.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "hi!soph", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("HI!SOPHIE", 66L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 66L + "'", long2 == 66L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("0100-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Illegal embedded sign character");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", ' ');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "-1#0#1", (java.lang.CharSequence[]) strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '4', (int) (short) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0100-1", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100-1" + "'", str2.equals("100-1"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "10.14.3");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification", (int) (short) 100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...435...." + "'", str3.equals("...435...."));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "Jv(TM) ...", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("100-1", "DK1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100-1" + "'", str2.equals("100-1"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) (-1L), 0.0d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("/librax86_64", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/librax86_64" + "'", str2.equals("/librax86_64"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("#444 4#4 4a", "mixed mode", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#444 4#4 4a" + "'", str3.equals("#444 4#4 4a"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 35.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "32.0a100.0a0.0a-1.0a0.0a35.0", (java.lang.CharSequence) "/USophie/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "52.0a32.0", "o");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "44", (java.lang.CharSequence) "DK1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("1.6", "                                                51.0                                                ", 0);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "hi!sophie");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("              Sophie               ");
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", strArray6, strArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 1 vs 3");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        long[] longArray6 = new long[] { 100, (-1L), 0L, 1, 'a', 100L };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', (int) ' ', 0);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', 3, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a-1a0a1a97a100" + "'", str13.equals("100a-1a0a1a97a100"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(0.0d, (double) 8, (double) 1L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "...435....", (java.lang.CharSequence) "UTF-8");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("0#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#10", "####################################################");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#10" + "'", str2.equals("0#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#10"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "aaaaaaaaaa");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "US                                                                                                  ", (java.lang.CharSequence) "h !", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("1.0#0.0#52.0", "/USophie/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("100-1");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b15", (java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/", 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "xaaa4axa4aa              Sophie                     ", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                                51.0                                                ", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                51.0                                                " + "'", str2.equals("                                                51.0                                                "));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("-1", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("sophie                                                                                              ", (-1));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie                                                                                              " + "'", str2.equals("sophie                                                                                              "));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "1.7.0_80", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 33 + "'", int1 == 33);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        java.lang.CharSequence[] charSequenceArray0 = null;
        int int1 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequenceArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "Mac OS X", (java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("en", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "51.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Java HotSpot(TM) 64-Bit Server VM");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java HotSpot(TM) 64-Bit Server VM\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "0#100#-1");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("52.0a32.0", "0#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#10", "xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "52.xa32.x" + "'", str3.equals("52.xa32.x"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("10");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1.equals(10.0d));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle Corporation" + "'", str1.equals("Oracle Corporation"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "52.0a32.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("#aaa4a#a4aa", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#aaa4a#a4aa                                         " + "'", str2.equals("#aaa4a#a4aa                                         "));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File", "hi!");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File" + "'", str2.equals("class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("######HTTP://JAVA.ORACLE.COM/######");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "######HTTP://JAVA.ORACLE.COM/######" + "'", str1.equals("######HTTP://JAVA.ORACLE.COM/######"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (java.lang.CharSequence) "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            ", 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("-1a0a1sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.mac", "24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1a0a1sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.mac" + "'", str2.equals("-1a0a1sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.mac"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/USophie/U", 97, 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(66, 0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "                                 Java(TM) SE Runtime Environment                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0a100a-1", (java.lang.CharSequence) "01.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4444444...", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "####################################################");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "mixed mode");
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("http://java.oracle.com/", strArray1, strArray4);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "http://java.oracle.com/" + "'", str7.equals("http://java.oracle.com/"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("4444444444444444444444444444444444444444444444444444", "/USophie/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str2.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("HTTP://JAVA.ORACLE.COM/", "dk1.7.0_80.jdk/Contents/Home/jre", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(0.0f, 0.0f, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(97, 10, 41);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("24.80-b11", "hi!sophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "24.80-b11" + "'", str2.equals("24.80-b11"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 41, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:." + "'", str3.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:."));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HTTP://JAVA.ORACLE.COM/" + "'", str1.equals("HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("ihpos!ih", (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("dk1.7.0_80", "#aaa4a#a4aa", 4, 100);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "dk1.#aaa4a#a4aa" + "'", str4.equals("dk1.#aaa4a#a4aa"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 'a', (long) 6, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "RaphicsEnvironment", (java.lang.CharSequence) "-1a0a1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                                                51.0                                                ", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("", "0a100a-1", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut(charSequence0, (java.lang.CharSequence) "#444 4#4 4a");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("              Sophie               ");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, '4');
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "              4Sophie4               " + "'", str3.equals("              4Sophie4               "));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "", (int) (short) 10);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("##########");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("Use...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Use..." + "'", str1.equals("Use..."));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        long[] longArray3 = new long[] { 32L, 100, (short) -1 };
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(longArray3, 'a', 8, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray3);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKIT", (java.lang.CharSequence) "                                                                                                 hi!", 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (short) 0);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1" + "'", str8.equals("-1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-1" + "'", str10.equals("-1"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("sun.lwawt.macosx.CPrinterJob", "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "wawt.macosx.CPrinterJob" + "'", str2.equals("wawt.macosx.CPrinterJob"));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (java.lang.CharSequence) "0#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#10");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf(charSequence0, (java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace(charSequence0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa", "-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("", '#', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) (-1.0f), 0.0d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("100a-1a0a1a97a100", 66);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 66 + "'", int2 == 66);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("51.051.051.051.051.051.05/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/51.051.051.051.051.051.051", "-1#0#1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("java or VM", 100, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("eihpoS", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "eihpoS" + "'", str2.equals("eihpoS"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("hi!", "Java Virtual Machine Specification", "");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) (short) -1, (float) (byte) 100, (float) 97L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.0f) + "'", float3 == (-1.0f));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("51.0", "100.0 32.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", 0, 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java Platform API Specification", (java.lang.CharSequence) "52.0a32.0", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("52.0a32.0", (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        int[] intArray3 = new int[] { (byte) 0, 100, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a100a-1" + "'", str7.equals("0a100a-1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0 100 -1" + "'", str12.equals("0 100 -1"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "US                                                                                                 ", (java.lang.CharSequence) "141041410");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("44", 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 44L + "'", long2 == 44L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("#aaa4a#a4aa");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("ava HotSpo", "52.0a32.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ava HotSpo" + "'", str2.equals("ava HotSpo"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "oc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", 66, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("100a-1a0a1a97a100", "10.14.3", 4);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        long[] longArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(longArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean5 = javaVersion0.atLeast(javaVersion1);
        java.lang.String str6 = javaVersion1.toString();
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion8 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean10 = javaVersion8.atLeast(javaVersion9);
        boolean boolean11 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        boolean boolean12 = javaVersion7.atLeast(javaVersion8);
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion8);
        boolean boolean14 = javaVersion1.atLeast(javaVersion8);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.6" + "'", str6.equals("1.6"));
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion8 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion8.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("0 100 -1", 6, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0 100 -1" + "'", str3.equals("0 100 -1"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (int) '4', 97);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            ", (java.lang.CharSequence) "ava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            " + "'", charSequence2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            "));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(' ', 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " " + "'", str2.equals(" "));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("0#100#-1", (int) ' ', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                h !", "");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        char[] charArray3 = new char[] { '#', '#', '#' };
        char[] charArray7 = new char[] { '#', '#', '#' };
        char[] charArray11 = new char[] { '#', '#', '#' };
        char[][] charArray12 = new char[][] { charArray3, charArray7, charArray11 };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(charArray12);
        org.junit.Assert.assertNotNull(charArray3);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertNotNull(charArray12);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("raphicsEnvironment");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("US", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("mixed mode", (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("en");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "en" + "'", str1.equals("en"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/USophie/U", "                                .0_80-b15", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("sun.lwawt.macosx.CPrinterJob", "4444444...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.lwawt.macosx.CPrinterJob" + "'", str2.equals("sun.lwawt.macosx.CPrinterJob"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("sophie", 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("####################################################", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        double[] doubleArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(doubleArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("", (int) (byte) 0, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 0, (long) 8, (long) '4');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("44", "51.051.051.051.051.051.05/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/51.051.051.051.051.051.051", (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "oc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) '4', 10.0f, (float) '4');
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 0.0f, 0.0d, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("4444444444444444444444444444444444444444444444-14041", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444-14041" + "'", str2.equals("4444444444444444444444444444444444444444444444-14041"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("en");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "en" + "'", str2.equals("en"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("SUN.LWAWT.MACOSX.LWCTOOLKIT", "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str2.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (short) 10, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("Jv(TM) SE Runtime Environment", "raphicsEnvironment", "52.xa32.x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Jv(TM) SE Runtime Environment" + "'", str3.equals("Jv(TM) SE Runtime Environment"));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "0100-1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray9 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray9);
        int int11 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray9);
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray9, '4', 6, 66);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("              Sophie               ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "1.1", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444-14041");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                                51.0                                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "51.0" + "'", str1.equals("51.0"));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("\n", "#aaa4a#a4aa                                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\n" + "'", str2.equals("\n"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("Sophie", 41, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "44444444444444444444444444444444444Sophie" + "'", str3.equals("44444444444444444444444444444444444Sophie"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "51.0", (java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "o", (java.lang.CharSequence) "1.1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("...435....", "#aaa4a#a4aa                                         ", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("dk1.#aaa4a#a4aa", 41, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dk1.#aaa4a#a4aa                          " + "'", str3.equals("dk1.#aaa4a#a4aa                          "));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "100.0#32.0", "...435....");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("1.0#0.0#52.0", "eihpos!ih");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "en");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "dk1.#aaa4a#a4aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "4444444...");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444-14041", "/Library/Java/JavaVirtualMachines/jdkaaaaaaaaaa.0_80.jdk/Contents/Home/jre/lib/endorsed", 97);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Comparable<java.lang.String>[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4444444444444444444444444444444444444444444444-1441" + "'", str4.equals("4444444444444444444444444444444444444444444444-1441"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("RaphicsEnvironment", "4444444...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RaphicsEnvironment" + "'", str2.equals("RaphicsEnvironment"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("Java Platform API Specification", "java or VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Platform API Specification" + "'", str2.equals("Java Platform API Specification"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("-1", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "eihpos!ih");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/", (java.lang.CharSequence) " ", 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("#aaa4a#a4aa                                         ", (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 2, (double) 41, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 41.0d + "'", double3 == 41.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (-1L), (float) 1L, (float) 10);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.0f + "'", float3 == 10.0f);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", "/Library/Java/JavaVirtualMachines/jdkaaaaaaaaaa.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 3, (long) ' ', (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 100, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("6_64");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "32.04100.040.04-1.040.0435.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(97L, (long) (short) -1, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 97L + "'", long3 == 97L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", "o", (int) (byte) 1);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, ' ', 0, (-1));
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/librax86_64", "1.7");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "10.14.3");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1#0#1", " ", 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation", strArray3, strArray7);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, 'a', (int) (short) 1, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Oracle Corporation" + "'", str8.equals("Oracle Corporation"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "h !");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("eihpos!ih");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/USophie/U");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM", 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (java.lang.CharSequence) "US                                                                                                 ");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", charSequence2.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("US");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Jv(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "51.051.051.051.051.051.05/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/51.051.051.051.051.051.051", (java.lang.CharSequence) "Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("...435....", "10.14.3");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                " + "'", str1.equals("                                "));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Java Virtual Machine Specification", "\n");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java Virtual Machine Specification" + "'", str2.equals("Java Virtual Machine Specification"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "oc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("                                .0_80-b15", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                .0_80-b15" + "'", str2.equals("                                .0_80-b15"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", "US                                                                                                 ", 0, 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "US                                                                                                 " + "'", str4.equals("US                                                                                                 "));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("dk1.#aaa4a#a4aa                          ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sophie" + "'", str1.equals("sophie"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("SUN.LWAWT.MACOSX.LWCTOOLKIT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SUN.LWAWT.MACOSX.LWCTOOLKIT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                                Java(TM) SE Runtime ", (java.lang.CharSequence) "wawt.macosx.CPrinterJob", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "97.0435.04-1.0435.0452.0", (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("1.7.0_80", "# 4   #   a", (-1), 66);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "# 4   #   a" + "'", str4.equals("# 4   #   a"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("mixed mode");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "dk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("!ih                                                                                                 ", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("0100-1", "/Library/Java/JavaVirtualMachines/jdkaaaaaaaaaa.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdkaaaaaaaaaa.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdkaaaaaaaaaa.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "4444444444444444444444444444444444444444444444-1441", (java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("1.0#0.0#52.0", "/Users/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#0.0#52.0" + "'", str2.equals("1.0#0.0#52.0"));
    }
}

