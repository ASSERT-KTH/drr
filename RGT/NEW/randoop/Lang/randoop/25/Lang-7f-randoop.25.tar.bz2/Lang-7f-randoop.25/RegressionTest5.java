import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test001");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "", "US                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test002");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("", "", "                                .0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                .0_80-b15" + "'", str3.equals("                                .0_80-b15"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test003");
        char[] charArray8 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "100.0a32.0", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test004");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11", "ttttttttttttttttttttttttttttttttht!", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11" + "'", str3.equals("24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test005");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("dk1.#aaa4a#a4aa                          ", "", "chines/jdk1.7.0_80.jdk/Contents/H");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dk1.#aaa4a#a4aa                          " + "'", str3.equals("dk1.#aaa4a#a4aa                          "));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test006");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("#4a444#444a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#4a444#444a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("wawt.macosx.CPrinterJob", "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "wawt.macosx.CPrinterJob" + "'", str2.equals("wawt.macosx.CPrinterJob"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test008");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", "Java(TM) SE Runtime");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION" + "'", str2.equals("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test009");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("-1a0a1sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.mac");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test010");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444-14a41", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test011");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("52.xa32.x", 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test012");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("Jv(TM) ...", "#/sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jv(TM) ..." + "'", str2.equals("Jv(TM) ..."));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test013");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "-1a0a1", (java.lang.CharSequence) "100.0#32.0chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Libr", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test014");
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "x   4 x 4  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test015");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "4444444444444444444444444444444444444444444444-14041");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test016");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 52, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test017");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Ava HotSpo", (java.lang.CharSequence) "-1#0#1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test018");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie", (int) '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", strArray3, strArray7);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str8.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str9.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str10.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str12.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test019");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "0a100a-", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test020");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("/");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test021");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b15", (java.lang.CharSequence) "141041410", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test022");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean5 = javaVersion0.atLeast(javaVersion1);
        boolean boolean6 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion7 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean8 = javaVersion1.atLeast(javaVersion7);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + javaVersion7 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion7.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test023");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("141041410                                  ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "141041410                                  ..." + "'", str1.equals("141041410                                  ..."));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test024");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "x86_64");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test025");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center(":", 73, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test026");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 10, (byte) 1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test027");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("97.0 35.0 -1.0", " ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97.0 35.0 -1.0" + "'", str2.equals("97.0 35.0 -1.0"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test028");
        char[] charArray7 = new char[] { '#', 'a', '4', '#', '4', 'a' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        java.lang.Class<?> wildcardClass10 = charArray7.getClass();
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ', (int) 'a', (int) '#');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0.0#41.0#32.0#0.0#1.6#3.0", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "#aaa4a#a4aa" + "'", str9.equals("#aaa4a#a4aa"));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test029");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("4444444444444444444444444444444444444444444444-14041", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test030");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(4.0d, 100.0d, (double) 35L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test031");
        byte[] byteArray1 = new byte[] { (byte) 10 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "...esU");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: ...esU");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test032");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:", "...esU");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test033");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("32.0#100.0#0.0#-1.0#0.0#35.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test034");
        long[] longArray1 = new long[] { (byte) 10 };
        long long2 = org.apache.commons.lang3.math.NumberUtils.max(longArray1);
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray1, 'a', (int) (byte) 1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test035");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) (byte) 10, (short) 0, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test036");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "dk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test037");
        long[] longArray6 = new long[] { 100, (-1L), 0L, 1, 'a', 100L };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', (int) ' ', 0);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ', 4, (int) (short) 0);
        long long18 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long19 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a-1a0a1a97a100" + "'", str13.equals("100a-1a0a1a97a100"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test038");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("01.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B15", (int) (byte) 10, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test039");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("51.0", "10a1a-1a-14444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test040");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "raphicsEnvironmentraphicsEnvironmentraphicsEnvironment", (java.lang.CharSequence) "                                ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test041");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("#aaa4a#a4aa                                         ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test042");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast(".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libr", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libr" + "'", str2.equals(".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libr"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test043");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) 1 + "'", short7 == (short) 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test044");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("", '4');
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.stripAll(strArray2, "#4A444#444A");
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test045");
        char[] charArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(charArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test046");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("http://java.oracle.com/", "Java(TM) SE Runtime");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "http://java.oracle.com/" + "'", str2.equals("http://java.oracle.com/"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test047");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.", (java.lang.CharSequence) "01.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B15", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test048");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) (byte) 100, (float) 2L, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test049");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("51.051.051.051.051.051.05/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/51.051.051.051.051.051.051", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test050");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("32.04100.040.04-1.040.0435.0", "-1");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test051");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS", "97.0 35.0 -1.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS" + "'", str2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("", "4444444444444444444444444444444444444444444444-14a41");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar24.80-b11");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test054");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("MV ro avaj", (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test055");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "Java(TM) SE Runtime", (java.lang.CharSequence) "1.7.0_80-b15", 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test056");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "32.0a100.0a0.0a-1.0a0.0a35.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test057");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test058");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "100-1", charSequence1, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test059");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("              4Sophie4               ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "              4Sophie4               " + "'", str4.equals("              4Sophie4               "));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test060");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test061");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  4 x 4   x", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  4 x 4   x" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  4 x 4   x"));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test062");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1 1 100 1 -1", "java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1 1 100 1 -1" + "'", str2.equals("1 1 100 1 -1"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test063");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/", (java.lang.CharSequence) "-1a0a1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test064");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("100.0#32.0chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Libr", (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test065");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("10a1a-1a-1", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a1a-1a-1" + "'", str2.equals("10a1a-1a-1"));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test066");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("10 1 -1 -1", "0#100#-1", 11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10 1 -1 -1" + "'", str3.equals("10 1 -1 -1"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test067");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/Users", 0);
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a', 11, 90);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 11");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test068");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "hi!sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test069");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 6, 0.0d, 4.4444444444444445E51d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("10a-1a10a32a-1a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10A-1A10A32A-1A1" + "'", str1.equals("10A-1A10A32A-1A1"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test071");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence) "phicsEnvironmentar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test072");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("Oracle Corporation", 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test073");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("#aaa4a#a4aa", "h !");
        int int4 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "/Users", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "100.0#32.0chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test074");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("ava HotSpo");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test075");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("Oracle Corporation");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test076");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "          ", "4444444444444444444444444444444444444444444444-14a41");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test077");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("hi!sophi", 3);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!sophi" + "'", str2.equals("hi!sophi"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test078");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("DK1.7.0_80");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"DK1.7.0_80\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test079");
        java.lang.String[] strArray2 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("raphicsEnvironment");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.replaceEach("                                aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                 ", strArray2, strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1#0#1", " ", 0);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("97.0a35.0a-1.0a35.0a52.", strArray2, strArray9);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "                                aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                 " + "'", str5.equals("                                aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                 "));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "97.0a35.0a-1.0a35.0a52." + "'", str10.equals("97.0a35.0a-1.0a35.0a52."));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test080");
        char[] charArray12 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100.0 32.0", charArray12);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray12, 'a', (int) (byte) 0, (int) (short) 1);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaa", charArray12);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0#100#-1", charArray12);
        java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(charArray12, '#', 4, (int) (byte) -1);
        int int26 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "#4a444#444a", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "#" + "'", str19.equals("#"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test081");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0a100a-1", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test083");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf(charSequence0, (java.lang.CharSequence) "# 4   #   a", 87);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test084");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (-14041), (long) ' ', (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-14041L) + "'", long3 == (-14041L));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test085");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("97.0a35.0a-1.0a35.0a52.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97.0a35.0a-1.0a35.0a52.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "1.0#0.0#52.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str2.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test087");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 87, 97.0f, 73.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 73.0f + "'", float3 == 73.0f);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test088");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "01.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test089");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("...esU", (int) (byte) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test090");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/", 0);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "0a100a-1");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "UTF-8", (int) (short) 100, 7);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("SUN.LWAWT.MACOSX.LWCTOOLKIT", "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:", "32.04100.040.04-1.040.0435.0444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str3.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test092");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aa", (java.lang.CharSequence) " o ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test093");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java(TM) SE Runtime Environment", 8, "100.0#32.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str3.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test094");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("sun.awt.CGraphicsEnvironment", 41);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sun.awt.CGraphicsEnvironment" + "'", str2.equals("sun.awt.CGraphicsEnvironment"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test095");
        long[] longArray6 = new long[] { (short) 10, 32L, 97, (byte) 0, (-1L), (-1L) };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        try {
            java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, '#', 73, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 73");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test096");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("01.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test097");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "01.7.0_80-b15", (java.lang.CharSequence) "1a10a1a10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test098");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("/USophie/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/eihpoSU/" + "'", str1.equals("/eihpoSU/"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test099");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("Sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test100");
        char[] charArray1 = new char[] {};
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "US", charArray1);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(charArray1, 'a', (int) (short) 0, (int) (byte) -1);
        org.junit.Assert.assertNotNull(charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test101");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java(TM) SE Runtime", (java.lang.CharSequence) "#aaaaa4aaa#aaa4aaaa                                         ", 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test102");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("x   4 x 4  ", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "x   4 x 4  " + "'", str2.equals("x   4 x 4  "));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test103");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "1a10a1a10", (java.lang.CharSequence) "UTF-8", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test104");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("raphicsEnvironmentraphicsEnvironmentraphicsEnvironment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"raphicsEn\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test105");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) 0, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test106");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "hi!sophi");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("wawt.macosx.CPrinterJob", "32.04100.040.04-1.040.0435.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "wawt.macosx.CPrinterJob" + "'", str2.equals("wawt.macosx.CPrinterJob"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test108");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "RaphicsEnvironmentRaphicsEnvironmentRaphicsEnvirRaphicsEnvironmentRaphicsEnvironmentRaphicsEnviro");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test109");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test110");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop..." + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop..."));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test111");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b15", "aajava HotSpot(TM) 64-Bit Server VMaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b15" + "'", str2.equals("01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b15"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test112");
        int[] intArray3 = new int[] { (byte) 0, 100, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray3, '4', 0, 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test113");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 10, (short) 1, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test114");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/eihpoSU/");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test115");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("phicsEnvironmentar", 11, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "phicsEnvironmentar" + "'", str3.equals("phicsEnvironmentar"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test116");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test117");
        float[] floatArray6 = new float[] { ' ', (short) 100, 0L, (-1L), 0, '#' };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "32.0a100.0a0.0a-1.0a0.0a35.0" + "'", str10.equals("32.0a100.0a0.0a-1.0a0.0a35.0"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test118");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', (int) (short) 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "MV ro avaj");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: MV ro avaj");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) -1 + "'", byte12 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1" + "'", str14.equals("-1"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test119");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("\n");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test120");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "44444444444444444444444444444444444", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdkaaaaaaaaaa.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test121");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("raphicsEnvironmentraphicsEnvironmentraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "raphicsEnvironmentraphicsEnvironmentraphicsEnvironment" + "'", str1.equals("raphicsEnvironmentraphicsEnvironmentraphicsEnvironment"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test122");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "/USophie/", " o ");
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test123");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "141041410                                                                                           ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test124");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Java(TM) SE Runtime Environment", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o ", (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test125");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                h !", 'a', 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                h !" + "'", str3.equals("                                h !"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test126");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("-1a0a1sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.mac");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a0a1sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.mac" + "'", str1.equals("-1a0a1sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.mac"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test127");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(32, (int) (byte) 1, 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test128");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("1a0a1a0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a0a1a0" + "'", str1.equals("1a0a1a0"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test129");
        double[] doubleArray2 = new double[] { 100.0d, 1 };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double4 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test130");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("                                                                                                 ", 10);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "          " + "'", str2.equals("          "));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test131");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "MV ro avaj", (java.lang.CharSequence) " o ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test132");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("", "/librax86_64");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test133");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "32.0 100.0 0.0 -1.0 0.0 35.0", (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  4 x 4   x", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test134");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "", " ...");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test135");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "#/sophie", (java.lang.CharSequence) "RS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test136");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA                                 " + "'", str1.equals("                                AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA                                 "));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test137");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        java.lang.String str1 = javaVersion0.toString();
        java.lang.String str2 = javaVersion0.toString();
        boolean boolean3 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion0);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.6" + "'", str1.equals("1.6"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test138");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("0#100#-1", "aaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0#100#-1" + "'", str2.equals("0#100#-1"));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test139");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase(charSequence0, (java.lang.CharSequence) "/Users/sophie", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test140");
        long[] longArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(longArray0, 'a', 33, 6);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test141");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "http://java.oracle.com/", 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test142");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "0#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#10", (java.lang.CharSequence) "raphicsEnvironmentraphicsEnvironmentraphicsEnvironment", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test143");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center(" eihpos!ih", 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " eihpos!ih" + "'", str2.equals(" eihpos!ih"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test144");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test145");
        char[] charArray11 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100.0#32.0", charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "# 4   #   a", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "                                .0_80-b15", charArray11);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray11, '4');
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 32 + "'", int16 == 32);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "#444 4#4 4a" + "'", str18.equals("#444 4#4 4a"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test146");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("SUN.LWAWT.MACOSX.LWCTOOLKIT", "                                .0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str2.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test147");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("dk1.7.0_80", (int) (short) 100, "1a10a1a10");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dk1.7.0_801a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a10" + "'", str3.equals("dk1.7.0_801a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a10"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test148");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("10 1 -1 -1", "100-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10 1 -1 -1" + "'", str2.equals("10 1 -1 -1"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test149");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "-1a0a1sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.mac", (java.lang.CharSequence) "44");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test150");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop...", (java.lang.CharSequence) "97.0a35.0a-1.0a35.0a52.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test151");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "hi!soph");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test152");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("100.0 32.0", 87);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                      100.0 32.0                                       " + "'", str2.equals("                                      100.0 32.0                                       "));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test153");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("raphicsEnvironmentraphicsEnvironmentraphicsEnvironment", '#');
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "raphicsEnvironmentraphicsEnvironmentraphicsEnvironment" + "'", str3.equals("raphicsEnvironmentraphicsEnvironmentraphicsEnvironment"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test154");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "97.0a35.0a-1.0a35.0a52.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test155");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "Java Virtual Machine Specification", "hi!");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test157");
        int[] intArray4 = new int[] { 97, 97, '4', '4' };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray4);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray4, '#', 3, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test158");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max((int) (byte) 10, (int) (short) 0, 3);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test159");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("Java Virtual Machine Specification");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java Virtual Machine Specification\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test160");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "x   4 x 4  ", (java.lang.CharSequence) "Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test161");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) -1, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test162");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Java(TM) SE Runtime Environment", "-140");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str2.equals("Java(TM) SE Runtime Environment"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test163");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        java.lang.Class<?> wildcardClass1 = javaVersion0.getClass();
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test164");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("                                  10.14.3");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test165");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("1.6", "dk1.7.0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test166");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("100.0a32.0");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test167");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("97.0435.04-1.0435.0452.", "                                .0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97.0435.04-1.0435.0452" + "'", str2.equals("97.0435.04-1.0435.0452"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test168");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4', (int) (short) 0, 2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1#0#1" + "'", str6.equals("-1#0#1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-140" + "'", str10.equals("-140"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-14041" + "'", str12.equals("-14041"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 1 + "'", short13 == (short) 1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test169");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("97.0a35.0a-1.0a35.0a52.0", 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test170");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users", (java.lang.CharSequence) "x   4 x 4  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test171");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "01.7.0_80-b15", (java.lang.CharSequence) "a4 4#4 444#");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test172");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 1, (byte) -1, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test173");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                                      100.0 32.0                                       ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test174");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("ttttttttttttttttttttttttttttttttht!");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ttttttttttttttttttttttttttttttttht!" + "'", str1.equals("ttttttttttttttttttttttttttttttttht!"));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test175");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test176");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("phicsEnvironmentar", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test177");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith(charSequence0, (java.lang.CharSequence) "                                                                                                 hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test178");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "                                AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test179");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("#aaa4a#a4aa                                         ", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#aaa4a#a4aa                                         " + "'", str2.equals("#aaa4a#a4aa                                         "));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test180");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 0, 0);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.Class<?> wildcardClass11 = shortArray3.getClass();
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-14041" + "'", str13.equals("-14041"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test181");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("97.0435.04-1.0435.0452", 33, "10a1a-1a-14444444444444444444444");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a1a97.0435.04-1.0435.045210a1a-" + "'", str3.equals("10a1a97.0435.04-1.0435.045210a1a-"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test182");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporation", "raphicsEnvironment", (int) (short) 0);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "97.0435.04-1.0435.0452.0");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Oracle Corporation" + "'", str5.equals("Oracle Corporation"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test183");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "01.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test184");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "dk1.7.0_801a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test185");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) 8, (float) (-14041), (float) 13);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 13.0f + "'", float3 == 13.0f);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test186");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min((int) '#', 73, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test187");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("", "-140");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test188");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("", (int) (byte) 0, "97.0 35.0 -1.0 35.0 52.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test189");
        double double3 = org.apache.commons.lang3.math.NumberUtils.min((double) 2L, 10.0d, (double) 8.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test190");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("1a10a1a10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1a10a1a10" + "'", str1.equals("1a10a1a10"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test191");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Libr", (java.lang.CharSequence) "100a-1a0a1a97a100");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Libr" + "'", charSequence2.equals("chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Libr"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test192");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 1, (byte) 100, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray5, ' ');
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1 1 100 1 -1" + "'", str9.equals("1 1 100 1 -1"));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) 100 + "'", byte10 == (byte) 100);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test193");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "####################################################", (java.lang.CharSequence) "#/sophie#/sophie#/sophie#/sophie#/sophie#/sox   4 x 4  #/sophie#/sophie#/sophie#/sophie#/sophie#/sop");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test194");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "-1#0#1", (java.lang.CharSequence) "                                                                                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test195");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("#/sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#/SOPHIE" + "'", str1.equals("#/SOPHIE"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test196");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("32.0#100.0#0.0#-1.0#0.0#35.0", 6, "\n");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "32.0#100.0#0.0#-1.0#0.0#35.0" + "'", str3.equals("32.0#100.0#0.0#-1.0#0.0#35.0"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test197");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.countMatches(charSequence0, (java.lang.CharSequence) "-140     ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test198");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("6", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test199");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "US                                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test200");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "32.0a100.0a0.0a-1.0a0.0a35.0", (java.lang.CharSequence) "DK1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test201");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o ", 66, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaa" + "'", str3.equals("aaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaa"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test202");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                                     -1#0#1                                               ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test203");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("1.0#0.0#52.0", "          ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test204");
        int[] intArray0 = new int[] {};
        try {
            int int1 = org.apache.commons.lang3.math.NumberUtils.max(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array cannot be empty.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test205");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                " + "'", str1.equals("                                "));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test206");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("Mac OS X");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Mac OS X\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test207");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("#");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#" + "'", str1.equals("#"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test208");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 1, (byte) 100, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', 4, 0);
        java.lang.Class<?> wildcardClass13 = byteArray5.getClass();
        try {
            java.lang.String str15 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "Ava HotSpo");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: Ava HotSpo");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test209");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("mixed mode", 90);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "mixed mode" + "'", str2.equals("mixed mode"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test210");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test211");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test212");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                h !", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test213");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("DK1.7.0_80", ' ', '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DK1.7.0_80" + "'", str3.equals("DK1.7.0_80"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test214");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test215");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "SUN.LWAWT.MACOSX.LWCTOOLKIT");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test216");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/co");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "oc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test217");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("RaphicsEnvironmentRaphicsEnvironmentRaphicsEnvirRaphicsEnvironmentRaphicsEnvironmentRaphicsEnviro");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RaphicsEnvironmentRaphicsEnvironmentRaphicsEnvirRaphicsEnvironmentRaphicsEnvironmentRaphicsEnviro" + "'", str1.equals("RaphicsEnvironmentRaphicsEnvironmentRaphicsEnvirRaphicsEnvironmentRaphicsEnvironmentRaphicsEnviro"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test218");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) 0, (short) 1, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test219");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("100.0 32.0", "sophie                                                                                              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0 32.0" + "'", str2.equals("100.0 32.0"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test220");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("-140     ", 33, 66);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-140     " + "'", str3.equals("-140     "));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test221");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 32L, 46.0f, (float) 13);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 13.0f + "'", float3 == 13.0f);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test222");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 0, (byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 0 + "'", byte3 == (byte) 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test223");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "Java(TM) SE Runtime", (java.lang.CharSequence) "Ava HotSpo");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test224");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 0, (byte) 0, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test225");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("1.2", (-14041));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test226");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "ava HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "/eihpoSU/", (int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test227");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("MV ro avaj", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  4 x 4   x", (-1));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "MV ro avaj" + "'", str3.equals("MV ro avaj"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test228");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("SUN.LWAWT.MACOSX.LWCTOOLKIT", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str2.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test229");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("mixed mode", 10, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "mixed mode" + "'", str3.equals("mixed mode"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test230");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "Dk1.7.0_80", (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test231");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "10", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test232");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0.23#0.25", (java.lang.CharSequence) "                                ", 87);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "/USophie/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test234");
        try {
            java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("1.6", (-1), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minimum abbreviation width is 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test235");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("#6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test236");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("4444444444444444444444444444444444444444444444-1441", (int) '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444-1441" + "'", str2.equals("444444444444444444444444444444-1441"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test237");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "xaaa4axa4aa", (java.lang.CharSequence) "32.0a100.0a0.0a-1.0a0.0a35.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test238");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test239");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/", (java.lang.CharSequence) "Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test240");
        int int3 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "x   4 x 4  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (java.lang.CharSequence) "raphicsEnvironment", 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test241");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "51.0", 0, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test242");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("dk1.7.0_80", "4444444...", "chines/jdk1.7.0_80.jdk/Contents/H");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dk1j7j0_80" + "'", str3.equals("dk1j7j0_80"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test243");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("SUN.LWAWT.MACOSX.LWCTOOLKIT", "a4 4#4 444#");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SUN.LWAWT.MACOSX.LWCTOOLKIT" + "'", str2.equals("SUN.LWAWT.MACOSX.LWCTOOLKIT"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test244");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "1.7");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test245");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("10a1a-1a-1", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C", 41);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1" + "'", str3.equals("10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test246");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("                            java HotSpot(TM) 64-Bit Server VM                             ", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                            java HotSpot(TM) 64-Bit Server VM                             " + "'", str2.equals("                            java HotSpot(TM) 64-Bit Server VM                             "));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test247");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("                                .0_80-b15");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left(".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libraaaaaaaaaaaaaaaaaaaaaa", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test249");
        char[] charArray8 = new char[] { '#', 'a', '4', '#', '4', 'a' };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a');
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "xaaa4axa4aa", charArray8);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", charArray8);
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "#aaa4a#a4aa" + "'", str10.equals("#aaa4a#a4aa"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test250");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("dk1j7j0_80");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "dk1j7j0_80" + "'", str1.equals("dk1j7j0_80"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test251");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "hi!sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test252");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("32.04100.040.04-1.040.0435.0", "Use...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Use..." + "'", str2.equals("Use..."));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test253");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", (int) (byte) 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test254");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (short) 0);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) (byte) 10, (int) (byte) 10);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test255");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, (java.lang.CharSequence) "Ava HotSpo");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test256");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "44", (java.lang.CharSequence) "US                                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test257");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "Dk1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test258");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test259");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("-1a0a1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"-1a0a1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS" + "'", str3.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test261");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "52.0a32.0", (java.lang.CharSequence) "#4A444#444A");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test262");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("97.0435.04-1.0435.0452.0", "", "1a10a1a10", (int) ' ');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "97.0435.04-1.0435.0452.0" + "'", str4.equals("97.0435.04-1.0435.0452.0"));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test263");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("Mac OS X");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "X SO caM" + "'", str1.equals("X SO caM"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test264");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Dk1.7.0_80", "Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test265");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("US                                                                                                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test266");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short6 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + short6 + "' != '" + (short) -1 + "'", short6 == (short) -1);
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 1 + "'", short8 == (short) 1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test267");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("51.0", "                                Java(TM) SE Runtime ", "", 0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "51.0" + "'", str4.equals("51.0"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test268");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        char[] charArray10 = new char[] { '#', '4', ' ', '4', ' ' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " ", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                51.0                                                ", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "#a4a a4a " + "'", str16.equals("#a4a a4a "));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test269");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("a                                aa", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a                                aa" + "'", str2.equals("a                                aa"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test270");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test271");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("104-14104324-141", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test272");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("51.0", "#4A444#444A");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "51.0" + "'", str2.equals("51.0"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test273");
        int[] intArray4 = new int[] { 1, (byte) 10, (short) 1, 10 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, '#', (int) (byte) 100, (int) (byte) 10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray4, '4', 1, (int) (byte) 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a');
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(intArray4, 'a', (int) 'a', 33);
        java.lang.String str24 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "141041410" + "'", str8.equals("141041410"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1a10a1a10" + "'", str18.equals("1a10a1a10"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1 10 1 10" + "'", str24.equals("1 10 1 10"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test274");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("dk1.#aaa4a#a4aa                          ", "-1#0#1");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test275");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                 Java HotSpot(TM) 64-Bit Server VM                                  ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test276");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("0 100 -1", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test277");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test278");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("32.04100.040.04-1.040.0435.0444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32.04100.040.04-1.040.0435.0444444444444444444" + "'", str1.equals("32.04100.040.04-1.040.0435.0444444444444444444"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test279");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("100a-1a0a1a97a100", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "       100a-1a0a1a97a100        " + "'", str2.equals("       100a-1a0a1a97a100        "));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test280");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test281");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("32.04100.040.04-1.040.0435.0444444444444444444", 35, 9);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test282");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "100.0#32.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test283");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("97.0 35.0 -1.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97.0 35.0 -1.0" + "'", str1.equals("97.0 35.0 -1.0"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test284");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("4444444444444444444444444444444444444444444444-14a41");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                 ", 2, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                 " + "'", str3.equals("                                aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                 "));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test286");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                 Java(TM) SE Runtime Environment                                 ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                 jAVA(tm) se rUNTIME eNVIRONMENT                                 " + "'", str1.equals("                                 jAVA(tm) se rUNTIME eNVIRONMENT                                 "));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test287");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 8, "xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test288");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("X   4 X 4  ", "1a0a1a0", "TIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X   4 X 4  " + "'", str3.equals("X   4 X 4  "));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test289");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("6", (float) 90);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0f + "'", float2 == 6.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test290");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) (short) 1, 46);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test291");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1", (int) (byte) 10);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test292");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("10.14.3", "");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/", 0);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("44", strArray3, strArray8);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "44" + "'", str10.equals("44"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test293");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "/librax86_6");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test294");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max(52.0f, 6.0f, (float) 0L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 52.0f + "'", float3 == 52.0f);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test295");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.overlay("", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", 33, (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar" + "'", str4.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test296");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test297");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("01.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B15", 4, "#4a444#444a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "01.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B15" + "'", str3.equals("01.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B15"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test298");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "", "brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test299");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern(":", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ":" + "'", str2.equals(":"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test300");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("#aaaaa4aaa#aaa4aaaa                                         ", "44444444444444444444444444444444444Sophie");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#aaaaa4aaa#aaa4aaaa                                         " + "'", str2.equals("#aaaaa4aaa#aaa4aaaa                                         "));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test301");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isEmpty((java.lang.CharSequence) "hi!sophie ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test302");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("", "HI!SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test303");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(0, (int) (short) -1, 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test304");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "...435....");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test305");
        char[] charArray9 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test306");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("52.xa32.x", "100.0#32.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "52.xa32.x" + "'", str2.equals("52.xa32.x"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test307");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test308");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("-140", "1.7.0_80-b15");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "oc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", 90, 0);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test309");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CO");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test310");
        float float3 = org.apache.commons.lang3.math.NumberUtils.max((float) ' ', (float) (short) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 32.0f + "'", float3 == 32.0f);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test311");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/librax86_6", (int) (short) 100, 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test312");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("#aaaaa4aaa#aaa4aaaa                                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#aaaaa4aaa#aaa4aaaa                                         " + "'", str1.equals("#aaaaa4aaa#aaa4aaaa                                         "));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test313");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                          1.7.0_80-b15                                           ", "              Sophie               ", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("a                                aa", "RS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a                                aa" + "'", str2.equals("a                                aa"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test315");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', (int) (short) 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) 'a', (int) (short) 0);
        java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 6, 2);
        byte byte19 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertTrue("'" + byte19 + "' != '" + (byte) -1 + "'", byte19 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-1" + "'", str21.equals("-1"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test316");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.2", "               eihpoS              ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.2" + "'", str2.equals("1.2"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test317");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test318");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361", (java.lang.CharSequence) "#aaa4a#a4aa", 46);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test319");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("100.0#32.0", (byte) 0);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 0 + "'", byte2 == (byte) 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("chines/jdk1.7.0_80.jdk/Contents/H", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "chines/jdk1.7.0_80.jdk/Contents/H" + "'", str2.equals("chines/jdk1.7.0_80.jdk/Contents/H"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test321");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray10 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence1, charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "wawt.macosx.CPrinterJob", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test322");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test323");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("eihpos!ih");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "eihpos!i" + "'", str1.equals("eihpos!i"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test324");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) ".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libr", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test325");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("0100-1", "", "Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification-Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification" + "'", str3.equals("Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification-Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test326");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("01.7.0_80-b15", "Jv(TM) ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test327");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("RaphicsEnvironmentRaphicsEnvironmentRaphicsEnvirRaphicsEnvironmentRaphicsEnvironmentRaphicsEnviro", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test328");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, '4');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test329");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/", "                            java HotSpot(TM) 64-Bit Server VM                             ", "hi!");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Uh/U/Uh/32.0#100.0#0.0#1.0#0.0#35.0/Uh/U/Uh/" + "'", str3.equals("/Uh/U/Uh/32.0#100.0#0.0#1.0#0.0#35.0/Uh/U/Uh/"));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test330");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "hi!soph");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test331");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10a1a-1a-1");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "####################################################");
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80");
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie", strArray6, strArray9);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.stripAll(strArray9, "raphicsEnvironment");
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                                                                                 hi!", strArray2, strArray12);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/Users/sophie" + "'", str10.equals("/Users/sophie"));
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "                                                                                                 hi!" + "'", str13.equals("                                                                                                 hi!"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test332");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("sophie", 97);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "sophie" + "'", str2.equals("sophie"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test333");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("97.0435.04-1.0435.0452.");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"97.0435.04-1.0435.0452.\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test334");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("sophie                                                                                              ", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sophie                                                                                              " + "'", str3.equals("sophie                                                                                              "));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test335");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("6");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "6" + "'", str1.equals("6"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test336");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test337");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", "01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION" + "'", str2.equals("oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test338");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray10 = new char[] { '#', '4', ' ', '4', ' ' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " ", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                51.0                                                ", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone(charSequence1, charArray10);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "10a1a-1a-14444444444444444444444", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test339");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) (short) 100, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment", " ...");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test341");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("x   4 x 4  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test342");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 1, 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', 0, (-1));
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0#32.0" + "'", str10.equals("100.0#32.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test343");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test344");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("phicsEnvironmentar", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "phicsEnvironmentar" + "'", str2.equals("phicsEnvironmentar"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test345");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase(".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libraaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + ".0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDACHINES/JDKALmAvIRTUAVA/jAVARY/jA/lIBRAAAAAAAAAAAAAAAAAAAAAA" + "'", str1.equals(".0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDACHINES/JDKALmAvIRTUAVA/jAVARY/jA/lIBRAAAAAAAAAAAAAAAAAAAAAA"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test346");
        char[] charArray7 = new char[] { '#', 'a', '4', '#', '4', 'a' };
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(charArray7, 'a');
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "#aaa4a#a4aa" + "'", str9.equals("#aaa4a#a4aa"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test347");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/H", (java.lang.CharSequence) "               eihpoS              ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test348");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("                                .0_80-b15");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                .0_80-b1" + "'", str1.equals("                                .0_80-b1"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test349");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "Java(TM) SE Runtime");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test350");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("0a100a-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test351");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("x   4 x 4  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "x   4 x 4  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("x   4 x 4  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test352");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("1a0a1a0", "10 1 -1 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a0a1a0" + "'", str2.equals("1a0a1a0"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test353");
        long[] longArray6 = new long[] { (short) 10, 32L, 97, (byte) 0, (-1L), (-1L) };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "10a32a97a0a-1a-1" + "'", str10.equals("10a32a97a0a-1a-1"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test354");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "", "                                 jAVA(tm) se rUNTIME eNVIRONMENT                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test355");
        float[] floatArray3 = new float[] { (-1L), (byte) 1, (byte) 1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "-1.0 1.0 1.0" + "'", str5.equals("-1.0 1.0 1.0"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test356");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotEmpty((java.lang.CharSequence) "#/sophie#/sophie#/sophie#/sophie#/sophie#/sox   4 x 4  #/sophie#/sophie#/sophie#/sophie#/sophie#/sop");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test357");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("32.04100.040.04-1.040.0435.0444444444444444444", "/eihpoSU/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test358");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 0, 0);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#', (int) (short) 1, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test359");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "1 10 1 10");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test360");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test361");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test362");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "0#100#-1", (-14041));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test363");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", (java.lang.CharSequence) "1.7", (int) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test364");
        char[] charArray9 = new char[] { '#', '4', ' ', '4', ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " ", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray9);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                51.0                                                ", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "...esU", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test365");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 4, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test366");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils1 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils2 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils3 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray4 = new org.apache.commons.lang3.SystemUtils[] { systemUtils0, systemUtils1, systemUtils2, systemUtils3 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray4);
        org.junit.Assert.assertNotNull(systemUtilsArray4);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test367");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 100, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 100 + "'", short3 == (short) 100);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test368");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("4444444444444444444444444444444444444444444444444444", strArray4, strArray8);
        java.lang.String[] strArray10 = null;
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("                                               -1#0#1                                               ", strArray4, strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str9.equals("4444444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "                                               -1#0#1                                               " + "'", str11.equals("                                               -1#0#1                                               "));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test369");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie", (int) '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", strArray3, strArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "", (int) 'a', 97);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, '#', 1, (int) (short) 0);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, ' ');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str8.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str9.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str19.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test370");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "                                h !", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444", 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test371");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithIgnoreCase((java.lang.CharSequence) "5241041", (java.lang.CharSequence) "oRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test372");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "1.6", (java.lang.CharSequence) "!ih");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test373");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("US", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "US" + "'", str2.equals("US"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test374");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("                                                                                                 ", "4444444444444444444444444444444444444444444444-14041", "#a4a a4a ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                 " + "'", str3.equals("                                                                                                 "));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test375");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str1.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test376");
        long[] longArray6 = new long[] { (short) 10, 32L, 97, (byte) 0, (-1L), (-1L) };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10a32a97a0a-1a-1" + "'", str11.equals("10a32a97a0a-1a-1"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test377");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(46, 8, 46);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test378");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("104-14104324-141");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test379");
        long[] longArray6 = new long[] { 10L, (byte) -1, (short) 10, ' ', (short) -1, (byte) 1 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', (int) '#', 0);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', 13, (int) (byte) 1);
        try {
            java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(longArray6, '#', 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test380");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop...", "dk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test381");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "mv RO AVAJ", "#/SOPHIE");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test382");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("phicsEnvironmentar");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PHICSENVIRONMENTAR" + "'", str1.equals("PHICSENVIRONMENTAR"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test383");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("xaaa4axa4aa", "                                  10.14.3");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test384");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length BigInteger");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test385");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("100-1", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test386");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("                                ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                " + "'", str1.equals("                                "));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test387");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence) "HI!SOPHIE");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test388");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("1a10a1a10", 35, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1a10a1a1044444444444444444444444444" + "'", str3.equals("1a10a1a1044444444444444444444444444"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test389");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test390");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("/Library/Java/JavaVirtualMachines/jdkaaaaaaaaaa.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test391");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("141041410                                  ...", 2, (int) '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "141041410                                  ..." + "'", str3.equals("141041410                                  ..."));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test392");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/", 0);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "10.14.3");
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", strArray5, strArray8);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "sun.lwawt.macosx.CPrinterJob", 0, 0);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "!ih                                                                                                 ", (java.lang.CharSequence[]) strArray8);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "aa");
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str9.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "hi!" + "'", str15.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!" + "'", str17.equals("hi!"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test393");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("X SO caM", "10a-1a10a32a-1a1", "97.0435.04-1.0435.0452");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "X SO caM" + "'", str3.equals("X SO caM"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test394");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", ".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libraaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test395");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            ", (java.lang.CharSequence) "97.0a35.0a-1.0a35.0a52.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test396");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("DK1.7.0_80", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DK1.7.0_80" + "'", str2.equals("DK1.7.0_80"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test398");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) 0, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test399");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "ttttttttttttttttttttttttttttttttht!", (java.lang.CharSequence) "1.1S");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test400");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) 0, (short) (byte) 10, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 10 + "'", short3 == (short) 10);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test401");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test402");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("10a1a-1a-1");
        java.lang.String[] strArray3 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("a4 4#4 444#", strArray2, strArray3);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "a4 4#4 444#" + "'", str4.equals("a4 4#4 444#"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test403");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java" + "'", str2.equals("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java"));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test404");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("#4A444#444A", 3, "o");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#4A444#444A" + "'", str3.equals("#4A444#444A"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test405");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 0, 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 32.0d + "'", double9 == 32.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test406");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min(0.0f, 0.0f, (float) (-14041L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-14041.0f) + "'", float3 == (-14041.0f));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test407");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS" + "'", str2.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test408");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("X   4 X 4  ", "/Uh/U/Uh/32.0#100.0#0.0#1.0#0.0#35.0/Uh/U/Uh/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X   4 X 4  " + "'", str2.equals("X   4 X 4  "));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test409");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:", "       100a-1a0a1a97a100        ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:" + "'", str2.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:"));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test410");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("Jv(TM) ...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Jv(TM) ..." + "'", str1.equals("Jv(TM) ..."));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test411");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "JV(TM) SE RUNTIME ENVIRONMENT", (java.lang.CharSequence) "-140", (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test412");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) -1, (short) (byte) 0, (short) 10);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) -1 + "'", short3 == (short) -1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test413");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("32.04100.040.04-1.040.0435.0444444444444444444", ' ');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test414");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Oracle Corporation", (java.lang.CharSequence) "1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test415");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "          ");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test416");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("100.0 32.0", "x   4 x 4  ", "                                h !");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "100.0 32.0" + "'", str3.equals("100.0 32.0"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test417");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "141041410", 52);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "#4A444#444A");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test418");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("sun.lwawt.macosx.LWCToolkit", "java HotSpot(TM) 64-Bit Server VM", "chines/jdk1.7.0_80.jdk/Contents/H", 7);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str4.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test419");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("/");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test420");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("SUN.LWAWT.MACOSX.LWCTOOLKIT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"SUN.LWAWT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test421");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("4");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4" + "'", str1.equals("4"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test422");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (short) 0);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', (int) '4', (int) (short) 0);
        byte byte13 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) -1 + "'", byte7 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + byte13 + "' != '" + (byte) -1 + "'", byte13 == (byte) -1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test423");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "!ih                                                                                                 ", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                .0_80-b15", "Java Virtual Machine Specification");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test425");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("32.0#100.0#0.0#-1.0#0.0#35.0", 0, "52.0a32.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "32.0#100.0#0.0#-1.0#0.0#35.0" + "'", str3.equals("32.0#100.0#0.0#-1.0#0.0#35.0"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test426");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("", (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test427");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("us", "Java Platform API Specification", (int) (byte) -1);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test428");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "1a10a1a1044444444444444444444444444");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test429");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "ava HotSpo", (java.lang.CharSequence) "TIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test430");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                 Java HotSpot(TM) 64-Bit Server VM                                  ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test431");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("1.1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"1.1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test432");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "-140");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test433");
        int int1 = org.apache.commons.lang3.StringUtils.length((java.lang.CharSequence) "/librax86_6");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 11 + "'", int1 == 11);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test434");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "                            java HotSpot(TM) 64-Bit Server VM                             ", (java.lang.CharSequence) "Java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test435");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", '4');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test436");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("                                .0_80-b1");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test437");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "44444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test438");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "raphicsEnvironmentraphicsEnvironmentraphicsEnvironment", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test439");
        short[] shortArray0 = null;
        try {
            short short1 = org.apache.commons.lang3.math.NumberUtils.max(shortArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The Array must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test440");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "RaphicsEnvironment", 3);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test441");
        byte[] byteArray1 = new byte[] { (byte) 10 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str5 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "/Uh/U/Uh/32.0#100.0#0.0#1.0#0.0#35.0/Uh/U/Uh/");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /Uh/U/Uh/32.0#100.0#0.0#1.0#0.0#35.0/Uh/U/Uh/");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test442");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("Use...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test443");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 66);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test444");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("4444444444444444444444444444444444444444444444-14a41", "# 4   #   a");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444444444444444444-14a41" + "'", str2.equals("4444444444444444444444444444444444444444444444-14a41"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test445");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test446");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripAccents("                                                        mixed mode");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                                        mixed mode" + "'", str1.equals("                                                        mixed mode"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test447");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                      100.0 32.0                                       ", "java or VM");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test448");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("32.0a100.0a0.0a-1.0a0.0a35.0", "100.0#32.0", 97);
        int int5 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test449");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "...esU", (int) (byte) 100, 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("                                     -1#0#1                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                     -1#0#1                                               " + "'", str1.equals("                                     -1#0#1                                               "));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test451");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 3, (long) 9, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test452");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/librax86_64", "sophie");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test453");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 2, 100L, (long) 97);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test454");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("eihpos!ih", (-1), "US                                                                                                 ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "eihpos!ih" + "'", str3.equals("eihpos!ih"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test455");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStart("HTTP://JAVA.ORACLE.COM/", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "HTTP://JAVA.ORACLE.COM/" + "'", str2.equals("HTTP://JAVA.ORACLE.COM/"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test456");
        float[] floatArray5 = new float[] { 'a', '#', (-1), '#', '4' };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        float float9 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 97.0f + "'", float6 == 97.0f);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "97.0a35.0a-1.0a35.0a52.0" + "'", str8.equals("97.0a35.0a-1.0a35.0a52.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + (-1.0f) + "'", float9 == (-1.0f));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test457");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("                            java HotSpot(TM) 64-Bit Server VM                             ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test458");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("DK1.7.0_80", "Java Virtual Machine Specification", "/librax86_6");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test459");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("0 100 -1");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \" 100 -1\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test460");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("us");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, 'a');
        boolean boolean6 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "TIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", (java.lang.CharSequence[]) strArray3);
        int int7 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "4444444444444444444444444444444aaaaaaaaaa44444444444444444444444444444444", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "us" + "'", str5.equals("us"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test461");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("52.0a32.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52.0a32.0" + "'", str1.equals("52.0a32.0"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test462");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("hi!", '#');
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:", (java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test463");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("us", 66);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "us                                                                " + "'", str2.equals("us                                                                "));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test464");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "1.2", (java.lang.CharSequence) "                                 jAVA(tm) se rUNTIME eNVIRONMENT                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test465");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test466");
        char[] charArray11 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray11);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray11);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray11, 'a', (int) (short) 1, 0);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#aaa4a#a4aa", charArray11);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "!ih                                                                                                 ", charArray11);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0a100a-", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test467");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("X SO caM", "0a100a-1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "X SO caM" + "'", str2.equals("X SO caM"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test468");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 10, (long) '4', (long) 33);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 10L + "'", long3 == 10L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test469");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("sun.lwawt.macosx.LWCToolkit");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "sun.lwawt.macosx.LWCToolkit" + "'", str1.equals("sun.lwawt.macosx.LWCToolkit"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test470");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("####################################################", "/Users/sophie/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "DK1.7.0_80");
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA                                 ", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "x   4 x 4  aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray8);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test471");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("#444 4#4 4a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"#444 4#4 4a\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("", 5, 90);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test473");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) ":", (java.lang.CharSequence) "ava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test474");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 1, 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0#32.0" + "'", str9.equals("100.0#32.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0 32.0" + "'", str11.equals("100.0 32.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100.0432.0" + "'", str13.equals("100.0432.0"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test475");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "mixed mode", (java.lang.CharSequence) "Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification-Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test476");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("...esU");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "...esU" + "'", str1.equals("...esU"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test477");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("oc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test478");
        byte[] byteArray1 = new byte[] { (byte) 10 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "10" + "'", str5.equals("10"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test479");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("/Users/sophie/Documents/defects4j/tmp/run_randoop...", 9, "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop..." + "'", str3.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop..."));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test480");
        char[] charArray14 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray14);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray14);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100.0 32.0", charArray14);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray14, 'a', (int) (byte) 0, (int) (short) 1);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaa", charArray14);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "01.7.0_80-b15", charArray14);
        boolean boolean24 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!sophi", charArray14);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(charArray14, ' ');
        int int27 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", charArray14);
        boolean boolean28 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "51.0", charArray14);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "#" + "'", str21.equals("#"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "# 4   #   a" + "'", str26.equals("# 4   #   a"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test481");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("01.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B15", "hi!soph", "US                                                                                                  ");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test482");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", (int) (byte) 100, "##4# ### #a");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##4# ### #a##4# ### #a##4# ### #a##4# ### #a##4# ### #a##4# ### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("##4# ### #a##4# ### #a##4# ### #a##4# ### #a##4# ### #a##4# ### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test483");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.deleteWhitespace("dk1.#aaa4a#a4aa                          ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "dk1.#aaa4a#a4aa" + "'", str1.equals("dk1.#aaa4a#a4aa"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test484");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "ihpos!ih", "ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test485");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte(".0_80.JDK/cONTENTS/hOME/JRE/LIB/ENDORSEDACHINES/JDKALmAvIRTUAVA/jAVARY/jA/lIBRAAAAAAAAAAAAAAAAAAAAAA", (byte) -1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) -1 + "'", byte2 == (byte) -1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test486");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfBlank((java.lang.CharSequence) "                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", charSequence2.equals("                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test487");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "10.14.3", (int) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test488");
        int[] intArray4 = new int[] { 1, (byte) 10, (short) 1, 10 };
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(intArray4, '4');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(intArray4, '#', (int) (byte) 100, (int) (byte) 10);
        int int13 = org.apache.commons.lang3.math.NumberUtils.max(intArray4);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(intArray4, ' ', (int) (byte) 1, 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "141041410" + "'", str8.equals("141041410"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1 10 1 10" + "'", str15.equals("1 10 1 10"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test489");
        char[] charArray11 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray11);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100.0 32.0", charArray11);
        int int15 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "24.80-b11", charArray11);
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(charArray11, '4');
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#6", charArray11);
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "#444 4#4 4a" + "'", str17.equals("#444 4#4 4a"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test490");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "44444444444444444444444444444444444Sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test491");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString("44444444444444444444444444444444444444444444444444444444444444444dk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444dk1.7.0_80.jdk/Contents/Home/jre" + "'", str1.equals("44444444444444444444444444444444444444444444444444444444444444444dk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test492");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("97.0 35.0 -1.0", "dk1j7j0_80");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97.0 35.0 -1.0" + "'", str2.equals("97.0 35.0 -1.0"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test493");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "                                                                                                 hi!");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test494");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "phicsEnvironmentar", (java.lang.CharSequence) "RaphicsEnvironmentRaphicsEnvironmentRaphicsEnvirRaphicsEnvironmentRaphicsEnvironmentRaphicsEnviro");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test495");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("                            java HotSpot(TM) 64-Bit Server VM                             ");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test496");
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/", 0);
        boolean boolean6 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence[]) strArray5);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "0a100a-1");
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "10.14.3");
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.replaceEach("/", strArray5, strArray11);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray11, '#');
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "/" + "'", str12.equals("/"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "hi!" + "'", str14.equals("hi!"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test497");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("                                     -1#0#1                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1#0#1" + "'", str1.equals("-1#0#1"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test498");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Oracle Corporation", "4444444444444444444444444444444444444444444444444444");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "http://java.oracle.com/");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test499");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "x86_64", (java.lang.CharSequence) "              4Sophie4               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test500");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/eihpoSU/", (java.lang.CharSequence) "4");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }
}

