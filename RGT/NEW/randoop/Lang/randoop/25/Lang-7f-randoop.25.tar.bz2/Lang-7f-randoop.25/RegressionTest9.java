import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test01");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java(TM) SE Runtime", (java.lang.CharSequence) "-1a0a1sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.mac");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test02");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("97.0a35.0a-1.0a35.0a52.", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97.0a35.0a-1.0a35.0a52" + "'", str2.equals("97.0a35.0a-1.0a35.0a52"));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test03");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("-1.0 1.0 ", 42);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                -1.0 1.0                  " + "'", str2.equals("                -1.0 1.0                  "));
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test04");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 1, 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 32.0d + "'", double9 == 32.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0 32.0" + "'", str11.equals("100.0 32.0"));
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test05");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) -1, (short) 0, (short) 0);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test06");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed" + "'", str1.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed"));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test07");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty(charSequence0, (java.lang.CharSequence) "chines/jdk1.7.0_80.jdk/Contents/H");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "chines/jdk1.7.0_80.jdk/Contents/H" + "'", charSequence2.equals("chines/jdk1.7.0_80.jdk/Contents/H"));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test08");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 0, 0);
        short short10 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#', 35, (int) (byte) 1);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) 1 + "'", short10 == (short) 1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test09");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "104-14104324-141");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test10");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("HI!SOPHIE");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test11");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, (java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000o", (-14041));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test12");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("", ".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libr", "1#0#1-");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test13");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("#AAA4A#A4AA                                         ", "ttttttttttttttttttttttttttttttttht!", 90);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test14");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("a4 4#4 444#", (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test15");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test16");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("Java(TM) SE Runtime Environment", "0 100 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test17");
        int[] intArray3 = new int[] { (byte) 0, 100, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        int int8 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int9 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0#100#-1" + "'", str7.equals("0#100#-1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0 100 -1" + "'", str11.equals("0 100 -1"));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test18");
        int int2 = org.apache.commons.lang3.StringUtils.getLevenshteinDistance((java.lang.CharSequence) "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", (java.lang.CharSequence) "1#10#1#10");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 215 + "'", int2 == 215);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test19");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                .0_80-b1", "DK1.7.0_80##################################");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test20");
        float[] floatArray5 = new float[] { 'a', '#', (-1), '#', '4' };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray5, '#', 9, 0);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 97.0f + "'", float6 == 97.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 97.0f + "'", float7 == 97.0f);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 97.0f + "'", float12 == 97.0f);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test21");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (java.lang.CharSequence) "/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/", 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test22");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libr", "/Users", (int) (byte) 100);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "100.0#32.0", 13, 0);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "");
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test23");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("# 4   #   a", '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "   #   a4# " + "'", str2.equals("   #   a4# "));
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test24");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("-14041-140");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-14041-140" + "'", str1.equals("-14041-140"));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test25");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "sun.lwawt.macosx.LWCToolkit", (java.lang.CharSequence) "          x   4 x 4  ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test26");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("a                                aa", (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "a                                aa" + "'", str2.equals("a                                aa"));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test27");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("#AAA4A#A4AA", 41);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA" + "'", str2.equals("#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA#AAA4A#A4AA"));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test28");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "dk1.7.0_801a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a10", 35, 5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test29");
        short[] shortArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(shortArray0, '#', 27, 1);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test30");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/" + "'", str2.equals("erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/"));
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test31");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 215, 4.4444444444444445E51d, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.4444444444444445E51d + "'", double3 == 4.4444444444444445E51d);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test32");
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest9.test33");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie", (int) '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", strArray3, strArray7);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "", (int) 'a', 97);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/co");
        java.lang.String[] strArray17 = org.apache.commons.lang3.StringUtils.stripAll(strArray7, "Java(TM) SE Runtime Environment");
        int int18 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray17);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str8.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str9.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str15.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }
}

