import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test001");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "/", (java.lang.CharSequence) "XSOcaM");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test002");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("h !", (int) (short) 100, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "h !#################################################################################################" + "'", str3.equals("h !#################################################################################################"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test003");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith(charSequence0, charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test004");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) -1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test005");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0a100a-1", (java.lang.CharSequence) " ...", 41);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test006");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "ttttttttttttttttttttttttttttttttht!", (java.lang.CharSequence) "sun.awt.CGraphicsEnvironment", 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test007");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("             ", "#aaa4a#a4aa                                         ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test008");
        long[] longArray6 = new long[] { 100, (-1L), 0L, 1, 'a', 100L };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', (int) ' ', 0);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ', 4, (int) (short) 0);
        long long18 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long19 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long20 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long21 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a-1a0a1a97a100" + "'", str13.equals("100a-1a0a1a97a100"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 100L + "'", long19 == 100L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1L) + "'", long20 == (-1L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test009");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("/eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU/");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test010");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("o", "dk1.7.0_80.jdk/Contents/Home/jreSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSo", "10101-1101010");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test011");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0#100#-1", (java.lang.CharSequence) "                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H", (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test012");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("52.xa32.x");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "52.xa32.x" + "'", str1.equals("52.xa32.x"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test013");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 0, 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test014");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test015");
        int[] intArray3 = new int[] { (byte) 0, 100, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a100a-1" + "'", str7.equals("0a100a-1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0a100a-1" + "'", str14.equals("0a100a-1"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test016");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  4 x 4   x", "                                               -1#0#1                                               ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  4 x 4   x" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  4 x 4   x"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test017");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("-140");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-140L) + "'", long1 == (-140L));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test018");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble(" Users/sophie/Library/Java/Extensions:/Library");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"Users/sophie/Library/Java/Extensions:/Library\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test019");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("100.0#32.0chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Libr");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o ");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "   10 1 -1 -1");
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + ".0#32.0chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Lib" + "'", str5.equals(".0#32.0chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Lib"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test020");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "             ", (java.lang.CharSequence) "97.0 35.0 -1.0 35.0 52.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test021");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("TIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION" + "'", str2.equals("TIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATIONoRACLE cORPORATION"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test022");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("Java Platform API Specification", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  4 x 4   x", 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test023");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, '#', (-14041), 87);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test024");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("#4A444#444A", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test025");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max(0.0d, (double) 8, 13.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.0d + "'", double3 == 13.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test026");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("1a10a1a10", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test027");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "0#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#10", (java.lang.CharSequence) "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/co");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test028");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "#aaa4a#a4aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test029");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                .0_80-b1", (float) 6);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0f + "'", float2 == 6.0f);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test030");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("100#-1#0#1#97#100", (int) '4');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                 100#-1#0#1#97#100                  " + "'", str2.equals("                 100#-1#0#1#97#100                  "));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test031");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "o", 87);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test032");
        long[] longArray6 = new long[] { 10L, (byte) -1, (short) 10, ' ', (short) -1, (byte) 1 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.Class<?> wildcardClass8 = longArray6.getClass();
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', (int) (short) 100, (int) '4');
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(longArray6, '#', 0, 44);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test033");
        long[] longArray6 = new long[] { (short) 10, 32L, 97, (byte) 0, (-1L), (-1L) };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test034");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf(charSequence0, 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test035");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("Mac OS X", 33);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Mac OS X" + "'", str2.equals("Mac OS X"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test036");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment", (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment   " + "'", str2.equals("  Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment   "));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test037");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Mac OS X", "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Mac OS X" + "'", str3.equals("Mac OS X"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test038");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains(charSequence0, (java.lang.CharSequence) "-14a41");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test039");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "!ih                                                                                                 ", "1.7.0_80-b15");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str3.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test040");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/Users/sophie");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "52.0a32.0", (java.lang.CharSequence[]) strArray2);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test041");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("US");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, "1.7.0_80");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray1);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray1, "10.14.3");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "US" + "'", str3.equals("US"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test042");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/", (java.lang.CharSequence) "100.0a32.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test043");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "10.14.3");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("-1#0#1", " ", 0);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("Oracle Corporation", strArray3, strArray7);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Oracle Corporation" + "'", str8.equals("Oracle Corporation"));
        org.junit.Assert.assertNotNull(strArray9);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test044");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("sophie", "/Users/sophie", (int) (byte) -1);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "oc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/", 87, 27);
        boolean boolean9 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) " o ", (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test045");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                 Java HotSpot(TM) 64-Bit Server VM                                  ");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("US");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray4, "1.7.0_80");
        int int7 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "10.14.3");
        java.lang.Class<?> wildcardClass10 = strArray9.getClass();
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.replaceEach("", strArray2, strArray9);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "US" + "'", str6.equals("US"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test046");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.capitalize("44444444444444444444444444444444444Sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "44444444444444444444444444444444444Sophie" + "'", str1.equals("44444444444444444444444444444444444Sophie"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test047");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("1.7", "Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".7" + "'", str2.equals(".7"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test048");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isWhitespace((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CO");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test049");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.0 0.0 52.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test050");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1 1 100 1 -1", 87, "-1a0a1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1a0a1-1a0a1-1a0a1-1a0a1-1a0a1-1a0a1-1a0a1-1a0a1-1a0a1-1a0a1-1a0a1-1a0a1-1a1 1 100 1 -1" + "'", str3.equals("-1a0a1-1a0a1-1a0a1-1a0a1-1a0a1-1a0a1-1a0a1-1a0a1-1a0a1-1a0a1-1a0a1-1a0a1-1a1 1 100 1 -1"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test051");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test052");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp(" Users/sophie/Library/Java/Extensions:/Library", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " Users/sophie/Library/Java/Extensions:/Library" + "'", str2.equals(" Users/sophie/Library/Java/Extensions:/Library"));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test053");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("Java(TMkkk97kd .4kd -1kd .4kd 41kd", "/librax86_64");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test054");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "u", (java.lang.CharSequence) "phicsEnvironmentar");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test055");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "java platform api specification97.0435.04-1.0435.0452.0java platform api specification97.0435.04-1.0435.0452.0java platform api specification97.0435.04-1.0435.0452.0java platform api specification");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test056");
        byte[] byteArray1 = new byte[] { (byte) 10 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte4 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 10 + "'", byte3 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte4 + "' != '" + (byte) 10 + "'", byte4 == (byte) 10);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test057");
        float[] floatArray5 = new float[] { 'a', '#', (-1), '#', '4' };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray5, ' ');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 97.0f + "'", float6 == 97.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 97.0f + "'", float7 == 97.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "97.0 35.0 -1.0 35.0 52.0" + "'", str9.equals("97.0 35.0 -1.0 35.0 52.0"));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test058");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumericSpace((java.lang.CharSequence) "                                                                                           sophie");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test059");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Use...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test060");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("4444444...");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test061");
        short short2 = org.apache.commons.lang3.math.NumberUtils.toShort("java platform api specification97.0435.04-1.0435.0452.0java platform api specification97.0435.04-1.0435.0452.0java platform api specification97.0435.04-1.0435.0452.0java platform api specification", (short) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test062");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "####################################################");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80");
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.replaceEach("/Users/sophie", strArray4, strArray7);
        java.lang.String[] strArray9 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray7);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                          1.7.0_80-b15                                           ", (java.lang.CharSequence[]) strArray10);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray10);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Users/sophie" + "'", str8.equals("/Users/sophie"));
        org.junit.Assert.assertNotNull(strArray9);
        org.junit.Assert.assertNotNull(strArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test063");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("-1.0 1.0 1.0", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0 1.0 " + "'", str2.equals("-1.0 1.0 "));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test064");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("Java(TM...97.0 35.0 -1.0 35.0 52.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java(TM...97.0 35.0 -1.0 35.0 52.0" + "'", str1.equals("java(TM...97.0 35.0 -1.0 35.0 52.0"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test065");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("", 44, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test066");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("A AA", "o");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test067");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "          x   4 x 4  ", (java.lang.CharSequence) "/USophie/U");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test068");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "52.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.0", (java.lang.CharSequence) "97.0a35.0a-1.0a35.0a52.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test069");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("ava HotSpo", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test070");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("/Library/Java/JavaVirtualMachines/jdkaaaaaaaaaa.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/library/java/javavirtualmachines/jdkaaaaaaaaaa.0_80.jdk/contents/home/jre/lib/endorsed" + "'", str1.equals("/library/java/javavirtualmachines/jdkaaaaaaaaaa.0_80.jdk/contents/home/jre/lib/endorsed"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test071");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("RS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "1.7.0_80-b15");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test072");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("               eihpoS              ", "Java(TM) SE Runtime Environment", "0.0#41.0#32.0#0.0#1.6#3.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "               eihpoS              " + "'", str3.equals("               eihpoS              "));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test073");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("52.xa32.x", 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test074");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "Java Platform API Specification", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test075");
        java.lang.String[] strArray0 = null;
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray0, "                                                                                                 hi!");
        org.junit.Assert.assertNull(strArray2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test076");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 1, 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double11 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double14 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0432.0" + "'", str10.equals("100.0432.0"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 32.0d + "'", double11 == 32.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100.0432.0" + "'", str13.equals("100.0432.0"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 32.0d + "'", double14 == 32.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test077");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("sophie", ' ');
        try {
            java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, "/eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU//eihpoSU/", 7, 27);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test078");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10 -1 10 32 -1 1", 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test079");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart(" 6 ", "-140     ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "6 " + "'", str2.equals("6 "));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test080");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("-1a0a1");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-1a0a1" + "'", str1.equals("-1a0a1"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test081");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                 Java HotSpot(TM) 64-Bit Server VM                                  ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test082");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.chomp("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  4 x 4   x", "dk1.7.0_80.jdk/Contents/Home/jreSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSophieSo");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  4 x 4   x" + "'", str2.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  4 x 4   x"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test083");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "java or VM");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test084");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', (int) (short) 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-1" + "'", str13.equals("-1"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test085");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("10101-1101010", "/librax86_64", "oc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10101-1101010" + "'", str3.equals("10101-1101010"));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test086");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat(" 6 ", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " 6  6 " + "'", str2.equals(" 6  6 "));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test087");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("chines/jdk1.7.0_80.jdk/Contents/H", 0, "1.0 0.0 52.0");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "chines/jdk1.7.0_80.jdk/Contents/H" + "'", str3.equals("chines/jdk1.7.0_80.jdk/Contents/H"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test088");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://java.oracle.com/" + "'", str1.equals("http://java.oracle.com/"));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test089");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/H\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test090");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring(".0#32.0chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Lib", 13);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Lib" + "'", str2.equals("/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Lib"));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test091");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceOnce("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            ", "", "-14a41");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            " + "'", str3.equals("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS            "));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test092");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "!ih", (int) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test093");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDKs.7./_8/.JDK/COUS");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test094");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("...nsi...");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test095");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " Users/sophie/Library/Java/Extensions:/Library", (java.lang.CharSequence) ".io.Filecl");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test096");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("java HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test097");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("97.0435.04-1.0435.0452", "                 100#-1#0#1#97#100                  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + ".0435.04-1.0435.0452" + "'", str2.equals(".0435.04-1.0435.0452"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test098");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "######HTTP://JAVA.ORACLE.COM/######");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test099");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("32.0 100.0 0.0 -1.0 0.0 35.0", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test100");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 52, 0.0d, 32.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.0d + "'", double3 == 52.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test101");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.max((byte) 100, (byte) 1, (byte) 100);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) 100 + "'", byte3 == (byte) 100);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test102");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("0100-1", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test103");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("-1.0 1.0 1.0", "                                      100.0 32.0                                       ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-1.0 1.0 1.0" + "'", str2.equals("-1.0 1.0 1.0"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test104");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                               UTF-8                                                ", (java.lang.CharSequence) ".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test105");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("-140", "wawt.macosx.CPrinterJob");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test106");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, 100, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test107");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C" + "'", str2.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test108");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("", 11);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "           " + "'", str2.equals("           "));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test109");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("#aaa4a#a4aa                                         ", "ihpos!ih", 0);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test110");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "Java(TM) SE Runtime Environment", (java.lang.CharSequence) "01.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B15", 20);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test111");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(0, (int) (short) 100, 27);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test112");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment", (java.lang.CharSequence) "97.0435.04-1.0435.0452.0");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test113");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("/library/java/javavirtualmachines/jdk1.7.0_80.jdk/co");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "Use...", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test114");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOfIgnoreCase((java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", (java.lang.CharSequence) "              Sophie               ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test115");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("                                AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA                                 ", 46, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA                                 " + "'", str3.equals("                                AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA                                 "));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test116");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Use...", (int) (byte) 10, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Use...    " + "'", str3.equals("Use...    "));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test117");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4', (int) (short) 0, 2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        short short13 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1#0#1" + "'", str6.equals("-1#0#1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-140" + "'", str10.equals("-140"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-14041" + "'", str12.equals("-14041"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) -1 + "'", short13 == (short) -1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test118");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Oracle Corporation");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test119");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 1, (byte) 100, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', 4, 0);
        java.lang.Class<?> wildcardClass13 = byteArray5.getClass();
        byte byte14 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + byte14 + "' != '" + (byte) 100 + "'", byte14 == (byte) 100);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test120");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("32.04100.040.04-1.040.0435.0", "�");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "32.04100.040.04-1.040.0435.0" + "'", str2.equals("32.04100.040.04-1.040.0435.0"));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test121");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("4444444444444444444444444444444aaaaaaaaaa44444444444444444444444444444444", 0, "xaaa4axa4aa              Sophie                     ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444aaaaaaaaaa44444444444444444444444444444444" + "'", str3.equals("4444444444444444444444444444444aaaaaaaaaa44444444444444444444444444444444"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test122");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNumeric((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000o");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test123");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                Java(TM) SE Runtime ");
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("51.0", "#", (int) 'a');
        try {
            java.lang.String str7 = org.apache.commons.lang3.StringUtils.replaceEach("/USophie/U", strArray2, strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Search and Replace array lengths don't match: 3 vs 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray6);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test124");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "sophiesophiesophius                                                                sophiesophiesophi", (java.lang.CharSequence) "raphicsEnvironmentraphicsEnvironmentraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test125");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("Mac OS X", "1.0#0.0#52.0", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test126");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "          ", (java.lang.CharSequence) ".7");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "          " + "'", charSequence2.equals("          "));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test127");
        try {
            java.math.BigDecimal bigDecimal1 = org.apache.commons.lang3.math.NumberUtils.createBigDecimal(".io.Filecl");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test128");
        short short3 = org.apache.commons.lang3.math.NumberUtils.max((short) (byte) -1, (short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 1 + "'", short3 == (short) 1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test129");
        char[] charArray9 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sophie", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "0100-1", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test130");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("dk1.#aaa4a#a4aa", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test131");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("10a1a97.0435.04-1.0435.045210a1a-", "hi!sophi");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "10a1a97.0435.04-1.0435.045210a1a-" + "'", str2.equals("10a1a97.0435.04-1.0435.045210a1a-"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test132");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("104-14104324-141", (int) (byte) 100, 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test133");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("                                AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA                                 ");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test134");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("# 4   #   a", "                                Java(TM) SE Runtime ", (int) '4');
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test135");
        int[] intArray3 = new int[] { (byte) 0, 100, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a100a-1" + "'", str7.equals("0a100a-1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "041004-1" + "'", str10.equals("041004-1"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test136");
        byte[] byteArray4 = new byte[] { (byte) 10, (byte) 1, (byte) -1, (byte) -1 };
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(byteArray4, 'a');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(byteArray4, ' ');
        try {
            java.lang.String str10 = org.apache.commons.lang3.StringUtils.toString(byteArray4, "!ih");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: !ih");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10a1a-1a-1" + "'", str6.equals("10a1a-1a-1"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10 1 -1 -1" + "'", str8.equals("10 1 -1 -1"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test137");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("#6", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test138");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4', 11, 0);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short11 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + short11 + "' != '" + (short) -1 + "'", short11 == (short) -1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test139");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", "                                      100.0 32.0                                       ");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test140");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10a-1a10a32a-1a1", " 6  6 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test141");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "x86_64", "Java(TM) SE Runtime");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test142");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "24.80-b11");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test143");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray10 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.0#0.0#52.0", charArray10);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "0a100a-1", charArray10);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, charArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray10, '#');
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "##4# ### #a" + "'", str16.equals("##4# ### #a"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test144");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie", (int) '#');
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray4);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.stripAll(strArray4);
        java.lang.String[] strArray12 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("Oracle Corporation", "raphicsEnvironment", (int) (short) 0);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("aa", strArray4, strArray12);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str5.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "aa" + "'", str13.equals("aa"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test145");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.7", 100, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test146");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("", "32.0#100.0#0.0#-1.0#0.0#35.0", 41);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test147");
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "aa                          4a#a4dk1.#aaa", charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test148");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "mv RO AVAJ", (java.lang.CharSequence) "0a100a-");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test149");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 1, (byte) 100, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/co");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: /library/java/javavirtualmachines/jdk1.7.0_80.jdk/co");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test150");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens(".0435.04-1.0435.0452", 'a');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test151");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "en", (java.lang.CharSequence) "DK1.7.0_80");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test152");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("1#10#1#10");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1#10#1#10" + "'", str1.equals("1#10#1#10"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test153");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) 10, (byte) 100, (byte) -1);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test154");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test155");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("                                 Java HotSpot(TM) 64-Bit Server VM                                  ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Java HotSpot(TM) 64-Bit Server VM" + "'", str1.equals("Java HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test156");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("#############################...esU", 23, '4');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#############################...esU" + "'", str3.equals("#############################...esU"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test157");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2", (java.lang.CharSequence) "                                 jAVA(tm) se rUNTIME eNVIRONMENT                                 ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test158");
        char[] charArray10 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "sun.lwawt.macosx.CPrinterJob", charArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a', (int) (short) 1, 0);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "#aaa4a#a4aa", charArray10);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray10, ' ');
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(charArray10, '4', 1, (int) (short) -1);
        int int24 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ava HotSpot(TM) 64-Bit Server VM", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "# 4   #   a" + "'", str19.equals("# 4   #   a"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test159");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("51.051.051.051.051.051.05/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/51.051.051.051.051.051.051", "dk1.7.0_80");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test160");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("/librax86_6", (int) '#', 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test161");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("PHICSENVIRONMENTAR", 7, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PHICSENVIRONMENTAR" + "'", str3.equals("PHICSENVIRONMENTAR"));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test162");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "                                                                                                 hi!", 7);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test163");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.upperCase("0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test164");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("/eihpoSU/", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                       /eihpoSU/" + "'", str2.equals("                       /eihpoSU/"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test165");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToEmpty("PHICSENVIRONMENTAR");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PHICSENVIRONMENTAR" + "'", str1.equals("PHICSENVIRONMENTAR"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test166");
        int int2 = org.apache.commons.lang3.StringUtils.countMatches((java.lang.CharSequence) "#aaa4a#a4aa", (java.lang.CharSequence) "10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test167");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substring("!ih", 52, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test168");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfBlank("4444444444444444444444444444444aaaaaaaaaa44444444444444444444444444444444.0#0.0#52.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "4444444444444444444444444444444aaaaaaaaaa44444444444444444444444444444444.0#0.0#52.0" + "'", str2.equals("4444444444444444444444444444444aaaaaaaaaa44444444444444444444444444444444.0#0.0#52.0"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test169");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "dk1.7.0_8mixed modemixe", 2, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test170");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("MV ro avaj");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "mV ro avaj" + "'", str1.equals("mV ro avaj"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test171");
        long[] longArray6 = new long[] { 100, (-1L), 0L, 1, 'a', 100L };
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', (int) ' ', 0);
        long long11 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        long long14 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long15 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long16 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ', (int) (short) 100, 0);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1L) + "'", long11 == (-1L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "100a-1a0a1a97a100" + "'", str13.equals("100a-1a0a1a97a100"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 100L + "'", long14 == 100L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test172");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("ava HotSpo");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ava hotspo" + "'", str1.equals("ava hotspo"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test173");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBeforeLast("                                  10.14.3", "1 1 100 1 -1");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                  10.14.3" + "'", str2.equals("                                  10.14.3"));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test174");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 0, (-140L), (long) 34);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-140L) + "'", long3 == (-140L));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test175");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.uncapitalize("0a100a-");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "0a100a-" + "'", str1.equals("0a100a-"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test176");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) "97.0a35.0a-1.0a35.0a52.", (java.lang.CharSequence) "1.6/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + "97.0a35.0a-1.0a35.0a52." + "'", charSequence2.equals("97.0a35.0a-1.0a35.0a52."));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test177");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("dk1.7.0_80");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"dk1.7.0_80\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test178");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("1a1a10a0a-1", "/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1a1a10a0a-1" + "'", str2.equals("1a1a10a0a-1"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test179");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("aa                          4a#a4dk1.#aaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AA                          4A#A4DK1.#AAA" + "'", str1.equals("AA                          4A#A4DK1.#AAA"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test180");
        java.lang.CharSequence charSequence1 = null;
        char[] charArray10 = new char[] { '#', '4', ' ', '4', ' ' };
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " ", charArray10);
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray10);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "                                                51.0                                                ", charArray10);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsAny(charSequence1, charArray10);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(charArray10, 'a');
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "!ih                                                                                                 ", charArray10);
        org.junit.Assert.assertNotNull(charArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "#a4a a4a " + "'", str16.equals("#a4a a4a "));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test181");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("1.0a0.0a52.0", "          x   4 x 4  ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test182");
        double double1 = org.apache.commons.lang3.math.NumberUtils.toDouble("-1.0 1.0 ");
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test183");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 'a', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                                                                                 " + "'", str3.equals("                                                                                                 "));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test184");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("100.0#32.0chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Libr", 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0#32.0chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Libr" + "'", str2.equals("100.0#32.0chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Libr"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test185");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray1, ' ', (int) (short) 100, (int) (short) 1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test186");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (long) 27);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 27L + "'", long2 == 27L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test187");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("1.1", "xaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aaJava Virtual Machine Specificationxaaa4axa4aa", "");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.1" + "'", str3.equals("1.1"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test188");
        float[] floatArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(floatArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test189");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test190");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.Class<?> wildcardClass5 = shortArray3.getClass();
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short8 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short9 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        short short12 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) (byte) 10, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1#0#1" + "'", str7.equals("-1#0#1"));
        org.junit.Assert.assertTrue("'" + short8 + "' != '" + (short) 1 + "'", short8 == (short) 1);
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) -1 + "'", short9 == (short) -1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1a0a1" + "'", str11.equals("-1a0a1"));
        org.junit.Assert.assertTrue("'" + short12 + "' != '" + (short) 1 + "'", short12 == (short) 1);
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 1 + "'", short13 == (short) 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test191");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("#a4a a4a                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ", 35);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           " + "'", str2.equals("                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           "));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test192");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test193");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("...435....", (int) '#', ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "            ...435....             " + "'", str3.equals("            ...435....             "));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test194");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#######", (java.lang.CharSequence) "/Uh/U/Uh/32.0#100.0#0.0#1.0#0.0#35.0/Uh/U/Uh/", 9);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test195");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("dk1.#aaa4a#a4aa                          ", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "dk1.#aaa4a#a4aa                          " + "'", str2.equals("dk1.#aaa4a#a4aa                          "));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test196");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("97.0435.04-1.0435.0452.0", "brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", 100);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test197");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "AA                          4A#A4DK1.#AAA", 8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test198");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.upperCase("                                     -1#0#1                                               ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "                                     -1#0#1                                               " + "'", str1.equals("                                     -1#0#1                                               "));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test199");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("1.6", "                                                51.0                                                ", 0);
        java.lang.String[] strArray5 = org.apache.commons.lang3.StringUtils.stripAll(strArray3, "hi!sophie");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray5, "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/co");
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray7, 'a', (int) (short) -1, 1678);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test200");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(33, 0, 11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 33 + "'", int3 == 33);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test201");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("aaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaa");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"aaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaa\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test202");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("97.0435.04-1.0435.0452");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97.0435.04-1.0435.0452" + "'", str1.equals("97.0435.04-1.0435.0452"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test203");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("", "#444 4#4 4a");
        boolean boolean4 = org.apache.commons.lang3.StringUtils.endsWithAny((java.lang.CharSequence) "                                .0_80-b1", (java.lang.CharSequence[]) strArray3);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, "110110", (-14041), 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -14041");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test204");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("                                 Java(TM) SE Runtime Environment                                 ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test205");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) " o ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test206");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", (java.lang.CharSequence) "#aaa4a#a4aa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test207");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 0, 0);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        short short13 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-14041" + "'", str12.equals("-14041"));
        org.junit.Assert.assertTrue("'" + short13 + "' != '" + (short) 1 + "'", short13 == (short) 1);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-1a0a1" + "'", str15.equals("-1a0a1"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test208");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("sophie                                                                                              ", "52.0#32.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test209");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence) "                                  10.14.3", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS                                             Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test210");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "4444444444444444444444444444444aaaaaaaaaa44444444444444444444444444444444", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test211");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        org.apache.commons.lang3.JavaVersion javaVersion1 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion2 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean3 = javaVersion1.atLeast(javaVersion2);
        boolean boolean4 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion1);
        boolean boolean5 = javaVersion0.atLeast(javaVersion1);
        org.apache.commons.lang3.JavaVersion javaVersion6 = org.apache.commons.lang3.JavaVersion.JAVA_1_7;
        boolean boolean7 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion6);
        boolean boolean8 = javaVersion1.atLeast(javaVersion6);
        org.apache.commons.lang3.JavaVersion javaVersion9 = org.apache.commons.lang3.JavaVersion.JAVA_1_2;
        org.apache.commons.lang3.JavaVersion javaVersion10 = org.apache.commons.lang3.JavaVersion.JAVA_1_6;
        org.apache.commons.lang3.JavaVersion javaVersion11 = org.apache.commons.lang3.JavaVersion.JAVA_1_8;
        boolean boolean12 = javaVersion10.atLeast(javaVersion11);
        boolean boolean13 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
        boolean boolean14 = javaVersion9.atLeast(javaVersion10);
        boolean boolean15 = org.apache.commons.lang3.SystemUtils.isJavaVersionAtLeast(javaVersion10);
        java.lang.String str16 = javaVersion10.toString();
        boolean boolean17 = javaVersion1.atLeast(javaVersion10);
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + javaVersion1 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion1.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion2 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion2.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + javaVersion6 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_7 + "'", javaVersion6.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_7));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + javaVersion9 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_2 + "'", javaVersion9.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_2));
        org.junit.Assert.assertTrue("'" + javaVersion10 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_6 + "'", javaVersion10.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_6));
        org.junit.Assert.assertTrue("'" + javaVersion11 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_8 + "'", javaVersion11.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_8));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1.6" + "'", str16.equals("1.6"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test212");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("sun.lwawt.macosx.CPrinterJob", (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test213");
        try {
            java.lang.Number number1 = org.apache.commons.lang3.math.NumberUtils.createNumber("# 4   #   a");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: # 4   #   a is not a valid number.");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test214");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("                                ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test215");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie", (int) '#');
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", strArray4, strArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "", (int) 'a', 97);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray8, "/library/java/javavirtualmachines/jdk1.7.0_80.jdk/co");
        java.lang.String[] strArray18 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "Java(TM) SE Runtime Environment");
        boolean boolean19 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "  ", (java.lang.CharSequence[]) strArray8);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str9.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str10.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str16.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertNotNull(strArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test216");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, 'a');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test217");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("us                                                                ", (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test218");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "32.04100.040.04-1.040.0435.0444444444444444444", "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test219");
        java.lang.CharSequence charSequence2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty((java.lang.CharSequence) " eihpos!ih", (java.lang.CharSequence) "#/SOPHIE");
        org.junit.Assert.assertTrue("'" + charSequence2 + "' != '" + " eihpos!ih" + "'", charSequence2.equals(" eihpos!ih"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test220");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", (byte) 100);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 100 + "'", byte2 == (byte) 100);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test221");
        int int3 = org.apache.commons.lang3.StringUtils.ordinalIndexOf((java.lang.CharSequence) "10 -1 10 32 -1 1", (java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test222");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("                                 Java(TM) SE Runtime Environment                                 ", '#');
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, '#');
        int int5 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "                                 Java(TM) SE Runtime Environment                                 " + "'", str4.equals("                                 Java(TM) SE Runtime Environment                                 "));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test223");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("                                .0_80-b1", (int) (short) 100);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test224");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.mid("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS", 20, 32);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RTUALMACHINES/JDK1.7.0_80.JDK/CO" + "'", str3.equals("RTUALMACHINES/JDK1.7.0_80.JDK/CO"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test225");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.startsWith((java.lang.CharSequence) "eihpoS", (java.lang.CharSequence) " -1 1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test226");
        java.lang.Object[] objArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(objArray0, '#', (-14041), 6);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test227");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment-14041Java(TM) SE Runtime Environment", '4');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test228");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("110110", "32.0#100.0#0.0#-1.0#0.0#35.0", 8);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "11011032.0#100.0#0.0#-1.0#0.0#35.011011032.0#100.0#0.0#-1.0#0.0#35.011011032.0#100.0#0.0#-1.0#0.0#35.011011032.0#100.0#0.0#-1.0#0.0#35.011011032.0#100.0#0.0#-1.0#0.0#35.011011032.0#100.0#0.0#-1.0#0.0#35.011011032.0#100.0#0.0#-1.0#0.0#35.0110110" + "'", str3.equals("11011032.0#100.0#0.0#-1.0#0.0#35.011011032.0#100.0#0.0#-1.0#0.0#35.011011032.0#100.0#0.0#-1.0#0.0#35.011011032.0#100.0#0.0#-1.0#0.0#35.011011032.0#100.0#0.0#-1.0#0.0#35.011011032.0#100.0#0.0#-1.0#0.0#35.011011032.0#100.0#0.0#-1.0#0.0#35.0110110"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test229");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumericSpace((java.lang.CharSequence) "##4# ### #a");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test230");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', 0, 0);
        short short10 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray3, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) '4', (int) (byte) 0);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + short10 + "' != '" + (short) -1 + "'", short10 == (short) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-1a0a1" + "'", str12.equals("-1a0a1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test231");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("/Users/sophie/Documents/defects4j/tmp/run_randoop...");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test232");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "0.0#-1.0#0.0#", "1.0a0.0a52.0");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test233");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "#############################...esU");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test234");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("#aaa4a#a4aa                                         ", "#6");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#aaa4a#a4aa                                         " + "'", str2.equals("#aaa4a#a4aa                                         "));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test235");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "                                h !", (java.lang.CharSequence) "hi!sophi");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test236");
        char[] charArray8 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean9 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray8);
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "1.0#0.0#52.0", charArray8);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', (int) 'a', (int) (short) 1);
        try {
            java.lang.String str18 = org.apache.commons.lang3.StringUtils.join(charArray8, 'a', (int) (byte) 1, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test237");
        byte byte1 = org.apache.commons.lang3.math.NumberUtils.toByte("1.0#0.0#52.0");
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test238");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "97.0a35.0a-1.0a35.0a52.0", (java.lang.CharSequence) "/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test239");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        java.lang.Class<?> wildcardClass2 = strArray1.getClass();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test240");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('a', 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaa" + "'", str2.equals("aaaa"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test241");
        float float2 = org.apache.commons.lang3.math.NumberUtils.toFloat("#/sophie#/sophie#/sophie#/sophie#/sophie#/sox   4 x 4  #/sophie#/sophie#/sophie#/sophie#/sophie#/sop", 32.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test242");
        float[] floatArray3 = new float[] { 1, 0.0f, '4' };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float5 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', (int) '#', (int) (byte) 10);
        float float10 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float11 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        float float12 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        float float13 = org.apache.commons.lang3.math.NumberUtils.min(floatArray3);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 52.0f + "'", float4 == 52.0f);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 52.0f + "'", float5 == 52.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 52.0f + "'", float10 == 52.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 52.0f + "'", float12 == 52.0f);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test243");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "raphicsEnvironment", (java.lang.CharSequence) "141041410                                                                                           ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test244");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("", "100a-1a0a1a97a100", "44");
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray3, '#');
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test245");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "So");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test246");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "a aa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test247");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("              Sophie               ", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test248");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("ava HotSpot(TM) 64-Bit Server VM", 34);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  ava HotSpot(TM) 64-Bit Server VM" + "'", str2.equals("  ava HotSpot(TM) 64-Bit Server VM"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test249");
        long long2 = org.apache.commons.lang3.math.NumberUtils.toLong("Mac OS X", 90L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 90L + "'", long2 == 90L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test250");
        int[] intArray3 = new int[] { (byte) 0, 100, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, '4', 66, 11);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test251");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "##4# ### #a##4# ### #a##4# ### #a##4# ### #a##4# ### #a##4# ### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test252");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trimToNull("1.2");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.2" + "'", str1.equals("1.2"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test253");
        char[] charArray14 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray14);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray14);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100.0 32.0", charArray14);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(charArray14, 'a', (int) (byte) 0, (int) (short) 1);
        boolean boolean22 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaa", charArray14);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "01.7.0_80-b15", charArray14);
        boolean boolean24 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!sophi", charArray14);
        java.lang.String str26 = org.apache.commons.lang3.StringUtils.join(charArray14, ' ');
        int int27 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", charArray14);
        boolean boolean28 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "-140", charArray14);
        org.junit.Assert.assertNotNull(charArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "#" + "'", str21.equals("#"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "# 4   #   a" + "'", str26.equals("# 4   #   a"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test254");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterType("...");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test255");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("1.0#0.0#52.0", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.0#0.0#52.0" + "'", str2.equals("1.0#0.0#52.0"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test256");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad(" -1 1", (int) (byte) -1, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " -1 1" + "'", str3.equals(" -1 1"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test257");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.abbreviate("�", 41);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "�" + "'", str2.equals("�"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test258");
        float[] floatArray5 = new float[] { 'a', '#', (-1), '#', '4' };
        float float6 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray5);
        float float8 = org.apache.commons.lang3.math.NumberUtils.min(floatArray5);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(floatArray5, 'a');
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 97.0f + "'", float6 == 97.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 97.0f + "'", float7 == 97.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + (-1.0f) + "'", float8 == (-1.0f));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "97.0a35.0a-1.0a35.0a52.0" + "'", str10.equals("97.0a35.0a-1.0a35.0a52.0"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test259");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "  ava HotSpot(TM) 64-Bit Server VM", (java.lang.CharSequence) "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test260");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("                                      100.0 32.0                                       ", (int) '#', "a4 4#4 444#");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "                                      100.0 32.0                                       " + "'", str3.equals("                                      100.0 32.0                                       "));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test261");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlpha((java.lang.CharSequence) "Java Platform API Specification");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test262");
        float float3 = org.apache.commons.lang3.math.NumberUtils.min((float) 2L, 10.0f, (float) 66L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test263");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("          x   4 x 4  ");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"x   4 x 4\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test264");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        try {
            java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#', (int) 'a', 1678);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) 1 + "'", short5 == (short) 1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test265");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) (byte) 10, (long) '4', (long) 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test266");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEndIgnoreCase("1.6", "HI!SOPHIE");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.6" + "'", str2.equals("1.6"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test267");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isNumber("1.0");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test268");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removePattern("u", "oc/kdj.08_0.7.1kdj/senihcamlautrivavaj/avaj/yrarbil/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "u" + "'", str2.equals("u"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test269");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("/USophie/U", "h !", "So");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test270");
        char[] charArray12 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray12);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray12);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100.0 32.0", charArray12);
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(charArray12, 'a', (int) (byte) 0, (int) (short) 1);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaa", charArray12);
        int int21 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "0#100#-1", charArray12);
        java.lang.String str23 = org.apache.commons.lang3.StringUtils.join(charArray12, '#');
        int int24 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "######HTTP://JAVA.ORACLE.COM/######", charArray12);
        try {
            java.lang.String str28 = org.apache.commons.lang3.StringUtils.join(charArray12, '#', (int) (short) 0, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "#" + "'", str19.equals("#"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "##4# ### #a" + "'", str23.equals("##4# ### #a"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test271");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat('#', 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "###########################" + "'", str2.equals("###########################"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test272");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "1", (java.lang.CharSequence) "RS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", 52);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test273");
        java.lang.Object[] objArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(objArray0, "1a10a1a1044444444444444444444444444");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test274");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", 97.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test275");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByWholeSeparator("                                          1.7.0_80-b15                                           ", "-140");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test276");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 1, 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '4');
        double double10 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100.0432.0" + "'", str9.equals("100.0432.0"));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.0d + "'", double10 == 32.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test277");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replace("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:", "0.0#41.0#32.0#0.0#1.6#3.0", "10 1 -1 -1");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:" + "'", str3.equals("444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444:"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test278");
        org.apache.commons.lang3.JavaVersion javaVersion0 = org.apache.commons.lang3.JavaVersion.JAVA_1_1;
        java.lang.String str1 = javaVersion0.toString();
        org.apache.commons.lang3.JavaVersion javaVersion2 = null;
        try {
            boolean boolean3 = javaVersion0.atLeast(javaVersion2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + javaVersion0 + "' != '" + org.apache.commons.lang3.JavaVersion.JAVA_1_1 + "'", javaVersion0.equals(org.apache.commons.lang3.JavaVersion.JAVA_1_1));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.1" + "'", str1.equals("1.1"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test279");
        float[] floatArray6 = new float[] { ' ', (short) 100, 0L, (-1L), 0, '#' };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        java.lang.Class<?> wildcardClass12 = floatArray6.getClass();
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "32.0a100.0a0.0a-1.0a0.0a35.0" + "'", str9.equals("32.0a100.0a0.0a-1.0a0.0a35.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "32.04100.040.04-1.040.0435.0" + "'", str11.equals("32.04100.040.04-1.040.0435.0"));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "32.0a100.0a0.0a-1.0a0.0a35.0" + "'", str14.equals("32.0a100.0a0.0a-1.0a0.0a35.0"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test280");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("en", 0, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "en" + "'", str3.equals("en"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test281");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("xaaa4axa4aa");
        java.lang.Class<?> wildcardClass3 = strArray2.getClass();
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "                                               -1#0#1                                               ", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test282");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("�", "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDKs.7./_8/.JDK/COUS", "Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test283");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("4444444444444444444444444444444444444444444444-1441", "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", "52.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.0", (-1));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4444444444444444444444444444444444444444444444-1441" + "'", str4.equals("4444444444444444444444444444444444444444444444-1441"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test284");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("So", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SoSo" + "'", str2.equals("SoSo"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test285");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat("/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/", "51.0", (int) (short) 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/" + "'", str3.equals("/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test286");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "Java(TM...", charSequence1, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test287");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 0, 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0#32.0" + "'", str10.equals("100.0#32.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100.0a32.0" + "'", str12.equals("100.0a32.0"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100.0a32.0" + "'", str14.equals("100.0a32.0"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test288");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        short short5 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ');
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + short5 + "' != '" + (short) -1 + "'", short5 == (short) -1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "-1 0 1" + "'", str7.equals("-1 0 1"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test289");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("##4# ### #a", "#", 97);
        int int4 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test290");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("A AA", (int) (short) -1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "A" + "'", str2.equals("A"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test291");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int[] intArray2 = new int[] {};
        int[][] intArray3 = new int[][] { intArray0, intArray1, intArray2 };
        int[] intArray4 = new int[] {};
        int[] intArray5 = new int[] {};
        int[] intArray6 = new int[] {};
        int[][] intArray7 = new int[][] { intArray4, intArray5, intArray6 };
        int[] intArray8 = new int[] {};
        int[] intArray9 = new int[] {};
        int[] intArray10 = new int[] {};
        int[][] intArray11 = new int[][] { intArray8, intArray9, intArray10 };
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int[] intArray14 = new int[] {};
        int[][] intArray15 = new int[][] { intArray12, intArray13, intArray14 };
        int[][][] intArray16 = new int[][][] { intArray3, intArray7, intArray11, intArray15 };
        java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray16);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test292");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chomp("32.04100.040.04-1.040.0435.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "32.04100.040.04-1.040.0435.0" + "'", str1.equals("32.04100.040.04-1.040.0435.0"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test293");
        short short1 = org.apache.commons.lang3.math.NumberUtils.toShort("141041410                                                                                           ");
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test294");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("4444444444444444444444444444444444444444444444444444", "", 1);
        int int5 = org.apache.commons.lang3.StringUtils.lastIndexOfAny((java.lang.CharSequence) "4444444...", (java.lang.CharSequence[]) strArray4);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray4, "32.04100.040.04-1.040.0435.0444444444444444444");
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(strArray7);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test295");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 87);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                            " + "'", str2.equals("                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                            "));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test296");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isNotBlank((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test297");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 4, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test298");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', (int) (short) 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 52, 33);
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test299");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#', 1, 0);
        short short9 = org.apache.commons.lang3.math.NumberUtils.max(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + short9 + "' != '" + (short) 1 + "'", short9 == (short) 1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test300");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test301");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "                                 Java(TM) SE Runtime Environment                                 ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test302");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "wawt.macosx.CPrinterJob", (java.lang.CharSequence) "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test303");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphaSpace((java.lang.CharSequence) "1.2");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test304");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllUpperCase((java.lang.CharSequence) "/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test305");
        int[] intArray3 = new int[] { (byte) 0, 100, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', 66, (int) (byte) 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test306");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 0, 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(doubleArray2, '#');
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ', (int) (byte) 1, (-14041));
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 10, 66);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100.0#32.0" + "'", str10.equals("100.0#32.0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "100.0a32.0" + "'", str12.equals("100.0a32.0"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test307");
        short[] shortArray0 = null;
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.join(shortArray0, ' ');
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test308");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("hi!sophie");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!sophie" + "'", str1.equals("hi!sophie"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test309");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWith((java.lang.CharSequence) "eihpoS", (java.lang.CharSequence) "class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test310");
        double double3 = org.apache.commons.lang3.math.NumberUtils.max((double) 1.0f, (double) 20, (double) 35L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test311");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("aaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaa", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaa" + "'", str2.equals("aaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaaaaaaaaaaaa/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o aaaaaaaaaa"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test312");
        long[] longArray6 = new long[] { 10L, (byte) -1, (short) 10, ' ', (short) -1, (byte) 1 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', (int) '#', 0);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long13 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a', (int) 'a', 0);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.join(longArray6, 'a');
        try {
            java.lang.String str25 = org.apache.commons.lang3.StringUtils.join(longArray6, ' ', (int) (short) 10, 1678);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10a-1a10a32a-1a1" + "'", str15.equals("10a-1a10a32a-1a1"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10a-1a10a32a-1a1" + "'", str21.equals("10a-1a10a32a-1a1"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test313");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAllLowerCase((java.lang.CharSequence) "/library/java/javavirtualmachines/jdkaaaaaaaaaa.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test314");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("RS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:.", "/eihpoSU/");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:." + "'", str2.equals("RS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/SYSTEM/LIBRARY/JAVA/EXTENSIONS:/USR/LIB/JAVA:."));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test315");
        java.lang.CharSequence charSequence2 = null;
        char[] charArray11 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray11);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray11);
        int int14 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence2, charArray11);
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "x   4 x 4  ", charArray11);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "1#10#1#10", charArray11);
        try {
            java.lang.String str20 = org.apache.commons.lang3.StringUtils.join(charArray11, '4', (int) '#', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(charArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test316");
        int[] intArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(intArray0, ' ', 52, 4);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test317");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "0#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#10", 87, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test318");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToNull("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation" + "'", str1.equals("Oracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle CorporationOracle Corporation"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test319");
        java.lang.CharSequence charSequence0 = null;
        char[] charArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly(charSequence0, charArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test320");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("1.7.0_80-b15", ".0_80.jdk/Contents/Home/jre/lib/endorsedachines/jdkalMaVirtuava/Javary/Ja/Libr");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1.7.0_80-b15" + "'", str2.equals("1.7.0_80-b15"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test321");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("                                      100.0 32.0                                       ", "52.0a97.0");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test322");
        byte[] byteArray1 = new byte[] { (byte) -1 };
        java.lang.String str5 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ', (int) '4', (int) (short) 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(byteArray1, '4', (int) (short) 0, 0);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.toString(byteArray1, "class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: class java.io.Fileclass [Sclass [Ljava.lang.String;class java.io.File");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) -1 + "'", byte11 == (byte) -1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test323");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.split("              Sophie               ");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.stripAll(strArray1);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test324");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max(10L, 6L, (long) '#');
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test325");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "01.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b1501.7.0_80-b15", (java.lang.CharSequence) "ava HotSpot(TM) 64-Bit Server VM");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test326");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("dk1.#aaa4a#a4aa                          ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test327");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("MV ro avaj", 32);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                      MV ro avaj" + "'", str2.equals("                      MV ro avaj"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test328");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "                                ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                " + "'", str2.equals("                                "));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test329");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        short short7 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1#0#1" + "'", str6.equals("-1#0#1"));
        org.junit.Assert.assertTrue("'" + short7 + "' != '" + (short) -1 + "'", short7 == (short) -1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test330");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithIgnoreCase((java.lang.CharSequence) "DK1.7.0_80dk1j7j0_80", (java.lang.CharSequence) "-1a0a1sun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.macosx.LWCToolkitsun.lwawt.mac");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test331");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("#a4a a4a                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ", ".io.Filecl");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#a4a a4a                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      " + "'", str2.equals("#a4a a4a                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      "));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test332");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/eihpoSU/");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test333");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("#444 444 ", (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test334");
        try {
            java.lang.Long long1 = org.apache.commons.lang3.math.NumberUtils.createLong("####################################################");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###################################################\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test335");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("44444444444444444444444444444444444444444444444444444444444444444dk1.7.0_80.jdk/Contents/Home/jre", '#');
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test336");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "1a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a101a10a1a10", (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test337");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("XSOcaM", "Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment", "Ava HotSpo", 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "XSOcaM" + "'", str4.equals("XSOcaM"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test338");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) (short) 100, 41L, (long) 35);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 35L + "'", long3 == 35L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test339");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("               eihpoS              ", "/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/", 33);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test340");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("97.0 35.0 -1.0", ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97.035.0-1.0" + "'", str2.equals("97.035.0-1.0"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test341");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("RaphicsEnvironment", 0, "aaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RaphicsEnvironment" + "'", str3.equals("RaphicsEnvironment"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test342");
        char[] charArray15 = new char[] { '#', '4', ' ', '#', ' ', 'a' };
        boolean boolean16 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "hi!", charArray15);
        int int17 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "1.7.0_80", charArray15);
        boolean boolean18 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "100.0 32.0", charArray15);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.join(charArray15, 'a', (int) (byte) 0, (int) (short) 1);
        boolean boolean23 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "aaaaaaaaaa", charArray15);
        boolean boolean24 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "01.7.0_80-b15", charArray15);
        boolean boolean25 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "hi!sophi", charArray15);
        boolean boolean26 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed", charArray15);
        boolean boolean27 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "0#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#10", charArray15);
        int int28 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "http://java.oracle.com/", charArray15);
        org.junit.Assert.assertNotNull(charArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "#" + "'", str22.equals("#"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test343");
        float[] floatArray3 = new float[] { 1, 0.0f, '4' };
        float float4 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(floatArray3, '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.join(floatArray3, ' ');
        float float9 = org.apache.commons.lang3.math.NumberUtils.max(floatArray3);
        try {
            java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray3, 'a', 42, 44);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 42");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 52.0f + "'", float4 == 52.0f);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1.0#0.0#52.0" + "'", str6.equals("1.0#0.0#52.0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.0 0.0 52.0" + "'", str8.equals("1.0 0.0 52.0"));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 52.0f + "'", float9 == 52.0f);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test344");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("...");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "..." + "'", str1.equals("..."));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test345");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("4444444444444444444444444444444444444444444444-1441", 34, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4444444444444444444444444444444444444444444444-1441" + "'", str3.equals("4444444444444444444444444444444444444444444444-1441"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test346");
        char[] charArray7 = new char[] { '#', '4', ' ', '4', ' ' };
        boolean boolean8 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " ", charArray7);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(charArray7, ' ', (int) '4', (int) (byte) 1);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Jv(TM) ...", charArray7);
        org.junit.Assert.assertNotNull(charArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test347");
        char[] charArray12 = new char[] { '#', 'a', '4', '#', '4', 'a' };
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(charArray12, 'a');
        boolean boolean15 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specification", charArray12);
        int int16 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ava HotSpo", charArray12);
        boolean boolean17 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray12);
        int int18 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "141041410", charArray12);
        int int19 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "100-1", charArray12);
        boolean boolean20 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361", charArray12);
        org.junit.Assert.assertNotNull(charArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "#aaa4a#a4aa" + "'", str14.equals("#aaa4a#a4aa"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test348");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("dk1.7.0_80", "1 1 100 1 -1", 44);
        org.junit.Assert.assertNotNull(strArray3);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test349");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("01.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B15");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test350");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("sun.awt.CGraphicsEnvironment");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SUN.AWT.cgRAPHICSeNVIRONMENT" + "'", str1.equals("SUN.AWT.cgRAPHICSeNVIRONMENT"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test351");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.defaultString(" Users/sophie/Library/Java/Extensions:/Library");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + " Users/sophie/Library/Java/Extensions:/Library" + "'", str1.equals(" Users/sophie/Library/Java/Extensions:/Library"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test352");
        byte byte3 = org.apache.commons.lang3.math.NumberUtils.min((byte) -1, (byte) 0, (byte) 10);
        org.junit.Assert.assertTrue("'" + byte3 + "' != '" + (byte) -1 + "'", byte3 == (byte) -1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test353");
        try {
            java.math.BigInteger bigInteger1 = org.apache.commons.lang3.math.NumberUtils.createBigInteger("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"/Librar\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test354");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("52.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"52.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.052.0#32.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test355");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.split("", "1.7.0_80");
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "sophie", (int) '#');
        java.lang.String str8 = org.apache.commons.lang3.StringUtils.getCommonPrefix(strArray7);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", strArray3, strArray7);
        java.lang.String[] strArray10 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre" + "'", str8.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str9.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
        org.junit.Assert.assertNotNull(strArray10);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test356");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("", 6, ' ');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "      " + "'", str3.equals("      "));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test357");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "52.xa32.x");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test358");
        org.apache.commons.lang3.SystemUtils systemUtils0 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils1 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray2 = new org.apache.commons.lang3.SystemUtils[] { systemUtils0, systemUtils1 };
        org.apache.commons.lang3.SystemUtils systemUtils3 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils4 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray5 = new org.apache.commons.lang3.SystemUtils[] { systemUtils3, systemUtils4 };
        org.apache.commons.lang3.SystemUtils systemUtils6 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils7 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray8 = new org.apache.commons.lang3.SystemUtils[] { systemUtils6, systemUtils7 };
        org.apache.commons.lang3.SystemUtils systemUtils9 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils systemUtils10 = new org.apache.commons.lang3.SystemUtils();
        org.apache.commons.lang3.SystemUtils[] systemUtilsArray11 = new org.apache.commons.lang3.SystemUtils[] { systemUtils9, systemUtils10 };
        org.apache.commons.lang3.SystemUtils[][] systemUtilsArray12 = new org.apache.commons.lang3.SystemUtils[][] { systemUtilsArray2, systemUtilsArray5, systemUtilsArray8, systemUtilsArray11 };
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray12);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray12);
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(systemUtilsArray12);
        org.junit.Assert.assertNotNull(systemUtilsArray2);
        org.junit.Assert.assertNotNull(systemUtilsArray5);
        org.junit.Assert.assertNotNull(systemUtilsArray8);
        org.junit.Assert.assertNotNull(systemUtilsArray11);
        org.junit.Assert.assertNotNull(systemUtilsArray12);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test359");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(52, (int) '#', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test360");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equals((java.lang.CharSequence) "/ia-/a/ia32a-/a/", (java.lang.CharSequence) "#aaaaa4aaa#aaa4aaaa                                         ");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test361");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 1, (byte) 100, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', 4, 0);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(byteArray5, 'a', (int) (byte) 10, (int) (byte) 10);
        byte byte17 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) -1 + "'", byte8 == (byte) -1);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + byte17 + "' != '" + (byte) -1 + "'", byte17 == (byte) -1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test362");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "                 100#-1#0#1#97#100                  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test363");
        char[] charArray9 = new char[] { '#', '4', ' ', '4', ' ' };
        boolean boolean10 = org.apache.commons.lang3.StringUtils.containsAny((java.lang.CharSequence) " ", charArray9);
        boolean boolean11 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T/", charArray9);
        int int12 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) "Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment", charArray9);
        boolean boolean13 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "-14041", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test364");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.trim("##4# ### #a##4# ### #a##4# ### #a##4# ### #a##4# ### #a##4# ### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "##4# ### #a##4# ### #a##4# ### #a##4# ### #a##4# ### #a##4# ### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str1.equals("##4# ### #a##4# ### #a##4# ### #a##4# ### #a##4# ### #a##4# ### #aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test365");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.normalizeSpace("aaaaa");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "aaaaa" + "'", str1.equals("aaaaa"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test366");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("32.0#100.0#0.0#-1.0#0.0#35.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"32.0#100.0#0.0#-1.0#0.0#35.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test367");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBetween("10.14.3", "97.0a35.0a-1.0a35.0a52.");
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test368");
        int int3 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "######HTTP://JAVA.ORACLE.COM/######", (java.lang.CharSequence) "100.0#32.0", (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test369");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 0, 0);
        double double8 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double9 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a');
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        double double13 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100.0a32.0" + "'", str11.equals("100.0a32.0"));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test370");
        java.lang.CharSequence charSequence1 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "##########", charSequence1, 73);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test371");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("aaaaa", "6 ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aaaaa" + "'", str2.equals("aaaaa"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test372");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.substringBetween("", "/Users/sophie/Library/Java/Extensions:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java", "-14041");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test373");
        short[] shortArray3 = new short[] { (short) -1, (short) 0, (byte) 1 };
        short short4 = org.apache.commons.lang3.math.NumberUtils.min(shortArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(shortArray3, '#');
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4', (int) (short) 0, 2);
        java.lang.String str12 = org.apache.commons.lang3.StringUtils.join(shortArray3, '4');
        try {
            java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(shortArray3, ' ', (int) (short) 10, 87);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shortArray3);
        org.junit.Assert.assertTrue("'" + short4 + "' != '" + (short) -1 + "'", short4 == (short) -1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1#0#1" + "'", str6.equals("-1#0#1"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-140" + "'", str10.equals("-140"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "-14041" + "'", str12.equals("-14041"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test374");
        long[] longArray6 = new long[] { (short) 10, 32L, 97, (byte) 0, (-1L), (-1L) };
        long long7 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long8 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long9 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long10 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 97L + "'", long7 == 97L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 97L + "'", long9 == 97L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test375");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.right("0 100 -1", 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test376");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("Java(TM) SE Runtime EnvironmentuJava(TM) SE Runtime EnvironmentsJava(TM) SE Runtime Environment", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jv(TM) SE Runtime EnvironmentuJv(TM) SE Runtime EnvironmentsJv(TM) SE Runtime Environment" + "'", str2.equals("Jv(TM) SE Runtime EnvironmentuJv(TM) SE Runtime EnvironmentsJv(TM) SE Runtime Environment"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test377");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(52, 90, 42);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 90 + "'", int3 == 90);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test378");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("", " ...", "104-14104324-141", 20);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test379");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 1, (byte) 100, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte8 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        byte byte9 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte10 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        byte byte11 = org.apache.commons.lang3.math.NumberUtils.max(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 100 + "'", byte7 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte8 + "' != '" + (byte) 100 + "'", byte8 == (byte) 100);
        org.junit.Assert.assertTrue("'" + byte9 + "' != '" + (byte) -1 + "'", byte9 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte10 + "' != '" + (byte) -1 + "'", byte10 == (byte) -1);
        org.junit.Assert.assertTrue("'" + byte11 + "' != '" + (byte) 100 + "'", byte11 == (byte) 100);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test380");
        java.lang.CharSequence charSequence0 = null;
        java.lang.CharSequence[] charSequenceArray1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.endsWithAny(charSequence0, charSequenceArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test381");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("dk1.7.0_80.jdk/Contents/Home/jre");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DK1.7.0_80.JDK/cONTENTS/hOME/JRE" + "'", str1.equals("DK1.7.0_80.JDK/cONTENTS/hOME/JRE"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test382");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("4444444444444444444444444444444444444444444444444444", strArray4, strArray8);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.stripAll(strArray8, "dk1.7.0_80.jdk/Contents/Home/jre");
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.split("/USophie/U", ' ');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("aaaaa", strArray11, strArray14);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str9.equals("4444444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "aaaaa" + "'", str15.equals("aaaaa"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test383");
        try {
            java.lang.Integer int1 = org.apache.commons.lang3.math.NumberUtils.createInteger("444444444444444444444444444444-1441");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"444444444444444444444444444444-1441\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test384");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("ava HotSpo", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test385");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "xaaa4axa4aa              Sophie                     ", (java.lang.CharSequence) "                 /Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test386");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.containsWhitespace((java.lang.CharSequence) "Java(TM) SE Runtime");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test387");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.left("aaaa", 2);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "aa" + "'", str2.equals("aa"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test388");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "Ava HotSpo");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test389");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", 1, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str3.equals("ns:/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre/lib/ext:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test390");
        java.lang.CharSequence charSequence0 = null;
        int int3 = org.apache.commons.lang3.StringUtils.indexOf(charSequence0, (int) (byte) -1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test391");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "              4Sophie4               ", "HTTP://JAVA.ORACLE.COM/");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test392");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "/library/java/javavirtualmachines/jdkaaaaaaaaaa.0_80.jdk/contents/home/jre/lib/endorsed");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test393");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(20, 9, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test394");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAny(charSequence0, "0#100#-1");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test395");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("PHICSENVIRONMENTAR", "dk1.7.0_8mixed modemixe");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test396");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.leftPad("1#0#1-", 41, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "###################################1#0#1-" + "'", str3.equals("###################################1#0#1-"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test397");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.difference("US", "SoSo");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SoSo" + "'", str2.equals("SoSo"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test398");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.repeat("97.0435.04-1.0435.0452.0", (int) ' ');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "97.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.0" + "'", str2.equals("97.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.0"));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test399");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.center("raphicsEnvironment", 23);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "  raphicsEnvironment   " + "'", str2.equals("  raphicsEnvironment   "));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test400");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("...");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test401");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) " o ", 52, 66);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test402");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringBefore("Jv(TM) SE Runtime Environment", "1.2");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Jv(TM) SE Runtime Environment" + "'", str2.equals("Jv(TM) SE Runtime Environment"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test403");
        float[] floatArray6 = new float[] { ' ', (short) 100, 0L, (-1L), 0, '#' };
        float float7 = org.apache.commons.lang3.math.NumberUtils.max(floatArray6);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.join(floatArray6, 'a');
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(floatArray6, '4');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(floatArray6, '#');
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ');
        java.lang.String str19 = org.apache.commons.lang3.StringUtils.join(floatArray6, ' ', 5, (int) (byte) 1);
        float float20 = org.apache.commons.lang3.math.NumberUtils.min(floatArray6);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 100.0f + "'", float7 == 100.0f);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "32.0a100.0a0.0a-1.0a0.0a35.0" + "'", str9.equals("32.0a100.0a0.0a-1.0a0.0a35.0"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "32.04100.040.04-1.040.0435.0" + "'", str11.equals("32.04100.040.04-1.040.0435.0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "32.0#100.0#0.0#-1.0#0.0#35.0" + "'", str13.equals("32.0#100.0#0.0#-1.0#0.0#35.0"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "32.0 100.0 0.0 -1.0 0.0 35.0" + "'", str15.equals("32.0 100.0 0.0 -1.0 0.0 35.0"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + (-1.0f) + "'", float20 == (-1.0f));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test404");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultString("-140", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-140" + "'", str2.equals("-140"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test405");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.substringsBetween("97.0435.04-1.0435.0452.", "", "                           aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                            ");
        org.junit.Assert.assertNull(strArray3);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test406");
        int int2 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/C10a1a-1a-1", (java.lang.CharSequence) "                                aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa                                 ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test407");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("mV ro avaj");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test408");
        int int3 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "#aaa4a#a4aa", (java.lang.CharSequence) "01.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B15", 16);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test409");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isBlank((java.lang.CharSequence) "/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/51.0/USophie/U/USophie/32.0#100.0#0.0#-1.0#0.0#35.0/USophie/U/USophie/");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test410");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.lowerCase("97.0435.04-1.0435.0452.");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "97.0435.04-1.0435.0452." + "'", str1.equals("97.0435.04-1.0435.0452."));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test411");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "1.01.01.01.", (java.lang.CharSequence) " U    ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test412");
        java.lang.CharSequence charSequence1 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase((java.lang.CharSequence) "1#0#1-", charSequence1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test413");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("#aaa4a#a4aa                                         ", 0, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#aaa4a#a4aa                                         " + "'", str3.equals("#aaa4a#a4aa                                         "));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test414");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeEnd("110110", "M/######");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "110110" + "'", str2.equals("110110"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test415");
        try {
            java.lang.Double double1 = org.apache.commons.lang3.math.NumberUtils.createDouble("###################################1#0#1-");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"###################################1#0#1-\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test416");
        try {
            java.lang.Float float1 = org.apache.commons.lang3.math.NumberUtils.createFloat("100.0a32.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"100.0a32.0\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test417");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfIgnoreCase((java.lang.CharSequence) "java platform api specification97.0435.04-1.0435.0452.0java platform api specification97.0435.04-1.0435.0452.0java platform api specification97.0435.04-1.0435.0452.0java platform api specification", (java.lang.CharSequence) "/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/COUS                                             Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                                                   Java HotSpot(TM) 64-Bit Server VM                                              ");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test418");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.swapCase("DK1.7.0_80dk1j7j0_8");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "dk1.7.0_80DK1J7J0_8" + "'", str1.equals("dk1.7.0_80DK1J7J0_8"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test419");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("DK1.7.0_80", 44, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DK1.7.0_80##################################" + "'", str3.equals("DK1.7.0_80##################################"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test420");
        float float1 = org.apache.commons.lang3.math.NumberUtils.toFloat("                                ");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test421");
        long long3 = org.apache.commons.lang3.math.NumberUtils.max((long) 100, (long) 8, (long) 10);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test422");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("#4a444#444a", 7);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "#4a444#444a" + "'", str2.equals("#4a444#444a"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test423");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.center("10.14.3", 73, 'a');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" + "'", str3.equals("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa10.14.3aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test424");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.strip("100.0432.0", "");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0432.0" + "'", str2.equals("100.0432.0"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test425");
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.replace("1.1", "                                .0_80-b15", "1#10#1#10", (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1.1" + "'", str4.equals("1.1"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test426");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.split("1.710.14.3", "-140");
        org.junit.Assert.assertNotNull(strArray2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test427");
        java.lang.CharSequence charSequence0 = null;
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsIgnoreCase(charSequence0, (java.lang.CharSequence) "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  4 x 4   x");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test428");
        boolean boolean1 = org.apache.commons.lang3.math.NumberUtils.isDigits("10a1a97.0435.04-1.0435.045210a1a-");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test429");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.equalsIgnoreCase((java.lang.CharSequence) "h !", (java.lang.CharSequence) "   10 1 -1 -1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test430");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("xaaa4axa4aa              Sophie                     ", "mixed mode");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "xaaa4axa4aa              Soph" + "'", str2.equals("xaaa4axa4aa              Soph"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test431");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("                                      100.0 32.0                                       ");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test432");
        long[] longArray3 = new long[] { '4', 10L, 1 };
        long long4 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join(longArray3, '4');
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray3, '#', 0, (int) (short) -1);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "5241041" + "'", str6.equals("5241041"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test433");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 1, 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ', 8, (int) (short) -1);
        double double12 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.Class<?> wildcardClass13 = doubleArray2.getClass();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 32.0d + "'", double12 == 32.0d);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test434");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substring("", 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test435");
        java.lang.String[] strArray3 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/LIBRARY/JAVA/JAVAVIRTUALMACHINES/JDK1.7.0_80.JDK/CO");
        int int4 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "10.14.3", (java.lang.CharSequence[]) strArray3);
        boolean boolean5 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "          ", (java.lang.CharSequence[]) strArray3);
        java.lang.String[] strArray6 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        java.lang.String[] strArray7 = org.apache.commons.lang3.StringUtils.stripAll(strArray3);
        int int8 = org.apache.commons.lang3.StringUtils.indexOfDifference((java.lang.CharSequence[]) strArray7);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(strArray6);
        org.junit.Assert.assertNotNull(strArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test436");
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.toByte("dk1.#aaa4a#a4aa", (byte) 1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 1 + "'", byte2 == (byte) 1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test437");
        int int2 = org.apache.commons.lang3.StringUtils.lastIndexOf((java.lang.CharSequence) "                 100#-1#0#1#97#100                  ", (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test438");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replacePattern("##########", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000 o ", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa  4 x 4   x");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "##########" + "'", str3.equals("##########"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test439");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("dk1.#aaa4a#a4aa                          ", "-1#0#1");
        java.lang.String str6 = org.apache.commons.lang3.StringUtils.join((java.lang.Object[]) strArray2, ' ', (int) 'a', 41);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test440");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "              Sophie               ", (java.lang.CharSequence) "aajava HotSpot(TM) 64-Bit Server VMaa");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test441");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.replaceChars("AAAAAAAAAA", "4444444444444444444444444444444444444444444444-14a41", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AAAAAAAAAA" + "'", str3.equals("AAAAAAAAAA"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test442");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("1.0 0.0 52.0");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "1.0 0.0 52." + "'", str1.equals("1.0 0.0 52."));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test443");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfter("                                                51.0                                                ", "eihpos!i");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test444");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) ".0435.04-1.0435.0452", "h !#################################################################################################");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test445");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviateMiddle("141041410                                                                                           ", "/uSERS/SOPHIE/lIBRARY/jAVA/eXTENSIONS:/lIBRARY/jAVA/eXTENSIONS:/nETWORK/lIBRARY/jAVA/eXTENSIONS:/sYSTEM/lIBRARY/jAVA/eXTENSIONS:/USR/LIB/JAVA:.", 42);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "141041410                                                                                           " + "'", str3.equals("141041410                                                                                           "));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test446");
        int int2 = org.apache.commons.lang3.StringUtils.indexOfAnyBut((java.lang.CharSequence) " 6  6 ", (java.lang.CharSequence) "java(TM...97.0 35.0 -1.0 35.0 52.0");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test447");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.substringAfterLast("97.0a35.0a-1.0a35.0a52.", "4 HotSpot(TM) 64-Bit Server VM                             ");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test448");
        double[] doubleArray2 = new double[] { 100.0f, ' ' };
        double double3 = org.apache.commons.lang3.math.NumberUtils.min(doubleArray2);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) (byte) 1, 0);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(doubleArray2, ' ', 8, (int) (short) -1);
        double double12 = org.apache.commons.lang3.math.NumberUtils.max(doubleArray2);
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(doubleArray2, 'a', (int) '4', 16);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test449");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.reverse("10.14.3");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "3.41.01" + "'", str1.equals("3.41.01"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test450");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.stripToEmpty("4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str1.equals("4444444444444444444444444444444444444444444444444444"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test451");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("", "sun.lwawt.macosx.CPrinterJob");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test452");
        char[] charArray9 = new char[] { '#', 'a', '4', '#', '4', 'a' };
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(charArray9, 'a');
        boolean boolean12 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "Java Virtual Machine Specification", charArray9);
        int int13 = org.apache.commons.lang3.StringUtils.indexOfAny((java.lang.CharSequence) "ava HotSpo", charArray9);
        boolean boolean14 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) " Users/sophie/Library/Java/Extensions:/Library", charArray9);
        org.junit.Assert.assertNotNull(charArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "#aaa4a#a4aa" + "'", str11.equals("#aaa4a#a4aa"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test453");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsOnly((java.lang.CharSequence) "0#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#100#-10#10", "1.1");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test454");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.defaultIfEmpty("1#0#1-", "4444444444444444444444444444444444444444444444444444");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#0#1-" + "'", str2.equals("1#0#1-"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test455");
        java.lang.String[] strArray1 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("US");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("Java Platform API Specification", "", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("ava HotSpot(TM) 64-Bit Server VM", strArray4, strArray8);
        java.lang.String str10 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("#6", strArray1, strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ava HotSpot(TM) 64-Bit Server VM" + "'", str9.equals("ava HotSpot(TM) 64-Bit Server VM"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "#6" + "'", str10.equals("#6"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test456");
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Contents/Home/jre", "", (int) (short) -1);
        java.lang.String[] strArray11 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/", 0);
        java.lang.String[] strArray14 = org.apache.commons.lang3.StringUtils.splitByWholeSeparatorPreserveAllTokens("hi!", "10.14.3");
        java.lang.String str15 = org.apache.commons.lang3.StringUtils.replaceEach("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co", strArray11, strArray14);
        boolean boolean16 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "erj/emoH/stnetnoC/kdj.08_0.7.1kdj/senihcaMlautriVavaJ/avaJ/yrarbiL/", (java.lang.CharSequence[]) strArray11);
        java.lang.String[] strArray20 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("US", ":", 0);
        java.lang.String str21 = org.apache.commons.lang3.StringUtils.replaceEach("Java(TM) SE Runtime Environment", strArray11, strArray20);
        java.lang.String str22 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("#444 444 ", strArray4, strArray11);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co" + "'", str15.equals("/Library/Java/JavaVirtualMachines/jdk1.7.0_80.jdk/Co"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(strArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Java(TM) SE Runtime Environment" + "'", str21.equals("Java(TM) SE Runtime Environment"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "#444 444 " + "'", str22.equals("#444 444 "));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test457");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("100-1", 'a');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100-1" + "'", str2.equals("100-1"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test458");
        int[] intArray3 = new int[] { (byte) 0, 100, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a100a-1" + "'", str7.equals("0a100a-1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "041004-1" + "'", str14.equals("041004-1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0#100#-1" + "'", str16.equals("0#100#-1"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test459");
        int[] intArray3 = new int[] { (byte) 0, 100, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        java.lang.String str13 = org.apache.commons.lang3.StringUtils.join(intArray3, '#');
        try {
            java.lang.String str17 = org.apache.commons.lang3.StringUtils.join(intArray3, '#', (-14041), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -14041");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a100a-1" + "'", str7.equals("0a100a-1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0#100#-1" + "'", str11.equals("0#100#-1"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0#100#-1" + "'", str13.equals("0#100#-1"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test460");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.contains((java.lang.CharSequence) "a4 4#4 444#", 73);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test461");
        boolean boolean2 = org.apache.commons.lang3.StringUtils.containsNone((java.lang.CharSequence) "4444444444444444444444444444444444444444444444444444", "hi!soph");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test462");
        int[] intArray3 = new int[] { (byte) 0, 100, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str7 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        int int8 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        int int9 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int10 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int11 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int12 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(intArray3, '4');
        java.lang.String str16 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a');
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0a100a-1" + "'", str7.equals("0a100a-1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "041004-1" + "'", str14.equals("041004-1"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0a100a-1" + "'", str16.equals("0a100a-1"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test463");
        java.lang.String[] strArray2 = org.apache.commons.lang3.StringUtils.splitByCharacterType("");
        boolean boolean3 = org.apache.commons.lang3.StringUtils.startsWithAny((java.lang.CharSequence) "#/sophie#/sophie#/sophie#/sophie#/sophie#/sox   4 x 4  #/sophie#/sophie#/sophie#/sophie#/sophie#/sop", (java.lang.CharSequence[]) strArray2);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test464");
        int int1 = org.apache.commons.lang3.math.NumberUtils.toInt("UTF-8");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test465");
        int int3 = org.apache.commons.lang3.math.NumberUtils.min(23, 11, 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test466");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("                       /eihpoSU/");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test467");
        int[] intArray3 = new int[] { (byte) 0, 100, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, ' ', 13, (int) (byte) -1);
        int int12 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test468");
        short short3 = org.apache.commons.lang3.math.NumberUtils.min((short) 0, (short) (byte) 10, (short) 100);
        org.junit.Assert.assertTrue("'" + short3 + "' != '" + (short) 0 + "'", short3 == (short) 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test469");
        byte[] byteArray1 = new byte[] { (byte) 10 };
        byte byte2 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(byteArray1, ' ');
        byte byte5 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        byte byte7 = org.apache.commons.lang3.math.NumberUtils.max(byteArray1);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(byteArray1, 'a', 0, (int) (byte) 0);
        byte byte12 = org.apache.commons.lang3.math.NumberUtils.min(byteArray1);
        java.lang.String str14 = org.apache.commons.lang3.StringUtils.join(byteArray1, '#');
        org.junit.Assert.assertNotNull(byteArray1);
        org.junit.Assert.assertTrue("'" + byte2 + "' != '" + (byte) 10 + "'", byte2 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + byte5 + "' != '" + (byte) 10 + "'", byte5 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) 10 + "'", byte6 == (byte) 10);
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 10 + "'", byte7 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + byte12 + "' != '" + (byte) 10 + "'", byte12 == (byte) 10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "10" + "'", str14.equals("10"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test470");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.rightPad("1#0#1-", 27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1#0#1-                     " + "'", str2.equals("1#0#1-                     "));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test471");
        java.lang.String[] strArray1 = org.apache.commons.lang3.StringUtils.splitByCharacterTypeCamelCase("sophiesophiesophius                                                                sophiesophiesophi");
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test472");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.rightPad("Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification-Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification", (int) (short) 0, '#');
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification-Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification" + "'", str3.equals("Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification-Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification1Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification97.0435.04-1.0435.0452.0Java Platform API Specification"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test473");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 1, (byte) 100, (byte) 1, (byte) -1 };
        byte byte6 = org.apache.commons.lang3.math.NumberUtils.min(byteArray5);
        try {
            java.lang.String str8 = org.apache.commons.lang3.StringUtils.toString(byteArray5, "1#10#1#10");
            org.junit.Assert.fail("Expected exception of type java.io.UnsupportedEncodingException; message: 1#10#1#10");
        } catch (java.io.UnsupportedEncodingException e) {
        }
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + byte6 + "' != '" + (byte) -1 + "'", byte6 == (byte) -1);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test474");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.apache.commons.lang3.StringUtils.lowerCase("52.0a97.0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test475");
        long[] longArray6 = new long[] { 10L, (byte) -1, (short) 10, ' ', (short) -1, (byte) 1 };
        long long7 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(longArray6, '4', (int) '#', 0);
        long long12 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        long long13 = org.apache.commons.lang3.math.NumberUtils.max(longArray6);
        long long14 = org.apache.commons.lang3.math.NumberUtils.min(longArray6);
        org.junit.Assert.assertNotNull(longArray6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test476");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.reverseDelimited("44444444444444444444444444444444444444444444444444444444444444444dk1.7.0_80.jdk/Contents/Home/jre", '#');
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444444444444444444444444444444444dk1.7.0_80.jdk/Contents/Home/jre" + "'", str2.equals("44444444444444444444444444444444444444444444444444444444444444444dk1.7.0_80.jdk/Contents/Home/jre"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test477");
        int int3 = org.apache.commons.lang3.StringUtils.lastOrdinalIndexOf((java.lang.CharSequence) "-140     ", (java.lang.CharSequence) "#aaa4a#a4aa                                         ", 44);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test478");
        long long3 = org.apache.commons.lang3.math.NumberUtils.min((long) 73, 32L, (long) 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test479");
        int int3 = org.apache.commons.lang3.math.NumberUtils.max(52, 35, 44);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test480");
        java.lang.CharSequence charSequence0 = null;
        int int2 = org.apache.commons.lang3.StringUtils.indexOfDifference(charSequence0, (java.lang.CharSequence) "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test481");
        int int3 = org.apache.commons.lang3.StringUtils.indexOf((java.lang.CharSequence) "4444444444444444444444444444444444444444444444-1441", 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test482");
        java.lang.CharSequence charSequence0 = null;
        java.lang.String[] strArray4 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("4444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444", "");
        java.lang.String[] strArray8 = org.apache.commons.lang3.StringUtils.splitPreserveAllTokens("", "/", 0);
        java.lang.String str9 = org.apache.commons.lang3.StringUtils.replaceEachRepeatedly("4444444444444444444444444444444444444444444444444444", strArray4, strArray8);
        int int10 = org.apache.commons.lang3.StringUtils.lastIndexOfAny(charSequence0, (java.lang.CharSequence[]) strArray4);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "4444444444444444444444444444444444444444444444444444" + "'", str9.equals("4444444444444444444444444444444444444444444444444444"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test483");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("phicsEnvironmentar");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test484");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripStart("Mac OS X", ".0#32.0chines/jdk1.7.0_80.jdk/Contents/Home/jrealMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Jachines/jdk1.7.0_80.jdk/Contents/Home/jre/LibralMaVirtuava/Javary/Ja/Lib");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + " OS X" + "'", str2.equals(" OS X"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test485");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("100.0 32.0", "01.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B1501.7.0_80-B15");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "100.0 32.0" + "'", str2.equals("100.0 32.0"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test486");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.strip("#AAA4A#A4AA                                         ");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "#AAA4A#A4AA" + "'", str1.equals("#AAA4A#A4AA"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test487");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAsciiPrintable((java.lang.CharSequence) "          x   4 x 4  ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test488");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.abbreviate("97.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.097.0435.04-1.0435.0452.0", (int) (short) 10, 11);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "...-1.04..." + "'", str3.equals("...-1.04..."));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test489");
        boolean boolean1 = org.apache.commons.lang3.StringUtils.isAlphanumeric((java.lang.CharSequence) "1#0#1-                     ");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test490");
        double double2 = org.apache.commons.lang3.math.NumberUtils.toDouble("Java Virtual Machine Specification", (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test491");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.remove("44444444444444444444444444444444444", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc000o");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "44444444444444444444444444444444444" + "'", str2.equals("44444444444444444444444444444444444"));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test492");
        int int2 = org.apache.commons.lang3.math.NumberUtils.toInt("/library/java/javavirtualmachines/jdkaaaaaaaaaa.0_80.jdk/contents/home/jre/lib/endorsed", 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test493");
        long long1 = org.apache.commons.lang3.math.NumberUtils.toLong("10A-1A10A32A-1A1");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test494");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.leftPad("-1 0 1", 73);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "                                                                   -1 0 1" + "'", str2.equals("                                                                   -1 0 1"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test495");
        java.lang.String str1 = org.apache.commons.lang3.StringUtils.chop("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:/");
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:" + "'", str1.equals("/USERS/SOPHIE/LIBRARY/JAVA/EXTENSIONS:/LIBRARY/JAVA/EXTENSIONS:/NETWORK/LIBRARY/JAVA/EXTENSIONS:"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test496");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.removeStartIgnoreCase("brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav", "1.0 0.0 52.0");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav" + "'", str2.equals("brary/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/jav"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test497");
        java.lang.String str3 = org.apache.commons.lang3.StringUtils.repeat(" OS X", "MV ro avaj", 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " OS XMV ro avaj OS XMV ro avaj OS XMV ro avaj OS XMV ro avaj OS XMV ro avaj OS XMV ro avaj OS XMV ro avaj OS XMV ro avaj OS XMV ro avaj OS X" + "'", str3.equals(" OS XMV ro avaj OS XMV ro avaj OS XMV ro avaj OS XMV ro avaj OS XMV ro avaj OS XMV ro avaj OS XMV ro avaj OS XMV ro avaj OS XMV ro avaj OS X"));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test498");
        double[] doubleArray0 = null;
        java.lang.String str4 = org.apache.commons.lang3.StringUtils.join(doubleArray0, 'a', 13, 8);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test499");
        int[] intArray3 = new int[] { (byte) 0, 100, (short) -1 };
        int int4 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int5 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int6 = org.apache.commons.lang3.math.NumberUtils.max(intArray3);
        int int7 = org.apache.commons.lang3.math.NumberUtils.min(intArray3);
        try {
            java.lang.String str11 = org.apache.commons.lang3.StringUtils.join(intArray3, 'a', (int) ' ', 44);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest8.test500");
        java.lang.String str2 = org.apache.commons.lang3.StringUtils.stripEnd("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.jar", "/var/folders/_v/6v597zmn4_v31cq2n2x1n4fc0000gn/T");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j" + "'", str2.equals("/Users/sophie/Documents/defects4j/tmp/run_randoop.pl_52056_1560279361/target/classes:/Users/sophie/Documents/defects4j/framework/lib/test_generation/generation/randoop-current.j"));
    }
}

