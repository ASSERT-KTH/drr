import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 10, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 350L + "'", long2 == 350L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            org.joda.time.Period period1 = new org.joda.time.Period((java.lang.Object) 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1L, 1L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 1, (int) (short) 0, (int) (short) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Throwable throwable0 = null;
        try {
            boolean boolean1 = org.joda.time.IllegalInstantException.isIllegalInstant(throwable0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = new org.joda.time.DurationFieldType[] {};
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.Object obj0 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) "hi!");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField4 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType2, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, dateTimeFieldType2, (int) (byte) -1, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.Period period4 = period0.withMillis((int) (byte) 100);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.Period period7 = period4.withField(durationFieldType5, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 100, (int) '4', 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        try {
            org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.lang.Object obj0 = null;
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(obj0, periodType1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis((long) (byte) 1, 0, (int) 'a', 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType7, (int) (byte) 10, (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 100, (int) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3200L + "'", long2 == 3200L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField9 = new org.joda.time.field.DividedDateTimeField(dateTimeField6, dateTimeFieldType7, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            long long7 = gregorianChronology0.set(readablePartial5, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-1L), 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getDays();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period5 = new org.joda.time.Period();
        int int6 = period5.size();
        org.joda.time.Period period7 = period5.negated();
        boolean boolean8 = gregorianChronology4.equals((java.lang.Object) period7);
        org.joda.time.DurationField durationField9 = gregorianChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.minuteOfDay();
        boolean boolean11 = period0.equals((java.lang.Object) dateTimeField10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (byte) 0, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField3 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("hi!");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.PeriodType periodType2 = period0.getPeriodType();
        int int3 = period0.getMinutes();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getDays();
        org.joda.time.Period period5 = period0.withYears(8);
        org.joda.time.format.PeriodFormatter periodFormatter6 = null;
        java.lang.String str7 = period5.toString(periodFormatter6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "P8Y" + "'", str7.equals("P8Y"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.Period period2 = new org.joda.time.Period();
        int int3 = period2.size();
        org.joda.time.PeriodType periodType4 = period2.getPeriodType();
        java.lang.String str5 = periodType4.getName();
        org.joda.time.PeriodType periodType6 = periodType4.withSecondsRemoved();
        try {
            org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) gregorianChronology0, periodType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Standard" + "'", str5.equals("Standard"));
        org.junit.Assert.assertNotNull(periodType6);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test041");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        int int5 = dateTimeZone1.getOffsetFromLocal((long) ' ');
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.PeriodType periodType5 = period3.getPeriodType();
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType5);
        org.joda.time.PeriodType periodType7 = periodType5.withYearsRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) 10L, periodType7, (org.joda.time.Chronology) iSOChronology8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(iSOChronology8);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.time();
        org.junit.Assert.assertNotNull(periodType0);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
//        long long8 = dateTimeZone3.convertLocalToUTC((long) (-1), true, (long) 8);
//        java.lang.String str10 = dateTimeZone3.getShortName(10L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePartial readablePartial1 = null;
        int[] intArray5 = new int[] { (byte) 1, (byte) -1, (short) 1 };
        try {
            gregorianChronology0.validate(readablePartial1, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(10, 8, (int) ' ', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass5 = period4.getClass();
        org.joda.time.Period period7 = period4.minusMonths((int) (short) 10);
        try {
            int int9 = period4.getValue(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        try {
            long long5 = iSOChronology0.getDateTimeMillis(8, (int) ' ', 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.plusSeconds(100);
        try {
            org.joda.time.DurationFieldType durationFieldType8 = period6.getFieldType((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("P8Y");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"P8Y/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 0L + "'", long0 == 0L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            int[] intArray6 = iSOChronology0.get(readablePartial4, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.PeriodType periodType2 = period0.getPeriodType();
        java.lang.Class<?> wildcardClass3 = periodType2.getClass();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        try {
            int int6 = period3.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.ReadablePartial readablePartial2 = null;
        org.joda.time.Period period4 = org.joda.time.Period.hours(100);
        org.joda.time.Period period5 = period4.negated();
        org.joda.time.Days days6 = period5.toStandardDays();
        int[] intArray7 = period5.getValues();
        try {
            gregorianChronology0.validate(readablePartial2, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(days6);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period3 = period1.withPeriodType(periodType2);
        org.joda.time.Period period5 = period1.minusMinutes(10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField4 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, dateTimeFieldType2, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.minusMinutes((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = period4.indexOf(durationFieldType5);
        org.joda.time.Days days7 = period4.toStandardDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(days7);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858120000000L) + "'", long1 == (-210858120000000L));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(10);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekOfWeekyear();
        org.joda.time.DurationField durationField9 = gregorianChronology7.hours();
        org.joda.time.Period period10 = new org.joda.time.Period();
        int int11 = period10.size();
        org.joda.time.Period period12 = period10.negated();
        org.joda.time.DurationFieldType durationFieldType13 = null;
        int int14 = period12.indexOf(durationFieldType13);
        org.joda.time.DurationFieldType durationFieldType16 = period12.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField17 = new org.joda.time.field.DecoratedDurationField(durationField9, durationFieldType16);
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField19 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType16, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The scalar must not be 0 or 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType16);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField3, (int) (short) 0, (int) (short) 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for clockhourOfDay must be in the range [10,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.Period period2 = new org.joda.time.Period(100L, (long) (byte) 1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.minusMinutes((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period1.toDurationTo(readableInstant5);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period();
        int int11 = period10.size();
        org.joda.time.PeriodType periodType12 = period10.getPeriodType();
        org.joda.time.Period period13 = new org.joda.time.Period(readableDuration8, readableInstant9, periodType12);
        org.joda.time.Period period14 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant7, periodType12);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, (long) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        long long4 = dateTimeZone0.convertLocalToUTC((long) '#', false, (long) 100);
        org.joda.time.Period period5 = new org.joda.time.Period();
        int int6 = period5.size();
        org.joda.time.PeriodType periodType7 = period5.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = periodType7.isSupported(durationFieldType8);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology14 = gregorianChronology10.withZone(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        int int19 = cachedDateTimeZone17.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone20 = cachedDateTimeZone17.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology10, dateTimeZone20);
        try {
            org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) dateTimeZone0, periodType7, (org.joda.time.Chronology) zonedChronology21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 35L + "'", long4 == 35L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology21);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1L, 35L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period3 = period1.withPeriodType(periodType2);
        try {
            org.joda.time.Period period5 = period3.withMillis(10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-210858120000000L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        illegalFieldValueException4.prependMessage("Coordinated Universal Time");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0" + "'", str7.equals("10.0"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("Standard");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'Standard' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period3 = period1.withPeriodType(periodType2);
        org.joda.time.Weeks weeks4 = period1.toStandardWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(weeks4);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.Period period4 = new org.joda.time.Period();
        int int5 = period4.size();
        org.joda.time.Period period6 = period4.negated();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period6.indexOf(durationFieldType7);
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField11 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType10);
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField12 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType10);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfDay();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis((int) (short) 0, (int) (byte) 100, (int) (byte) -1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000116d + "'", double1 == 2440587.500000116d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) -1);
        org.joda.time.Period period3 = period1.minusMillis(0);
        try {
            org.joda.time.Seconds seconds4 = period3.toStandardSeconds();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Seconds as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField7 = gregorianChronology0.hours();
        long long10 = durationField7.subtract(35L, (int) (byte) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 35L + "'", long10 == 35L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.String str6 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Standard" + "'", str6.equals("Standard"));
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test090");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        try {
//            org.joda.time.Period period4 = new org.joda.time.Period((java.lang.Object) dateTimeZone1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.FixedDateTimeZone");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        try {
            long long16 = zonedChronology11.getDateTimeMillis((int) '4', (int) '4', 0, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period3 = period1.withSeconds((int) (byte) 0);
        int int4 = period1.getYears();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 10, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Coordinated Universal Time");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.getActions();
        java.lang.String str4 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.Period period4 = new org.joda.time.Period((int) '4', 1, 0, (int) '#');
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(35, (int) (byte) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(350L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 35, (java.lang.Number) 1.0f, (java.lang.Number) 350L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.Period period5 = org.joda.time.Period.hours(100);
        org.joda.time.Period period6 = period5.negated();
        int[] intArray7 = period6.getValues();
        try {
            gregorianChronology0.validate(readablePartial3, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period2.minusMinutes(33);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add((long) (-1), (int) ' ');
//        org.joda.time.ReadablePartial readablePartial7 = null;
//        org.joda.time.Period period10 = org.joda.time.Period.hours(100);
//        org.joda.time.Period period11 = period10.negated();
//        int[] intArray12 = period11.getValues();
//        try {
//            int[] intArray14 = offsetDateTimeField3.set(readablePartial7, 1, intArray12, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [33,85]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19349999999L + "'", long6 == 19349999999L);
//        org.junit.Assert.assertNotNull(period10);
//        org.junit.Assert.assertNotNull(period11);
//        org.junit.Assert.assertNotNull(intArray12);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866673600000L) + "'", long1 == (-210866673600000L));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale14 = null;
        try {
            java.lang.String str15 = offsetDateTimeField3.getAsText(readablePartial13, locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField7 = gregorianChronology0.hours();
        org.joda.time.Period period8 = new org.joda.time.Period();
        boolean boolean10 = period8.equals((java.lang.Object) false);
        org.joda.time.Period period12 = period8.plusMillis((int) (byte) 1);
        int[] intArray15 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period8, (-10L), (long) (short) 0);
        try {
            long long23 = gregorianChronology0.getDateTimeMillis(1, 1, 0, (int) (short) 10, (int) (short) 0, (int) '#', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.Period period4 = new org.joda.time.Period();
        int int5 = period4.size();
        org.joda.time.Period period6 = period4.negated();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period6.indexOf(durationFieldType7);
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField11 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType10);
        boolean boolean12 = decoratedDurationField11.isSupported();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField14 = gregorianChronology13.eras();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField15 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, (org.joda.time.DurationField) decoratedDurationField11, durationField14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period();
        int int3 = period2.size();
        org.joda.time.PeriodType periodType4 = period2.getPeriodType();
        java.lang.String str5 = periodType4.getName();
        org.joda.time.PeriodType periodType6 = periodType4.withSecondsRemoved();
        try {
            org.joda.time.Period period7 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Standard" + "'", str5.equals("Standard"));
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        try {
            org.joda.time.Period period1 = new org.joda.time.Period((java.lang.Object) (-210858120000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (byte) -1);
        org.joda.time.DurationField durationField3 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.joda.time.Period period4 = new org.joda.time.Period();
        int int5 = period4.size();
        org.joda.time.Period period6 = period4.negated();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period6.indexOf(durationFieldType7);
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField11 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType10);
        java.lang.String str12 = decoratedDurationField11.getName();
        boolean boolean13 = decoratedDurationField11.isSupported();
        long long16 = decoratedDurationField11.getDifferenceAsLong((long) (byte) 100, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.weekOfWeekyear();
        org.joda.time.DurationField durationField19 = gregorianChronology17.hours();
        org.joda.time.Period period20 = new org.joda.time.Period();
        int int21 = period20.size();
        org.joda.time.Period period22 = period20.negated();
        org.joda.time.DurationFieldType durationFieldType23 = null;
        int int24 = period22.indexOf(durationFieldType23);
        org.joda.time.DurationFieldType durationFieldType26 = period22.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField27 = new org.joda.time.field.DecoratedDurationField(durationField19, durationFieldType26);
        java.lang.String str28 = decoratedDurationField27.getName();
        boolean boolean29 = decoratedDurationField27.isSupported();
        long long32 = decoratedDurationField27.getDifferenceAsLong((long) (byte) 100, (long) 100);
        java.lang.String str33 = decoratedDurationField27.toString();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField34 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, (org.joda.time.DurationField) decoratedDurationField11, (org.joda.time.DurationField) decoratedDurationField27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "years" + "'", str12.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 8 + "'", int21 == 8);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "years" + "'", str28.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DurationField[years]" + "'", str33.equals("DurationField[years]"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.PeriodType periodType5 = period0.getPeriodType();
        int int6 = period0.getMonths();
        org.joda.time.Period period8 = period0.minusSeconds((int) '4');
        int int9 = period0.getDays();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        int int3 = period2.size();
        org.joda.time.Period period4 = new org.joda.time.Period();
        int int5 = period4.size();
        org.joda.time.Period period6 = period4.negated();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period6.indexOf(durationFieldType7);
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(durationFieldType10, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.Period period16 = period2.withFieldAdded(durationFieldType10, (int) (byte) 100);
        try {
            org.joda.time.Days days17 = period16.toStandardDays();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Days as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        try {
            long long12 = gregorianChronology0.getDateTimeMillis((int) (byte) 10, (int) (short) -1, 35, 33, 10, 32, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 33 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) -1);
        org.joda.time.Period period3 = period1.plusWeeks((int) '4');
        int int4 = period3.size();
        int int5 = period3.getMonths();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(0L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(360000000L, 604803200L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-244803200L) + "'", long2 == (-244803200L));
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        int int4 = cachedDateTimeZone2.getOffset(0L);
//        org.joda.time.DateTimeZone dateTimeZone5 = cachedDateTimeZone2.getUncachedZone();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = cachedDateTimeZone2.getShortName((long) 0, locale7);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = cachedDateTimeZone2.getShortName((-1L), locale10);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(4L, 0L);
        try {
            long long9 = offsetDateTimeField3.set(0L, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 4L + "'", long6 == 4L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter4 = null;
        java.lang.String str5 = period0.toString(periodFormatter4);
        org.joda.time.DurationFieldType durationFieldType7 = period0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField8 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        try {
            int int10 = unsupportedDurationField8.getValue(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0S" + "'", str5.equals("PT0S"));
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField8);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        try {
            long long18 = zonedChronology11.getDateTimeMillis(1260000000L, (int) ' ', 33, (int) (byte) -1, 32);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
//        long long15 = offsetDateTimeField3.roundFloor((long) 2);
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        java.util.Locale locale17 = null;
//        try {
//            java.lang.String str18 = offsetDateTimeField3.getAsText(readablePartial16, locale17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-230400000L) + "'", long15 == (-230400000L));
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.Period period1 = org.joda.time.Period.days(1);
        org.joda.time.MutablePeriod mutablePeriod2 = period1.toMutablePeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(mutablePeriod2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis((int) (byte) 10, (int) ' ', 33, (int) (short) 10, (int) (byte) 100, (int) (short) 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 10, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period();
        int int3 = period2.size();
        org.joda.time.PeriodType periodType4 = period2.getPeriodType();
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType4);
        org.joda.time.PeriodType periodType6 = periodType4.withYearsRemoved();
        java.lang.String str7 = periodType6.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PeriodType[StandardNoYears]" + "'", str7.equals("PeriodType[StandardNoYears]"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (-1), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.PeriodType periodType5 = period0.getPeriodType();
        int int6 = period0.getMonths();
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.Period period10 = period0.withPeriodType(periodType9);
        org.joda.time.Period period12 = period0.withMillis((int) (short) 10);
        org.joda.time.Period period14 = period0.plusMinutes((int) (short) 10);
        org.joda.time.Period period16 = period14.plusSeconds((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("years", 33, 8, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 33 for years must be in the range [8,8]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-43104900L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-3935130120000000L) + "'", long1 == (-3935130120000000L));
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test135");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560629534061L + "'", long1 == 1560629534061L);
//    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.Period period1 = new org.joda.time.Period();
//        int int2 = period1.size();
//        org.joda.time.Period period3 = period1.negated();
//        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
//        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
//        long long8 = durationField5.subtract((long) (-1), 32);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
//        org.junit.Assert.assertNotNull(period3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-19357200001L) + "'", long8 == (-19357200001L));
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-210866673600000L));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.Period period4 = org.joda.time.Period.hours(100);
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) period4);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType7 = periodType6.withSecondsRemoved();
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) period4, periodType7);
        int int9 = period4.getSeconds();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add((long) (-1), (int) ' ');
//        long long8 = offsetDateTimeField3.roundFloor((long) (byte) 100);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField3.getMaximumShortTextLength(locale9);
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        org.joda.time.Period period14 = org.joda.time.Period.hours(100);
//        org.joda.time.Period period15 = period14.negated();
//        org.joda.time.Days days16 = period15.toStandardDays();
//        int[] intArray17 = period15.getValues();
//        java.util.Locale locale19 = null;
//        try {
//            int[] intArray20 = offsetDateTimeField3.set(readablePartial11, 0, intArray17, "P-33YT10H8S", locale19);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"P-33YT10H8S\" for weekOfWeekyear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19349999999L + "'", long6 == 19349999999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-230400000L) + "'", long8 == (-230400000L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period15);
//        org.junit.Assert.assertNotNull(days16);
//        org.junit.Assert.assertNotNull(intArray17);
//    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add((long) (-1), (int) ' ');
//        long long8 = offsetDateTimeField3.roundHalfFloor((long) 85);
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) ' ');
//        long long15 = offsetDateTimeField12.add(3200L, (int) (short) 1);
//        int int17 = offsetDateTimeField12.get((long) (short) 100);
//        int int19 = offsetDateTimeField12.get((-10L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField12.getType();
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField21 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType20);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19349999999L + "'", long6 == 19349999999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-230400000L) + "'", long8 == (-230400000L));
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 604803200L + "'", long15 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 33 + "'", int17 == 33);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 33 + "'", int19 == 33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test143");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
//        long long15 = offsetDateTimeField3.roundFloor((long) 2);
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField19 = gregorianChronology18.eras();
//        org.joda.time.Period period21 = org.joda.time.Period.hours(100);
//        org.joda.time.Period period22 = period21.negated();
//        int[] intArray24 = gregorianChronology18.get((org.joda.time.ReadablePeriod) period21, 0L);
//        java.util.Locale locale26 = null;
//        try {
//            int[] intArray27 = offsetDateTimeField3.set(readablePartial16, 100, intArray24, "hi!", locale26);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for weekOfWeekyear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-230400000L) + "'", long15 == (-230400000L));
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertNotNull(period22);
//        org.junit.Assert.assertNotNull(intArray24);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(2, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        try {
            long long17 = zonedChronology11.getDateTimeMillis(0, 33, 85, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 33 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Standard");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Standard/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Days days3 = period2.toStandardDays();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Period period5 = period2.withFields(readablePeriod4);
        org.joda.time.Period period7 = period2.minusMonths(8);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(days3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str8 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str9 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10.0" + "'", str7.equals("10.0"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]" + "'", str9.equals("org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        long long5 = cachedDateTimeZone2.previousTransition((long) 0);
        int int7 = cachedDateTimeZone2.getStandardOffset((long) 8);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PT0S", "org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]");
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        try {
            long long17 = zonedChronology11.getDateTimeMillis((int) (short) 1, (int) (byte) -1, 32, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("P8Y", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str8 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]" + "'", str8.equals("org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField7 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        int int4 = cachedDateTimeZone2.getOffset(0L);
//        org.joda.time.DateTimeZone dateTimeZone5 = cachedDateTimeZone2.getUncachedZone();
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = cachedDateTimeZone2.getName((long) 'a', locale7);
//        boolean boolean9 = cachedDateTimeZone2.isFixed();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (byte) 1, 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        long long7 = dateTimeZone3.convertLocalToUTC(99L, false);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 99L + "'", long7 == 99L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField3.getWrappedField();
        long long17 = offsetDateTimeField3.add((long) 4, (int) '4');
        long long19 = offsetDateTimeField3.roundHalfFloor((-58571700L));
        long long22 = offsetDateTimeField3.add((long) (short) 10, 0);
        long long25 = offsetDateTimeField3.getDifferenceAsLong(0L, 1L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31449600004L + "'", long17 == 31449600004L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200000L) + "'", long19 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 10L + "'", long22 == 10L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField8 = gregorianChronology0.years();
        boolean boolean10 = gregorianChronology0.equals((java.lang.Object) "UTC");
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.dayOfYear();
        org.joda.time.ReadablePartial readablePartial12 = null;
        try {
            long long14 = gregorianChronology0.set(readablePartial12, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsText(readablePartial9, 8, locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumTextLength(locale13);
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.Period period18 = org.joda.time.Period.hours(100);
        org.joda.time.Period period19 = period18.negated();
        int[] intArray20 = period19.getValues();
        try {
            int[] intArray22 = offsetDateTimeField3.addWrapField(readablePartial15, 100, intArray20, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "8" + "'", str12.equals("8"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(intArray20);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField8 = gregorianChronology0.years();
        boolean boolean10 = gregorianChronology0.equals((java.lang.Object) "UTC");
        org.joda.time.DurationField durationField11 = gregorianChronology0.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            long long7 = gregorianChronology0.set(readablePartial5, (-10L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.DurationField durationField14 = gregorianChronology12.hours();
        org.joda.time.Period period15 = new org.joda.time.Period();
        int int16 = period15.size();
        org.joda.time.Period period17 = period15.negated();
        org.joda.time.DurationFieldType durationFieldType18 = null;
        int int19 = period17.indexOf(durationFieldType18);
        org.joda.time.DurationFieldType durationFieldType21 = period17.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField22 = new org.joda.time.field.DecoratedDurationField(durationField14, durationFieldType21);
        org.joda.time.Period period23 = new org.joda.time.Period();
        int int24 = period23.size();
        org.joda.time.Period period25 = period23.negated();
        org.joda.time.DurationFieldType durationFieldType26 = null;
        int int27 = period25.indexOf(durationFieldType26);
        org.joda.time.DurationFieldType durationFieldType29 = period25.getFieldType((int) (short) 0);
        org.joda.time.Period period30 = new org.joda.time.Period();
        int int31 = period30.size();
        org.joda.time.Period period32 = period30.negated();
        int int33 = period30.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter34 = null;
        java.lang.String str35 = period30.toString(periodFormatter34);
        org.joda.time.DurationFieldType durationFieldType37 = period30.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField38 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType37);
        org.joda.time.DurationFieldType[] durationFieldTypeArray39 = new org.joda.time.DurationFieldType[] { durationFieldType6, durationFieldType21, durationFieldType29, durationFieldType37 };
        try {
            org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.forFields(durationFieldTypeArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: PeriodType does not support fields: [years, years, years]");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 8 + "'", int31 == 8);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "PT0S" + "'", str35.equals("PT0S"));
        org.junit.Assert.assertNotNull(durationFieldType37);
        org.junit.Assert.assertNotNull(unsupportedDurationField38);
        org.junit.Assert.assertNotNull(durationFieldTypeArray39);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass5 = period4.getClass();
        org.joda.time.Period period7 = period4.minusMonths((int) (short) 10);
        org.joda.time.Period period8 = period7.normalizedStandard();
        org.joda.time.Period period9 = period8.negated();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        int int15 = offsetDateTimeField3.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) ' ');
        long long22 = offsetDateTimeField19.add(3200L, (int) (short) 1);
        int int24 = offsetDateTimeField19.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial25 = null;
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField19.getAsShortText(readablePartial25, (int) '4', locale27);
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField19.getMaximumShortTextLength(locale29);
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
        long long37 = offsetDateTimeField34.add(3200L, (int) (short) 1);
        int int39 = offsetDateTimeField34.get((long) (short) 100);
        int int41 = offsetDateTimeField34.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField19, dateTimeFieldType42, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType42, (int) 'a');
        int int48 = offsetDateTimeField46.getLeapAmount((-210858120000000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 604803200L + "'", long22 == 604803200L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 33 + "'", int24 == 33);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "52" + "'", str28.equals("52"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604803200L + "'", long37 == 604803200L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 33 + "'", int41 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField3.getWrappedField();
        long long16 = offsetDateTimeField3.roundHalfEven(3200L);
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.Period period20 = org.joda.time.Period.hours(100);
        org.joda.time.Period period21 = period20.negated();
        org.joda.time.Days days22 = period21.toStandardDays();
        int[] intArray23 = period21.getValues();
        try {
            int[] intArray25 = offsetDateTimeField3.add(readablePartial17, 10, intArray23, 33);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200000L) + "'", long16 == (-259200000L));
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(days22);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        try {
            long long31 = dividedDateTimeField28.set((-1L), 32);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for weekOfWeekyear must be in the range [3,8]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) -1);
        org.joda.time.Period period3 = period1.plusWeeks((int) '4');
        int int4 = period3.size();
        int int5 = period3.getMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add((long) (-1), (int) ' ');
        long long8 = offsetDateTimeField3.roundHalfFloor((long) 85);
        java.util.Locale locale11 = null;
        try {
            long long12 = offsetDateTimeField3.set(360000000L, "UTC", locale11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19353599999L + "'", long6 == 19353599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-259200000L) + "'", long8 == (-259200000L));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        int int15 = offsetDateTimeField3.getMaximumValue(10L);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField3.getAsText(readablePartial16, (int) (short) 10, locale18);
        java.util.Locale locale22 = null;
        try {
            long long23 = offsetDateTimeField3.set(19349999999L, "Coordinated Universal Time", locale22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Coordinated Universal Time\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10" + "'", str19.equals("10"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        java.lang.String str16 = offsetDateTimeField3.getAsText(99L);
        try {
            long long19 = offsetDateTimeField3.add((long) ' ', (-210866673600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -210866673600000 * 604800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "33" + "'", str16.equals("33"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'PT100H' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add((long) (-1), (int) ' ');
        long long8 = offsetDateTimeField3.roundFloor((long) (byte) 100);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField3.getMaximumTextLength(locale9);
        org.joda.time.DurationField durationField11 = offsetDateTimeField3.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19353599999L + "'", long6 == 19353599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-259200000L) + "'", long8 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNull(durationField11);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (byte) -1);
        java.lang.String str2 = period1.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PT-0.001S" + "'", str2.equals("PT-0.001S"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', (int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (short) 1, (int) (short) -1, 0, 1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        try {
            long long15 = offsetDateTimeField3.add((-210858134399967L), (-210858134399967L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -210858134399967 * 604800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Throwable[] throwableArray8 = illegalFieldValueException4.getSuppressed();
        java.lang.String str9 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        boolean boolean6 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Standard" + "'", str7.equals("Standard"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-19170000001L), (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -613440000032");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Days days3 = period2.toStandardDays();
        org.joda.time.Period period5 = period2.plusHours(1);
        int int6 = period5.getDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(days3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter4 = null;
        java.lang.String str5 = period0.toString(periodFormatter4);
        org.joda.time.DurationFieldType durationFieldType7 = period0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField8 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        try {
            long long11 = unsupportedDurationField8.getMillis(1L, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0S" + "'", str5.equals("PT0S"));
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField8);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0d + "'", number6.equals(10.0d));
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
//        java.lang.String str6 = dateTimeZone4.getName((-19170000001L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 4);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(85, (int) (byte) 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        long long15 = offsetDateTimeField3.roundFloor((long) 2);
        boolean boolean17 = offsetDateTimeField3.isLeap((-210858120000000L));
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField3.getAsShortText((long) (byte) -1, locale19);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "33" + "'", str20.equals("33"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundHalfEven((-57599900L));
        org.joda.time.ReadablePartial readablePartial6 = null;
        int[] intArray10 = new int[] { 'a', (byte) 0 };
        try {
            int[] intArray12 = offsetDateTimeField3.add(readablePartial6, 0, intArray10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 96 for weekOfWeekyear must be in the range [33,85]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-259200000L) + "'", long5 == (-259200000L));
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 4L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866414400000L) + "'", long1 == (-210866414400000L));
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(4L, 0L);
//        long long8 = offsetDateTimeField3.roundCeiling((long) '#');
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 4L + "'", long6 == 4L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 345599900L + "'", long8 == 345599900L);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology8 = gregorianChronology4.withZone(dateTimeZone7);
        long long10 = dateTimeZone7.convertUTCToLocal(0L);
        org.joda.time.Chronology chronology11 = iSOChronology0.withZone(dateTimeZone7);
        org.joda.time.Chronology chronology12 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        java.lang.String str11 = illegalFieldValueException10.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.PeriodType periodType5 = period0.getPeriodType();
        int int6 = period0.getMonths();
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.Period period10 = period0.withPeriodType(periodType9);
        org.joda.time.Period period12 = period0.withMillis((int) (short) 10);
        int int13 = period0.getWeeks();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("years");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'years' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.PeriodType periodType5 = period0.getPeriodType();
        int int6 = period0.getMonths();
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.Period period10 = period0.withPeriodType(periodType9);
        org.joda.time.Period period12 = period0.withMillis((int) (short) 10);
        org.joda.time.Period period14 = period0.plusMinutes((int) (short) 10);
        org.joda.time.Period period16 = period14.withMillis(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
//        long long15 = offsetDateTimeField3.roundFloor((long) 2);
//        boolean boolean17 = offsetDateTimeField3.isLeap((-210858120000000L));
//        long long19 = offsetDateTimeField3.roundCeiling(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200100L) + "'", long15 == (-259200100L));
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 345599900L + "'", long19 == 345599900L);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsText(readablePartial9, 8, locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumTextLength(locale13);
        java.lang.String str16 = offsetDateTimeField3.getAsShortText(2L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "8" + "'", str12.equals("8"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "33" + "'", str16.equals("33"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField7 = gregorianChronology0.hours();
        org.joda.time.Period period8 = new org.joda.time.Period();
        boolean boolean10 = period8.equals((java.lang.Object) false);
        org.joda.time.Period period12 = period8.plusMillis((int) (byte) 1);
        int[] intArray15 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period8, (-10L), (long) (short) 0);
        org.joda.time.Duration duration16 = period8.toStandardDuration();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(duration16);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.Period period1 = org.joda.time.Period.years(100);
        org.joda.time.Period period3 = period1.plusHours(35);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.minutes();
        org.joda.time.Chronology chronology7 = gregorianChronology5.withUTC();
        org.joda.time.Period period9 = org.joda.time.Period.months((int) '4');
        int[] intArray11 = gregorianChronology5.get((org.joda.time.ReadablePeriod) period9, (long) 10);
        try {
            org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) period1, periodType4, (org.joda.time.Chronology) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "PeriodType[StandardNoYears]", "");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "P8Y", "10");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        int int3 = period2.size();
        org.joda.time.Period period4 = new org.joda.time.Period();
        int int5 = period4.size();
        org.joda.time.Period period6 = period4.negated();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period6.indexOf(durationFieldType7);
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(durationFieldType10, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.Period period16 = period2.withFieldAdded(durationFieldType10, (int) (byte) 100);
        int int17 = period16.getYears();
        try {
            org.joda.time.Minutes minutes18 = period16.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((-43104900L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-43104900) + "'", int1 == (-43104900));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass5 = period4.getClass();
        org.joda.time.Period period7 = period4.minusMonths((int) (short) 10);
        org.joda.time.Period period8 = period7.normalizedStandard();
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Period period10 = period7.withPeriodType(periodType9);
        org.joda.time.Period period12 = period7.minusYears(0);
        int int13 = period7.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        int int10 = offsetDateTimeField3.get((-10L));
        long long13 = offsetDateTimeField3.getDifferenceAsLong(360000000L, 0L);
        java.lang.String str15 = offsetDateTimeField3.getAsShortText((-210858120000000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "42" + "'", str15.equals("42"));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1000L + "'", long2 == 1000L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        java.lang.String str11 = decoratedDurationField10.getName();
        long long13 = decoratedDurationField10.getMillis(350L);
        long long15 = decoratedDurationField10.getMillis(100);
        int int18 = decoratedDurationField10.getValue((long) 8, (long) '#');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "years" + "'", str11.equals("years"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1260000000L + "'", long13 == 1260000000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 360000000L + "'", long15 == 360000000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("PT-0.001S");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'PT-0.001S' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        java.lang.String str11 = decoratedDurationField10.getName();
        boolean boolean12 = decoratedDurationField10.isSupported();
        long long15 = decoratedDurationField10.getDifferenceAsLong((long) (byte) 100, (long) 100);
        java.lang.String str16 = decoratedDurationField10.toString();
        long long19 = decoratedDurationField10.getMillis((long) (byte) 1, (-10L));
        long long22 = decoratedDurationField10.getValueAsLong((long) 4, (long) (byte) 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "years" + "'", str11.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DurationField[years]" + "'", str16.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 3600000L + "'", long19 == 3600000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        int int13 = decoratedDurationField10.getDifference((-10L), 2440588L);
        long long16 = decoratedDurationField10.add((long) 0, 0L);
        long long19 = decoratedDurationField10.add((-244803200L), (-57599900L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-207359884803200L) + "'", long19 == (-207359884803200L));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        int int15 = offsetDateTimeField3.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) ' ');
        long long22 = offsetDateTimeField19.add(3200L, (int) (short) 1);
        int int24 = offsetDateTimeField19.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial25 = null;
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField19.getAsShortText(readablePartial25, (int) '4', locale27);
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField19.getMaximumShortTextLength(locale29);
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
        long long37 = offsetDateTimeField34.add(3200L, (int) (short) 1);
        int int39 = offsetDateTimeField34.get((long) (short) 100);
        int int41 = offsetDateTimeField34.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField19, dateTimeFieldType42, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType42, (int) 'a');
        org.joda.time.ReadablePartial readablePartial47 = null;
        java.util.Locale locale48 = null;
        try {
            java.lang.String str49 = offsetDateTimeField3.getAsShortText(readablePartial47, locale48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 604803200L + "'", long22 == 604803200L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 33 + "'", int24 == 33);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "52" + "'", str28.equals("52"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604803200L + "'", long37 == 604803200L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 33 + "'", int41 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.Period period7 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period9 = period7.withPeriodType(periodType8);
        boolean boolean10 = fixedDateTimeZone4.equals((java.lang.Object) periodType8);
        int int12 = fixedDateTimeZone4.getStandardOffset((-230400000L));
        long long14 = fixedDateTimeZone4.nextTransition((long) '#');
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 35L + "'", long14 == 35L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(604803200L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 604803200 + "'", int1 == 604803200);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.Period period4 = org.joda.time.Period.hours(100);
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) period4);
        org.joda.time.DurationField durationField6 = gregorianChronology0.eras();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis(0, (-43104900), 0, 35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -43104900 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
//        int int9 = cachedDateTimeZone7.getOffset(0L);
//        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        java.lang.String str15 = dateTimeZone13.getName((long) 1);
//        java.lang.String str17 = dateTimeZone13.getName(0L);
//        org.joda.time.Chronology chronology18 = zonedChronology11.withZone(dateTimeZone13);
//        try {
//            long long23 = zonedChronology11.getDateTimeMillis(10, (-1), 0, 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Coordinated Universal Time" + "'", str17.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology18);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (byte) -1);
        java.lang.String str3 = iSOChronology0.toString();
        org.joda.time.DurationField durationField4 = iSOChronology0.millis();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField8 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfEra();
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        long long14 = gregorianChronology0.add((long) (byte) -1, 0L, (int) (byte) -1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 10, 0, 8, 0);
        org.joda.time.Period period6 = period4.minusYears(33);
        org.joda.time.format.PeriodFormatter periodFormatter7 = null;
        java.lang.String str8 = period6.toString(periodFormatter7);
        org.joda.time.Period period9 = period6.toPeriod();
        org.joda.time.Period period11 = period6.plusHours((int) (short) 1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "P-33YT10H8S" + "'", str8.equals("P-33YT10H8S"));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsText(readablePartial9, 8, locale11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.Period period16 = org.joda.time.Period.hours(100);
        org.joda.time.Period period17 = period16.negated();
        int[] intArray18 = period17.getValues();
        try {
            int[] intArray20 = offsetDateTimeField3.addWrapField(readablePartial13, (int) (byte) -1, intArray18, 85);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "8" + "'", str12.equals("8"));
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.Period period4 = org.joda.time.Period.hours(100);
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) period4);
        org.joda.time.DurationField durationField6 = gregorianChronology0.eras();
        try {
            long long9 = durationField6.subtract(100L, (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("GregorianChronology[PT100H]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[PT100H]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test233");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("P8Y");
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField3 = gregorianChronology2.minutes();
//        org.joda.time.Chronology chronology4 = gregorianChronology2.withUTC();
//        org.joda.time.Period period6 = org.joda.time.Period.hours(100);
//        boolean boolean7 = gregorianChronology2.equals((java.lang.Object) period6);
//        long long13 = gregorianChronology2.getDateTimeMillis((long) (byte) 10, 0, 0, 0, 100);
//        boolean boolean14 = jodaTimePermission1.equals((java.lang.Object) 0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter4 = null;
        java.lang.String str5 = period0.toString(periodFormatter4);
        org.joda.time.DurationFieldType durationFieldType7 = period0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField8 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField10 = gregorianChronology9.minutes();
        int int11 = unsupportedDurationField8.compareTo(durationField10);
        try {
            long long13 = unsupportedDurationField8.getMillis((long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0S" + "'", str5.equals("PT0S"));
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.PeriodType periodType3 = period1.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = periodType3.isSupported(durationFieldType4);
        org.joda.time.Period period6 = new org.joda.time.Period();
        int int7 = period6.size();
        org.joda.time.Period period8 = period6.negated();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        int int10 = period8.indexOf(durationFieldType9);
        org.joda.time.DurationFieldType durationFieldType12 = period8.getFieldType((int) (short) 0);
        int int13 = periodType3.indexOf(durationFieldType12);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(durationFieldType12, (java.lang.Number) (byte) 100, (java.lang.Number) 10.0d, (java.lang.Number) 1.0f);
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField19 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType12, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis(1, 10, (int) (byte) -1, 85);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.Period period4 = org.joda.time.Period.months((int) '4');
        int[] intArray6 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period4, (long) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        try {
            long long18 = zonedChronology12.getDateTimeMillis(1260000000L, (int) (short) 1, (int) (byte) 0, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(zonedChronology12);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        long long13 = unsupportedDurationField11.getUnitMillis();
        try {
            long long16 = unsupportedDurationField11.getMillis(0, 31449600004L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 85);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withHoursRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add((long) (-1), (int) ' ');
//        long long8 = offsetDateTimeField3.roundFloor((long) (byte) 100);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField3.getMaximumShortTextLength(locale9);
//        int int12 = offsetDateTimeField3.getLeapAmount((-1L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19353599999L + "'", long6 == 19353599999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-259200100L) + "'", long8 == (-259200100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "97", "");
        org.junit.Assert.assertNull(str4);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
//        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField3.getWrappedField();
//        long long17 = offsetDateTimeField3.add((long) 4, (int) '4');
//        long long19 = offsetDateTimeField3.roundHalfFloor((-58571700L));
//        int int20 = offsetDateTimeField3.getMaximumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31449600004L + "'", long17 == 31449600004L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200100L) + "'", long19 == (-259200100L));
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 85 + "'", int20 == 85);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.days();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.PeriodType periodType3 = period1.getPeriodType();
        java.lang.String str4 = periodType3.getName();
        int int5 = periodType3.size();
        try {
            org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) periodType0, periodType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Standard" + "'", str4.equals("Standard"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        int int6 = offsetDateTimeField3.getDifference((long) (short) 0, (long) (short) 100);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField3.getAsShortText(19353599999L, locale8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "65" + "'", str9.equals("65"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add((long) (-1), (int) ' ');
        long long9 = offsetDateTimeField3.add((long) (short) 0, (long) (byte) 1);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField3, (int) (short) 100, (int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [97,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19353599999L + "'", long6 == 19353599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 604800000L + "'", long9 == 604800000L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter4 = null;
        java.lang.String str5 = period0.toString(periodFormatter4);
        org.joda.time.DurationFieldType durationFieldType7 = period0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField8 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        java.lang.String str9 = unsupportedDurationField8.getName();
        try {
            int int12 = unsupportedDurationField8.getDifference((-230400000L), 99L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0S" + "'", str5.equals("PT0S"));
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "years" + "'", str9.equals("years"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) '4', (int) 'a', (-1), (-43104900));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass5 = period4.getClass();
        org.joda.time.Period period7 = period4.minusMonths((int) (short) 10);
        org.joda.time.Seconds seconds8 = period4.toStandardSeconds();
        org.joda.time.Period period10 = period4.plusMillis(8);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(seconds8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            int[] intArray4 = iSOChronology0.get(readablePartial2, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int4 = cachedDateTimeZone2.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone5 = cachedDateTimeZone2.getUncachedZone();
        boolean boolean6 = cachedDateTimeZone2.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(360000000L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 360000000 + "'", int1 == 360000000);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis(35, 35, (-1), (int) (byte) 0, (int) (byte) 0, (int) (short) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add((long) (-1), (int) ' ');
//        long long8 = offsetDateTimeField3.roundHalfFloor((long) 85);
//        long long10 = offsetDateTimeField3.roundHalfCeiling(0L);
//        java.lang.String str12 = offsetDateTimeField3.getAsText(350L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19353599999L + "'", long6 == 19353599999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-259200100L) + "'", long8 == (-259200100L));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-259200100L) + "'", long10 == (-259200100L));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "33" + "'", str12.equals("33"));
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        long long32 = dividedDateTimeField28.add((-3935130120000000L), (long) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField28, 10);
        org.joda.time.ReadablePartial readablePartial35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology38 = gregorianChronology37.withUTC();
        org.joda.time.DurationField durationField39 = gregorianChronology37.hours();
        org.joda.time.Period period41 = org.joda.time.Period.hours(100);
        org.joda.time.Period period42 = period41.negated();
        org.joda.time.Days days43 = period42.toStandardDays();
        org.joda.time.Period period45 = period42.plusHours(1);
        int[] intArray47 = gregorianChronology37.get((org.joda.time.ReadablePeriod) period45, (-207359884803200L));
        try {
            int[] intArray49 = dividedDateTimeField28.set(readablePartial35, 85, intArray47, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [3,8]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3934918440000000L) + "'", long32 == (-3934918440000000L));
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(days43);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(intArray47);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        long long32 = dividedDateTimeField28.add((-3935130120000000L), (long) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField28, 10);
        java.lang.String str36 = dividedDateTimeField28.getAsText((long) (-43104900));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3934918440000000L) + "'", long32 == (-3934918440000000L));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "3" + "'", str36.equals("3"));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) '#');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DurationField durationField3 = iSOChronology0.centuries();
        org.joda.time.ReadablePartial readablePartial4 = null;
        int[] intArray5 = null;
        try {
            iSOChronology0.validate(readablePartial4, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        int int4 = cachedDateTimeZone2.getOffset(readableInstant3);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        org.joda.time.Period period6 = new org.joda.time.Period();
        int int7 = period6.size();
        org.joda.time.Period period8 = period6.negated();
        int int9 = period6.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter10 = null;
        java.lang.String str11 = period6.toString(periodFormatter10);
        org.joda.time.DurationFieldType durationFieldType13 = period6.getFieldType(0);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withSecondsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.DurationFieldType durationFieldType17 = null;
        int int18 = periodType16.indexOf(durationFieldType17);
        org.joda.time.Period period19 = period6.normalizedStandard(periodType16);
        boolean boolean20 = cachedDateTimeZone2.equals((java.lang.Object) period6);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT0S" + "'", str11.equals("PT0S"));
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int7 = offsetDateTimeField3.getOffset();
        try {
            long long10 = offsetDateTimeField3.set((long) (byte) 1, "PT100H");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PT100H\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
//        long long15 = offsetDateTimeField3.roundFloor((long) 2);
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField19 = gregorianChronology18.minutes();
//        org.joda.time.Chronology chronology20 = gregorianChronology18.withUTC();
//        org.joda.time.Period period22 = org.joda.time.Period.months((int) '4');
//        int[] intArray24 = gregorianChronology18.get((org.joda.time.ReadablePeriod) period22, (long) 10);
//        try {
//            int[] intArray26 = offsetDateTimeField3.add(readablePartial16, 8, intArray24, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200100L) + "'", long15 == (-259200100L));
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(period22);
//        org.junit.Assert.assertNotNull(intArray24);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.Period period4 = org.joda.time.Period.months((int) '4');
        int[] intArray6 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period4, (long) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DurationField durationField13 = gregorianChronology0.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(durationField13);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField3.getAsText(readablePartial9, 8, locale11);
//        java.util.Locale locale13 = null;
//        int int14 = offsetDateTimeField3.getMaximumTextLength(locale13);
//        long long16 = offsetDateTimeField3.remainder((long) 35);
//        int int18 = offsetDateTimeField3.get((-1L));
//        try {
//            long long21 = offsetDateTimeField3.add(12L, 19353599999L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 19353599999 * 604800000");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "8" + "'", str12.equals("8"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 259200135L + "'", long16 == 259200135L);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 33 + "'", int18 == 33);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Throwable[] throwableArray8 = illegalFieldValueException4.getSuppressed();
        java.lang.Number number9 = illegalFieldValueException4.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType10 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10.0d + "'", number9.equals(10.0d));
        org.junit.Assert.assertNull(durationFieldType10);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2) + "'", int1 == (-2));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        try {
            long long36 = unsupportedDateTimeField34.remainder((long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.Period period4 = period0.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period4.minusSeconds(0);
        int int7 = period6.getMillis();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (byte) 10, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 110L + "'", long2 == 110L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.PeriodType periodType5 = period0.getPeriodType();
        int int6 = period0.getMonths();
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.Period period10 = period0.withPeriodType(periodType9);
        org.joda.time.Period period12 = period10.minusYears(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.util.Locale locale35 = null;
        try {
            int int36 = unsupportedDateTimeField34.getMaximumTextLength(locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        org.joda.time.Period period37 = org.joda.time.Period.hours(100);
        org.joda.time.Period period38 = period37.negated();
        org.joda.time.Days days39 = period38.toStandardDays();
        int[] intArray40 = period38.getValues();
        try {
            int int41 = unsupportedDateTimeField34.getMaximumValue(readablePartial35, intArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(days39);
        org.junit.Assert.assertNotNull(intArray40);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        java.lang.String str13 = dateTimeZone12.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        int int10 = offsetDateTimeField3.get((-10L));
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.Period period14 = org.joda.time.Period.hours(100);
        org.joda.time.Period period15 = period14.negated();
        int[] intArray16 = period15.getValues();
        try {
            int[] intArray18 = offsetDateTimeField3.addWrapField(readablePartial11, 35, intArray16, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass5 = period4.getClass();
        org.joda.time.Period period7 = period4.minusMonths((int) (short) 10);
        org.joda.time.Seconds seconds8 = period4.toStandardSeconds();
        org.joda.time.MutablePeriod mutablePeriod9 = period4.toMutablePeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(seconds8);
        org.junit.Assert.assertNotNull(mutablePeriod9);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DurationField durationField2 = gregorianChronology0.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        long long13 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType14 = unsupportedDurationField11.getType();
        try {
            long long16 = unsupportedDurationField11.getMillis((long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType14);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test279");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
//        java.util.Locale locale13 = null;
//        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
//        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
//        int int23 = offsetDateTimeField18.get((long) (short) 100);
//        int int25 = offsetDateTimeField18.get((-10L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
//        int int30 = dividedDateTimeField28.get((-57599900L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
//        long long37 = offsetDateTimeField34.add(3200L, (int) (short) 1);
//        int int39 = offsetDateTimeField34.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int int41 = offsetDateTimeField34.getMinimumValue(readablePartial40);
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = offsetDateTimeField34.getAsText((long) 8, locale43);
//        int int46 = offsetDateTimeField34.getMaximumValue(10L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) ' ');
//        long long53 = offsetDateTimeField50.add(3200L, (int) (short) 1);
//        int int55 = offsetDateTimeField50.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial56 = null;
//        java.util.Locale locale58 = null;
//        java.lang.String str59 = offsetDateTimeField50.getAsShortText(readablePartial56, (int) '4', locale58);
//        java.util.Locale locale60 = null;
//        int int61 = offsetDateTimeField50.getMaximumShortTextLength(locale60);
//        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology62.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, (int) ' ');
//        long long68 = offsetDateTimeField65.add(3200L, (int) (short) 1);
//        int int70 = offsetDateTimeField65.get((long) (short) 100);
//        int int72 = offsetDateTimeField65.get((-10L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = offsetDateTimeField65.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType73, (int) (byte) 10);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType73, (int) 'a');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField78 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType73);
//        long long80 = remainderDateTimeField78.roundHalfCeiling((long) (-43104900));
//        int int81 = remainderDateTimeField78.getMinimumValue();
//        try {
//            long long84 = remainderDateTimeField78.set(259200135L, 85);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 85 for weekOfWeekyear must be in the range [0,9]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604803200L + "'", long37 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 33 + "'", int41 == 33);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "33" + "'", str44.equals("33"));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 85 + "'", int46 == 85);
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 604803200L + "'", long53 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 33 + "'", int55 == 33);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "52" + "'", str59.equals("52"));
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology62);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604803200L + "'", long68 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 33 + "'", int70 == 33);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 33 + "'", int72 == 33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-259200100L) + "'", long80 == (-259200100L));
//        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, 10);
        int int29 = dividedDateTimeField28.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        try {
            long long36 = unsupportedDateTimeField34.remainder((-259200100L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period3 = period1.withPeriodType(periodType2);
        org.joda.time.Period period5 = period3.minusWeeks(0);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period();
        int int9 = period8.size();
        org.joda.time.PeriodType periodType10 = period8.getPeriodType();
        org.joda.time.Period period11 = new org.joda.time.Period(readableDuration6, readableInstant7, periodType10);
        org.joda.time.PeriodType periodType12 = periodType10.withYearsRemoved();
        org.joda.time.PeriodType periodType13 = periodType10.withHoursRemoved();
        org.joda.time.Period period14 = period3.normalizedStandard(periodType10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) -1);
        org.joda.time.Period period3 = period1.minusMillis(0);
        try {
            org.joda.time.Minutes minutes4 = period3.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.DurationField durationField3 = iSOChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        try {
            java.lang.String str39 = unsupportedDateTimeField34.getAsShortText(readablePartial36, (int) (byte) 1, locale38);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        int int10 = offsetDateTimeField3.get((-10L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField3.getType();
//        long long14 = offsetDateTimeField3.getDifferenceAsLong(1260000000L, (long) (short) 1);
//        long long16 = offsetDateTimeField3.roundHalfCeiling((long) (short) 1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField18 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200100L) + "'", long16 == (-259200100L));
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.Period period1 = org.joda.time.Period.years(100);
        org.joda.time.Period period3 = period1.plusHours(35);
        org.joda.time.Period period5 = period1.minusMillis(8);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        try {
            int int36 = unsupportedDateTimeField34.getMaximumValue((-207359884803200L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        int int15 = offsetDateTimeField3.getMaximumValue(10L);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField3.getAsText(readablePartial16, (int) (short) 10, locale18);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale21 = null;
        try {
            java.lang.String str22 = offsetDateTimeField3.getAsShortText(readablePartial20, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10" + "'", str19.equals("10"));
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
//        java.util.Locale locale13 = null;
//        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
//        java.lang.String str16 = offsetDateTimeField3.getAsText(99L);
//        long long18 = offsetDateTimeField3.remainder(0L);
//        long long20 = offsetDateTimeField3.roundHalfCeiling((long) 33);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "33" + "'", str16.equals("33"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 259200100L + "'", long18 == 259200100L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-259200100L) + "'", long20 == (-259200100L));
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.PeriodType periodType5 = period0.getPeriodType();
        int int6 = period0.getMonths();
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.Period period10 = period0.withPeriodType(periodType9);
        org.joda.time.Period period11 = period0.negated();
        org.joda.time.Period period13 = org.joda.time.Period.hours(100);
        org.joda.time.Period period14 = period13.negated();
        org.joda.time.Period period16 = period13.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass17 = period16.getClass();
        org.joda.time.Period period19 = period16.minusMonths((int) (short) 10);
        org.joda.time.Period period20 = period19.normalizedStandard();
        org.joda.time.PeriodType periodType21 = null;
        org.joda.time.Period period22 = period19.withPeriodType(periodType21);
        org.joda.time.Period period23 = period11.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.Period period25 = period23.minusSeconds((int) (byte) -1);
        org.joda.time.Period period27 = period23.minusWeeks((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField3.getWrappedField();
        long long17 = offsetDateTimeField3.add(31449600004L, (long) 604803200);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 365785006809600004L + "'", long17 == 365785006809600004L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        int int10 = offsetDateTimeField3.get((-10L));
        long long13 = offsetDateTimeField3.addWrapField((long) ' ', (int) (byte) 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 6048000032L + "'", long13 == 6048000032L);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        try {
            boolean boolean37 = unsupportedDateTimeField34.isLeap((long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
//        java.util.Locale locale13 = null;
//        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
//        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
//        int int23 = offsetDateTimeField18.get((long) (short) 100);
//        int int25 = offsetDateTimeField18.get((-10L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
//        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
//        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
//        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
//        org.joda.time.ReadablePartial readablePartial38 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology39.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField40, (int) ' ');
//        long long45 = offsetDateTimeField42.add(3200L, (int) (short) 1);
//        int int47 = offsetDateTimeField42.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial48 = null;
//        int int49 = offsetDateTimeField42.getMinimumValue(readablePartial48);
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = offsetDateTimeField42.getAsText((long) 8, locale51);
//        org.joda.time.DateTimeField dateTimeField53 = offsetDateTimeField42.getWrappedField();
//        long long56 = offsetDateTimeField42.add((long) 4, (int) '4');
//        long long58 = offsetDateTimeField42.roundHalfFloor((-58571700L));
//        java.util.Locale locale60 = null;
//        java.lang.String str61 = offsetDateTimeField42.getAsText(10L, locale60);
//        org.joda.time.ReadablePartial readablePartial62 = null;
//        org.joda.time.Period period63 = new org.joda.time.Period();
//        int int64 = period63.size();
//        org.joda.time.Period period65 = period63.negated();
//        int int66 = period63.getMillis();
//        int int67 = period63.getMonths();
//        org.joda.time.PeriodType periodType68 = period63.getPeriodType();
//        int int69 = period63.getMonths();
//        org.joda.time.Period period71 = org.joda.time.Period.millis((int) (byte) -1);
//        org.joda.time.PeriodType periodType72 = period71.getPeriodType();
//        org.joda.time.Period period73 = period63.withPeriodType(periodType72);
//        org.joda.time.Period period74 = period63.negated();
//        org.joda.time.Duration duration75 = period74.toStandardDuration();
//        org.joda.time.Period period77 = period74.plusMonths((int) '4');
//        int[] intArray78 = period77.getValues();
//        int int79 = offsetDateTimeField42.getMaximumValue(readablePartial62, intArray78);
//        try {
//            int int80 = unsupportedDateTimeField34.getMaximumValue(readablePartial38, intArray78);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 604803200L + "'", long45 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 33 + "'", int47 == 33);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 33 + "'", int49 == 33);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "33" + "'", str52.equals("33"));
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 31449600004L + "'", long56 == 31449600004L);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-259200100L) + "'", long58 == (-259200100L));
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "33" + "'", str61.equals("33"));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 8 + "'", int64 == 8);
//        org.junit.Assert.assertNotNull(period65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
//        org.junit.Assert.assertNotNull(periodType68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
//        org.junit.Assert.assertNotNull(period71);
//        org.junit.Assert.assertNotNull(periodType72);
//        org.junit.Assert.assertNotNull(period73);
//        org.junit.Assert.assertNotNull(period74);
//        org.junit.Assert.assertNotNull(duration75);
//        org.junit.Assert.assertNotNull(period77);
//        org.junit.Assert.assertNotNull(intArray78);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 85 + "'", int79 == 85);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        try {
            long long39 = unsupportedDateTimeField34.remainder(19353599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.Period period4 = org.joda.time.Period.months((int) '4');
        int[] intArray6 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period4, (long) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.yearOfEra();
        org.joda.time.Chronology chronology14 = zonedChronology12.withUTC();
        try {
            long long22 = zonedChronology12.getDateTimeMillis(10, (int) (byte) 0, (int) (byte) -1, 100, (int) (short) 100, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.Chronology chronology12 = zonedChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology11.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period6 = period4.withPeriodType(periodType5);
        org.joda.time.Period period7 = period2.plus((org.joda.time.ReadablePeriod) period4);
        org.joda.time.Period period8 = new org.joda.time.Period();
        int int9 = period8.size();
        org.joda.time.Period period10 = period8.negated();
        int int11 = period8.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter12 = null;
        java.lang.String str13 = period8.toString(periodFormatter12);
        org.joda.time.DurationFieldType durationFieldType15 = period8.getFieldType(0);
        org.joda.time.Days days16 = period8.toStandardDays();
        org.joda.time.Period period17 = period7.withFields((org.joda.time.ReadablePeriod) days16);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PT0S" + "'", str13.equals("PT0S"));
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertNotNull(days16);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-210858120000000L), 604803200L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-210858724803200L) + "'", long2 == (-210858724803200L));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        try {
            long long43 = unsupportedDateTimeField34.set((-3155673600002L), (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        org.joda.time.DurationField durationField30 = dividedDateTimeField28.getDurationField();
        try {
            long long32 = dividedDateTimeField28.roundHalfCeiling(0L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 30 for weekOfWeekyear must be in the range [33,85]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertNotNull(durationField30);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekOfWeekyear();
        org.joda.time.DurationField durationField4 = gregorianChronology2.hours();
        org.joda.time.Period period5 = new org.joda.time.Period(0L, 0L, (org.joda.time.Chronology) gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
//        java.util.Locale locale13 = null;
//        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
//        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
//        int int23 = offsetDateTimeField18.get((long) (short) 100);
//        int int25 = offsetDateTimeField18.get((-10L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
//        int int30 = dividedDateTimeField28.get((-57599900L));
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
//        long long37 = offsetDateTimeField34.add(3200L, (int) (short) 1);
//        int int39 = offsetDateTimeField34.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial40 = null;
//        int int41 = offsetDateTimeField34.getMinimumValue(readablePartial40);
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = offsetDateTimeField34.getAsText((long) 8, locale43);
//        int int46 = offsetDateTimeField34.getMaximumValue(10L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) ' ');
//        long long53 = offsetDateTimeField50.add(3200L, (int) (short) 1);
//        int int55 = offsetDateTimeField50.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial56 = null;
//        java.util.Locale locale58 = null;
//        java.lang.String str59 = offsetDateTimeField50.getAsShortText(readablePartial56, (int) '4', locale58);
//        java.util.Locale locale60 = null;
//        int int61 = offsetDateTimeField50.getMaximumShortTextLength(locale60);
//        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology62.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, (int) ' ');
//        long long68 = offsetDateTimeField65.add(3200L, (int) (short) 1);
//        int int70 = offsetDateTimeField65.get((long) (short) 100);
//        int int72 = offsetDateTimeField65.get((-10L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = offsetDateTimeField65.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType73, (int) (byte) 10);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType73, (int) 'a');
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField78 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType73);
//        long long80 = remainderDateTimeField78.roundHalfCeiling((long) (-43104900));
//        long long82 = remainderDateTimeField78.roundCeiling((long) '#');
//        try {
//            long long85 = remainderDateTimeField78.set((long) (-2), (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for weekOfWeekyear must be in the range [0,9]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604803200L + "'", long37 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 33 + "'", int41 == 33);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "33" + "'", str44.equals("33"));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 85 + "'", int46 == 85);
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 604803200L + "'", long53 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 33 + "'", int55 == 33);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "52" + "'", str59.equals("52"));
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology62);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604803200L + "'", long68 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 33 + "'", int70 == 33);
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 33 + "'", int72 == 33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-259200100L) + "'", long80 == (-259200100L));
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 345599900L + "'", long82 == 345599900L);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period6 = new org.joda.time.Period();
        int int7 = period6.size();
        org.joda.time.Period period8 = period6.negated();
        boolean boolean9 = gregorianChronology5.equals((java.lang.Object) period8);
        org.joda.time.DurationField durationField10 = gregorianChronology5.weeks();
        org.joda.time.Period period11 = new org.joda.time.Period((-57599900L), (long) (short) 1, periodType2, (org.joda.time.Chronology) gregorianChronology5);
        try {
            int int13 = period11.getValue(32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        org.joda.time.ReadablePartial readablePartial36 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField38 = gregorianChronology37.eras();
        org.joda.time.Period period40 = org.joda.time.Period.hours(100);
        org.joda.time.Period period41 = period40.negated();
        int[] intArray43 = gregorianChronology37.get((org.joda.time.ReadablePeriod) period40, 0L);
        try {
            int int44 = unsupportedDateTimeField34.getMaximumValue(readablePartial36, intArray43);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(intArray43);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, 10);
        try {
            long long31 = dividedDateTimeField28.set(4L, 85);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 85 for weekOfWeekyear must be in the range [3,8]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, 10);
        org.joda.time.ReadablePartial readablePartial29 = null;
        int[] intArray32 = new int[] { 35 };
        try {
            int[] intArray34 = offsetDateTimeField3.addWrapPartial(readablePartial29, 0, intArray32, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.Chronology chronology12 = zonedChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.clockhourOfDay();
        java.lang.String str14 = zonedChronology11.toString();
        org.joda.time.Chronology chronology15 = zonedChronology11.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.Chronology chronology21 = zonedChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (byte) 0, true);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str14.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-100L) + "'", long24 == (-100L));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        org.joda.time.ReadablePartial readablePartial41 = null;
        java.util.Locale locale43 = null;
        try {
            java.lang.String str44 = unsupportedDateTimeField34.getAsText(readablePartial41, (int) (byte) -1, locale43);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply(110449353600052L, 259200108L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 110449353600052 * 259200108");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.add((long) (-2), (-1));
        java.util.Locale locale39 = null;
        try {
            java.lang.String str40 = unsupportedDateTimeField34.getAsText((-604800000L), locale39);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3155673600002L) + "'", long37 == (-3155673600002L));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int4 = cachedDateTimeZone2.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone5 = cachedDateTimeZone2.getUncachedZone();
        java.lang.String str6 = dateTimeZone5.toString();
        long long10 = dateTimeZone5.convertLocalToUTC(259200008L, false, 10L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 259200008L + "'", long10 == 259200008L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        boolean boolean31 = dividedDateTimeField28.isLeap(604803200L);
        int int33 = dividedDateTimeField28.get(19349999999L);
        org.joda.time.ReadablePartial readablePartial34 = null;
        java.util.Locale locale35 = null;
        try {
            java.lang.String str36 = dividedDateTimeField28.getAsShortText(readablePartial34, locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((-1));
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekOfWeekyear();
        org.joda.time.DurationField durationField4 = gregorianChronology2.hours();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.dayOfWeek();
        org.joda.time.DurationField durationField6 = gregorianChronology2.minutes();
        try {
            org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) (-1), (org.joda.time.Chronology) gregorianChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        org.joda.time.ReadablePartial readablePartial41 = null;
        org.joda.time.Period period43 = org.joda.time.Period.hours(100);
        org.joda.time.Period period44 = period43.negated();
        int[] intArray45 = period44.getValues();
        try {
            int int46 = unsupportedDateTimeField34.getMinimumValue(readablePartial41, intArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(intArray45);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.Chronology chronology12 = zonedChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.clockhourOfDay();
        java.lang.String str14 = zonedChronology11.toString();
        org.joda.time.Chronology chronology15 = zonedChronology11.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.Chronology chronology21 = zonedChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.ReadablePartial readablePartial23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period();
        int int25 = period24.size();
        org.joda.time.Period period26 = period24.negated();
        int int27 = period24.getMillis();
        int int28 = period24.getMonths();
        org.joda.time.PeriodType periodType29 = period24.getPeriodType();
        int int30 = period24.getMonths();
        org.joda.time.Period period32 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType33 = period32.getPeriodType();
        org.joda.time.Period period34 = period24.withPeriodType(periodType33);
        org.joda.time.Period period35 = period24.negated();
        org.joda.time.Duration duration36 = period35.toStandardDuration();
        org.joda.time.Period period38 = period35.plusMonths((int) '4');
        int[] intArray39 = period38.getValues();
        try {
            iSOChronology22.validate(readablePartial23, intArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str14.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 8 + "'", int25 == 8);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(duration36);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(intArray39);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter4 = null;
        java.lang.String str5 = period0.toString(periodFormatter4);
        org.joda.time.DurationFieldType durationFieldType7 = period0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField8 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField10 = gregorianChronology9.minutes();
        int int11 = unsupportedDurationField8.compareTo(durationField10);
        boolean boolean12 = unsupportedDurationField8.isPrecise();
        try {
            long long15 = unsupportedDurationField8.getMillis((long) (byte) 100, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0S" + "'", str5.equals("PT0S"));
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        int int13 = decoratedDurationField10.getDifference((-10L), 2440588L);
        java.lang.String str14 = decoratedDurationField10.getName();
        long long16 = decoratedDurationField10.getValueAsLong((long) (byte) 10);
        java.lang.String str17 = decoratedDurationField10.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "years" + "'", str14.equals("years"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DurationField[years]" + "'", str17.equals("DurationField[years]"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.Period period1 = new org.joda.time.Period((-43104900L));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period();
        int int3 = period2.size();
        org.joda.time.PeriodType periodType4 = period2.getPeriodType();
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType4);
        org.joda.time.Minutes minutes6 = period5.toStandardMinutes();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(minutes6);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, 10);
        try {
            long long30 = dividedDateTimeField28.roundCeiling(0L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 30 for weekOfWeekyear must be in the range [33,85]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        try {
            java.lang.String str39 = unsupportedDateTimeField34.getAsText((long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.Chronology chronology12 = zonedChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology11.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        long long13 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType14 = unsupportedDurationField11.getType();
        java.lang.String str15 = unsupportedDurationField11.getName();
        try {
            long long18 = unsupportedDurationField11.getMillis(365785006809600004L, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "years" + "'", str15.equals("years"));
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
//        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField3.getWrappedField();
//        long long16 = offsetDateTimeField3.roundHalfEven(3200L);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField20 = gregorianChronology19.eras();
//        org.joda.time.Period period22 = org.joda.time.Period.hours(100);
//        org.joda.time.Period period23 = period22.negated();
//        int[] intArray25 = gregorianChronology19.get((org.joda.time.ReadablePeriod) period22, 0L);
//        try {
//            int[] intArray27 = offsetDateTimeField3.set(readablePartial17, (int) (byte) 1, intArray25, 8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 8 for weekOfWeekyear must be in the range [33,85]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200100L) + "'", long16 == (-259200100L));
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(period22);
//        org.junit.Assert.assertNotNull(period23);
//        org.junit.Assert.assertNotNull(intArray25);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology6 = gregorianChronology2.withZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        int int11 = cachedDateTimeZone9.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone12 = cachedDateTimeZone9.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone12);
        org.joda.time.Period period14 = new org.joda.time.Period(10L, 110449353600052L, (org.joda.time.Chronology) zonedChronology13);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfWeek();
        org.joda.time.DurationField durationField4 = iSOChronology0.centuries();
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        java.lang.String str6 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.weekyearOfCentury();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[UTC]" + "'", str6.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int4 = cachedDateTimeZone2.getOffset(0L);
        int int6 = cachedDateTimeZone2.getOffsetFromLocal((long) (short) -1);
        long long8 = cachedDateTimeZone2.nextTransition((long) 4);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 4L + "'", long8 == 4L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.PeriodType periodType5 = period0.getPeriodType();
        int int6 = period0.getMonths();
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.Period period10 = period0.withPeriodType(periodType9);
        org.joda.time.Period period11 = period0.negated();
        org.joda.time.Period period13 = org.joda.time.Period.hours(100);
        org.joda.time.Period period14 = period13.negated();
        org.joda.time.Period period16 = period13.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass17 = period16.getClass();
        org.joda.time.Period period19 = period16.minusMonths((int) (short) 10);
        org.joda.time.Period period20 = period19.normalizedStandard();
        org.joda.time.PeriodType periodType21 = null;
        org.joda.time.Period period22 = period19.withPeriodType(periodType21);
        org.joda.time.Period period23 = period11.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.Period period25 = period19.withYears((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        java.lang.String str11 = decoratedDurationField10.getName();
        boolean boolean12 = decoratedDurationField10.isSupported();
        long long15 = decoratedDurationField10.getDifferenceAsLong((long) (byte) 100, (long) 100);
        boolean boolean16 = decoratedDurationField10.isSupported();
        long long19 = decoratedDurationField10.getDifferenceAsLong((-3935130120000000L), 259200035L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "years" + "'", str11.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1093091772L) + "'", long19 == (-1093091772L));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period3 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period5 = period3.withPeriodType(periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType4);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(6048000032L, (long) 33);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6047999999L + "'", long2 == 6047999999L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass5 = period4.getClass();
        org.joda.time.Period period7 = period4.minusMonths((int) (short) 10);
        org.joda.time.Period period8 = period7.normalizedStandard();
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Period period10 = period7.withPeriodType(periodType9);
        org.joda.time.Period period12 = period7.minusYears(0);
        org.joda.time.Period period14 = period7.withSeconds(2);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        long long13 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType14 = unsupportedDurationField11.getType();
        java.lang.String str15 = unsupportedDurationField11.getName();
        boolean boolean16 = unsupportedDurationField11.isPrecise();
        try {
            long long19 = unsupportedDurationField11.getValueAsLong(259200035L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "years" + "'", str15.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isSupported();
        try {
            int int15 = unsupportedDurationField11.getDifference((-230400000L), 259200008L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 0, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        try {
            long long42 = unsupportedDateTimeField34.roundCeiling(360000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Weeks weeks2 = period1.toStandardWeeks();
        org.joda.time.DurationFieldType[] durationFieldTypeArray3 = period1.getFieldTypes();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.forFields(durationFieldTypeArray3);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(weeks2);
        org.junit.Assert.assertNotNull(durationFieldTypeArray3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.PeriodType periodType2 = period0.getPeriodType();
        java.lang.String str3 = periodType2.getName();
        int int4 = periodType2.size();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = periodType2.indexOf(durationFieldType5);
        org.joda.time.Period period8 = org.joda.time.Period.hours(100);
        org.joda.time.Period period9 = period8.negated();
        int int10 = period9.size();
        org.joda.time.Period period11 = new org.joda.time.Period();
        int int12 = period11.size();
        org.joda.time.Period period13 = period11.negated();
        org.joda.time.DurationFieldType durationFieldType14 = null;
        int int15 = period13.indexOf(durationFieldType14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(durationFieldType17, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.Period period23 = period9.withFieldAdded(durationFieldType17, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology28 = gregorianChronology24.withZone(dateTimeZone27);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone31 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone30);
        int int33 = cachedDateTimeZone31.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone34 = cachedDateTimeZone31.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology35 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology24, dateTimeZone34);
        org.joda.time.Chronology chronology36 = zonedChronology35.withUTC();
        org.joda.time.Period period37 = new org.joda.time.Period();
        int int38 = period37.size();
        org.joda.time.Period period39 = period37.negated();
        int int40 = period37.getDays();
        boolean boolean41 = zonedChronology35.equals((java.lang.Object) int40);
        boolean boolean42 = period9.equals((java.lang.Object) zonedChronology35);
        boolean boolean43 = periodType2.equals((java.lang.Object) period9);
        org.joda.time.PeriodType periodType44 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Standard" + "'", str3.equals("Standard"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(cachedDateTimeZone31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(zonedChronology35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 8 + "'", int38 == 8);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(periodType44);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.String str4 = cachedDateTimeZone2.getShortName((-244803200L));
//        java.lang.String str6 = cachedDateTimeZone2.getShortName((long) (short) 0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PST", "10.0");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test345");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
//        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField3.getWrappedField();
//        long long17 = offsetDateTimeField3.add((long) 4, (int) '4');
//        long long19 = offsetDateTimeField3.roundHalfFloor((-58571700L));
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField3.getAsText(10L, locale21);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        java.util.Locale locale24 = null;
//        try {
//            java.lang.String str25 = offsetDateTimeField3.getAsShortText(readablePartial23, locale24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31449600004L + "'", long17 == 31449600004L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200100L) + "'", long19 == (-259200100L));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "33" + "'", str22.equals("33"));
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        long long13 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType14 = unsupportedDurationField11.getType();
        java.lang.String str15 = unsupportedDurationField11.getName();
        try {
            int int18 = unsupportedDurationField11.getDifference((-259200000L), 3200L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "years" + "'", str15.equals("years"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        boolean boolean41 = unsupportedDateTimeField34.isLenient();
        java.util.Locale locale43 = null;
        try {
            java.lang.String str44 = unsupportedDateTimeField34.getAsText(19353599999L, locale43);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        boolean boolean13 = unsupportedDurationField11.isPrecise();
        try {
            int int15 = unsupportedDurationField11.getValue((long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-43104900), (int) (short) -1, 100, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(604803200, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 604803199 + "'", int2 == 604803199);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "10");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        java.util.TimeZone timeZone16 = fixedDateTimeZone15.toTimeZone();
        org.joda.time.Period period18 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period20 = period18.withPeriodType(periodType19);
        boolean boolean21 = fixedDateTimeZone15.equals((java.lang.Object) periodType19);
        try {
            org.joda.time.Period period22 = new org.joda.time.Period((java.lang.Object) durationFieldType9, periodType19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.DurationFieldType$StandardDurationFieldType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        long long13 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType14 = unsupportedDurationField11.getType();
        try {
            long long16 = unsupportedDurationField11.getValueAsLong(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType14);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
//        int int9 = cachedDateTimeZone7.getOffset(0L);
//        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        java.lang.String str15 = dateTimeZone13.getName((long) 1);
//        java.lang.String str17 = dateTimeZone13.getName(0L);
//        org.joda.time.Chronology chronology18 = zonedChronology11.withZone(dateTimeZone13);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Coordinated Universal Time" + "'", str17.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(4L, 0L);
        org.joda.time.ReadablePartial readablePartial7 = null;
        int int8 = offsetDateTimeField3.getMinimumValue(readablePartial7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = offsetDateTimeField3.getAsText(readablePartial9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 4L + "'", long6 == 4L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.PeriodType periodType2 = period0.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        boolean boolean4 = periodType2.isSupported(durationFieldType3);
        org.joda.time.Period period5 = new org.joda.time.Period();
        int int6 = period5.size();
        org.joda.time.Period period7 = period5.negated();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = period7.indexOf(durationFieldType8);
        org.joda.time.DurationFieldType durationFieldType11 = period7.getFieldType((int) (short) 0);
        int int12 = periodType2.indexOf(durationFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(durationFieldType11, (java.lang.Number) (byte) 100, (java.lang.Number) 10.0d, (java.lang.Number) 1.0f);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(durationFieldType11, (java.lang.Number) (-43104900), (java.lang.Number) (short) -1, (java.lang.Number) (-3155673600002L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        org.joda.time.PeriodType periodType1 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withMinutesRemoved();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        int int9 = fixedDateTimeZone7.getOffset(0L);
        boolean boolean10 = periodType1.equals((java.lang.Object) fixedDateTimeZone7);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("PT100H");
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        try {
            java.lang.String str36 = unsupportedDateTimeField34.getAsShortText((long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add((long) (-1), (int) ' ');
        int int8 = offsetDateTimeField3.getLeapAmount((-210858120000000L));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField3.getAsText((-58571700L), locale10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19353599999L + "'", long6 == 19353599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "33" + "'", str11.equals("33"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "PeriodType[StandardNoYears]", "");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "3", "years");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getShortName(locale9, "97", "PST");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType2 = period1.getPeriodType();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period5 = org.joda.time.Period.hours(100);
        org.joda.time.Period period6 = period5.negated();
        int int7 = period6.size();
        org.joda.time.Period period8 = new org.joda.time.Period();
        int int9 = period8.size();
        org.joda.time.Period period10 = period8.negated();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period10.indexOf(durationFieldType11);
        org.joda.time.DurationFieldType durationFieldType14 = period10.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(durationFieldType14, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.Period period20 = period6.withFieldAdded(durationFieldType14, (int) (byte) 100);
        boolean boolean21 = periodType3.isSupported(durationFieldType14);
        int int22 = period1.get(durationFieldType14);
        org.joda.time.Weeks weeks23 = period1.toStandardWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(weeks23);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 10, 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 350L + "'", long2 == 350L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        int int10 = offsetDateTimeField3.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField3.getType();
        long long14 = offsetDateTimeField3.getDifferenceAsLong(1260000000L, (long) (short) 1);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = offsetDateTimeField3.getMaximumValue(readablePartial15);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray19 = null;
        try {
            int[] intArray21 = offsetDateTimeField3.add(readablePartial17, (int) '4', intArray19, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 85 + "'", int16 == 85);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        long long13 = unsupportedDurationField11.getUnitMillis();
        boolean boolean14 = unsupportedDurationField11.isSupported();
        try {
            int int16 = unsupportedDurationField11.getValue(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-259200000L));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.Period period10 = org.joda.time.Period.hours(100);
        org.joda.time.Period period11 = period10.negated();
        org.joda.time.Period period13 = period10.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass14 = period13.getClass();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType16 = periodType15.withSecondsRemoved();
        org.joda.time.PeriodType periodType17 = org.joda.time.DateTimeUtils.getPeriodType(periodType15);
        org.joda.time.Period period18 = period13.normalizedStandard(periodType17);
        org.joda.time.Period period19 = new org.joda.time.Period(31449600004L, periodType17);
        int int20 = periodType17.size();
        try {
            org.joda.time.Period period21 = new org.joda.time.Period((int) 'a', 604803199, (int) (byte) 10, 85, 2, 604803199, 9, 604803199, periodType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) ' ');
        long long9 = offsetDateTimeField6.add(3200L, (int) (short) 1);
        int int11 = offsetDateTimeField6.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField6.getAsShortText(readablePartial12, (int) '4', locale14);
        java.util.Locale locale16 = null;
        int int17 = offsetDateTimeField6.getMaximumShortTextLength(locale16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) ' ');
        long long24 = offsetDateTimeField21.add(3200L, (int) (short) 1);
        int int26 = offsetDateTimeField21.get((long) (short) 100);
        int int28 = offsetDateTimeField21.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField21.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType29, (int) (byte) 10);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 2);
        org.joda.time.PeriodType periodType36 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType37 = periodType36.withSecondsRemoved();
        org.joda.time.PeriodType periodType38 = org.joda.time.DateTimeUtils.getPeriodType(periodType36);
        org.joda.time.PeriodType periodType39 = periodType38.withMinutesRemoved();
        org.joda.time.PeriodType periodType40 = periodType39.withWeeksRemoved();
        org.joda.time.PeriodType periodType41 = periodType40.withMonthsRemoved();
        org.joda.time.Period period42 = new org.joda.time.Period((-244803200L), (-1L), periodType40);
        try {
            org.joda.time.Period period43 = new org.joda.time.Period((java.lang.Object) dateTimeFieldType29, periodType40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.DateTimeFieldType$StandardDateTimeFieldType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 604803200L + "'", long9 == 604803200L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "52" + "'", str15.equals("52"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 604803200L + "'", long24 == 604803200L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 33 + "'", int26 == 33);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 33 + "'", int28 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(periodType41);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.plusYears(0);
        org.joda.time.Period period7 = period3.minusMinutes((int) (byte) -1);
        org.joda.time.Duration duration8 = period3.toStandardDuration();
        long long9 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.minusMinutes((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period1.toDurationTo(readableInstant5);
        long long7 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration6);
        long long8 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration6);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant9);
        org.joda.time.MutablePeriod mutablePeriod11 = period10.toMutablePeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 360000000L + "'", long7 == 360000000L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 360000000L + "'", long8 == 360000000L);
        org.junit.Assert.assertNotNull(mutablePeriod11);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int4 = cachedDateTimeZone2.getOffset(0L);
        int int6 = cachedDateTimeZone2.getOffsetFromLocal((long) (short) -1);
        int int8 = cachedDateTimeZone2.getOffset((long) ' ');
        java.lang.String str10 = cachedDateTimeZone2.getNameKey((-244803200L));
        int int12 = cachedDateTimeZone2.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone13 = cachedDateTimeZone2.getUncachedZone();
        java.util.TimeZone timeZone14 = dateTimeZone13.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        org.joda.time.ReadablePartial readablePartial36 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period39 = new org.joda.time.Period();
        int int40 = period39.size();
        org.joda.time.Period period41 = period39.negated();
        boolean boolean42 = gregorianChronology38.equals((java.lang.Object) period41);
        org.joda.time.DurationField durationField43 = gregorianChronology38.weeks();
        org.joda.time.DurationField durationField44 = gregorianChronology38.millis();
        org.joda.time.DurationField durationField45 = gregorianChronology38.hours();
        org.joda.time.Period period46 = new org.joda.time.Period();
        boolean boolean48 = period46.equals((java.lang.Object) false);
        org.joda.time.Period period50 = period46.plusMillis((int) (byte) 1);
        int[] intArray53 = gregorianChronology38.get((org.joda.time.ReadablePeriod) period46, (-10L), (long) (short) 0);
        java.util.Locale locale55 = null;
        try {
            int[] intArray56 = unsupportedDateTimeField34.set(readablePartial36, (int) (byte) 100, intArray53, "", locale55);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 8 + "'", int40 == 8);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertNotNull(intArray53);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add((long) (-1), (int) ' ');
        int int8 = offsetDateTimeField3.getLeapAmount((-210858120000000L));
        long long11 = offsetDateTimeField3.addWrapField(1000L, 3);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19353599999L + "'", long6 == 19353599999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1814401000L + "'", long11 == 1814401000L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsText(readablePartial9, 8, locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumTextLength(locale13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField16 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "8" + "'", str12.equals("8"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        long long8 = durationField5.subtract(0L, 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.Object obj3 = null;
        boolean boolean4 = cachedDateTimeZone2.equals(obj3);
        long long6 = cachedDateTimeZone2.previousTransition((-210866414400100L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-210866414400100L) + "'", long6 == (-210866414400100L));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.ReadableInstant readableInstant3 = null;
        int int4 = cachedDateTimeZone2.getOffset(readableInstant3);
        java.lang.String str5 = cachedDateTimeZone2.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.Period period4 = org.joda.time.Period.months((int) '4');
        int[] intArray6 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period4, (long) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone15);
        org.joda.time.Chronology chronology17 = zonedChronology12.withZone(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology12.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone19 = zonedChronology12.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.PeriodType periodType5 = period0.getPeriodType();
        int int6 = period0.getMonths();
        org.joda.time.Period period8 = period0.minusSeconds((int) '4');
        org.joda.time.Seconds seconds9 = period0.toStandardSeconds();
        org.joda.time.PeriodType periodType10 = period0.getPeriodType();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(seconds9);
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.Period period6 = org.joda.time.Period.hours(100);
        org.joda.time.Period period7 = period6.negated();
        org.joda.time.Period period9 = period6.minusMinutes((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = period9.indexOf(durationFieldType10);
        long long14 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period9, (long) (byte) -1, 0);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.dayOfWeek();
        try {
            long long20 = gregorianChronology0.getDateTimeMillis((int) (short) 1, (int) '#', 100, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test382");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add((long) (-1), (int) ' ');
//        long long9 = offsetDateTimeField3.add((long) (short) 0, (long) (byte) 1);
//        long long11 = offsetDateTimeField3.roundHalfCeiling((-230400000L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19353599999L + "'", long6 == 19353599999L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 604800000L + "'", long9 == 604800000L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-259200100L) + "'", long11 == (-259200100L));
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        java.lang.String str1 = periodType0.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PeriodType[YearDayTime]" + "'", str1.equals("PeriodType[YearDayTime]"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        try {
            org.joda.time.Period period1 = new org.joda.time.Period(11044935360006200L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 3068037600");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeUtils.getZone(dateTimeZone3);
        java.util.TimeZone timeZone6 = dateTimeZone5.toTimeZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField8 = gregorianChronology0.years();
        boolean boolean10 = gregorianChronology0.equals((java.lang.Object) "UTC");
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.dayOfYear();
        org.joda.time.DurationField durationField12 = gregorianChronology0.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.hourOfHalfday();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.minuteOfHour();
        org.joda.time.DurationField durationField8 = gregorianChronology3.weeks();
        boolean boolean9 = iSOChronology0.equals((java.lang.Object) durationField8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        try {
            int int36 = unsupportedDateTimeField34.getMaximumValue((long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period();
        int int6 = period5.size();
        org.joda.time.PeriodType periodType7 = period5.getPeriodType();
        org.joda.time.Period period8 = new org.joda.time.Period(readableDuration3, readableInstant4, periodType7);
        org.joda.time.PeriodType periodType9 = periodType7.withYearsRemoved();
        org.joda.time.PeriodType periodType10 = periodType7.withHoursRemoved();
        org.joda.time.PeriodType periodType11 = org.joda.time.DateTimeUtils.getPeriodType(periodType10);
        org.joda.time.Period period12 = period1.normalizedStandard(periodType11);
        org.joda.time.PeriodType periodType13 = periodType11.withMinutesRemoved();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.Period period0 = new org.joda.time.Period();
        boolean boolean2 = period0.equals((java.lang.Object) false);
        org.joda.time.Period period4 = period0.plusMillis((int) (byte) 1);
        org.joda.time.Weeks weeks5 = period0.toStandardWeeks();
        org.joda.time.Period period7 = period0.minusSeconds((int) (byte) 10);
        org.joda.time.Period period9 = period0.minusDays((-2));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(weeks5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (short) -1, (-230400000L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 230400000 + "'", int2 == 230400000);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.Chronology chronology12 = zonedChronology11.withUTC();
        org.joda.time.DateTimeZone dateTimeZone13 = zonedChronology11.getZone();
        org.joda.time.ReadableInstant readableInstant14 = null;
        int int15 = dateTimeZone13.getOffset(readableInstant14);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.Period period1 = org.joda.time.Period.millis(360000000);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology7 = gregorianChronology3.withZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        int int12 = cachedDateTimeZone10.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone13 = cachedDateTimeZone10.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone13);
        org.joda.time.Chronology chronology15 = zonedChronology14.withUTC();
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology14.clockhourOfDay();
        java.lang.String str17 = zonedChronology14.toString();
        org.joda.time.Chronology chronology18 = zonedChronology14.withUTC();
        org.joda.time.Period period19 = new org.joda.time.Period((long) (byte) 100, (org.joda.time.Chronology) zonedChronology14);
        boolean boolean20 = periodType0.equals((java.lang.Object) (byte) 100);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str17.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        java.util.Locale locale16 = null;
        try {
            long long17 = offsetDateTimeField3.set((-210866673600000L), "ISOChronology[UTC]", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ISOChronology[UTC]\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
//        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField3.getWrappedField();
//        long long17 = offsetDateTimeField3.add((long) 4, (int) '4');
//        long long19 = offsetDateTimeField3.roundHalfFloor((-58571700L));
//        long long21 = offsetDateTimeField3.remainder((long) 8);
//        int int23 = offsetDateTimeField3.getMinimumValue((-3934918440000000L));
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = offsetDateTimeField3.getAsText((long) (short) 0, locale25);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31449600004L + "'", long17 == 31449600004L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200100L) + "'", long19 == (-259200100L));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 259200108L + "'", long21 == 259200108L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "33" + "'", str26.equals("33"));
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) -1);
        org.joda.time.Period period3 = period1.minusMillis(0);
        org.joda.time.Period period5 = period3.withMillis(1);
        org.joda.time.Period period6 = period3.negated();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType2 = period1.getPeriodType();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period5 = org.joda.time.Period.hours(100);
        org.joda.time.Period period6 = period5.negated();
        int int7 = period6.size();
        org.joda.time.Period period8 = new org.joda.time.Period();
        int int9 = period8.size();
        org.joda.time.Period period10 = period8.negated();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = period10.indexOf(durationFieldType11);
        org.joda.time.DurationFieldType durationFieldType14 = period10.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(durationFieldType14, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.Period period20 = period6.withFieldAdded(durationFieldType14, (int) (byte) 100);
        boolean boolean21 = periodType3.isSupported(durationFieldType14);
        int int22 = period1.get(durationFieldType14);
        org.joda.time.Period period24 = period1.plusMillis((int) (byte) 10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(period24);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.add((long) (-2), (-1));
        try {
            long long39 = unsupportedDateTimeField34.roundFloor((long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3155673600002L) + "'", long37 == (-3155673600002L));
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
//        int int9 = cachedDateTimeZone7.getOffset(0L);
//        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        java.lang.String str15 = dateTimeZone13.getName((long) 1);
//        java.lang.String str17 = dateTimeZone13.getName(0L);
//        org.joda.time.Chronology chronology18 = zonedChronology11.withZone(dateTimeZone13);
//        java.lang.String str19 = zonedChronology11.toString();
//        try {
//            long long24 = zonedChronology11.getDateTimeMillis((int) ' ', (int) (byte) 10, 0, 35);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Coordinated Universal Time" + "'", str17.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str19.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        long long32 = dividedDateTimeField28.add((-3935130120000000L), (long) '#');
        try {
            long long34 = dividedDateTimeField28.roundHalfCeiling(32L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 30 for weekOfWeekyear must be in the range [33,85]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3934918440000000L) + "'", long32 == (-3934918440000000L));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        java.lang.String str38 = unsupportedDateTimeField34.getName();
        java.util.Locale locale39 = null;
        try {
            int int40 = unsupportedDateTimeField34.getMaximumTextLength(locale39);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "weekOfWeekyear" + "'", str38.equals("weekOfWeekyear"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (short) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.PeriodType periodType2 = period0.getPeriodType();
        org.joda.time.Period period4 = org.joda.time.Period.years((int) (short) -1);
        org.joda.time.Period period6 = period4.plusWeeks((int) '4');
        int int7 = period6.size();
        org.joda.time.Period period8 = period0.plus((org.joda.time.ReadablePeriod) period6);
        org.joda.time.Period period9 = period0.toPeriod();
        org.joda.time.Period period11 = period9.plusWeeks(35);
        org.joda.time.PeriodType periodType12 = period11.getPeriodType();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        java.lang.String str38 = unsupportedDateTimeField34.getName();
        java.util.Locale locale41 = null;
        try {
            long long42 = unsupportedDateTimeField34.set(1L, "PST", locale41);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "weekOfWeekyear" + "'", str38.equals("weekOfWeekyear"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(3600000L, (long) (byte) 100, chronology2);
        org.joda.time.Period period5 = period3.minusMinutes(32);
        org.joda.time.Period period7 = period3.withMinutes(0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

//    @Test
//    public void test409() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test409");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
//        int int15 = offsetDateTimeField3.getMaximumValue(10L);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = offsetDateTimeField3.getAsText((long) ' ', locale17);
//        long long20 = offsetDateTimeField3.roundHalfFloor(1000L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "33" + "'", str18.equals("33"));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-259200100L) + "'", long20 == (-259200100L));
//    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(2, 230400000, 33, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
//        java.util.Locale locale13 = null;
//        int int14 = offsetDateTimeField3.getMaximumTextLength(locale13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
//        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
//        int int23 = offsetDateTimeField18.get((long) (short) 100);
//        int int25 = offsetDateTimeField18.get((-10L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, 10);
//        long long30 = offsetDateTimeField3.roundCeiling((long) (byte) 0);
//        org.joda.time.ReadablePartial readablePartial31 = null;
//        java.util.Locale locale32 = null;
//        try {
//            java.lang.String str33 = offsetDateTimeField3.getAsShortText(readablePartial31, locale32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 345599900L + "'", long30 == 345599900L);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(110449353600052L, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-110449353600052L) + "'", long2 == (-110449353600052L));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Days days3 = period2.toStandardDays();
        int[] intArray4 = period2.getValues();
        org.joda.time.format.PeriodFormatter periodFormatter5 = null;
        java.lang.String str6 = period2.toString(periodFormatter5);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(days3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT-100H" + "'", str6.equals("PT-100H"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) zonedChronology11, dateTimeZone16);
        try {
            long long22 = zonedChronology17.getDateTimeMillis((-1), 0, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.yearOfCentury();
        org.joda.time.DurationField durationField6 = gregorianChronology0.weekyears();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Coordinated Universal Time", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Coordinated Universal Time/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
//        boolean boolean12 = offsetDateTimeField3.isLeap(259200135L);
//        long long14 = offsetDateTimeField3.roundFloor((long) 9);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200100L) + "'", long14 == (-259200100L));
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        try {
            long long38 = unsupportedDateTimeField34.add((long) '#', (-43104900));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -4310490000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = iSOChronology1.weekyears();
        java.lang.String str3 = iSOChronology1.toString();
        org.joda.time.DurationField durationField4 = iSOChronology1.centuries();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField5 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ISOChronology[UTC]" + "'", str3.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        java.lang.String str11 = illegalFieldValueException10.getFieldName();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "years" + "'", str11.equals("years"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.DurationField durationField29 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.weekOfWeekyear();
        org.joda.time.DurationField durationField32 = gregorianChronology30.hours();
        org.joda.time.Period period33 = new org.joda.time.Period();
        int int34 = period33.size();
        org.joda.time.Period period35 = period33.negated();
        org.joda.time.DurationFieldType durationFieldType36 = null;
        int int37 = period35.indexOf(durationFieldType36);
        org.joda.time.DurationFieldType durationFieldType39 = period35.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField40 = new org.joda.time.field.DecoratedDurationField(durationField32, durationFieldType39);
        java.lang.String str41 = decoratedDurationField40.getName();
        boolean boolean42 = decoratedDurationField40.isSupported();
        long long45 = decoratedDurationField40.getDifferenceAsLong((long) (byte) 100, (long) 100);
        long long48 = decoratedDurationField40.add((-19357200001L), (int) '4');
        long long50 = decoratedDurationField40.getValueAsLong((-259200000L));
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField51 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType26, durationField29, (org.joda.time.DurationField) decoratedDurationField40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 8 + "'", int34 == 8);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "years" + "'", str41.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-19170000001L) + "'", long48 == (-19170000001L));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-72L) + "'", long50 == (-72L));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        int int15 = offsetDateTimeField3.getMaximumValue(10L);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = offsetDateTimeField3.getAsShortText(readablePartial16, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add((long) (-1), (int) ' ');
//        long long8 = offsetDateTimeField3.roundFloor((long) (byte) 100);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField3.getMaximumShortTextLength(locale9);
//        long long12 = offsetDateTimeField3.roundHalfCeiling((long) 85);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19353599999L + "'", long6 == 19353599999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-259200100L) + "'", long8 == (-259200100L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-259200100L) + "'", long12 == (-259200100L));
//    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        boolean boolean5 = dateTimeZone2.isStandardOffset((-62032176000100L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        int int10 = offsetDateTimeField3.get((-10L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField3.getType();
//        long long13 = offsetDateTimeField3.roundFloor((-110449353600052L));
//        java.lang.String str15 = offsetDateTimeField3.getAsShortText(1814401000L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-110449440000100L) + "'", long13 == (-110449440000100L));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "36" + "'", str15.equals("36"));
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.PeriodType periodType2 = period0.getPeriodType();
        java.lang.String str3 = periodType2.getName();
        int int4 = periodType2.size();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = periodType2.indexOf(durationFieldType5);
        org.joda.time.Period period8 = org.joda.time.Period.hours(100);
        org.joda.time.Period period9 = period8.negated();
        int int10 = period9.size();
        org.joda.time.Period period11 = new org.joda.time.Period();
        int int12 = period11.size();
        org.joda.time.Period period13 = period11.negated();
        org.joda.time.DurationFieldType durationFieldType14 = null;
        int int15 = period13.indexOf(durationFieldType14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(durationFieldType17, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.Period period23 = period9.withFieldAdded(durationFieldType17, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology28 = gregorianChronology24.withZone(dateTimeZone27);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone31 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone30);
        int int33 = cachedDateTimeZone31.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone34 = cachedDateTimeZone31.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology35 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology24, dateTimeZone34);
        org.joda.time.Chronology chronology36 = zonedChronology35.withUTC();
        org.joda.time.Period period37 = new org.joda.time.Period();
        int int38 = period37.size();
        org.joda.time.Period period39 = period37.negated();
        int int40 = period37.getDays();
        boolean boolean41 = zonedChronology35.equals((java.lang.Object) int40);
        boolean boolean42 = period9.equals((java.lang.Object) zonedChronology35);
        boolean boolean43 = periodType2.equals((java.lang.Object) period9);
        int int44 = period9.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Standard" + "'", str3.equals("Standard"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(cachedDateTimeZone31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(zonedChronology35);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 8 + "'", int38 == 8);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 8 + "'", int44 == 8);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        long long13 = unsupportedDurationField11.getUnitMillis();
        boolean boolean14 = unsupportedDurationField11.isSupported();
        try {
            int int17 = unsupportedDurationField11.getValue((long) 'a', (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str1 = dateTimeZone0.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PT100H" + "'", str1.equals("PT100H"));
//    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
//        java.lang.String str2 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField3 = iSOChronology0.centuries();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.Chronology chronology5 = iSOChronology0.withZone(dateTimeZone4);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone4.getName((long) '4', locale7);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Coordinated Universal Time" + "'", str8.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.PeriodType periodType5 = period0.getPeriodType();
        org.joda.time.PeriodType periodType6 = periodType5.withDaysRemoved();
        org.joda.time.PeriodType periodType7 = periodType5.withMillisRemoved();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(6, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.PeriodType periodType5 = period0.getPeriodType();
        int int6 = period0.getMonths();
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.Period period10 = period0.withPeriodType(periodType9);
        org.joda.time.PeriodType periodType11 = periodType9.withYearsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.DurationField durationField14 = gregorianChronology12.hours();
        org.joda.time.Period period15 = new org.joda.time.Period();
        int int16 = period15.size();
        org.joda.time.Period period17 = period15.negated();
        org.joda.time.DurationFieldType durationFieldType18 = null;
        int int19 = period17.indexOf(durationFieldType18);
        org.joda.time.DurationFieldType durationFieldType21 = period17.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField22 = new org.joda.time.field.DecoratedDurationField(durationField14, durationFieldType21);
        java.lang.String str23 = decoratedDurationField22.getName();
        boolean boolean24 = decoratedDurationField22.isSupported();
        long long27 = decoratedDurationField22.getDifferenceAsLong((long) (byte) 100, (long) 100);
        java.lang.String str28 = decoratedDurationField22.toString();
        boolean boolean29 = periodType11.equals((java.lang.Object) decoratedDurationField22);
        long long31 = decoratedDurationField22.getMillis(0);
        boolean boolean32 = decoratedDurationField22.isPrecise();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "years" + "'", str23.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DurationField[years]" + "'", str28.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) 10, 0, 100);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.add((long) (-2), (-1));
        try {
            int int39 = unsupportedDateTimeField34.getMinimumValue((long) (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3155673600002L) + "'", long37 == (-3155673600002L));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        java.lang.String str11 = decoratedDurationField10.getName();
        boolean boolean12 = decoratedDurationField10.isSupported();
        long long15 = decoratedDurationField10.getDifferenceAsLong((long) (byte) 100, (long) 100);
        long long18 = decoratedDurationField10.add((-19357200001L), (int) '4');
        long long20 = decoratedDurationField10.getValueAsLong((-259200000L));
        long long22 = decoratedDurationField10.getValueAsLong((long) (byte) -1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "years" + "'", str11.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-19170000001L) + "'", long18 == (-19170000001L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-72L) + "'", long20 == (-72L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
//        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField3.getWrappedField();
//        long long16 = offsetDateTimeField3.roundHalfEven(3200L);
//        java.util.Locale locale17 = null;
//        int int18 = offsetDateTimeField3.getMaximumTextLength(locale17);
//        int int20 = offsetDateTimeField3.get((-259200000L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200100L) + "'", long16 == (-259200100L));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 33 + "'", int20 == 33);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.era();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, (int) '#', 360000000, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for era must be in the range [360000000,8]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period3 = period1.withPeriodType(periodType2);
        org.joda.time.format.PeriodFormatter periodFormatter4 = null;
        java.lang.String str5 = period1.toString(periodFormatter4);
        org.joda.time.Period period7 = period1.minusWeeks(4);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT100H" + "'", str5.equals("PT100H"));
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        java.util.Locale locale30 = null;
        java.lang.String str31 = dividedDateTimeField28.getAsShortText((int) 'a', locale30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField33 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "97" + "'", str31.equals("97"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            long long7 = gregorianChronology0.set(readablePartial5, 32L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(dateTimeFieldType6);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        org.joda.time.ReadablePartial readablePartial36 = null;
        java.util.Locale locale38 = null;
        try {
            java.lang.String str39 = unsupportedDateTimeField34.getAsText(readablePartial36, (int) (byte) 10, locale38);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.PeriodType periodType2 = period0.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        boolean boolean4 = periodType2.isSupported(durationFieldType3);
        org.joda.time.Period period5 = new org.joda.time.Period();
        int int6 = period5.size();
        org.joda.time.Period period7 = period5.negated();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = period7.indexOf(durationFieldType8);
        org.joda.time.DurationFieldType durationFieldType11 = period7.getFieldType((int) (short) 0);
        int int12 = periodType2.indexOf(durationFieldType11);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(durationFieldType11, (java.lang.Number) (byte) 100, (java.lang.Number) 10.0d, (java.lang.Number) 1.0f);
        java.lang.Number number17 = illegalFieldValueException16.getLowerBound();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 10.0d + "'", number17.equals(10.0d));
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
//        long long15 = offsetDateTimeField3.roundFloor((long) 2);
//        org.joda.time.DurationField durationField16 = offsetDateTimeField3.getRangeDurationField();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, 35);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200100L) + "'", long15 == (-259200100L));
//        org.junit.Assert.assertNotNull(durationField16);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        long long13 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType14 = unsupportedDurationField11.getType();
        java.lang.String str15 = unsupportedDurationField11.getName();
        java.lang.String str16 = unsupportedDurationField11.toString();
        try {
            long long19 = unsupportedDurationField11.add(0L, 604803199);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "years" + "'", str15.equals("years"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UnsupportedDurationField[years]" + "'", str16.equals("UnsupportedDurationField[years]"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 10, 0, 8, 0);
        org.joda.time.Period period6 = period4.minusYears(33);
        org.joda.time.format.PeriodFormatter periodFormatter7 = null;
        java.lang.String str8 = period6.toString(periodFormatter7);
        org.joda.time.Period period9 = period6.toPeriod();
        try {
            org.joda.time.DurationFieldType durationFieldType11 = period6.getFieldType(32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "P-33YT10H8S" + "'", str8.equals("P-33YT10H8S"));
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int4 = cachedDateTimeZone2.getOffset(0L);
        int int6 = cachedDateTimeZone2.getOffsetFromLocal((long) (short) -1);
        long long8 = cachedDateTimeZone2.nextTransition((long) 4);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        org.joda.time.ReadablePartial readablePartial10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period();
        int int12 = period11.size();
        org.joda.time.Period period13 = period11.negated();
        int int14 = period11.getMillis();
        int int15 = period11.getMonths();
        org.joda.time.PeriodType periodType16 = period11.getPeriodType();
        int int17 = period11.getMonths();
        org.joda.time.Period period19 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType20 = period19.getPeriodType();
        org.joda.time.Period period21 = period11.withPeriodType(periodType20);
        org.joda.time.Period period22 = period11.negated();
        org.joda.time.Duration duration23 = period22.toStandardDuration();
        org.joda.time.Period period25 = period22.plusMonths((int) '4');
        int[] intArray26 = period25.getValues();
        try {
            gregorianChronology9.validate(readablePartial10, intArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 4L + "'", long8 == 4L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        boolean boolean41 = unsupportedDateTimeField34.isLenient();
        java.util.Locale locale43 = null;
        try {
            java.lang.String str44 = unsupportedDateTimeField34.getAsShortText(3, locale43);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("PeriodType[YearDayTime]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PeriodType[YearDayTime]\" is malformed at \"eriodType[YearDayTime]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        boolean boolean36 = unsupportedDateTimeField34.isLenient();
        java.util.Locale locale37 = null;
        try {
            int int38 = unsupportedDateTimeField34.getMaximumShortTextLength(locale37);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
//        java.util.Locale locale13 = null;
//        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
//        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
//        int int23 = offsetDateTimeField18.get((long) (short) 100);
//        int int25 = offsetDateTimeField18.get((-10L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
//        int int29 = dividedDateTimeField28.getDivisor();
//        long long32 = dividedDateTimeField28.add((-3935130120000000L), (long) '#');
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField28, 10);
//        long long37 = dividedDateTimeField28.set((long) 100, 4);
//        long long39 = dividedDateTimeField28.roundFloor((-210858134399967L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3934918440000000L) + "'", long32 == (-3934918440000000L));
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 6048000100L + "'", long37 == 6048000100L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-210859545600100L) + "'", long39 == (-210859545600100L));
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        int int6 = fixedDateTimeZone4.getOffset(0L);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        long long9 = fixedDateTimeZone4.previousTransition(0L);
        java.lang.String str11 = fixedDateTimeZone4.getNameKey(4L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "8" + "'", str11.equals("8"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        boolean boolean6 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(durationFieldType7);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getDays();
        org.joda.time.Period period5 = period0.withYears(8);
        int int6 = period0.getWeeks();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        org.joda.time.ReadablePartial readablePartial41 = null;
        java.util.Locale locale43 = null;
        try {
            java.lang.String str44 = unsupportedDateTimeField34.getAsShortText(readablePartial41, (int) ' ', locale43);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Throwable[] throwableArray8 = illegalFieldValueException4.getSuppressed();
        java.lang.Number number9 = illegalFieldValueException4.getIllegalNumberValue();
        boolean boolean10 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        illegalFieldValueException4.prependMessage("65");
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10.0d + "'", number9.equals(10.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.Period period4 = org.joda.time.Period.months((int) '4');
        int[] intArray6 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period4, (long) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology12.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType3 = periodType2.withMinutesRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withWeeksRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withMonthsRemoved();
        int int6 = periodType5.size();
        org.joda.time.Period period7 = new org.joda.time.Period();
        int int8 = period7.size();
        org.joda.time.Period period9 = period7.negated();
        int int10 = period7.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter11 = null;
        java.lang.String str12 = period7.toString(periodFormatter11);
        org.joda.time.DurationFieldType durationFieldType14 = period7.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField15 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType14);
        int int16 = periodType5.indexOf(durationFieldType14);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PT0S" + "'", str12.equals("PT0S"));
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertNotNull(unsupportedDurationField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '#');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        int int13 = decoratedDurationField10.getDifference((-10L), 2440588L);
        long long16 = decoratedDurationField10.add((long) 3, 4);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 14400003L + "'", long16 == 14400003L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        org.joda.time.ReadablePartial readablePartial41 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology44 = gregorianChronology43.withUTC();
        org.joda.time.DurationField durationField45 = gregorianChronology43.hours();
        org.joda.time.Period period47 = org.joda.time.Period.hours(100);
        org.joda.time.Period period48 = period47.negated();
        org.joda.time.Days days49 = period48.toStandardDays();
        org.joda.time.Period period51 = period48.plusHours(1);
        int[] intArray53 = gregorianChronology43.get((org.joda.time.ReadablePeriod) period51, (-207359884803200L));
        try {
            int[] intArray55 = unsupportedDateTimeField34.add(readablePartial41, 10, intArray53, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(days49);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(intArray53);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone2.getShortName(0L, locale5);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.100" + "'", str6.equals("+00:00:00.100"));
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        org.joda.time.DurationField durationField30 = dividedDateTimeField28.getDurationField();
        org.joda.time.DateTimeField dateTimeField31 = dividedDateTimeField28.getWrappedField();
        java.util.Locale locale33 = null;
        java.lang.String str34 = dividedDateTimeField28.getAsText(6048000032L, locale33);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "4" + "'", str34.equals("4"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        org.joda.time.DurationField durationField12 = null;
        int int13 = unsupportedDurationField11.compareTo(durationField12);
        try {
            int int15 = unsupportedDurationField11.getValue(1814401000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap3);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        boolean boolean5 = periodType2.equals((java.lang.Object) dateTimeZone4);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField7 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, (-210858120000000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.Chronology chronology12 = zonedChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.clockhourOfDay();
        java.lang.String str14 = zonedChronology11.toString();
        org.joda.time.Chronology chronology15 = zonedChronology11.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.Chronology chronology21 = zonedChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = zonedChronology11.minuteOfHour();
        java.lang.Object obj23 = null;
        boolean boolean24 = zonedChronology11.equals(obj23);
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology11.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str14.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone1);
//        java.lang.String str4 = cachedDateTimeZone1.getName((long) (short) 1);
//        java.lang.String str6 = cachedDateTimeZone1.getShortName((-259200000L));
//        java.lang.String str8 = cachedDateTimeZone1.getName(1814401000L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.100" + "'", str4.equals("+00:00:00.100"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00:00.100" + "'", str6.equals("+00:00:00.100"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.100" + "'", str8.equals("+00:00:00.100"));
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-72L), (long) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-72) + "'", int2 == (-72));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add((long) (-1), (int) ' ');
        long long9 = offsetDateTimeField3.add((long) (short) 0, (long) (byte) 1);
        boolean boolean10 = offsetDateTimeField3.isLenient();
        org.joda.time.DurationField durationField11 = offsetDateTimeField3.getLeapDurationField();
        int int12 = offsetDateTimeField3.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField16 = gregorianChronology15.minutes();
        org.joda.time.Chronology chronology17 = gregorianChronology15.withUTC();
        org.joda.time.Period period19 = org.joda.time.Period.months((int) '4');
        int[] intArray21 = gregorianChronology15.get((org.joda.time.ReadablePeriod) period19, (long) 10);
        try {
            int[] intArray23 = offsetDateTimeField3.addWrapField(readablePartial13, 604803199, intArray21, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 604803199");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19353599999L + "'", long6 == 19353599999L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 604800000L + "'", long9 == 604800000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 85 + "'", int12 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        org.joda.time.DurationField durationField11 = decoratedDurationField10.getWrappedField();
        java.lang.String str12 = decoratedDurationField10.getName();
        int int15 = decoratedDurationField10.getValue((long) 10, (-259200100L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "years" + "'", str12.equals("years"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
//        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField3.getWrappedField();
//        long long16 = offsetDateTimeField3.roundHalfEven(3200L);
//        java.lang.String str18 = offsetDateTimeField3.getAsShortText((long) 4);
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        java.util.Locale locale20 = null;
//        try {
//            java.lang.String str21 = offsetDateTimeField3.getAsShortText(readablePartial19, locale20);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200100L) + "'", long16 == (-259200100L));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "33" + "'", str18.equals("33"));
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (short) 1);
        java.util.TimeZone timeZone3 = dateTimeZone2.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) ' ');
        long long9 = offsetDateTimeField6.add(3200L, (int) (short) 1);
        int int11 = offsetDateTimeField6.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField6.getAsShortText(readablePartial12, (int) '4', locale14);
        java.util.Locale locale16 = null;
        int int17 = offsetDateTimeField6.getMaximumShortTextLength(locale16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) ' ');
        long long24 = offsetDateTimeField21.add(3200L, (int) (short) 1);
        int int26 = offsetDateTimeField21.get((long) (short) 100);
        int int28 = offsetDateTimeField21.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField21.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType29, (int) (byte) 10);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 2);
        java.util.Locale locale35 = null;
        java.lang.String str36 = dividedDateTimeField33.getAsText((int) (byte) 100, locale35);
        long long39 = dividedDateTimeField33.addWrapField(1560629534061L, (int) (short) 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 604803200L + "'", long9 == 604803200L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "52" + "'", str15.equals("52"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 604803200L + "'", long24 == 604803200L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 33 + "'", int26 == 33);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 33 + "'", int28 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "100" + "'", str36.equals("100"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560615134061L + "'", long39 == 1560615134061L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'PST' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.joda.time.Period period3 = org.joda.time.Period.hours(100);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.Period period6 = period3.minusMinutes((int) (short) 0);
        org.joda.time.Period period8 = period6.plusSeconds(100);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType10 = periodType9.withSecondsRemoved();
        org.joda.time.PeriodType periodType11 = org.joda.time.DateTimeUtils.getPeriodType(periodType9);
        org.joda.time.DurationFieldType durationFieldType12 = null;
        int int13 = periodType11.indexOf(durationFieldType12);
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period8, (java.lang.Object) periodType11);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology19 = gregorianChronology15.withZone(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone21);
        int int24 = cachedDateTimeZone22.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone25 = cachedDateTimeZone22.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology15, dateTimeZone25);
        org.joda.time.Chronology chronology27 = zonedChronology26.withUTC();
        org.joda.time.DateTimeField dateTimeField28 = zonedChronology26.clockhourOfDay();
        java.lang.String str29 = zonedChronology26.toString();
        org.joda.time.Chronology chronology30 = zonedChronology26.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone35 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.Chronology chronology36 = zonedChronology26.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone35);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone35);
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology37.secondOfDay();
        boolean boolean39 = periodType11.equals((java.lang.Object) dateTimeField38);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology41 = gregorianChronology40.withUTC();
        org.joda.time.DurationField durationField42 = gregorianChronology40.hours();
        org.joda.time.Period period44 = org.joda.time.Period.hours(100);
        org.joda.time.Period period45 = period44.negated();
        org.joda.time.Days days46 = period45.toStandardDays();
        org.joda.time.Period period48 = period45.plusHours(1);
        int[] intArray50 = gregorianChronology40.get((org.joda.time.ReadablePeriod) period48, (-207359884803200L));
        try {
            org.joda.time.Period period51 = new org.joda.time.Period((java.lang.Object) strMap0, periodType11, (org.joda.time.Chronology) gregorianChronology40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.util.Collections$UnmodifiableMap");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strMap0);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(zonedChronology26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str29.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(days46);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertNotNull(intArray50);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Days days3 = period2.toStandardDays();
        org.joda.time.Period period5 = period2.plusHours(1);
        org.joda.time.Period period6 = new org.joda.time.Period();
        int int7 = period6.size();
        org.joda.time.PeriodType periodType8 = period6.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        boolean boolean10 = periodType8.isSupported(durationFieldType9);
        org.joda.time.Period period11 = new org.joda.time.Period();
        int int12 = period11.size();
        org.joda.time.Period period13 = period11.negated();
        org.joda.time.DurationFieldType durationFieldType14 = null;
        int int15 = period13.indexOf(durationFieldType14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType((int) (short) 0);
        int int18 = periodType8.indexOf(durationFieldType17);
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(durationFieldType17, (java.lang.Number) (byte) 100, (java.lang.Number) 10.0d, (java.lang.Number) 1.0f);
        org.joda.time.Period period24 = period5.withField(durationFieldType17, (int) '#');
        int int25 = period24.getHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(days3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-99) + "'", int25 == (-99));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("PST", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PST/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.Chronology chronology12 = zonedChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) ' ');
        long long23 = offsetDateTimeField20.add(3200L, (int) (short) 1);
        int int25 = offsetDateTimeField20.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial26 = null;
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField20.getAsShortText(readablePartial26, (int) '4', locale28);
        java.util.Locale locale30 = null;
        int int31 = offsetDateTimeField20.getMaximumShortTextLength(locale30);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (int) ' ');
        long long38 = offsetDateTimeField35.add(3200L, (int) (short) 1);
        int int40 = offsetDateTimeField35.get((long) (short) 100);
        int int42 = offsetDateTimeField35.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField35.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField20, dateTimeFieldType43, (int) (byte) 10);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField47 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, dateTimeFieldType43, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField(dateTimeField13, dateTimeFieldType43, (int) '#');
        org.joda.time.ReadablePartial readablePartial50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology52.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, (int) ' ');
        long long58 = offsetDateTimeField55.add((long) (-1), (int) ' ');
        long long61 = offsetDateTimeField55.add((long) (short) 0, (long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial62 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField64 = gregorianChronology63.minutes();
        org.joda.time.Chronology chronology65 = gregorianChronology63.withUTC();
        org.joda.time.Period period67 = org.joda.time.Period.months((int) '4');
        int[] intArray69 = gregorianChronology63.get((org.joda.time.ReadablePeriod) period67, (long) 10);
        int int70 = offsetDateTimeField55.getMinimumValue(readablePartial62, intArray69);
        try {
            int[] intArray72 = dividedDateTimeField49.add(readablePartial50, 0, intArray69, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 604803200L + "'", long23 == 604803200L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "52" + "'", str29.equals("52"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 604803200L + "'", long38 == 604803200L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 33 + "'", int40 == 33);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 33 + "'", int42 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertNotNull(gregorianChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 19353599999L + "'", long58 == 19353599999L);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 604800000L + "'", long61 == 604800000L);
        org.junit.Assert.assertNotNull(gregorianChronology63);
        org.junit.Assert.assertNotNull(durationField64);
        org.junit.Assert.assertNotNull(chronology65);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 33 + "'", int70 == 33);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
//        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField3.getWrappedField();
//        long long17 = offsetDateTimeField3.add((long) 4, (int) '4');
//        long long19 = offsetDateTimeField3.roundHalfFloor((-58571700L));
//        long long21 = offsetDateTimeField3.remainder((long) 8);
//        long long24 = offsetDateTimeField3.getDifferenceAsLong((-100L), (-19357200001L));
//        try {
//            long long27 = offsetDateTimeField3.set(2L, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for weekOfWeekyear must be in the range [33,85]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31449600004L + "'", long17 == 31449600004L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200100L) + "'", long19 == (-259200100L));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 259200108L + "'", long21 == 259200108L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 32L + "'", long24 == 32L);
//    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        java.lang.String str5 = dateTimeZone1.getName(0L);
//        java.lang.String str6 = dateTimeZone1.getID();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test486");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
//        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField3.getWrappedField();
//        long long17 = offsetDateTimeField3.add((long) 4, (int) '4');
//        long long19 = offsetDateTimeField3.roundHalfFloor((-58571700L));
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField3.getAsText(10L, locale21);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        org.joda.time.Period period24 = new org.joda.time.Period();
//        int int25 = period24.size();
//        org.joda.time.Period period26 = period24.negated();
//        int int27 = period24.getMillis();
//        int int28 = period24.getMonths();
//        org.joda.time.PeriodType periodType29 = period24.getPeriodType();
//        int int30 = period24.getMonths();
//        org.joda.time.Period period32 = org.joda.time.Period.millis((int) (byte) -1);
//        org.joda.time.PeriodType periodType33 = period32.getPeriodType();
//        org.joda.time.Period period34 = period24.withPeriodType(periodType33);
//        org.joda.time.Period period35 = period24.negated();
//        org.joda.time.Duration duration36 = period35.toStandardDuration();
//        org.joda.time.Period period38 = period35.plusMonths((int) '4');
//        int[] intArray39 = period38.getValues();
//        int int40 = offsetDateTimeField3.getMaximumValue(readablePartial23, intArray39);
//        boolean boolean42 = offsetDateTimeField3.isLeap((-1093091772L));
//        long long44 = offsetDateTimeField3.roundFloor(259200135L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31449600004L + "'", long17 == 31449600004L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200100L) + "'", long19 == (-259200100L));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "33" + "'", str22.equals("33"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 8 + "'", int25 == 8);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(periodType33);
//        org.junit.Assert.assertNotNull(period34);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(duration36);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 85 + "'", int40 == 85);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-259200100L) + "'", long44 == (-259200100L));
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType2);
        org.joda.time.Period period5 = period3.plusYears(0);
        org.joda.time.Period period7 = period3.minusMinutes((int) (byte) -1);
        org.joda.time.Duration duration8 = period3.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration8);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        org.joda.time.ReadablePartial readablePartial38 = null;
        java.util.Locale locale39 = null;
        try {
            java.lang.String str40 = unsupportedDateTimeField34.getAsText(readablePartial38, locale39);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        boolean boolean36 = unsupportedDateTimeField34.isLenient();
        java.util.Locale locale38 = null;
        try {
            java.lang.String str39 = unsupportedDateTimeField34.getAsShortText((int) '#', locale38);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField8 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.yearOfEra();
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        try {
            int[] intArray14 = gregorianChronology0.get(readablePeriod11, (-259200000L), 11044935360006200L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter4 = null;
        java.lang.String str5 = period0.toString(periodFormatter4);
        org.joda.time.DurationFieldType durationFieldType7 = period0.getFieldType(0);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType9 = periodType8.withSecondsRemoved();
        org.joda.time.PeriodType periodType10 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = periodType10.indexOf(durationFieldType11);
        org.joda.time.Period period13 = period0.normalizedStandard(periodType10);
        org.joda.time.Period period15 = period0.minusYears(2);
        org.joda.time.Period period17 = period15.withMonths((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0S" + "'", str5.equals("PT0S"));
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
//        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField3.getWrappedField();
//        long long17 = offsetDateTimeField3.add((long) 4, (int) '4');
//        long long19 = offsetDateTimeField3.roundHalfFloor((-58571700L));
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = offsetDateTimeField3.getAsText(10L, locale21);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        org.joda.time.Period period24 = new org.joda.time.Period();
//        int int25 = period24.size();
//        org.joda.time.Period period26 = period24.negated();
//        int int27 = period24.getMillis();
//        int int28 = period24.getMonths();
//        org.joda.time.PeriodType periodType29 = period24.getPeriodType();
//        int int30 = period24.getMonths();
//        org.joda.time.Period period32 = org.joda.time.Period.millis((int) (byte) -1);
//        org.joda.time.PeriodType periodType33 = period32.getPeriodType();
//        org.joda.time.Period period34 = period24.withPeriodType(periodType33);
//        org.joda.time.Period period35 = period24.negated();
//        org.joda.time.Duration duration36 = period35.toStandardDuration();
//        org.joda.time.Period period38 = period35.plusMonths((int) '4');
//        int[] intArray39 = period38.getValues();
//        int int40 = offsetDateTimeField3.getMaximumValue(readablePartial23, intArray39);
//        boolean boolean42 = offsetDateTimeField3.isLeap((-1093091772L));
//        int int45 = offsetDateTimeField3.getDifference(604800000L, 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31449600004L + "'", long17 == 31449600004L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200100L) + "'", long19 == (-259200100L));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "33" + "'", str22.equals("33"));
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 8 + "'", int25 == 8);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(periodType29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(period32);
//        org.junit.Assert.assertNotNull(periodType33);
//        org.junit.Assert.assertNotNull(period34);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(duration36);
//        org.junit.Assert.assertNotNull(period38);
//        org.junit.Assert.assertNotNull(intArray39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 85 + "'", int40 == 85);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("P8Y");
        org.joda.time.Period period3 = org.joda.time.Period.hours(100);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.Period period6 = period3.minusMinutes((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationTo(readableInstant7);
        long long9 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        long long10 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant13);
        org.joda.time.Period period16 = period14.plusHours(3);
        jodaTimePermission1.checkGuard((java.lang.Object) period14);
        java.lang.String str18 = jodaTimePermission1.getName();
        java.lang.String str19 = jodaTimePermission1.getName();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 360000000L + "'", long9 == 360000000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 360000000L + "'", long10 == 360000000L);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P8Y" + "'", str18.equals("P8Y"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "P8Y" + "'", str19.equals("P8Y"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        org.joda.time.DurationField durationField11 = decoratedDurationField10.getWrappedField();
        long long12 = decoratedDurationField10.getUnitMillis();
        long long14 = decoratedDurationField10.getMillis(1L);
        long long16 = decoratedDurationField10.getMillis((int) '4');
        long long19 = decoratedDurationField10.subtract(360000000L, 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3600000L + "'", long12 == 3600000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3600000L + "'", long14 == 3600000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 187200000L + "'", long16 == 187200000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 360000000L + "'", long19 == 360000000L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("10", 1, 5, 5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for 10 must be in the range [5,5]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType4);
        org.joda.time.Period period7 = period5.minusHours(0);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        try {
            org.joda.time.DurationFieldType durationFieldType5 = periodType3.getFieldType(32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        int int4 = offsetDateTimeField3.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale6 = null;
        try {
            java.lang.String str7 = offsetDateTimeField3.getAsText(readablePartial5, locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 33 + "'", int4 == 33);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
//        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
//        int int8 = offsetDateTimeField3.get((long) (short) 100);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = offsetDateTimeField3.getAsText(readablePartial9, 8, locale11);
//        java.util.Locale locale13 = null;
//        int int14 = offsetDateTimeField3.getMaximumTextLength(locale13);
//        long long16 = offsetDateTimeField3.remainder((long) 35);
//        try {
//            long long19 = offsetDateTimeField3.set((-3934918440000000L), (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for weekOfWeekyear must be in the range [33,85]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "8" + "'", str12.equals("8"));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 259200135L + "'", long16 == 259200135L);
//    }
//}

