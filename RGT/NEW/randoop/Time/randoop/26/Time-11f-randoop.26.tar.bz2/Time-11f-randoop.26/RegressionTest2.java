import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter4 = null;
        java.lang.String str5 = period0.toString(periodFormatter4);
        org.joda.time.DurationFieldType durationFieldType7 = period0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField8 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField10 = gregorianChronology9.minutes();
        int int11 = unsupportedDurationField8.compareTo(durationField10);
        boolean boolean12 = unsupportedDurationField8.isPrecise();
        org.joda.time.DurationFieldType durationFieldType13 = unsupportedDurationField8.getType();
        try {
            long long16 = unsupportedDurationField8.getMillis(6236442000000L, (-1093091772L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0S" + "'", str5.equals("PT0S"));
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(durationFieldType13);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test002");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        java.lang.String str3 = dateTimeZone1.getName((long) 1);
//        java.lang.String str5 = dateTimeZone1.getName(0L);
//        org.joda.time.ReadableInstant readableInstant6 = null;
//        int int7 = dateTimeZone1.getOffset(readableInstant6);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Coordinated Universal Time" + "'", str5.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        java.lang.String str11 = decoratedDurationField10.getName();
        boolean boolean12 = decoratedDurationField10.isSupported();
        long long15 = decoratedDurationField10.getDifferenceAsLong((long) (byte) 100, (long) 100);
        long long18 = decoratedDurationField10.add(19349999999L, (int) (byte) 1);
        java.lang.String str19 = decoratedDurationField10.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "years" + "'", str11.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 19353599999L + "'", long18 == 19353599999L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "years" + "'", str19.equals("years"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withDaysRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withWeeksRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period6 = new org.joda.time.Period();
        int int7 = period6.size();
        org.joda.time.Period period8 = period6.negated();
        boolean boolean9 = gregorianChronology5.equals((java.lang.Object) period8);
        org.joda.time.DurationField durationField10 = gregorianChronology5.weeks();
        org.joda.time.DurationField durationField11 = gregorianChronology5.millis();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology5.weekyearOfCentury();
        org.joda.time.DurationField durationField13 = gregorianChronology5.years();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology5.year();
        org.joda.time.DurationField durationField15 = gregorianChronology5.weeks();
        org.joda.time.Period period17 = org.joda.time.Period.hours(100);
        org.joda.time.Period period18 = period17.negated();
        org.joda.time.Period period20 = period17.minusMinutes((int) (short) 0);
        org.joda.time.Period period22 = period20.plusSeconds(100);
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType24 = periodType23.withSecondsRemoved();
        org.joda.time.PeriodType periodType25 = org.joda.time.DateTimeUtils.getPeriodType(periodType23);
        org.joda.time.DurationFieldType durationFieldType26 = null;
        int int27 = periodType25.indexOf(durationFieldType26);
        boolean boolean28 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period22, (java.lang.Object) periodType25);
        org.joda.time.PeriodType periodType29 = periodType25.withMillisRemoved();
        org.joda.time.PeriodType periodType30 = periodType29.withWeeksRemoved();
        boolean boolean31 = gregorianChronology5.equals((java.lang.Object) periodType30);
        boolean boolean32 = periodType4.equals((java.lang.Object) boolean31);
        org.joda.time.Period period33 = new org.joda.time.Period((long) 32, (-57599900L), periodType4);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.Period period6 = org.joda.time.Period.hours(100);
        org.joda.time.Period period7 = period6.negated();
        org.joda.time.Period period9 = period6.minusMinutes((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = period9.indexOf(durationFieldType10);
        long long14 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period9, (long) (byte) -1, 0);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        int int10 = offsetDateTimeField3.get((-10L));
        long long13 = offsetDateTimeField3.getDifferenceAsLong(360000000L, 0L);
        long long15 = offsetDateTimeField3.roundFloor(0L);
        long long18 = offsetDateTimeField3.add(0L, (int) (short) -1);
        org.joda.time.ReadablePartial readablePartial19 = null;
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.Period period24 = new org.joda.time.Period(3600000L, (long) (byte) 100, chronology23);
        int[] intArray25 = period24.getValues();
        java.util.Locale locale27 = null;
        try {
            int[] intArray28 = offsetDateTimeField3.set(readablePartial19, 10, intArray25, "GregorianChronology[UTC]", locale27);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[UTC]\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200000L) + "'", long15 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-604800000L) + "'", long18 == (-604800000L));
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getDays();
        org.joda.time.Period period5 = period0.withYears(8);
        int int7 = period5.getValue(0);
        org.joda.time.PeriodType periodType8 = period5.getPeriodType();
        org.joda.time.PeriodType periodType9 = periodType8.withMillisRemoved();
        java.lang.String str10 = periodType8.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PeriodType[Standard]" + "'", str10.equals("PeriodType[Standard]"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(85);
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Duration duration3 = period1.toDurationFrom(readableInstant2);
        long long4 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration3);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5100000L + "'", long4 == 5100000L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
        java.lang.String str2 = iSOChronology0.toString();
        org.joda.time.DurationField durationField3 = iSOChronology0.weekyears();
        org.joda.time.DurationField durationField4 = iSOChronology0.seconds();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        java.lang.String str11 = decoratedDurationField10.getName();
        boolean boolean12 = decoratedDurationField10.isSupported();
        long long15 = decoratedDurationField10.getValueAsLong((-110449353600052L), (long) 10);
        int int18 = decoratedDurationField10.getDifference(604800000L, 0L);
        java.lang.Class<?> wildcardClass19 = decoratedDurationField10.getClass();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "years" + "'", str11.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-30680376L) + "'", long15 == (-30680376L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 168 + "'", int18 == 168);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(8, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 256 + "'", int2 == 256);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField3.getWrappedField();
        long long17 = offsetDateTimeField3.add((long) 4, (int) '4');
        long long19 = offsetDateTimeField3.roundHalfFloor((-58571700L));
        long long22 = offsetDateTimeField3.add((-43104900L), 0);
        int int24 = offsetDateTimeField3.getMinimumValue(187200000L);
        long long26 = offsetDateTimeField3.roundHalfFloor(110L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31449600004L + "'", long17 == 31449600004L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200000L) + "'", long19 == (-259200000L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-43104900L) + "'", long22 == (-43104900L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 33 + "'", int24 == 33);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-259200000L) + "'", long26 == (-259200000L));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.add((long) (-2), (-1));
        org.joda.time.ReadablePartial readablePartial38 = null;
        java.util.Locale locale40 = null;
        try {
            java.lang.String str41 = unsupportedDateTimeField34.getAsText(readablePartial38, (int) '#', locale40);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3155673600002L) + "'", long37 == (-3155673600002L));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        boolean boolean36 = unsupportedDateTimeField34.isSupported();
        try {
            long long39 = unsupportedDateTimeField34.set((long) 3499, "PeriodType[YearDayTime]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int30 = dividedDateTimeField28.get((-57599900L));
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
        long long37 = offsetDateTimeField34.add(3200L, (int) (short) 1);
        int int39 = offsetDateTimeField34.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = offsetDateTimeField34.getMinimumValue(readablePartial40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField34.getAsText((long) 8, locale43);
        int int46 = offsetDateTimeField34.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) ' ');
        long long53 = offsetDateTimeField50.add(3200L, (int) (short) 1);
        int int55 = offsetDateTimeField50.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial56 = null;
        java.util.Locale locale58 = null;
        java.lang.String str59 = offsetDateTimeField50.getAsShortText(readablePartial56, (int) '4', locale58);
        java.util.Locale locale60 = null;
        int int61 = offsetDateTimeField50.getMaximumShortTextLength(locale60);
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology62.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, (int) ' ');
        long long68 = offsetDateTimeField65.add(3200L, (int) (short) 1);
        int int70 = offsetDateTimeField65.get((long) (short) 100);
        int int72 = offsetDateTimeField65.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = offsetDateTimeField65.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType73, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType73, (int) 'a');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField78 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType73);
        long long80 = remainderDateTimeField78.roundHalfCeiling((long) (-43104900));
        int int81 = remainderDateTimeField78.getMinimumValue();
        int int82 = remainderDateTimeField78.getMaximumValue();
        org.joda.time.DurationField durationField83 = remainderDateTimeField78.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604803200L + "'", long37 == 604803200L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 33 + "'", int41 == 33);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "33" + "'", str44.equals("33"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 85 + "'", int46 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 604803200L + "'", long53 == 604803200L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 33 + "'", int55 == 33);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "52" + "'", str59.equals("52"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604803200L + "'", long68 == 604803200L);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 33 + "'", int70 == 33);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 33 + "'", int72 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-259200000L) + "'", long80 == (-259200000L));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 9 + "'", int82 == 9);
        org.junit.Assert.assertNotNull(durationField83);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiply(360000035, (-72));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows an int: 360000035 * -72");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.getDifferenceAsLong((long) (-5325), (-244803200L));
        java.lang.String str41 = unsupportedDateTimeField34.getName();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField34.getDurationField();
        try {
            long long44 = unsupportedDateTimeField34.roundHalfEven((long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "weekOfWeekyear" + "'", str41.equals("weekOfWeekyear"));
        org.junit.Assert.assertNotNull(durationField42);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField7 = gregorianChronology0.hours();
        org.joda.time.Period period8 = new org.joda.time.Period();
        boolean boolean10 = period8.equals((java.lang.Object) false);
        org.joda.time.Period period12 = period8.plusMillis((int) (byte) 1);
        int[] intArray15 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period8, (-10L), (long) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField17 = gregorianChronology16.minutes();
        org.joda.time.Chronology chronology18 = gregorianChronology16.withUTC();
        org.joda.time.Period period20 = org.joda.time.Period.months((int) '4');
        int[] intArray22 = gregorianChronology16.get((org.joda.time.ReadablePeriod) period20, (long) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology16, (org.joda.time.DateTimeZone) fixedDateTimeZone27);
        int int30 = fixedDateTimeZone27.getStandardOffset((-210866673600000L));
        boolean boolean31 = fixedDateTimeZone27.isFixed();
        org.joda.time.Chronology chronology32 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone27);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(zonedChronology28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 32 + "'", int30 == 32);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(chronology32);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        int int10 = offsetDateTimeField3.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField3.getType();
        long long14 = offsetDateTimeField3.getDifferenceAsLong(1260000000L, (long) (short) 1);
        boolean boolean15 = offsetDateTimeField3.isLenient();
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField3.getWrappedField();
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray19 = null;
        try {
            int[] intArray21 = offsetDateTimeField3.addWrapField(readablePartial17, (-2), intArray19, 168);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        int int15 = offsetDateTimeField3.getMaximumValue(10L);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField3.getAsText((long) ' ', locale17);
        org.joda.time.DurationField durationField19 = offsetDateTimeField3.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField3.getAsShortText(readablePartial20, 168, locale22);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "33" + "'", str18.equals("33"));
        org.junit.Assert.assertNull(durationField19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "168" + "'", str23.equals("168"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PT100H", (java.lang.Number) 1L, (java.lang.Number) 19353599999L, number3);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        java.lang.String str6 = illegalFieldValueException4.toString();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 1 for PT100H must not be smaller than 19353599999" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 1 for PT100H must not be smaller than 19353599999"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.Period period6 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period8 = period6.withPeriodType(periodType7);
        org.joda.time.Period period10 = period8.minusWeeks(0);
        int int11 = period10.getHours();
        org.joda.time.Period period13 = period10.plusWeeks(0);
        org.joda.time.Period period14 = period0.withFields((org.joda.time.ReadablePeriod) period10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.Period period0 = new org.joda.time.Period();
        boolean boolean2 = period0.equals((java.lang.Object) false);
        org.joda.time.Period period4 = period0.plusMillis((int) (byte) 1);
        org.joda.time.Weeks weeks5 = period0.toStandardWeeks();
        org.joda.time.Period period7 = period0.minusSeconds((int) (byte) 10);
        org.joda.time.Period period9 = period7.withYears(2);
        org.joda.time.Period period11 = org.joda.time.Period.hours(100);
        org.joda.time.Period period12 = period11.negated();
        org.joda.time.Period period14 = period11.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass15 = period14.getClass();
        org.joda.time.Period period17 = period14.minusMonths((int) (short) 10);
        org.joda.time.Period period18 = period7.withFields((org.joda.time.ReadablePeriod) period14);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period14.toDurationFrom(readableInstant19);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.Period period22 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration20, readableInstant21);
        org.joda.time.Period period24 = period22.withSeconds(5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(weeks5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertNotNull(period24);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        int int15 = offsetDateTimeField3.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) ' ');
        long long22 = offsetDateTimeField19.add(3200L, (int) (short) 1);
        int int24 = offsetDateTimeField19.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial25 = null;
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField19.getAsShortText(readablePartial25, (int) '4', locale27);
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField19.getMaximumShortTextLength(locale29);
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
        long long37 = offsetDateTimeField34.add(3200L, (int) (short) 1);
        int int39 = offsetDateTimeField34.get((long) (short) 100);
        int int41 = offsetDateTimeField34.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField19, dateTimeFieldType42, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType42, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) ' ');
        long long53 = offsetDateTimeField50.add(3200L, (int) (short) 1);
        int int55 = offsetDateTimeField50.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial56 = null;
        java.util.Locale locale58 = null;
        java.lang.String str59 = offsetDateTimeField50.getAsShortText(readablePartial56, (int) '4', locale58);
        java.util.Locale locale60 = null;
        int int61 = offsetDateTimeField50.getMaximumTextLength(locale60);
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology62.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, (int) ' ');
        long long68 = offsetDateTimeField65.add(3200L, (int) (short) 1);
        int int70 = offsetDateTimeField65.get((long) (short) 100);
        int int72 = offsetDateTimeField65.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = offsetDateTimeField65.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType73, 10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField77 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField46, dateTimeFieldType73, 5);
        int int79 = remainderDateTimeField77.getMaximumValue(110L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 604803200L + "'", long22 == 604803200L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 33 + "'", int24 == 33);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "52" + "'", str28.equals("52"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604803200L + "'", long37 == 604803200L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 33 + "'", int41 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 604803200L + "'", long53 == 604803200L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 33 + "'", int55 == 33);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "52" + "'", str59.equals("52"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604803200L + "'", long68 == 604803200L);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 33 + "'", int70 == 33);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 33 + "'", int72 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 4 + "'", int79 == 4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.Period period1 = org.joda.time.Period.months(9);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-52L), (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-152L) + "'", long2 == (-152L));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (byte) 0, 126000000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
        org.joda.time.DurationField durationField2 = iSOChronology0.days();
        org.joda.time.Period period4 = org.joda.time.Period.hours(100);
        org.joda.time.Period period5 = period4.negated();
        org.joda.time.Period period7 = period4.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass8 = period7.getClass();
        org.joda.time.Period period10 = period7.minusMonths((int) (short) 10);
        org.joda.time.Period period12 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType13 = period12.getPeriodType();
        org.joda.time.Period period14 = new org.joda.time.Period();
        int int15 = period14.size();
        org.joda.time.Period period16 = period14.negated();
        org.joda.time.DurationFieldType durationFieldType17 = null;
        int int18 = period16.indexOf(durationFieldType17);
        org.joda.time.DurationFieldType durationFieldType20 = period16.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(durationFieldType20, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.Period period26 = period12.withField(durationFieldType20, 35);
        int int27 = period7.get(durationFieldType20);
        boolean boolean28 = iSOChronology0.equals((java.lang.Object) durationFieldType20);
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeField29);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(35, 0, 1673545);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.Period period6 = org.joda.time.Period.hours(100);
        org.joda.time.Period period7 = period6.negated();
        org.joda.time.Period period9 = period6.minusMinutes((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = period9.indexOf(durationFieldType10);
        long long14 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period9, (long) (byte) -1, 0);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period2.getSeconds();
        org.joda.time.Period period5 = period2.minusMinutes(2);
        org.joda.time.Period period6 = new org.joda.time.Period();
        boolean boolean8 = period6.equals((java.lang.Object) false);
        org.joda.time.Period period10 = period6.plusMillis((int) (byte) 1);
        org.joda.time.Weeks weeks11 = period6.toStandardWeeks();
        org.joda.time.Period period13 = period6.minusSeconds((int) (byte) 10);
        org.joda.time.Period period15 = period13.withYears(2);
        org.joda.time.Period period17 = org.joda.time.Period.hours(100);
        org.joda.time.Period period18 = period17.negated();
        org.joda.time.Period period20 = period17.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass21 = period20.getClass();
        org.joda.time.Period period23 = period20.minusMonths((int) (short) 10);
        org.joda.time.Period period24 = period13.withFields((org.joda.time.ReadablePeriod) period20);
        org.joda.time.Period period25 = period2.minus((org.joda.time.ReadablePeriod) period24);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(weeks11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant1, readableDuration2, periodType3);
        org.joda.time.MutablePeriod mutablePeriod5 = period4.toMutablePeriod();
        long long8 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period4, (long) 10, 3);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(mutablePeriod5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.Period period4 = org.joda.time.Period.months((int) '4');
        int[] intArray6 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period4, (long) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        java.lang.String str13 = zonedChronology12.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ZonedChronology[GregorianChronology[UTC], PT100H]" + "'", str13.equals("ZonedChronology[GregorianChronology[UTC], PT100H]"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        boolean boolean41 = unsupportedDateTimeField34.isLenient();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField34.getRangeDurationField();
        long long45 = unsupportedDateTimeField34.add(0L, (-99));
        try {
            long long47 = unsupportedDateTimeField34.roundHalfEven(21168000350L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-312413760000000L) + "'", long45 == (-312413760000000L));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundCeiling((-62032493221900L));
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) ' ');
        long long12 = offsetDateTimeField9.add(3200L, (int) (short) 1);
        int int14 = offsetDateTimeField9.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = offsetDateTimeField9.getMinimumValue(readablePartial15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText((long) 8, locale18);
        int int21 = offsetDateTimeField9.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) ' ');
        long long28 = offsetDateTimeField25.add(3200L, (int) (short) 1);
        int int30 = offsetDateTimeField25.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField25.getAsShortText(readablePartial31, (int) '4', locale33);
        java.util.Locale locale35 = null;
        int int36 = offsetDateTimeField25.getMaximumShortTextLength(locale35);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, (int) ' ');
        long long43 = offsetDateTimeField40.add(3200L, (int) (short) 1);
        int int45 = offsetDateTimeField40.get((long) (short) 100);
        int int47 = offsetDateTimeField40.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = offsetDateTimeField40.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField25, dateTimeFieldType48, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType48, (int) 'a');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField54 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType48, 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = remainderDateTimeField54.getType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62032176000000L) + "'", long5 == (-62032176000000L));
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 604803200L + "'", long12 == 604803200L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 33 + "'", int14 == 33);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 33 + "'", int16 == 33);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "33" + "'", str19.equals("33"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 85 + "'", int21 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 604803200L + "'", long28 == 604803200L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 33 + "'", int30 == 33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "52" + "'", str34.equals("52"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 604803200L + "'", long43 == 604803200L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 33 + "'", int45 == 33);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 33 + "'", int47 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        org.joda.time.DurationField durationField12 = null;
        int int13 = unsupportedDurationField11.compareTo(durationField12);
        try {
            long long15 = unsupportedDurationField11.getValueAsLong(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType2 = period1.getPeriodType();
        java.lang.String str3 = periodType2.getName();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Standard" + "'", str3.equals("Standard"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.Period period2 = org.joda.time.Period.hours(100);
        org.joda.time.Period period3 = period2.negated();
        org.joda.time.Period period5 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period7 = period5.plusSeconds(100);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType9 = periodType8.withSecondsRemoved();
        org.joda.time.PeriodType periodType10 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
        org.joda.time.DurationFieldType durationFieldType11 = null;
        int int12 = periodType10.indexOf(durationFieldType11);
        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period7, (java.lang.Object) periodType10);
        org.joda.time.PeriodType periodType14 = periodType10.withMillisRemoved();
        org.joda.time.PeriodType periodType15 = periodType14.withWeeksRemoved();
        org.joda.time.Period period16 = new org.joda.time.Period((-43104900L), periodType14);
        try {
            org.joda.time.Period period18 = period16.plusDays(360000035);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) zonedChronology11, dateTimeZone16);
        org.joda.time.DurationField durationField18 = zonedChronology11.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        int int10 = offsetDateTimeField3.get((-10L));
        long long12 = offsetDateTimeField3.roundHalfCeiling(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) ' ');
        long long19 = offsetDateTimeField16.add(3200L, (int) (short) 1);
        int int21 = offsetDateTimeField16.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField16.getMinimumValue(readablePartial22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = offsetDateTimeField16.getAsText((long) 8, locale25);
        int int28 = offsetDateTimeField16.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) ' ');
        long long35 = offsetDateTimeField32.add(3200L, (int) (short) 1);
        int int37 = offsetDateTimeField32.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial38 = null;
        java.util.Locale locale40 = null;
        java.lang.String str41 = offsetDateTimeField32.getAsShortText(readablePartial38, (int) '4', locale40);
        java.util.Locale locale42 = null;
        int int43 = offsetDateTimeField32.getMaximumShortTextLength(locale42);
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology44.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, (int) ' ');
        long long50 = offsetDateTimeField47.add(3200L, (int) (short) 1);
        int int52 = offsetDateTimeField47.get((long) (short) 100);
        int int54 = offsetDateTimeField47.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType55 = offsetDateTimeField47.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField57 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField32, dateTimeFieldType55, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType55, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology60.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, (int) ' ');
        long long66 = offsetDateTimeField63.add(3200L, (int) (short) 1);
        int int68 = offsetDateTimeField63.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial69 = null;
        java.util.Locale locale71 = null;
        java.lang.String str72 = offsetDateTimeField63.getAsShortText(readablePartial69, (int) '4', locale71);
        java.util.Locale locale73 = null;
        int int74 = offsetDateTimeField63.getMaximumTextLength(locale73);
        org.joda.time.chrono.GregorianChronology gregorianChronology75 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField76 = gregorianChronology75.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField78 = new org.joda.time.field.OffsetDateTimeField(dateTimeField76, (int) ' ');
        long long81 = offsetDateTimeField78.add(3200L, (int) (short) 1);
        int int83 = offsetDateTimeField78.get((long) (short) 100);
        int int85 = offsetDateTimeField78.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType86 = offsetDateTimeField78.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField88 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField63, dateTimeFieldType86, 10);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField90 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField59, dateTimeFieldType86, 5);
        org.joda.time.IllegalFieldValueException illegalFieldValueException93 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType86, (java.lang.Number) 99L, "10");
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField97 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType86, 256, (int) '4', 5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-259200000L) + "'", long12 == (-259200000L));
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 604803200L + "'", long19 == 604803200L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 33 + "'", int21 == 33);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "33" + "'", str26.equals("33"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 85 + "'", int28 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 604803200L + "'", long35 == 604803200L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 33 + "'", int37 == 33);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "52" + "'", str41.equals("52"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 604803200L + "'", long50 == 604803200L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 33 + "'", int52 == 33);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 33 + "'", int54 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType55);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 604803200L + "'", long66 == 604803200L);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 33 + "'", int68 == 33);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "52" + "'", str72.equals("52"));
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 2 + "'", int74 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology75);
        org.junit.Assert.assertNotNull(dateTimeField76);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 604803200L + "'", long81 == 604803200L);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 33 + "'", int83 == 33);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 33 + "'", int85 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType86);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        java.lang.String str11 = decoratedDurationField10.getName();
        boolean boolean12 = decoratedDurationField10.isSupported();
        long long15 = decoratedDurationField10.getDifferenceAsLong((long) (byte) 100, (long) 100);
        boolean boolean16 = decoratedDurationField10.isSupported();
        boolean boolean17 = decoratedDurationField10.isPrecise();
        org.joda.time.DurationFieldType durationFieldType18 = decoratedDurationField10.getType();
        long long19 = decoratedDurationField10.getUnitMillis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "years" + "'", str11.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 3600000L + "'", long19 == 3600000L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        org.joda.time.DurationField durationField11 = decoratedDurationField10.getWrappedField();
        java.lang.String str12 = decoratedDurationField10.toString();
        long long15 = decoratedDurationField10.getDifferenceAsLong((-210858120000000L), (long) (byte) 10);
        long long18 = decoratedDurationField10.add((long) 85, (int) ' ');
        long long21 = decoratedDurationField10.add((-57599900L), (long) (short) 100);
        long long24 = decoratedDurationField10.add((long) (-33), (-61536L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DurationField[years]" + "'", str12.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-58571700L) + "'", long15 == (-58571700L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 115200085L + "'", long18 == 115200085L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 302400100L + "'", long21 == 302400100L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-221529600033L) + "'", long24 == (-221529600033L));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("P8Y");
        org.joda.time.Period period3 = org.joda.time.Period.hours(100);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.Period period6 = period3.minusMinutes((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationTo(readableInstant7);
        long long9 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        long long10 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant13);
        org.joda.time.Period period16 = period14.plusHours(3);
        jodaTimePermission1.checkGuard((java.lang.Object) period14);
        jodaTimePermission1.checkGuard((java.lang.Object) (-1L));
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 360000000L + "'", long9 == 360000000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 360000000L + "'", long10 == 360000000L);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.Period period4 = period0.withMillis((int) (byte) 100);
        org.joda.time.Period period6 = period4.minusSeconds(0);
        org.joda.time.Period period8 = org.joda.time.Period.hours(100);
        org.joda.time.Period period9 = period8.negated();
        org.joda.time.Days days10 = period9.toStandardDays();
        org.joda.time.Period period11 = period6.plus((org.joda.time.ReadablePeriod) period9);
        org.joda.time.Period period13 = period6.plusHours((-10256));
        org.joda.time.Period period15 = period13.withMinutes((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(days10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        boolean boolean7 = fixedDateTimeZone4.isStandardOffset((-62032493221900L));
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        java.util.Locale locale7 = null;
        java.lang.String str8 = fixedDateTimeZone4.getShortName(345599900L, locale7);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.100" + "'", str8.equals("+00:00:00.100"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(32);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder2.toDateTimeZone("GregorianChronology[PT100H]", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder2.setStandardOffset((int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder7.setFixedSavings("230400000", 230400000);
        java.io.DataOutput dataOutput12 = null;
        try {
            dateTimeZoneBuilder7.writeTo("org.joda.time.IllegalFieldValueException: Value \"33\" for ISOChronology[UTC] is not supported", dataOutput12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) ' ');
        long long9 = offsetDateTimeField6.add(3200L, (int) (short) 1);
        int int11 = offsetDateTimeField6.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField6.getAsShortText(readablePartial12, (int) '4', locale14);
        java.util.Locale locale16 = null;
        int int17 = offsetDateTimeField6.getMaximumShortTextLength(locale16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) ' ');
        long long24 = offsetDateTimeField21.add(3200L, (int) (short) 1);
        int int26 = offsetDateTimeField21.get((long) (short) 100);
        int int28 = offsetDateTimeField21.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField21.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType29, (int) (byte) 10);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 2);
        java.util.Locale locale34 = null;
        int int35 = dividedDateTimeField33.getMaximumTextLength(locale34);
        int int36 = dividedDateTimeField33.getMaximumValue();
        long long39 = dividedDateTimeField33.getDifferenceAsLong(35L, 0L);
        int int41 = dividedDateTimeField33.getLeapAmount((long) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 604803200L + "'", long9 == 604803200L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "52" + "'", str15.equals("52"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 604803200L + "'", long24 == 604803200L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 33 + "'", int26 == 33);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 33 + "'", int28 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 5 + "'", int36 == 5);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, 10);
        org.joda.time.ReadablePartial readablePartial29 = null;
        int int30 = offsetDateTimeField3.getMaximumValue(readablePartial29);
        org.joda.time.DurationField durationField31 = offsetDateTimeField3.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 85 + "'", int30 == 85);
        org.junit.Assert.assertNull(durationField31);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.dayOfWeek();
        org.joda.time.DurationField durationField7 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '#', (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(4838399998L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.Period period7 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period9 = period7.withPeriodType(periodType8);
        boolean boolean10 = fixedDateTimeZone4.equals((java.lang.Object) periodType8);
        int int12 = fixedDateTimeZone4.getStandardOffset((-230400000L));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int15 = fixedDateTimeZone4.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone17);
        int int20 = cachedDateTimeZone18.getOffset(0L);
        int int22 = cachedDateTimeZone18.getOffsetFromLocal((long) (short) -1);
        int int24 = cachedDateTimeZone18.getOffset((long) ' ');
        java.lang.String str26 = cachedDateTimeZone18.getNameKey((-244803200L));
        int int28 = cachedDateTimeZone18.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone29 = cachedDateTimeZone18.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone18);
        boolean boolean31 = fixedDateTimeZone4.equals((java.lang.Object) cachedDateTimeZone18);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UTC" + "'", str26.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        try {
            long long43 = unsupportedDateTimeField34.set((long) 168, "ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        int int40 = unsupportedDateTimeField34.getDifference((long) (byte) 10, 110L);
        try {
            int int42 = unsupportedDateTimeField34.getMaximumValue((long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Coordinated Universal Time\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(19349999999L);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        java.util.TimeZone timeZone10 = fixedDateTimeZone4.toTimeZone();
        long long12 = fixedDateTimeZone4.nextTransition((-244803200L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-244803200L) + "'", long12 == (-244803200L));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.Period period1 = new org.joda.time.Period(302400100L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        long long13 = unsupportedDurationField11.getUnitMillis();
        boolean boolean14 = unsupportedDurationField11.isSupported();
        boolean boolean15 = unsupportedDurationField11.isSupported();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.plusSeconds(100);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType8 = periodType7.withSecondsRemoved();
        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = periodType9.indexOf(durationFieldType10);
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period6, (java.lang.Object) periodType9);
        org.joda.time.PeriodType periodType13 = periodType9.withMillisRemoved();
        org.joda.time.PeriodType periodType14 = periodType13.withWeeksRemoved();
        org.joda.time.PeriodType periodType15 = periodType14.withWeeksRemoved();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.String str7 = illegalFieldValueException4.toString();
        java.lang.String str8 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "10.0" + "'", str8.equals("10.0"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int30 = dividedDateTimeField28.get((-57599900L));
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
        long long37 = offsetDateTimeField34.add(3200L, (int) (short) 1);
        int int39 = offsetDateTimeField34.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = offsetDateTimeField34.getMinimumValue(readablePartial40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField34.getAsText((long) 8, locale43);
        int int46 = offsetDateTimeField34.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) ' ');
        long long53 = offsetDateTimeField50.add(3200L, (int) (short) 1);
        int int55 = offsetDateTimeField50.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial56 = null;
        java.util.Locale locale58 = null;
        java.lang.String str59 = offsetDateTimeField50.getAsShortText(readablePartial56, (int) '4', locale58);
        java.util.Locale locale60 = null;
        int int61 = offsetDateTimeField50.getMaximumShortTextLength(locale60);
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology62.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, (int) ' ');
        long long68 = offsetDateTimeField65.add(3200L, (int) (short) 1);
        int int70 = offsetDateTimeField65.get((long) (short) 100);
        int int72 = offsetDateTimeField65.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = offsetDateTimeField65.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType73, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType73, (int) 'a');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField78 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType73);
        long long80 = remainderDateTimeField78.roundHalfCeiling((long) (-43104900));
        int int81 = remainderDateTimeField78.getMinimumValue();
        long long83 = remainderDateTimeField78.roundHalfFloor(4L);
        int int84 = remainderDateTimeField78.getMinimumValue();
        int int85 = remainderDateTimeField78.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604803200L + "'", long37 == 604803200L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 33 + "'", int41 == 33);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "33" + "'", str44.equals("33"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 85 + "'", int46 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 604803200L + "'", long53 == 604803200L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 33 + "'", int55 == 33);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "52" + "'", str59.equals("52"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604803200L + "'", long68 == 604803200L);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 33 + "'", int70 == 33);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 33 + "'", int72 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-259200100L) + "'", long80 == (-259200100L));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + (-259200100L) + "'", long83 == (-259200100L));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period3, (java.lang.Object) (-33));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        int int15 = offsetDateTimeField3.getMaximumValue(10L);
        java.util.Locale locale16 = null;
        int int17 = offsetDateTimeField3.getMaximumShortTextLength(locale16);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        boolean boolean41 = unsupportedDateTimeField34.isLenient();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField34.getRangeDurationField();
        long long45 = unsupportedDateTimeField34.add(0L, (-99));
        try {
            int int47 = unsupportedDateTimeField34.getLeapAmount(14400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-312413760000000L) + "'", long45 == (-312413760000000L));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = null;
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        long long5 = cachedDateTimeZone2.previousTransition(360000000L);
        long long7 = cachedDateTimeZone2.convertUTCToLocal((long) 35);
        int int9 = cachedDateTimeZone2.getStandardOffset((-6912000000L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 360000000L + "'", long5 == 360000000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 35L + "'", long7 == 35L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int7 = offsetDateTimeField3.getOffset();
        long long10 = offsetDateTimeField3.add((long) (byte) 1, (long) 3);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1814400001L + "'", long10 == 1814400001L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.Period period1 = org.joda.time.Period.years((-1));
        try {
            org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-99));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210875313600000L) + "'", long1 == (-210875313600000L));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        try {
            java.lang.String str37 = unsupportedDateTimeField34.getAsText(9L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        org.joda.time.DurationField durationField11 = decoratedDurationField10.getWrappedField();
        long long12 = decoratedDurationField10.getUnitMillis();
        long long14 = decoratedDurationField10.getMillis(1L);
        long long16 = decoratedDurationField10.getMillis((int) '4');
        org.joda.time.DurationField durationField17 = decoratedDurationField10.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3600000L + "'", long12 == 3600000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3600000L + "'", long14 == 3600000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 187200000L + "'", long16 == 187200000L);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        java.lang.String str41 = unsupportedDateTimeField34.toString();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField34.getDurationField();
        try {
            int int43 = unsupportedDateTimeField34.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "UnsupportedDateTimeField" + "'", str41.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(durationField42);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.plusSeconds(100);
        org.joda.time.Period period8 = period6.minusWeeks((-43104900));
        org.joda.time.Period period10 = period6.minusHours(32);
        org.joda.time.Period period12 = org.joda.time.Period.hours(100);
        org.joda.time.Period period13 = period12.negated();
        int int14 = period13.size();
        org.joda.time.Period period15 = new org.joda.time.Period();
        int int16 = period15.size();
        org.joda.time.Period period17 = period15.negated();
        org.joda.time.DurationFieldType durationFieldType18 = null;
        int int19 = period17.indexOf(durationFieldType18);
        org.joda.time.DurationFieldType durationFieldType21 = period17.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(durationFieldType21, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.Period period27 = period13.withFieldAdded(durationFieldType21, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology32 = gregorianChronology28.withZone(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone35 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone34);
        int int37 = cachedDateTimeZone35.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone38 = cachedDateTimeZone35.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology39 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology28, dateTimeZone38);
        org.joda.time.Chronology chronology40 = zonedChronology39.withUTC();
        org.joda.time.Period period41 = new org.joda.time.Period();
        int int42 = period41.size();
        org.joda.time.Period period43 = period41.negated();
        int int44 = period41.getDays();
        boolean boolean45 = zonedChronology39.equals((java.lang.Object) int44);
        boolean boolean46 = period13.equals((java.lang.Object) zonedChronology39);
        int int47 = period13.getSeconds();
        org.joda.time.Period period48 = new org.joda.time.Period();
        int int49 = period48.size();
        org.joda.time.Period period50 = period48.negated();
        int int51 = period48.getDays();
        org.joda.time.Period period53 = period48.withYears(8);
        int int55 = period53.getValue(0);
        org.joda.time.PeriodType periodType56 = period53.getPeriodType();
        org.joda.time.Period period57 = period13.withPeriodType(periodType56);
        org.joda.time.PeriodType periodType58 = periodType56.withDaysRemoved();
        org.joda.time.Period period59 = period10.normalizedStandard(periodType56);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(cachedDateTimeZone35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(zonedChronology39);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 8 + "'", int42 == 8);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 8 + "'", int49 == 8);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 8 + "'", int55 == 8);
        org.junit.Assert.assertNotNull(periodType56);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(periodType58);
        org.junit.Assert.assertNotNull(period59);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) -1, (int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        int int37 = unsupportedDateTimeField34.getDifference((long) '4', (-210866414400000L));
        long long40 = unsupportedDateTimeField34.getDifferenceAsLong((long) 'a', (-230400000L));
        boolean boolean41 = unsupportedDateTimeField34.isSupported();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField34.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 66 + "'", int37 == 66);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(durationField42);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField3.getWrappedField();
        long long17 = offsetDateTimeField3.add((long) 4, (int) '4');
        long long19 = offsetDateTimeField3.roundHalfFloor((-58571700L));
        long long22 = offsetDateTimeField3.add((-43104900L), 0);
        org.joda.time.DurationField durationField23 = offsetDateTimeField3.getLeapDurationField();
        java.lang.String str25 = offsetDateTimeField3.getAsText((long) 3);
        org.joda.time.ReadablePartial readablePartial26 = null;
        java.util.Locale locale27 = null;
        try {
            java.lang.String str28 = offsetDateTimeField3.getAsText(readablePartial26, locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31449600004L + "'", long17 == 31449600004L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200100L) + "'", long19 == (-259200100L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-43104900L) + "'", long22 == (-43104900L));
        org.junit.Assert.assertNull(durationField23);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "33" + "'", str25.equals("33"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.plusSeconds(100);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType8 = periodType7.withSecondsRemoved();
        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = periodType9.indexOf(durationFieldType10);
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period6, (java.lang.Object) periodType9);
        org.joda.time.PeriodType periodType13 = periodType9.withMillisRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) ' ');
        long long20 = offsetDateTimeField17.add(3200L, (int) (short) 1);
        int int22 = offsetDateTimeField17.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int int24 = offsetDateTimeField17.getMinimumValue(readablePartial23);
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField17.getAsText((long) 8, locale26);
        int int29 = offsetDateTimeField17.getMaximumValue(10L);
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField17.getAsText((long) ' ', locale31);
        org.joda.time.DurationField durationField33 = offsetDateTimeField17.getLeapDurationField();
        boolean boolean34 = periodType13.equals((java.lang.Object) offsetDateTimeField17);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, (int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 604803200L + "'", long20 == 604803200L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 33 + "'", int22 == 33);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 33 + "'", int24 == 33);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "33" + "'", str27.equals("33"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 85 + "'", int29 == 85);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "33" + "'", str32.equals("33"));
        org.junit.Assert.assertNull(durationField33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.Period period29 = new org.joda.time.Period();
        int int30 = period29.size();
        org.joda.time.Period period31 = period29.negated();
        int int32 = period29.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter33 = null;
        java.lang.String str34 = period29.toString(periodFormatter33);
        org.joda.time.DurationFieldType durationFieldType36 = period29.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField37 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
        org.joda.time.Period period38 = new org.joda.time.Period();
        int int39 = period38.size();
        org.joda.time.Period period40 = period38.negated();
        org.joda.time.DurationFieldType durationFieldType41 = null;
        int int42 = period40.indexOf(durationFieldType41);
        org.joda.time.DurationFieldType durationFieldType44 = period40.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(durationFieldType44, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType44);
        boolean boolean50 = unsupportedDurationField49.isPrecise();
        long long51 = unsupportedDurationField49.getUnitMillis();
        boolean boolean52 = unsupportedDurationField49.isSupported();
        int int53 = unsupportedDurationField37.compareTo((org.joda.time.DurationField) unsupportedDurationField49);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField54 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, (org.joda.time.DurationField) unsupportedDurationField49);
        org.joda.time.ReadablePartial readablePartial55 = null;
        java.util.Locale locale56 = null;
        try {
            java.lang.String str57 = unsupportedDateTimeField54.getAsShortText(readablePartial55, locale56);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PT0S" + "'", str34.equals("PT0S"));
        org.junit.Assert.assertNotNull(durationFieldType36);
        org.junit.Assert.assertNotNull(unsupportedDurationField37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 8 + "'", int39 == 8);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType44);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField54);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) zonedChronology11, dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone18 = zonedChronology11.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean2 = iSOChronology0.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.monthOfYear();
        org.joda.time.DurationField durationField4 = iSOChronology0.days();
        long long7 = durationField4.subtract(0L, (int) (byte) 1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-86400000L) + "'", long7 == (-86400000L));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        long long5 = dateTimeZone3.convertUTCToLocal(1L);
        long long7 = dateTimeZone1.getMillisKeepLocal(dateTimeZone3, (long) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        long long32 = dividedDateTimeField28.add((-3935130120000000L), (long) '#');
        java.util.Locale locale34 = null;
        java.lang.String str35 = dividedDateTimeField28.getAsShortText(466560000000004L, locale34);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3934918440000000L) + "'", long32 == (-3934918440000000L));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "6" + "'", str35.equals("6"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Coordinated Universal Time");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.toString();
        java.lang.String str4 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")" + "'", str3.equals("(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) '4');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        int int15 = offsetDateTimeField3.getMaximumValue(10L);
        org.joda.time.ReadablePartial readablePartial16 = null;
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField3.getAsText(readablePartial16, (int) (short) 10, locale18);
        long long22 = offsetDateTimeField3.getDifferenceAsLong(0L, (long) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10" + "'", str19.equals("10"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "YearDay");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(32);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder2.addRecurringSavings("years", 66, (int) 'a', (int) ' ', '4', 230400000, (int) (short) -1, 230934, true, 66);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        org.joda.time.ReadablePartial readablePartial38 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) ' ');
        long long46 = offsetDateTimeField43.add((long) (-1), (int) ' ');
        org.joda.time.ReadablePartial readablePartial47 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period49 = new org.joda.time.Period();
        int int50 = period49.size();
        org.joda.time.Period period51 = period49.negated();
        boolean boolean52 = gregorianChronology48.equals((java.lang.Object) period51);
        org.joda.time.DurationField durationField53 = gregorianChronology48.weeks();
        org.joda.time.DurationField durationField54 = gregorianChronology48.millis();
        org.joda.time.DurationField durationField55 = gregorianChronology48.hours();
        org.joda.time.Period period56 = new org.joda.time.Period();
        boolean boolean58 = period56.equals((java.lang.Object) false);
        org.joda.time.Period period60 = period56.plusMillis((int) (byte) 1);
        int[] intArray63 = gregorianChronology48.get((org.joda.time.ReadablePeriod) period56, (-10L), (long) (short) 0);
        int int64 = offsetDateTimeField43.getMinimumValue(readablePartial47, intArray63);
        try {
            int[] intArray66 = unsupportedDateTimeField34.set(readablePartial38, 360000035, intArray63, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 19353599999L + "'", long46 == 19353599999L);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 8 + "'", int50 == 8);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 33 + "'", int64 == 33);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        int int13 = decoratedDurationField10.getDifference((-10L), 2440588L);
        java.lang.String str14 = decoratedDurationField10.getName();
        long long16 = decoratedDurationField10.getValueAsLong((long) (byte) 10);
        long long19 = decoratedDurationField10.add((long) '4', (long) (byte) 100);
        long long21 = decoratedDurationField10.getMillis((long) 5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "years" + "'", str14.equals("years"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 360000052L + "'", long19 == 360000052L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 18000000L + "'", long21 == 18000000L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("YearDay", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"YearDay/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(2440587L, "PeriodType[YearDayTime]");
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        int int43 = unsupportedDateTimeField34.getDifference((long) (short) 1, 604800000L);
        org.joda.time.ReadablePartial readablePartial44 = null;
        java.util.Locale locale46 = null;
        try {
            java.lang.String str47 = unsupportedDateTimeField34.getAsText(readablePartial44, (int) (short) 0, locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-2), (-5325), 0, 3499);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1673 + "'", int4 == 1673);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, 10);
        long long31 = offsetDateTimeField3.add(129600000L, 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 129600000L + "'", long31 == 129600000L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Duration duration3 = period1.toDurationFrom(readableInstant2);
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration3);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Coordinated Universal Time");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("Coordinated Universal Time");
        java.lang.String str6 = jodaTimePermission5.getName();
        java.security.PermissionCollection permissionCollection7 = jodaTimePermission5.newPermissionCollection();
        boolean boolean8 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
        java.security.PermissionCollection permissionCollection9 = jodaTimePermission1.newPermissionCollection();
        java.security.PermissionCollection permissionCollection10 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
        org.junit.Assert.assertNotNull(permissionCollection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(permissionCollection9);
        org.junit.Assert.assertNotNull(permissionCollection10);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.Period period2 = new org.joda.time.Period((-210858724803200L), 31449600010L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        org.joda.time.DurationField durationField11 = decoratedDurationField10.getWrappedField();
        java.lang.String str12 = decoratedDurationField10.toString();
        long long15 = decoratedDurationField10.add((-86400000L), (-5325));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DurationField[years]" + "'", str12.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-19256400000L) + "'", long15 == (-19256400000L));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        boolean boolean41 = unsupportedDateTimeField34.isLenient();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField34.getRangeDurationField();
        org.joda.time.DurationField durationField43 = unsupportedDateTimeField34.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial44 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology46.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology46.hourOfHalfday();
        int int49 = gregorianChronology46.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology46.minuteOfHour();
        long long54 = gregorianChronology46.add((long) 4, (long) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField56 = gregorianChronology55.minutes();
        org.joda.time.Chronology chronology57 = gregorianChronology55.withUTC();
        org.joda.time.Period period59 = org.joda.time.Period.months((int) '4');
        int[] intArray61 = gregorianChronology55.get((org.joda.time.ReadablePeriod) period59, (long) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone66 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology67 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology55, (org.joda.time.DateTimeZone) fixedDateTimeZone66);
        org.joda.time.Chronology chronology68 = gregorianChronology46.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone66);
        org.joda.time.Period period69 = new org.joda.time.Period();
        int int70 = period69.size();
        org.joda.time.Period period71 = period69.negated();
        int int72 = period69.getMillis();
        int int73 = period69.getMonths();
        org.joda.time.PeriodType periodType74 = period69.getPeriodType();
        int int75 = period69.getMonths();
        org.joda.time.Period period77 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType78 = period77.getPeriodType();
        org.joda.time.Period period79 = period69.withPeriodType(periodType78);
        org.joda.time.Period period80 = period69.negated();
        org.joda.time.Duration duration81 = period80.toStandardDuration();
        org.joda.time.Period period83 = period80.plusMonths((int) '4');
        int int84 = period83.getMinutes();
        int[] intArray87 = gregorianChronology46.get((org.joda.time.ReadablePeriod) period83, 19349999999L, 266400108L);
        try {
            int[] intArray89 = unsupportedDateTimeField34.addWrapPartial(readablePartial44, (int) (byte) 10, intArray87, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertNull(durationField43);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 4L + "'", long54 == 4L);
        org.junit.Assert.assertNotNull(gregorianChronology55);
        org.junit.Assert.assertNotNull(durationField56);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(zonedChronology67);
        org.junit.Assert.assertNotNull(chronology68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 8 + "'", int70 == 8);
        org.junit.Assert.assertNotNull(period71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(periodType74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(period77);
        org.junit.Assert.assertNotNull(periodType78);
        org.junit.Assert.assertNotNull(period79);
        org.junit.Assert.assertNotNull(period80);
        org.junit.Assert.assertNotNull(duration81);
        org.junit.Assert.assertNotNull(period83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(intArray87);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period();
        int int5 = period4.size();
        org.joda.time.PeriodType periodType6 = period4.getPeriodType();
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration2, readableInstant3, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withYearsRemoved();
        org.joda.time.PeriodType periodType9 = periodType6.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology14 = gregorianChronology10.withZone(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        int int19 = cachedDateTimeZone17.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone20 = cachedDateTimeZone17.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology10, dateTimeZone20);
        org.joda.time.Chronology chronology22 = zonedChronology21.withUTC();
        org.joda.time.Period period23 = new org.joda.time.Period((long) (byte) 100, (-244803200L), periodType6, (org.joda.time.Chronology) zonedChronology21);
        org.joda.time.DateTimeField dateTimeField24 = zonedChronology21.millisOfDay();
        try {
            long long29 = zonedChronology21.getDateTimeMillis((int) (byte) -1, (-72), 33, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -72 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("33", "UnsupportedDurationField[years]");
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.PeriodType periodType2 = period0.getPeriodType();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType4 = periodType3.withSecondsRemoved();
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = periodType5.indexOf(durationFieldType6);
        org.joda.time.Period period8 = period0.normalizedStandard(periodType5);
        int int9 = period8.getHours();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        int int13 = decoratedDurationField10.getDifference((-10L), 2440588L);
        java.lang.String str14 = decoratedDurationField10.getName();
        long long16 = decoratedDurationField10.getValueAsLong((long) (byte) 10);
        java.lang.String str17 = decoratedDurationField10.getName();
        java.lang.String str18 = decoratedDurationField10.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "years" + "'", str14.equals("years"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "years" + "'", str17.equals("years"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "years" + "'", str18.equals("years"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.LocalDateTime localDateTime4 = null;
        boolean boolean5 = dateTimeZone2.isLocalDateTimeGap(localDateTime4);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int30 = dividedDateTimeField28.get((-57599900L));
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
        long long37 = offsetDateTimeField34.add(3200L, (int) (short) 1);
        int int39 = offsetDateTimeField34.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = offsetDateTimeField34.getMinimumValue(readablePartial40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField34.getAsText((long) 8, locale43);
        int int46 = offsetDateTimeField34.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) ' ');
        long long53 = offsetDateTimeField50.add(3200L, (int) (short) 1);
        int int55 = offsetDateTimeField50.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial56 = null;
        java.util.Locale locale58 = null;
        java.lang.String str59 = offsetDateTimeField50.getAsShortText(readablePartial56, (int) '4', locale58);
        java.util.Locale locale60 = null;
        int int61 = offsetDateTimeField50.getMaximumShortTextLength(locale60);
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology62.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, (int) ' ');
        long long68 = offsetDateTimeField65.add(3200L, (int) (short) 1);
        int int70 = offsetDateTimeField65.get((long) (short) 100);
        int int72 = offsetDateTimeField65.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = offsetDateTimeField65.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType73, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType73, (int) 'a');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField78 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType73);
        long long80 = remainderDateTimeField78.roundHalfCeiling((long) (-43104900));
        int int81 = remainderDateTimeField78.getMinimumValue();
        int int82 = remainderDateTimeField78.getMaximumValue();
        org.joda.time.DurationField durationField83 = remainderDateTimeField78.getRangeDurationField();
        org.joda.time.DurationField durationField84 = remainderDateTimeField78.getLeapDurationField();
        long long86 = remainderDateTimeField78.roundHalfFloor((-19256400000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604803200L + "'", long37 == 604803200L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 33 + "'", int41 == 33);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "33" + "'", str44.equals("33"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 85 + "'", int46 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 604803200L + "'", long53 == 604803200L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 33 + "'", int55 == 33);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "52" + "'", str59.equals("52"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604803200L + "'", long68 == 604803200L);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 33 + "'", int70 == 33);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 33 + "'", int72 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-259200100L) + "'", long80 == (-259200100L));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 9 + "'", int82 == 9);
        org.junit.Assert.assertNotNull(durationField83);
        org.junit.Assert.assertNull(durationField84);
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + (-19008000100L) + "'", long86 == (-19008000100L));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        long long32 = dividedDateTimeField28.add((-3935130120000000L), (long) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField28, 10);
        long long37 = dividedDateTimeField28.getDifferenceAsLong((-210858120000000L), (-110449440000100L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3934918440000000L) + "'", long32 == (-3934918440000000L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-16601L) + "'", long37 == (-16601L));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField8 = gregorianChronology0.years();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology0.getZone();
        try {
            long long17 = gregorianChronology0.getDateTimeMillis(35, 9, (-1), (int) (byte) 0, 360000035, (int) (short) 0, 66);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 360000035 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType3 = periodType2.withMonthsRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType5 = periodType2.withHoursRemoved();
        java.lang.String str6 = periodType5.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "HoursNoHours" + "'", str6.equals("HoursNoHours"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        long long32 = dividedDateTimeField28.add((-3935130120000000L), (long) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField28, 10);
        long long37 = dividedDateTimeField28.set((long) 100, 4);
        long long39 = dividedDateTimeField28.remainder(18144000009L);
        long long42 = dividedDateTimeField28.add((-259200100L), (-10255));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3934918440000000L) + "'", long32 == (-3934918440000000L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 6048000100L + "'", long37 == 6048000100L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 9L + "'", long39 == 9L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-62022499200100L) + "'", long42 == (-62022499200100L));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        org.joda.time.PeriodType periodType1 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withMillisRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period4 = new org.joda.time.Period();
        int int5 = period4.size();
        org.joda.time.Period period6 = period4.negated();
        int int7 = period4.getMillis();
        int int8 = period4.getMonths();
        org.joda.time.PeriodType periodType9 = period4.getPeriodType();
        int int10 = period4.getMonths();
        org.joda.time.Period period12 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType13 = period12.getPeriodType();
        org.joda.time.Period period14 = period4.withPeriodType(periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period((long) '#', 2440588L, periodType13);
        org.joda.time.Period period16 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType13);
        org.joda.time.PeriodType periodType17 = periodType13.withYearsRemoved();
        java.lang.String str18 = periodType17.getName();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "StandardNoYears" + "'", str18.equals("StandardNoYears"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period6 = period4.withPeriodType(periodType5);
        org.joda.time.Period period7 = period2.plus((org.joda.time.ReadablePeriod) period4);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period4.toDurationFrom(readableInstant8);
        org.joda.time.Period period11 = period4.withMillis(230400000);
        org.joda.time.Period period13 = period11.plusMonths(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.PeriodType periodType5 = period0.getPeriodType();
        int int6 = period0.getMonths();
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.Period period10 = period0.withPeriodType(periodType9);
        org.joda.time.Period period11 = period0.negated();
        org.joda.time.Period period13 = org.joda.time.Period.hours(100);
        org.joda.time.Period period14 = period13.negated();
        org.joda.time.Period period16 = period13.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass17 = period16.getClass();
        org.joda.time.Period period19 = period16.minusMonths((int) (short) 10);
        org.joda.time.Period period20 = period19.normalizedStandard();
        org.joda.time.PeriodType periodType21 = null;
        org.joda.time.Period period22 = period19.withPeriodType(periodType21);
        org.joda.time.Period period23 = period11.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.Period period25 = period11.withDays((-5325));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        org.joda.time.DateTimeField dateTimeField14 = offsetDateTimeField3.getWrappedField();
        long long17 = offsetDateTimeField3.add((long) 4, (int) '4');
        long long19 = offsetDateTimeField3.roundHalfFloor((-58571700L));
        long long21 = offsetDateTimeField3.roundHalfFloor((long) 'a');
        java.util.Locale locale22 = null;
        int int23 = offsetDateTimeField3.getMaximumTextLength(locale22);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31449600004L + "'", long17 == 31449600004L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200100L) + "'", long19 == (-259200100L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-259200100L) + "'", long21 == (-259200100L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2 + "'", int23 == 2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        java.lang.String str16 = offsetDateTimeField3.getAsText(99L);
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField3.getMaximumShortTextLength(locale17);
        int int19 = offsetDateTimeField3.getMaximumValue();
        org.joda.time.DurationField durationField20 = offsetDateTimeField3.getRangeDurationField();
        long long22 = offsetDateTimeField3.roundHalfEven(604800000L);
        int int24 = offsetDateTimeField3.getMinimumValue((-210855096003200L));
        int int26 = offsetDateTimeField3.getLeapAmount((long) 5);
        long long28 = offsetDateTimeField3.roundFloor((long) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "33" + "'", str16.equals("33"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 85 + "'", int19 == 85);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 345599900L + "'", long22 == 345599900L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 33 + "'", int24 == 33);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-259200100L) + "'", long28 == (-259200100L));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.months();
        org.joda.time.Period period3 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        int int4 = periodType2.size();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DurationField durationField7 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        boolean boolean41 = unsupportedDateTimeField34.isLenient();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField34.getRangeDurationField();
        long long45 = unsupportedDateTimeField34.add(0L, (-99));
        org.joda.time.ReadablePartial readablePartial46 = null;
        java.util.Locale locale47 = null;
        try {
            java.lang.String str48 = unsupportedDateTimeField34.getAsShortText(readablePartial46, locale47);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-312413760000000L) + "'", long45 == (-312413760000000L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.Period period2 = org.joda.time.Period.hours(100);
        org.joda.time.Period period3 = period2.negated();
        int int4 = period3.size();
        org.joda.time.Period period5 = new org.joda.time.Period();
        int int6 = period5.size();
        org.joda.time.Period period7 = period5.negated();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = period7.indexOf(durationFieldType8);
        org.joda.time.DurationFieldType durationFieldType11 = period7.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(durationFieldType11, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.Period period17 = period3.withFieldAdded(durationFieldType11, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology22 = gregorianChronology18.withZone(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone24);
        int int27 = cachedDateTimeZone25.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone28 = cachedDateTimeZone25.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology29 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology18, dateTimeZone28);
        org.joda.time.Chronology chronology30 = zonedChronology29.withUTC();
        org.joda.time.Period period31 = new org.joda.time.Period();
        int int32 = period31.size();
        org.joda.time.Period period33 = period31.negated();
        int int34 = period31.getDays();
        boolean boolean35 = zonedChronology29.equals((java.lang.Object) int34);
        boolean boolean36 = period3.equals((java.lang.Object) zonedChronology29);
        long long40 = zonedChronology29.add(1000L, 110449353600052L, 100);
        org.joda.time.DateTimeField dateTimeField41 = zonedChronology29.millisOfSecond();
        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (-210866673600000L), (java.lang.Object) dateTimeField41);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(zonedChronology29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 8 + "'", int32 == 8);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 11044935360006200L + "'", long40 == 11044935360006200L);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period();
        int int3 = period2.size();
        org.joda.time.Period period4 = period2.negated();
        int int5 = period2.getMillis();
        int int6 = period2.getMonths();
        org.joda.time.PeriodType periodType7 = period2.getPeriodType();
        int int8 = period2.getMonths();
        org.joda.time.Period period10 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.joda.time.Period period12 = period2.withPeriodType(periodType11);
        org.joda.time.PeriodType periodType13 = periodType11.withYearsRemoved();
        try {
            org.joda.time.Period period14 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        java.lang.String str11 = decoratedDurationField10.getName();
        boolean boolean12 = decoratedDurationField10.isSupported();
        long long15 = decoratedDurationField10.getDifferenceAsLong((long) (byte) 100, (long) 100);
        java.lang.String str16 = decoratedDurationField10.toString();
        long long19 = decoratedDurationField10.getMillis((long) (byte) 1, (-10L));
        org.joda.time.DurationField durationField20 = decoratedDurationField10.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "years" + "'", str11.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DurationField[years]" + "'", str16.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 3600000L + "'", long19 == 3600000L);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        int int40 = unsupportedDateTimeField34.getDifference((long) (byte) 10, 110L);
        try {
            int int41 = unsupportedDateTimeField34.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(32);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder2.toDateTimeZone("GregorianChronology[PT100H]", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder2.setFixedSavings("ZonedChronology[GregorianChronology[UTC], UTC]", 230400000);
        java.io.OutputStream outputStream10 = null;
        try {
            dateTimeZoneBuilder2.writeTo("", outputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int30 = dividedDateTimeField28.get((-57599900L));
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
        long long37 = offsetDateTimeField34.add(3200L, (int) (short) 1);
        int int39 = offsetDateTimeField34.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = offsetDateTimeField34.getMinimumValue(readablePartial40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField34.getAsText((long) 8, locale43);
        int int46 = offsetDateTimeField34.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) ' ');
        long long53 = offsetDateTimeField50.add(3200L, (int) (short) 1);
        int int55 = offsetDateTimeField50.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial56 = null;
        java.util.Locale locale58 = null;
        java.lang.String str59 = offsetDateTimeField50.getAsShortText(readablePartial56, (int) '4', locale58);
        java.util.Locale locale60 = null;
        int int61 = offsetDateTimeField50.getMaximumShortTextLength(locale60);
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology62.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, (int) ' ');
        long long68 = offsetDateTimeField65.add(3200L, (int) (short) 1);
        int int70 = offsetDateTimeField65.get((long) (short) 100);
        int int72 = offsetDateTimeField65.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = offsetDateTimeField65.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType73, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType73, (int) 'a');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField78 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType73);
        long long80 = remainderDateTimeField78.roundHalfCeiling((long) (-43104900));
        int int82 = remainderDateTimeField78.get(14400003L);
        java.lang.String str84 = remainderDateTimeField78.getAsShortText((-58572096L));
        long long87 = remainderDateTimeField78.add((long) '4', (-58571700L));
        org.joda.time.DateTimeFieldType dateTimeFieldType88 = remainderDateTimeField78.getType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604803200L + "'", long37 == 604803200L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 33 + "'", int41 == 33);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "33" + "'", str44.equals("33"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 85 + "'", int46 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 604803200L + "'", long53 == 604803200L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 33 + "'", int55 == 33);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "52" + "'", str59.equals("52"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604803200L + "'", long68 == 604803200L);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 33 + "'", int70 == 33);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 33 + "'", int72 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-259200100L) + "'", long80 == (-259200100L));
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 3 + "'", int82 == 3);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "3" + "'", str84.equals("3"));
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + (-35424164159999948L) + "'", long87 == (-35424164159999948L));
        org.junit.Assert.assertNotNull(dateTimeFieldType88);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        org.joda.time.DurationField durationField11 = decoratedDurationField10.getWrappedField();
        long long12 = decoratedDurationField10.getUnitMillis();
        long long14 = decoratedDurationField10.getMillis(1L);
        long long17 = decoratedDurationField10.getMillis(100, (long) (-2));
        long long20 = decoratedDurationField10.getMillis(29286042, 0L);
        long long23 = decoratedDurationField10.add((long) 4, 129600000L);
        org.joda.time.DurationField durationField24 = decoratedDurationField10.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3600000L + "'", long12 == 3600000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3600000L + "'", long14 == 3600000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 360000000L + "'", long17 == 360000000L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 105429751200000L + "'", long20 == 105429751200000L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 466560000000004L + "'", long23 == 466560000000004L);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        long long13 = unsupportedDurationField11.getUnitMillis();
        try {
            long long16 = unsupportedDurationField11.getDifferenceAsLong((-72L), 3200L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        boolean boolean13 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException12);
        java.lang.String str14 = illegalFieldValueException12.toString();
        java.lang.String str15 = illegalFieldValueException12.getIllegalValueAsString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException12);
        java.lang.Throwable[] throwableArray17 = illegalFieldValueException12.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]" + "'", str14.equals("org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "10.0" + "'", str15.equals("10.0"));
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        boolean boolean41 = unsupportedDateTimeField34.isLenient();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField34.getRangeDurationField();
        long long45 = unsupportedDateTimeField34.add(0L, (-99));
        long long48 = unsupportedDateTimeField34.add((long) 9, (int) '4');
        try {
            long long50 = unsupportedDateTimeField34.roundCeiling(345600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-312413760000000L) + "'", long45 == (-312413760000000L));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 164096150400009L + "'", long48 == 164096150400009L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) ' ');
        long long9 = offsetDateTimeField6.add(3200L, (int) (short) 1);
        int int11 = offsetDateTimeField6.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField6.getAsShortText(readablePartial12, (int) '4', locale14);
        java.util.Locale locale16 = null;
        int int17 = offsetDateTimeField6.getMaximumShortTextLength(locale16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) ' ');
        long long24 = offsetDateTimeField21.add(3200L, (int) (short) 1);
        int int26 = offsetDateTimeField21.get((long) (short) 100);
        int int28 = offsetDateTimeField21.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField21.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType29, (int) (byte) 10);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 2);
        java.util.Locale locale35 = null;
        java.lang.String str36 = dividedDateTimeField33.getAsText((int) (byte) 100, locale35);
        long long39 = dividedDateTimeField33.add((long) (byte) 100, 10L);
        long long42 = dividedDateTimeField33.getDifferenceAsLong(0L, 35L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 604803200L + "'", long9 == 604803200L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "52" + "'", str15.equals("52"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 604803200L + "'", long24 == 604803200L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 33 + "'", int26 == 33);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 33 + "'", int28 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "100" + "'", str36.equals("100"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 72000100L + "'", long39 == 72000100L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField8 = gregorianChronology0.years();
        long long14 = gregorianChronology0.getDateTimeMillis((long) '4', 4, (int) (short) 1, (int) '#', (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 14495000L + "'", long14 == 14495000L);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(85);
        org.joda.time.Period period3 = period1.withHours((int) '#');
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField8 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.year();
        org.joda.time.DurationField durationField10 = gregorianChronology0.weeks();
        org.joda.time.Period period12 = org.joda.time.Period.hours(100);
        org.joda.time.Period period13 = period12.negated();
        org.joda.time.Period period15 = period12.minusMinutes((int) (short) 0);
        org.joda.time.Period period17 = period15.plusSeconds(100);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType19 = periodType18.withSecondsRemoved();
        org.joda.time.PeriodType periodType20 = org.joda.time.DateTimeUtils.getPeriodType(periodType18);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        int int22 = periodType20.indexOf(durationFieldType21);
        boolean boolean23 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period17, (java.lang.Object) periodType20);
        org.joda.time.PeriodType periodType24 = periodType20.withMillisRemoved();
        org.joda.time.PeriodType periodType25 = periodType24.withWeeksRemoved();
        boolean boolean26 = gregorianChronology0.equals((java.lang.Object) periodType25);
        try {
            long long32 = gregorianChronology0.getDateTimeMillis((-62032176000100L), 0, 1673, (int) (byte) 10, 7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1673 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Coordinated Universal Time", "3");
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.PeriodType periodType2 = period0.getPeriodType();
        java.lang.String str3 = periodType2.getName();
        int int4 = periodType2.size();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = periodType2.indexOf(durationFieldType5);
        org.joda.time.PeriodType periodType7 = periodType2.withMinutesRemoved();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Standard" + "'", str3.equals("Standard"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add((long) (-1), (int) ' ');
        long long8 = offsetDateTimeField3.roundFloor((long) (byte) 100);
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField3.getMaximumShortTextLength(locale9);
        int int12 = offsetDateTimeField3.get((long) (byte) 1);
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField3.getAsText((-210858134399967L), locale14);
        long long17 = offsetDateTimeField3.roundFloor(21168000350L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19353599999L + "'", long6 == 19353599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-259200100L) + "'", long8 == (-259200100L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 33 + "'", int12 == 33);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "42" + "'", str15.equals("42"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 20908799900L + "'", long17 == 20908799900L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.Period period7 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period9 = period7.withPeriodType(periodType8);
        boolean boolean10 = fixedDateTimeZone4.equals((java.lang.Object) periodType8);
        int int12 = fixedDateTimeZone4.getStandardOffset(350L);
        java.lang.Object obj13 = null;
        boolean boolean14 = fixedDateTimeZone4.equals(obj13);
        boolean boolean16 = fixedDateTimeZone4.isStandardOffset(302400100L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        int int13 = decoratedDurationField10.getDifference((-10L), 2440588L);
        java.lang.String str14 = decoratedDurationField10.getName();
        long long16 = decoratedDurationField10.getValueAsLong((long) (byte) 10);
        java.lang.String str17 = decoratedDurationField10.getName();
        long long20 = decoratedDurationField10.getDifferenceAsLong((long) 32, 604800000L);
        boolean boolean21 = decoratedDurationField10.isPrecise();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "years" + "'", str14.equals("years"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "years" + "'", str17.equals("years"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-167L) + "'", long20 == (-167L));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.minusMinutes((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = period4.indexOf(durationFieldType5);
        org.joda.time.Period period8 = period4.withYears((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period4.toDurationFrom(readableInstant9);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        int int10 = offsetDateTimeField3.get((-10L));
        long long13 = offsetDateTimeField3.getDifferenceAsLong(360000000L, 0L);
        int int15 = offsetDateTimeField3.get(164096150400009L);
        java.lang.String str16 = offsetDateTimeField3.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 33 + "'", int15 == 33);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[weekOfWeekyear]" + "'", str16.equals("DateTimeField[weekOfWeekyear]"));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        long long15 = offsetDateTimeField3.roundFloor((long) 2);
        boolean boolean17 = offsetDateTimeField3.isLeap((-210858120000000L));
        org.joda.time.ReadablePartial readablePartial18 = null;
        int int19 = offsetDateTimeField3.getMaximumValue(readablePartial18);
        long long22 = offsetDateTimeField3.add((-210858724803200L), (long) 6);
        int int24 = offsetDateTimeField3.getLeapAmount((long) 604803200);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int[] intArray27 = null;
        java.util.Locale locale29 = null;
        try {
            int[] intArray30 = offsetDateTimeField3.set(readablePartial25, (int) (byte) 1, intArray27, "PeriodType[YearDayTime]", locale29);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PeriodType[YearDayTime]\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-259200100L) + "'", long15 == (-259200100L));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 85 + "'", int19 == 85);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-210855096003200L) + "'", long22 == (-210855096003200L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField5 = gregorianChronology0.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int30 = dividedDateTimeField28.get((-57599900L));
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
        long long37 = offsetDateTimeField34.add(3200L, (int) (short) 1);
        int int39 = offsetDateTimeField34.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = offsetDateTimeField34.getMinimumValue(readablePartial40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField34.getAsText((long) 8, locale43);
        int int46 = offsetDateTimeField34.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) ' ');
        long long53 = offsetDateTimeField50.add(3200L, (int) (short) 1);
        int int55 = offsetDateTimeField50.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial56 = null;
        java.util.Locale locale58 = null;
        java.lang.String str59 = offsetDateTimeField50.getAsShortText(readablePartial56, (int) '4', locale58);
        java.util.Locale locale60 = null;
        int int61 = offsetDateTimeField50.getMaximumShortTextLength(locale60);
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology62.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, (int) ' ');
        long long68 = offsetDateTimeField65.add(3200L, (int) (short) 1);
        int int70 = offsetDateTimeField65.get((long) (short) 100);
        int int72 = offsetDateTimeField65.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = offsetDateTimeField65.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType73, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType73, (int) 'a');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField78 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType73);
        long long80 = remainderDateTimeField78.roundHalfCeiling((long) (-43104900));
        long long82 = remainderDateTimeField78.roundCeiling((long) '#');
        long long84 = remainderDateTimeField78.roundFloor((long) 85);
        org.joda.time.DateTimeFieldType dateTimeFieldType85 = remainderDateTimeField78.getType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604803200L + "'", long37 == 604803200L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 33 + "'", int41 == 33);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "33" + "'", str44.equals("33"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 85 + "'", int46 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 604803200L + "'", long53 == 604803200L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 33 + "'", int55 == 33);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "52" + "'", str59.equals("52"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604803200L + "'", long68 == 604803200L);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 33 + "'", int70 == 33);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 33 + "'", int72 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-259200100L) + "'", long80 == (-259200100L));
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 345599900L + "'", long82 == 345599900L);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + (-259200100L) + "'", long84 == (-259200100L));
        org.junit.Assert.assertNotNull(dateTimeFieldType85);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(3600000L, 110449353600052L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-110449350000052L) + "'", long2 == (-110449350000052L));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.PeriodType periodType5 = period3.getPeriodType();
        org.joda.time.Period period6 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType5);
        org.joda.time.PeriodType periodType7 = periodType5.withYearsRemoved();
        org.joda.time.PeriodType periodType8 = periodType5.withHoursRemoved();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(0L, periodType8, chronology9);
        org.joda.time.Seconds seconds11 = period10.toStandardSeconds();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(seconds11);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        java.lang.String str11 = decoratedDurationField10.getName();
        boolean boolean12 = decoratedDurationField10.isSupported();
        long long15 = decoratedDurationField10.getDifferenceAsLong((long) (byte) 100, (long) 100);
        java.lang.String str16 = decoratedDurationField10.toString();
        long long19 = decoratedDurationField10.getMillis((long) (byte) 1, (-10L));
        java.lang.String str20 = decoratedDurationField10.toString();
        long long21 = decoratedDurationField10.getUnitMillis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "years" + "'", str11.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DurationField[years]" + "'", str16.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 3600000L + "'", long19 == 3600000L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DurationField[years]" + "'", str20.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 3600000L + "'", long21 == 3600000L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        org.joda.time.DurationField durationField11 = decoratedDurationField10.getWrappedField();
        java.lang.String str12 = decoratedDurationField10.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.weekOfWeekyear();
        org.joda.time.DurationField durationField15 = gregorianChronology13.hours();
        org.joda.time.Period period16 = new org.joda.time.Period();
        int int17 = period16.size();
        org.joda.time.Period period18 = period16.negated();
        org.joda.time.DurationFieldType durationFieldType19 = null;
        int int20 = period18.indexOf(durationFieldType19);
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField23 = new org.joda.time.field.DecoratedDurationField(durationField15, durationFieldType22);
        java.lang.String str24 = decoratedDurationField23.getName();
        boolean boolean25 = decoratedDurationField23.isSupported();
        int int26 = decoratedDurationField10.compareTo((org.joda.time.DurationField) decoratedDurationField23);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DurationField[years]" + "'", str12.equals("DurationField[years]"));
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "years" + "'", str24.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "StandardNoYears");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundCeiling((-62032493221900L));
        try {
            long long8 = offsetDateTimeField3.set(110449353600062000L, 1673);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1673 for weekOfWeekyear must be in the range [33,85]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62032176000100L) + "'", long5 == (-62032176000100L));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.Period period4 = org.joda.time.Period.months((int) '4');
        int[] intArray6 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period4, (long) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone15);
        org.joda.time.Chronology chronology17 = zonedChronology12.withZone(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology12.minuteOfHour();
        java.lang.Object obj19 = null;
        boolean boolean20 = zonedChronology12.equals(obj19);
        org.joda.time.Chronology chronology21 = zonedChronology12.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(chronology21);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        java.lang.String str12 = unsupportedDurationField11.getName();
        try {
            int int15 = unsupportedDurationField11.getValue(110449353600052L, (-5325L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "years" + "'", str12.equals("years"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        long long32 = dividedDateTimeField28.add((-3935130120000000L), (long) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField28, 10);
        java.util.Locale locale35 = null;
        int int36 = dividedDateTimeField28.getMaximumShortTextLength(locale35);
        int int39 = dividedDateTimeField28.getDifference((-19256400000L), (long) 8);
        java.util.Locale locale41 = null;
        java.lang.String str42 = dividedDateTimeField28.getAsText(1814401000L, locale41);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3934918440000000L) + "'", long32 == (-3934918440000000L));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-3) + "'", int39 == (-3));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "3" + "'", str42.equals("3"));
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test158");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        int int4 = cachedDateTimeZone2.getOffset(0L);
//        int int6 = cachedDateTimeZone2.getOffsetFromLocal((long) (short) -1);
//        int int8 = cachedDateTimeZone2.getOffset((long) ' ');
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = cachedDateTimeZone2.getShortName((long) 32, locale10);
//        int int13 = cachedDateTimeZone2.getOffset(0L);
//        int int15 = cachedDateTimeZone2.getOffset(110449353600062000L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isSupported();
        try {
            long long14 = unsupportedDurationField11.getMillis(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.Chronology chronology12 = zonedChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.dayOfMonth();
        org.joda.time.DurationField durationField14 = zonedChronology11.hours();
        try {
            long long22 = zonedChronology11.getDateTimeMillis((int) '#', 66, (-33), 1673545, (int) (short) -1, 6, 33);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1673545 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(100, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        long long13 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType14 = unsupportedDurationField11.getType();
        java.lang.String str15 = unsupportedDurationField11.getName();
        java.lang.String str16 = unsupportedDurationField11.toString();
        long long17 = unsupportedDurationField11.getUnitMillis();
        java.lang.String str18 = unsupportedDurationField11.getName();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "years" + "'", str15.equals("years"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "UnsupportedDurationField[years]" + "'", str16.equals("UnsupportedDurationField[years]"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "years" + "'", str18.equals("years"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, 10);
        long long30 = offsetDateTimeField3.roundHalfCeiling((-16601L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-259200100L) + "'", long30 == (-259200100L));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.Chronology chronology12 = zonedChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.clockhourOfDay();
        org.joda.time.DateTimeZone dateTimeZone14 = zonedChronology11.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Coordinated Universal Time");
        java.lang.String str2 = jodaTimePermission1.toString();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.minutes();
        org.joda.time.PeriodType periodType4 = periodType3.withDaysRemoved();
        boolean boolean5 = jodaTimePermission1.equals((java.lang.Object) periodType3);
        java.security.PermissionCollection permissionCollection6 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"Coordinated Universal Time\")"));
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(permissionCollection6);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.add((long) (-2), (-1));
        java.util.Locale locale39 = null;
        try {
            java.lang.String str40 = unsupportedDateTimeField34.getAsText(6048000100L, locale39);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3155673600002L) + "'", long37 == (-3155673600002L));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.getDifferenceAsLong((long) (-5325), (-244803200L));
        java.lang.String str41 = unsupportedDateTimeField34.getName();
        try {
            long long43 = unsupportedDateTimeField34.roundHalfEven(115200085L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "weekOfWeekyear" + "'", str41.equals("weekOfWeekyear"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int30 = dividedDateTimeField28.get((-57599900L));
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
        long long37 = offsetDateTimeField34.add(3200L, (int) (short) 1);
        int int39 = offsetDateTimeField34.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = offsetDateTimeField34.getMinimumValue(readablePartial40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField34.getAsText((long) 8, locale43);
        int int46 = offsetDateTimeField34.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) ' ');
        long long53 = offsetDateTimeField50.add(3200L, (int) (short) 1);
        int int55 = offsetDateTimeField50.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial56 = null;
        java.util.Locale locale58 = null;
        java.lang.String str59 = offsetDateTimeField50.getAsShortText(readablePartial56, (int) '4', locale58);
        java.util.Locale locale60 = null;
        int int61 = offsetDateTimeField50.getMaximumShortTextLength(locale60);
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology62.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, (int) ' ');
        long long68 = offsetDateTimeField65.add(3200L, (int) (short) 1);
        int int70 = offsetDateTimeField65.get((long) (short) 100);
        int int72 = offsetDateTimeField65.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = offsetDateTimeField65.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType73, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType73, (int) 'a');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField78 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType73);
        long long80 = remainderDateTimeField78.roundHalfCeiling((long) (-43104900));
        long long82 = remainderDateTimeField78.roundCeiling((long) '#');
        long long84 = remainderDateTimeField78.roundFloor((long) 85);
        long long86 = remainderDateTimeField78.roundFloor((long) 85);
        org.joda.time.DurationField durationField87 = remainderDateTimeField78.getRangeDurationField();
        java.lang.String str89 = remainderDateTimeField78.getAsShortText(259200035L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604803200L + "'", long37 == 604803200L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 33 + "'", int41 == 33);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "33" + "'", str44.equals("33"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 85 + "'", int46 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 604803200L + "'", long53 == 604803200L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 33 + "'", int55 == 33);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "52" + "'", str59.equals("52"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604803200L + "'", long68 == 604803200L);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 33 + "'", int70 == 33);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 33 + "'", int72 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-259200100L) + "'", long80 == (-259200100L));
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 345599900L + "'", long82 == 345599900L);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + (-259200100L) + "'", long84 == (-259200100L));
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + (-259200100L) + "'", long86 == (-259200100L));
        org.junit.Assert.assertNotNull(durationField87);
        org.junit.Assert.assertTrue("'" + str89 + "' != '" + "3" + "'", str89.equals("3"));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundCeiling((-62032493221900L));
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) ' ');
        long long12 = offsetDateTimeField9.add(3200L, (int) (short) 1);
        int int14 = offsetDateTimeField9.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = offsetDateTimeField9.getMinimumValue(readablePartial15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText((long) 8, locale18);
        int int21 = offsetDateTimeField9.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) ' ');
        long long28 = offsetDateTimeField25.add(3200L, (int) (short) 1);
        int int30 = offsetDateTimeField25.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField25.getAsShortText(readablePartial31, (int) '4', locale33);
        java.util.Locale locale35 = null;
        int int36 = offsetDateTimeField25.getMaximumShortTextLength(locale35);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, (int) ' ');
        long long43 = offsetDateTimeField40.add(3200L, (int) (short) 1);
        int int45 = offsetDateTimeField40.get((long) (short) 100);
        int int47 = offsetDateTimeField40.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = offsetDateTimeField40.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField25, dateTimeFieldType48, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType48, (int) 'a');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField54 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType48, 100);
        long long56 = remainderDateTimeField54.roundHalfFloor((long) 5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62032176000100L) + "'", long5 == (-62032176000100L));
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 604803200L + "'", long12 == 604803200L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 33 + "'", int14 == 33);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 33 + "'", int16 == 33);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "33" + "'", str19.equals("33"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 85 + "'", int21 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 604803200L + "'", long28 == 604803200L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 33 + "'", int30 == 33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "52" + "'", str34.equals("52"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 604803200L + "'", long43 == 604803200L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 33 + "'", int45 == 33);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 33 + "'", int47 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-259200100L) + "'", long56 == (-259200100L));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Coordinated Universal Time");
        boolean boolean3 = jodaTimePermission1.equals((java.lang.Object) 230934);
        org.joda.time.Period period4 = new org.joda.time.Period();
        int int5 = period4.size();
        org.joda.time.Period period6 = period4.negated();
        org.joda.time.Period period7 = new org.joda.time.Period();
        int int8 = period7.getWeeks();
        org.joda.time.Period period10 = org.joda.time.Period.hours(100);
        org.joda.time.Period period11 = period10.negated();
        org.joda.time.Days days12 = period11.toStandardDays();
        org.joda.time.Period period14 = period11.plusHours(1);
        org.joda.time.Period period16 = period14.minusWeeks(100);
        org.joda.time.Period period17 = new org.joda.time.Period();
        int int18 = period17.size();
        org.joda.time.Period period19 = period17.negated();
        org.joda.time.DurationFieldType durationFieldType20 = null;
        int int21 = period19.indexOf(durationFieldType20);
        org.joda.time.DurationFieldType durationFieldType23 = period19.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(durationFieldType23, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType23);
        org.joda.time.Period period30 = period14.withField(durationFieldType23, 230400000);
        org.joda.time.Period period31 = period7.withFields((org.joda.time.ReadablePeriod) period30);
        org.joda.time.Period period32 = period6.minus((org.joda.time.ReadablePeriod) period31);
        boolean boolean33 = jodaTimePermission1.equals((java.lang.Object) period32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(days12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        int int3 = period2.size();
        int int4 = period2.getMonths();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(32);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder0.toDateTimeZone("ISOChronology[UTC]", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        int int37 = unsupportedDateTimeField34.getDifference((long) '4', (-210866414400000L));
        long long40 = unsupportedDateTimeField34.getDifferenceAsLong((long) 'a', (-230400000L));
        boolean boolean41 = unsupportedDateTimeField34.isSupported();
        int int44 = unsupportedDateTimeField34.getDifference(360000151L, (long) (-33));
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology48 = gregorianChronology47.withUTC();
        org.joda.time.DurationField durationField49 = gregorianChronology47.hours();
        org.joda.time.Period period51 = org.joda.time.Period.hours(100);
        org.joda.time.Period period52 = period51.negated();
        org.joda.time.Days days53 = period52.toStandardDays();
        org.joda.time.Period period55 = period52.plusHours(1);
        int[] intArray57 = gregorianChronology47.get((org.joda.time.ReadablePeriod) period55, (-207359884803200L));
        try {
            int[] intArray59 = unsupportedDateTimeField34.addWrapField(readablePartial45, 1673, intArray57, 1673);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 66 + "'", int37 == 66);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(days53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(intArray57);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        long long18 = zonedChronology11.getDateTimeMillis((-210858120000000L), 8, 0, (int) (byte) 0, 33);
        org.joda.time.DateTimeField dateTimeField19 = zonedChronology11.year();
        try {
            long long25 = zonedChronology11.getDateTimeMillis((-62032176000000L), (-72), (-1), 360000035, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -72 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-210858134399967L) + "'", long18 == (-210858134399967L));
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PT100H", (java.lang.Number) 1L, (java.lang.Number) 19353599999L, number3);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        java.util.TimeZone timeZone12 = fixedDateTimeZone11.toTimeZone();
        org.joda.time.Period period14 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period16 = period14.withPeriodType(periodType15);
        boolean boolean17 = fixedDateTimeZone11.equals((java.lang.Object) periodType15);
        int int19 = fixedDateTimeZone11.getStandardOffset(350L);
        java.lang.Object obj20 = null;
        boolean boolean21 = fixedDateTimeZone11.equals(obj20);
        org.joda.time.Chronology chronology22 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DurationField durationField23 = gregorianChronology0.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 32 + "'", int19 == 32);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int4 = cachedDateTimeZone2.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone5 = cachedDateTimeZone2.getUncachedZone();
        long long8 = dateTimeZone5.convertLocalToUTC(35L, true);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone5);
        org.joda.time.LocalDateTime localDateTime10 = null;
        boolean boolean11 = dateTimeZone5.isLocalDateTimeGap(localDateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.Period period29 = new org.joda.time.Period();
        int int30 = period29.size();
        org.joda.time.Period period31 = period29.negated();
        int int32 = period29.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter33 = null;
        java.lang.String str34 = period29.toString(periodFormatter33);
        org.joda.time.DurationFieldType durationFieldType36 = period29.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField37 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType36);
        org.joda.time.Period period38 = new org.joda.time.Period();
        int int39 = period38.size();
        org.joda.time.Period period40 = period38.negated();
        org.joda.time.DurationFieldType durationFieldType41 = null;
        int int42 = period40.indexOf(durationFieldType41);
        org.joda.time.DurationFieldType durationFieldType44 = period40.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(durationFieldType44, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField49 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType44);
        boolean boolean50 = unsupportedDurationField49.isPrecise();
        long long51 = unsupportedDurationField49.getUnitMillis();
        boolean boolean52 = unsupportedDurationField49.isSupported();
        int int53 = unsupportedDurationField37.compareTo((org.joda.time.DurationField) unsupportedDurationField49);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField54 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, (org.joda.time.DurationField) unsupportedDurationField49);
        org.joda.time.DurationField durationField55 = unsupportedDateTimeField54.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PT0S" + "'", str34.equals("PT0S"));
        org.junit.Assert.assertNotNull(durationFieldType36);
        org.junit.Assert.assertNotNull(unsupportedDurationField37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 8 + "'", int39 == 8);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType44);
        org.junit.Assert.assertNotNull(unsupportedDurationField49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField54);
        org.junit.Assert.assertNull(durationField55);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        boolean boolean36 = unsupportedDateTimeField34.isLenient();
        long long39 = unsupportedDateTimeField34.add((-43104900L), (-1));
        long long42 = unsupportedDateTimeField34.getDifferenceAsLong(25916501880000000L, (-10L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-3155716704900L) + "'", long39 == (-3155716704900L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 8212L + "'", long42 == 8212L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        long long13 = unsupportedDurationField11.getUnitMillis();
        boolean boolean14 = unsupportedDurationField11.isSupported();
        boolean boolean15 = unsupportedDurationField11.isPrecise();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period();
        int int5 = period4.size();
        org.joda.time.PeriodType periodType6 = period4.getPeriodType();
        org.joda.time.Period period7 = new org.joda.time.Period(readableDuration2, readableInstant3, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withYearsRemoved();
        org.joda.time.PeriodType periodType9 = periodType6.withHoursRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology14 = gregorianChronology10.withZone(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        int int19 = cachedDateTimeZone17.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone20 = cachedDateTimeZone17.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology10, dateTimeZone20);
        org.joda.time.Chronology chronology22 = zonedChronology21.withUTC();
        org.joda.time.Period period23 = new org.joda.time.Period((long) (byte) 100, (-244803200L), periodType6, (org.joda.time.Chronology) zonedChronology21);
        org.joda.time.DateTimeField dateTimeField24 = zonedChronology21.centuryOfEra();
        try {
            long long29 = zonedChronology21.getDateTimeMillis(0, 0, 1673545, 35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(32);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder2.toDateTimeZone("GregorianChronology[PT100H]", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder2.setStandardOffset((int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder7.setFixedSavings("230400000", 230400000);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder7.setStandardOffset((-99));
        java.io.DataOutput dataOutput14 = null;
        try {
            dateTimeZoneBuilder12.writeTo("UnsupportedDateTimeField", dataOutput14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder12);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.joda.time.Period period0 = new org.joda.time.Period();
        boolean boolean2 = period0.equals((java.lang.Object) false);
        org.joda.time.Period period4 = period0.plusMillis((int) (byte) 1);
        org.joda.time.Period period6 = period4.withMinutes(33);
        org.joda.time.Period period7 = new org.joda.time.Period();
        int int8 = period7.size();
        org.joda.time.Period period9 = period7.negated();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = period9.indexOf(durationFieldType10);
        org.joda.time.DurationFieldType durationFieldType13 = period9.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(durationFieldType13, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField18 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType13);
        boolean boolean19 = unsupportedDurationField18.isPrecise();
        boolean boolean20 = unsupportedDurationField18.isPrecise();
        org.joda.time.DurationFieldType durationFieldType21 = unsupportedDurationField18.getType();
        boolean boolean22 = period4.isSupported(durationFieldType21);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertNotNull(unsupportedDurationField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.String str9 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]" + "'", str9.equals("org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        long long13 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType14 = unsupportedDurationField11.getType();
        java.lang.String str15 = unsupportedDurationField11.getName();
        boolean boolean16 = unsupportedDurationField11.isPrecise();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.weekOfWeekyear();
        org.joda.time.DurationField durationField19 = gregorianChronology17.hours();
        org.joda.time.Period period20 = new org.joda.time.Period();
        int int21 = period20.size();
        org.joda.time.Period period22 = period20.negated();
        org.joda.time.DurationFieldType durationFieldType23 = null;
        int int24 = period22.indexOf(durationFieldType23);
        org.joda.time.DurationFieldType durationFieldType26 = period22.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField27 = new org.joda.time.field.DecoratedDurationField(durationField19, durationFieldType26);
        java.lang.String str28 = decoratedDurationField27.getName();
        boolean boolean29 = decoratedDurationField27.isSupported();
        long long32 = decoratedDurationField27.getDifferenceAsLong((long) (byte) 100, (long) 100);
        long long35 = decoratedDurationField27.add((-19357200001L), (int) '4');
        long long38 = decoratedDurationField27.getValueAsLong((-244803200L), 10L);
        int int39 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) decoratedDurationField27);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "years" + "'", str15.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 8 + "'", int21 == 8);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "years" + "'", str28.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-19170000001L) + "'", long35 == (-19170000001L));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-68L) + "'", long38 == (-68L));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) ' ');
        long long9 = offsetDateTimeField6.add(3200L, (int) (short) 1);
        int int11 = offsetDateTimeField6.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField6.getAsShortText(readablePartial12, (int) '4', locale14);
        java.util.Locale locale16 = null;
        int int17 = offsetDateTimeField6.getMaximumShortTextLength(locale16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) ' ');
        long long24 = offsetDateTimeField21.add(3200L, (int) (short) 1);
        int int26 = offsetDateTimeField21.get((long) (short) 100);
        int int28 = offsetDateTimeField21.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField21.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType29, (int) (byte) 10);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 2);
        java.util.Locale locale35 = null;
        java.lang.String str36 = dividedDateTimeField33.getAsText((int) (byte) 100, locale35);
        long long39 = dividedDateTimeField33.add((long) (byte) 100, 10L);
        long long42 = dividedDateTimeField33.getDifferenceAsLong(21168000350L, (long) 33);
        boolean boolean43 = dividedDateTimeField33.isSupported();
        long long45 = dividedDateTimeField33.remainder(604803200L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 604803200L + "'", long9 == 604803200L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "52" + "'", str15.equals("52"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 604803200L + "'", long24 == 604803200L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 33 + "'", int26 == 33);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 33 + "'", int28 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "100" + "'", str36.equals("100"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 72000100L + "'", long39 == 72000100L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 2940L + "'", long42 == 2940L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 604803200L + "'", long45 == 604803200L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumTextLength(locale13);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField3.getAsShortText(readablePartial15, 230400000, locale17);
        long long21 = offsetDateTimeField3.add((-110449440000000L), 1);
        org.joda.time.DurationField durationField22 = offsetDateTimeField3.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "230400000" + "'", str18.equals("230400000"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-110448835200000L) + "'", long21 == (-110448835200000L));
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        boolean boolean36 = unsupportedDateTimeField34.isSupported();
        int int39 = unsupportedDateTimeField34.getDifference(11044935360006200L, 6047999999L);
        java.util.Locale locale41 = null;
        try {
            java.lang.String str42 = unsupportedDateTimeField34.getAsShortText((-99), locale41);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 3499 + "'", int39 == 3499);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        int int4 = period1.getMillis();
        int int5 = period1.getMonths();
        org.joda.time.PeriodType periodType6 = period1.getPeriodType();
        int int7 = period1.getMonths();
        org.joda.time.Period period9 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType10 = period9.getPeriodType();
        org.joda.time.Period period11 = period1.withPeriodType(periodType10);
        org.joda.time.Period period12 = period1.negated();
        org.joda.time.Duration duration13 = period12.toStandardDuration();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration13);
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) readableInstant0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration13);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        long long13 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType14 = unsupportedDurationField11.getType();
        long long15 = unsupportedDurationField11.getUnitMillis();
        org.joda.time.Period period16 = new org.joda.time.Period();
        int int17 = period16.size();
        org.joda.time.Period period18 = period16.negated();
        org.joda.time.DurationFieldType durationFieldType19 = null;
        int int20 = period18.indexOf(durationFieldType19);
        org.joda.time.DurationFieldType durationFieldType22 = period18.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException26 = new org.joda.time.IllegalFieldValueException(durationFieldType22, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField27 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType22);
        boolean boolean28 = unsupportedDurationField27.isPrecise();
        long long29 = unsupportedDurationField27.getUnitMillis();
        int int30 = unsupportedDurationField11.compareTo((org.joda.time.DurationField) unsupportedDurationField27);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(unsupportedDurationField27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Coordinated Universal Time");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("Coordinated Universal Time");
        java.lang.String str6 = jodaTimePermission5.getName();
        java.security.PermissionCollection permissionCollection7 = jodaTimePermission5.newPermissionCollection();
        boolean boolean8 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean11 = iSOChronology9.equals((java.lang.Object) (byte) -1);
        org.joda.time.DurationField durationField12 = iSOChronology9.days();
        jodaTimePermission5.checkGuard((java.lang.Object) durationField12);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Coordinated Universal Time" + "'", str2.equals("Coordinated Universal Time"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
        org.junit.Assert.assertNotNull(permissionCollection7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int30 = dividedDateTimeField28.get((-57599900L));
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
        long long37 = offsetDateTimeField34.add(3200L, (int) (short) 1);
        int int39 = offsetDateTimeField34.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = offsetDateTimeField34.getMinimumValue(readablePartial40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField34.getAsText((long) 8, locale43);
        int int46 = offsetDateTimeField34.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) ' ');
        long long53 = offsetDateTimeField50.add(3200L, (int) (short) 1);
        int int55 = offsetDateTimeField50.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial56 = null;
        java.util.Locale locale58 = null;
        java.lang.String str59 = offsetDateTimeField50.getAsShortText(readablePartial56, (int) '4', locale58);
        java.util.Locale locale60 = null;
        int int61 = offsetDateTimeField50.getMaximumShortTextLength(locale60);
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology62.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, (int) ' ');
        long long68 = offsetDateTimeField65.add(3200L, (int) (short) 1);
        int int70 = offsetDateTimeField65.get((long) (short) 100);
        int int72 = offsetDateTimeField65.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = offsetDateTimeField65.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType73, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType73, (int) 'a');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField78 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType73);
        org.joda.time.IllegalFieldValueException illegalFieldValueException80 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType73, "ISOChronology[UTC]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException83 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType73, (java.lang.Number) 5788799900L, "PT0S");
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604803200L + "'", long37 == 604803200L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 33 + "'", int41 == 33);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "33" + "'", str44.equals("33"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 85 + "'", int46 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 604803200L + "'", long53 == 604803200L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 33 + "'", int55 == 33);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "52" + "'", str59.equals("52"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604803200L + "'", long68 == 604803200L);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 33 + "'", int70 == 33);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 33 + "'", int72 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.Period period4 = org.joda.time.Period.months((int) '4');
        int[] intArray6 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period4, (long) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DurationField durationField13 = zonedChronology12.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.PeriodType periodType5 = period0.getPeriodType();
        int int6 = period0.getMonths();
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.Period period10 = period0.withPeriodType(periodType9);
        org.joda.time.Period period12 = period0.withMillis((int) (short) 10);
        org.joda.time.Period period14 = period12.minusMinutes((int) 'a');
        org.joda.time.Period period16 = period14.minusHours((int) (byte) 10);
        org.joda.time.Duration duration17 = period16.toStandardDuration();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(duration17);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        java.lang.String str2 = lenientChronology1.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "LenientChronology[ISOChronology[UTC]]" + "'", str2.equals("LenientChronology[ISOChronology[UTC]]"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter4 = null;
        java.lang.String str5 = period0.toString(periodFormatter4);
        org.joda.time.DurationFieldType durationFieldType7 = period0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField8 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        org.joda.time.Period period9 = new org.joda.time.Period();
        int int10 = period9.size();
        org.joda.time.Period period11 = period9.negated();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        int int13 = period11.indexOf(durationFieldType12);
        org.joda.time.DurationFieldType durationFieldType15 = period11.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType15, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType15);
        boolean boolean21 = unsupportedDurationField20.isPrecise();
        long long22 = unsupportedDurationField20.getUnitMillis();
        boolean boolean23 = unsupportedDurationField20.isSupported();
        int int24 = unsupportedDurationField8.compareTo((org.joda.time.DurationField) unsupportedDurationField20);
        boolean boolean25 = unsupportedDurationField20.isPrecise();
        try {
            long long27 = unsupportedDurationField20.getMillis(1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0S" + "'", str5.equals("PT0S"));
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        int int10 = offsetDateTimeField3.getMinimumValue(readablePartial9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField3.getAsText((long) 8, locale12);
        int int15 = offsetDateTimeField3.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) ' ');
        long long22 = offsetDateTimeField19.add(3200L, (int) (short) 1);
        int int24 = offsetDateTimeField19.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial25 = null;
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField19.getAsShortText(readablePartial25, (int) '4', locale27);
        java.util.Locale locale29 = null;
        int int30 = offsetDateTimeField19.getMaximumShortTextLength(locale29);
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
        long long37 = offsetDateTimeField34.add(3200L, (int) (short) 1);
        int int39 = offsetDateTimeField34.get((long) (short) 100);
        int int41 = offsetDateTimeField34.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField34.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField44 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField19, dateTimeFieldType42, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType42, (int) 'a');
        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 35L, "P8Y");
        org.joda.time.IllegalFieldValueException illegalFieldValueException51 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, "Coordinated Universal Time");
        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 33, (java.lang.Number) 360000000, (java.lang.Number) (-110449353600052L));
        org.joda.time.IllegalFieldValueException illegalFieldValueException57 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, "P8Y");
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "33" + "'", str13.equals("33"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 85 + "'", int15 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 604803200L + "'", long22 == 604803200L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 33 + "'", int24 == 33);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "52" + "'", str28.equals("52"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604803200L + "'", long37 == 604803200L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 33 + "'", int41 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = unsupportedDateTimeField34.getType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-33));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Days days3 = period2.toStandardDays();
        int[] intArray4 = period2.getValues();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Duration duration6 = period2.toDurationTo(readableInstant5);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(days3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(duration6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        long long8 = gregorianChronology0.add((long) 4, (long) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField10 = gregorianChronology9.minutes();
        org.joda.time.Chronology chronology11 = gregorianChronology9.withUTC();
        org.joda.time.Period period13 = org.joda.time.Period.months((int) '4');
        int[] intArray15 = gregorianChronology9.get((org.joda.time.ReadablePeriod) period13, (long) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology9, (org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.Chronology chronology22 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        int int24 = fixedDateTimeZone20.getStandardOffset((long) 360000000);
        long long26 = fixedDateTimeZone20.convertUTCToLocal((long) '#');
        long long28 = fixedDateTimeZone20.nextTransition(19353599999L);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) ' ');
        long long35 = offsetDateTimeField32.add(3200L, (int) (short) 1);
        int int37 = offsetDateTimeField32.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial38 = null;
        int int39 = offsetDateTimeField32.getMinimumValue(readablePartial38);
        boolean boolean41 = offsetDateTimeField32.isLeap(259200135L);
        boolean boolean42 = fixedDateTimeZone20.equals((java.lang.Object) boolean41);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 4L + "'", long8 == 4L);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 32 + "'", int24 == 32);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 135L + "'", long26 == 135L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 19353599999L + "'", long28 == 19353599999L);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 604803200L + "'", long35 == 604803200L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 33 + "'", int37 == 33);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.hours(100);
        org.joda.time.Period period3 = period2.negated();
        int int4 = period3.size();
        org.joda.time.Period period5 = new org.joda.time.Period();
        int int6 = period5.size();
        org.joda.time.Period period7 = period5.negated();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = period7.indexOf(durationFieldType8);
        org.joda.time.DurationFieldType durationFieldType11 = period7.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(durationFieldType11, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.Period period17 = period3.withFieldAdded(durationFieldType11, (int) (byte) 100);
        org.joda.time.Period period19 = period17.plusMinutes(0);
        org.joda.time.DurationFieldType[] durationFieldTypeArray20 = period17.getFieldTypes();
        org.joda.time.Period period22 = period17.minusDays(1);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.Duration duration24 = period22.toDurationFrom(readableInstant23);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType26 = periodType25.withSecondsRemoved();
        org.joda.time.PeriodType periodType27 = periodType26.withYearsRemoved();
        org.joda.time.Period period28 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration24, periodType27);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(durationFieldTypeArray20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(duration24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType27);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (byte) 100);
        java.lang.Class<?> wildcardClass2 = period1.getClass();
        org.joda.time.Minutes minutes3 = period1.toStandardMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(minutes3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add((long) (-1), (int) ' ');
        long long8 = offsetDateTimeField3.roundHalfFloor((long) 85);
        int int9 = offsetDateTimeField3.getOffset();
        java.lang.String str11 = offsetDateTimeField3.getAsShortText((-19357200001L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19353599999L + "'", long6 == 19353599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-259200100L) + "'", long8 == (-259200100L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 32 + "'", int9 == 32);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "53" + "'", str11.equals("53"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int31 = dividedDateTimeField28.getDifference((-62032176000100L), (long) 1);
        long long34 = dividedDateTimeField28.add(2440587L, 5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-10256) + "'", int31 == (-10256));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 30242440587L + "'", long34 == 30242440587L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        org.joda.time.DurationField durationField30 = dividedDateTimeField28.getDurationField();
        org.joda.time.DateTimeField dateTimeField31 = dividedDateTimeField28.getWrappedField();
        java.lang.String str32 = dividedDateTimeField28.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "weekOfWeekyear" + "'", str32.equals("weekOfWeekyear"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.Period period3 = period1.minusMillis((int) '#');
        org.joda.time.Period period5 = period3.withYears(10);
        org.joda.time.Period period7 = period3.withMonths(8);
        org.joda.time.Period period9 = period7.withWeeks((int) (short) 0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("10.0", (-43104900), (int) (short) 1, 0, 'a', (int) (byte) 1, (int) (short) -1, 0, false, (int) 'a');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder11.setStandardOffset(0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long5 = offsetDateTimeField3.roundCeiling((-62032493221900L));
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) ' ');
        long long12 = offsetDateTimeField9.add(3200L, (int) (short) 1);
        int int14 = offsetDateTimeField9.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = offsetDateTimeField9.getMinimumValue(readablePartial15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField9.getAsText((long) 8, locale18);
        int int21 = offsetDateTimeField9.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) ' ');
        long long28 = offsetDateTimeField25.add(3200L, (int) (short) 1);
        int int30 = offsetDateTimeField25.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial31 = null;
        java.util.Locale locale33 = null;
        java.lang.String str34 = offsetDateTimeField25.getAsShortText(readablePartial31, (int) '4', locale33);
        java.util.Locale locale35 = null;
        int int36 = offsetDateTimeField25.getMaximumShortTextLength(locale35);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, (int) ' ');
        long long43 = offsetDateTimeField40.add(3200L, (int) (short) 1);
        int int45 = offsetDateTimeField40.get((long) (short) 100);
        int int47 = offsetDateTimeField40.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = offsetDateTimeField40.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField50 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField25, dateTimeFieldType48, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField9, dateTimeFieldType48, (int) 'a');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField54 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType48, 100);
        org.joda.time.DurationField durationField55 = remainderDateTimeField54.getDurationField();
        org.joda.time.ReadablePartial readablePartial56 = null;
        java.util.Locale locale58 = null;
        java.lang.String str59 = remainderDateTimeField54.getAsShortText(readablePartial56, 0, locale58);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62032176000100L) + "'", long5 == (-62032176000100L));
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 604803200L + "'", long12 == 604803200L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 33 + "'", int14 == 33);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 33 + "'", int16 == 33);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "33" + "'", str19.equals("33"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 85 + "'", int21 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 604803200L + "'", long28 == 604803200L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 33 + "'", int30 == 33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "52" + "'", str34.equals("52"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 604803200L + "'", long43 == 604803200L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 33 + "'", int45 == 33);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 33 + "'", int47 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "0" + "'", str59.equals("0"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int30 = dividedDateTimeField28.get((-57599900L));
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
        long long37 = offsetDateTimeField34.add(3200L, (int) (short) 1);
        int int39 = offsetDateTimeField34.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = offsetDateTimeField34.getMinimumValue(readablePartial40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField34.getAsText((long) 8, locale43);
        int int46 = offsetDateTimeField34.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) ' ');
        long long53 = offsetDateTimeField50.add(3200L, (int) (short) 1);
        int int55 = offsetDateTimeField50.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial56 = null;
        java.util.Locale locale58 = null;
        java.lang.String str59 = offsetDateTimeField50.getAsShortText(readablePartial56, (int) '4', locale58);
        java.util.Locale locale60 = null;
        int int61 = offsetDateTimeField50.getMaximumShortTextLength(locale60);
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology62.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, (int) ' ');
        long long68 = offsetDateTimeField65.add(3200L, (int) (short) 1);
        int int70 = offsetDateTimeField65.get((long) (short) 100);
        int int72 = offsetDateTimeField65.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = offsetDateTimeField65.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType73, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType73, (int) 'a');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField78 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType73);
        long long80 = remainderDateTimeField78.roundHalfCeiling((long) (-43104900));
        long long82 = remainderDateTimeField78.roundHalfFloor((-58571700L));
        long long84 = remainderDateTimeField78.roundCeiling(2L);
        java.lang.String str86 = remainderDateTimeField78.getAsText((long) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604803200L + "'", long37 == 604803200L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 33 + "'", int41 == 33);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "33" + "'", str44.equals("33"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 85 + "'", int46 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 604803200L + "'", long53 == 604803200L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 33 + "'", int55 == 33);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "52" + "'", str59.equals("52"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604803200L + "'", long68 == 604803200L);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 33 + "'", int70 == 33);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 33 + "'", int72 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-259200100L) + "'", long80 == (-259200100L));
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-259200100L) + "'", long82 == (-259200100L));
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 345599900L + "'", long84 == 345599900L);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "3" + "'", str86.equals("3"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.util.Locale locale37 = null;
        try {
            long long38 = unsupportedDateTimeField34.set(1260000000L, "YearDay", locale37);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.Period period7 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period9 = period7.withPeriodType(periodType8);
        boolean boolean10 = fixedDateTimeZone4.equals((java.lang.Object) periodType8);
        int int12 = fixedDateTimeZone4.getStandardOffset(350L);
        long long14 = fixedDateTimeZone4.nextTransition(0L);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        int int37 = unsupportedDateTimeField34.getDifference((long) '4', (-210866414400000L));
        long long40 = unsupportedDateTimeField34.getDifferenceAsLong((long) 'a', (-230400000L));
        boolean boolean41 = unsupportedDateTimeField34.isSupported();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField34.getDurationField();
        try {
            int int43 = unsupportedDateTimeField34.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 66 + "'", int37 == 66);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(durationField42);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 10, 0, 8, 0);
        org.joda.time.Period period6 = period4.withDays(6);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.add((long) (-2), (-1));
        java.util.Locale locale38 = null;
        try {
            int int39 = unsupportedDateTimeField34.getMaximumShortTextLength(locale38);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-3155673600002L) + "'", long37 == (-3155673600002L));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        int int37 = unsupportedDateTimeField34.getDifference((long) '4', (-210866414400000L));
        long long40 = unsupportedDateTimeField34.getDifferenceAsLong((long) 'a', (-230400000L));
        boolean boolean41 = unsupportedDateTimeField34.isSupported();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField34.getLeapDurationField();
        org.joda.time.DurationField durationField43 = unsupportedDateTimeField34.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 66 + "'", int37 == 66);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertNull(durationField43);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        long long32 = dividedDateTimeField28.add((-3935130120000000L), (long) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField28, 10);
        long long37 = dividedDateTimeField28.set((long) 100, 4);
        long long40 = dividedDateTimeField28.add(32L, 9);
        java.util.Locale locale42 = null;
        java.lang.String str43 = dividedDateTimeField28.getAsShortText((-2), locale42);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3934918440000000L) + "'", long32 == (-3934918440000000L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 6048000100L + "'", long37 == 6048000100L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 54432000032L + "'", long40 == 54432000032L);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "-2" + "'", str43.equals("-2"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(32);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder2.toDateTimeZone("GregorianChronology[PT100H]", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder2.setStandardOffset((int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder7.setFixedSavings("230400000", 230400000);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder7.setStandardOffset((-99));
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder20 = dateTimeZoneBuilder7.addCutover((int) (byte) 1, 'a', 0, 1673, 0, false, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder12);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isSupported();
        boolean boolean14 = unsupportedDurationField11.equals((java.lang.Object) 5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.centuryOfEra();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period();
        int int12 = period11.size();
        org.joda.time.PeriodType periodType13 = period11.getPeriodType();
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration9, readableInstant10, periodType13);
        org.joda.time.PeriodType periodType15 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = periodType13.withWeeksRemoved();
        boolean boolean17 = gregorianChronology0.equals((java.lang.Object) periodType13);
        org.joda.time.DurationField durationField18 = gregorianChronology0.months();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, (int) (byte) 0, 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        org.joda.time.DurationField durationField12 = null;
        int int13 = unsupportedDurationField11.compareTo(durationField12);
        try {
            long long15 = unsupportedDurationField11.getMillis(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Period period4 = period1.minusMinutes((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        int int6 = period4.indexOf(durationFieldType5);
        org.joda.time.Period period8 = period4.withHours((int) '4');
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter4 = null;
        java.lang.String str5 = period0.toString(periodFormatter4);
        org.joda.time.DurationFieldType durationFieldType7 = period0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField8 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField10 = gregorianChronology9.minutes();
        int int11 = unsupportedDurationField8.compareTo(durationField10);
        boolean boolean12 = unsupportedDurationField8.isPrecise();
        java.lang.String str13 = unsupportedDurationField8.getName();
        try {
            int int16 = unsupportedDurationField8.getValue(1814401000L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0S" + "'", str5.equals("PT0S"));
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "years" + "'", str13.equals("years"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.joda.time.Period period1 = org.joda.time.Period.hours(604803199);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        boolean boolean36 = unsupportedDateTimeField34.isLenient();
        try {
            long long38 = unsupportedDateTimeField34.roundHalfEven(31795199900L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.Period period3 = period1.withWeeks((int) (short) 100);
        org.joda.time.Period period4 = new org.joda.time.Period();
        int int5 = period4.size();
        org.joda.time.PeriodType periodType6 = period4.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = periodType6.isSupported(durationFieldType7);
        org.joda.time.Period period9 = new org.joda.time.Period();
        int int10 = period9.size();
        org.joda.time.Period period11 = period9.negated();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        int int13 = period11.indexOf(durationFieldType12);
        org.joda.time.DurationFieldType durationFieldType15 = period11.getFieldType((int) (short) 0);
        int int16 = periodType6.indexOf(durationFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(durationFieldType15, (java.lang.Number) (byte) 100, (java.lang.Number) 10.0d, (java.lang.Number) 1.0f);
        int int21 = period1.indexOf(durationFieldType15);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, 10);
        org.joda.time.ReadablePartial readablePartial29 = null;
        int int30 = offsetDateTimeField3.getMaximumValue(readablePartial29);
        boolean boolean31 = offsetDateTimeField3.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 85 + "'", int30 == 85);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.getDifferenceAsLong((long) (-5325), (-244803200L));
        java.lang.String str41 = unsupportedDateTimeField34.getName();
        org.joda.time.ReadablePartial readablePartial42 = null;
        java.util.Locale locale44 = null;
        try {
            java.lang.String str45 = unsupportedDateTimeField34.getAsShortText(readablePartial42, 360000000, locale44);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "weekOfWeekyear" + "'", str41.equals("weekOfWeekyear"));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("PT100H", (java.lang.Number) 1L, (java.lang.Number) 19353599999L, number3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        boolean boolean36 = unsupportedDateTimeField34.isSupported();
        org.joda.time.DurationField durationField37 = unsupportedDateTimeField34.getLeapDurationField();
        boolean boolean38 = unsupportedDateTimeField34.isLenient();
        org.joda.time.ReadablePartial readablePartial39 = null;
        java.util.Locale locale40 = null;
        try {
            java.lang.String str41 = unsupportedDateTimeField34.getAsText(readablePartial39, locale40);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(durationField37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add((long) (-1), (int) ' ');
        long long8 = offsetDateTimeField3.roundHalfFloor(21168000350L);
        java.lang.String str9 = offsetDateTimeField3.getName();
        java.util.Locale locale12 = null;
        try {
            long long13 = offsetDateTimeField3.set((long) 33, "PT-0.001S", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PT-0.001S\" for weekOfWeekyear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 19353599999L + "'", long6 == 19353599999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 20908799900L + "'", long8 == 20908799900L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "weekOfWeekyear" + "'", str9.equals("weekOfWeekyear"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int30 = dividedDateTimeField28.get((-57599900L));
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
        long long37 = offsetDateTimeField34.add(3200L, (int) (short) 1);
        int int39 = offsetDateTimeField34.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = offsetDateTimeField34.getMinimumValue(readablePartial40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField34.getAsText((long) 8, locale43);
        int int46 = offsetDateTimeField34.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) ' ');
        long long53 = offsetDateTimeField50.add(3200L, (int) (short) 1);
        int int55 = offsetDateTimeField50.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial56 = null;
        java.util.Locale locale58 = null;
        java.lang.String str59 = offsetDateTimeField50.getAsShortText(readablePartial56, (int) '4', locale58);
        java.util.Locale locale60 = null;
        int int61 = offsetDateTimeField50.getMaximumShortTextLength(locale60);
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology62.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, (int) ' ');
        long long68 = offsetDateTimeField65.add(3200L, (int) (short) 1);
        int int70 = offsetDateTimeField65.get((long) (short) 100);
        int int72 = offsetDateTimeField65.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = offsetDateTimeField65.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType73, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType73, (int) 'a');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField78 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType73);
        long long80 = remainderDateTimeField78.roundHalfCeiling((long) (-43104900));
        int int82 = remainderDateTimeField78.get(14400003L);
        org.joda.time.chrono.GregorianChronology gregorianChronology83 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField84 = gregorianChronology83.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField86 = new org.joda.time.field.OffsetDateTimeField(dateTimeField84, (int) ' ');
        long long89 = offsetDateTimeField86.add(3200L, (int) (short) 1);
        int int91 = offsetDateTimeField86.get((long) (short) 100);
        int int93 = offsetDateTimeField86.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType94 = offsetDateTimeField86.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField95 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField78, dateTimeFieldType94);
        long long98 = remainderDateTimeField78.addWrapField(43200000L, (int) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604803200L + "'", long37 == 604803200L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 33 + "'", int41 == 33);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "33" + "'", str44.equals("33"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 85 + "'", int46 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 604803200L + "'", long53 == 604803200L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 33 + "'", int55 == 33);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "52" + "'", str59.equals("52"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604803200L + "'", long68 == 604803200L);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 33 + "'", int70 == 33);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 33 + "'", int72 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-259200100L) + "'", long80 == (-259200100L));
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 3 + "'", int82 == 3);
        org.junit.Assert.assertNotNull(gregorianChronology83);
        org.junit.Assert.assertNotNull(dateTimeField84);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 604803200L + "'", long89 == 604803200L);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 33 + "'", int91 == 33);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 33 + "'", int93 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType94);
        org.junit.Assert.assertTrue("'" + long98 + "' != '" + 43200000L + "'", long98 == 43200000L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.Period period4 = period0.withMillis((int) (byte) -1);
        org.joda.time.Period period6 = period4.minusMinutes(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        boolean boolean4 = cachedDateTimeZone2.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(32);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder2.toDateTimeZone("GregorianChronology[PT100H]", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder2.setStandardOffset((int) (short) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder7.setFixedSavings("230400000", 230400000);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder12 = dateTimeZoneBuilder7.setStandardOffset((-99));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder23 = dateTimeZoneBuilder7.addRecurringSavings("GregorianChronology[UTC]", (-5325), (int) (byte) 10, (int) (byte) -1, '4', (int) (byte) 1, 1673545, (int) (short) 0, false, 3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder12);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder23);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.Chronology chronology12 = zonedChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.clockhourOfDay();
        java.lang.String str14 = zonedChronology11.toString();
        org.joda.time.Chronology chronology15 = zonedChronology11.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.Chronology chronology21 = zonedChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        int int23 = fixedDateTimeZone20.getOffset((long) (byte) 100);
        java.lang.String str25 = fixedDateTimeZone20.getNameKey(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        java.util.TimeZone timeZone27 = fixedDateTimeZone20.toTimeZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str14.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "8" + "'", str25.equals("8"));
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(timeZone27);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(32);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder2.toDateTimeZone("GregorianChronology[PT100H]", true);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder2.toDateTimeZone("65", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        int int37 = unsupportedDateTimeField34.getDifference((long) '4', (-210866414400000L));
        long long40 = unsupportedDateTimeField34.getDifferenceAsLong((long) 'a', (-230400000L));
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = unsupportedDateTimeField34.getType();
        org.joda.time.ReadablePartial readablePartial42 = null;
        java.util.Locale locale43 = null;
        try {
            java.lang.String str44 = unsupportedDateTimeField34.getAsText(readablePartial42, locale43);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 66 + "'", int37 == 66);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.getDifferenceAsLong((long) (-5325), (-244803200L));
        java.lang.String str41 = unsupportedDateTimeField34.getName();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField34.getDurationField();
        java.util.Locale locale43 = null;
        try {
            int int44 = unsupportedDateTimeField34.getMaximumTextLength(locale43);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "weekOfWeekyear" + "'", str41.equals("weekOfWeekyear"));
        org.junit.Assert.assertNotNull(durationField42);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField3 = gregorianChronology2.eras();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        java.lang.String str6 = cachedDateTimeZone5.toString();
        org.joda.time.Chronology chronology7 = lenientChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        org.joda.time.ReadablePartial readablePartial8 = null;
        try {
            int[] intArray10 = lenientChronology1.get(readablePartial8, (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT100H" + "'", str6.equals("PT100H"));
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("P8Y");
        org.joda.time.Period period3 = org.joda.time.Period.hours(100);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.Period period6 = period3.minusMinutes((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationTo(readableInstant7);
        long long9 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        long long10 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant13);
        org.joda.time.Period period16 = period14.plusHours(3);
        jodaTimePermission1.checkGuard((java.lang.Object) period14);
        java.lang.String str18 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission20 = new org.joda.time.JodaTimePermission("P8Y");
        boolean boolean21 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission20);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) ' ');
        long long28 = offsetDateTimeField25.add(3200L, (int) (short) 1);
        int int30 = offsetDateTimeField25.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = offsetDateTimeField25.getMinimumValue(readablePartial31);
        java.util.Locale locale34 = null;
        java.lang.String str35 = offsetDateTimeField25.getAsText((long) 8, locale34);
        org.joda.time.DateTimeField dateTimeField36 = offsetDateTimeField25.getWrappedField();
        long long39 = offsetDateTimeField25.add((long) 4, (int) '4');
        long long41 = offsetDateTimeField25.roundHalfFloor((-58571700L));
        long long43 = offsetDateTimeField25.remainder((long) 8);
        boolean boolean44 = jodaTimePermission1.equals((java.lang.Object) offsetDateTimeField25);
        java.util.Locale locale45 = null;
        int int46 = offsetDateTimeField25.getMaximumTextLength(locale45);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 360000000L + "'", long9 == 360000000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 360000000L + "'", long10 == 360000000L);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "P8Y" + "'", str18.equals("P8Y"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 604803200L + "'", long28 == 604803200L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 33 + "'", int30 == 33);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 33 + "'", int32 == 33);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "33" + "'", str35.equals("33"));
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 31449600004L + "'", long39 == 31449600004L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-259200100L) + "'", long41 == (-259200100L));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 259200108L + "'", long43 == 259200108L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        int int10 = offsetDateTimeField3.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField3.getType();
        long long14 = offsetDateTimeField3.getDifferenceAsLong(1260000000L, (long) (short) 1);
        long long16 = offsetDateTimeField3.roundHalfCeiling((long) (short) 1);
        int int17 = offsetDateTimeField3.getMaximumValue();
        int int19 = offsetDateTimeField3.getLeapAmount((long) (short) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200100L) + "'", long16 == (-259200100L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 85 + "'", int17 == 85);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        java.lang.String str41 = unsupportedDateTimeField34.toString();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField34.getDurationField();
        try {
            long long45 = unsupportedDateTimeField34.set(1560615134061L, 360000035);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "UnsupportedDateTimeField" + "'", str41.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(durationField42);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        java.lang.String str41 = unsupportedDateTimeField34.toString();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField34.getDurationField();
        try {
            long long44 = unsupportedDateTimeField34.remainder(14495100L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "UnsupportedDateTimeField" + "'", str41.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(durationField42);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.Chronology chronology12 = zonedChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) ' ');
        long long23 = offsetDateTimeField20.add(3200L, (int) (short) 1);
        int int25 = offsetDateTimeField20.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial26 = null;
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField20.getAsShortText(readablePartial26, (int) '4', locale28);
        java.util.Locale locale30 = null;
        int int31 = offsetDateTimeField20.getMaximumShortTextLength(locale30);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (int) ' ');
        long long38 = offsetDateTimeField35.add(3200L, (int) (short) 1);
        int int40 = offsetDateTimeField35.get((long) (short) 100);
        int int42 = offsetDateTimeField35.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField35.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField20, dateTimeFieldType43, (int) (byte) 10);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField47 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, dateTimeFieldType43, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField(dateTimeField13, dateTimeFieldType43, (int) '#');
        int int51 = dividedDateTimeField49.getMinimumValue((-58571700L));
        int int52 = dividedDateTimeField49.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 604803200L + "'", long23 == 604803200L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "52" + "'", str29.equals("52"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 604803200L + "'", long38 == 604803200L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 33 + "'", int40 == 33);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 33 + "'", int42 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 100, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 135 + "'", int2 == 135);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.Chronology chronology12 = zonedChronology11.withUTC();
        org.joda.time.DurationField durationField13 = zonedChronology11.minutes();
        org.joda.time.Chronology chronology14 = zonedChronology11.withUTC();
        org.joda.time.DurationField durationField15 = zonedChronology11.hours();
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology11.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField8 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.year();
        org.joda.time.DurationField durationField10 = gregorianChronology0.weeks();
        org.joda.time.Period period12 = org.joda.time.Period.hours(100);
        org.joda.time.Period period13 = period12.negated();
        org.joda.time.Period period15 = period12.minusMinutes((int) (short) 0);
        org.joda.time.Period period17 = period15.plusSeconds(100);
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType19 = periodType18.withSecondsRemoved();
        org.joda.time.PeriodType periodType20 = org.joda.time.DateTimeUtils.getPeriodType(periodType18);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        int int22 = periodType20.indexOf(durationFieldType21);
        boolean boolean23 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period17, (java.lang.Object) periodType20);
        org.joda.time.PeriodType periodType24 = periodType20.withMillisRemoved();
        org.joda.time.PeriodType periodType25 = periodType24.withWeeksRemoved();
        boolean boolean26 = gregorianChronology0.equals((java.lang.Object) periodType25);
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test253");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        int int4 = cachedDateTimeZone2.getOffset(0L);
//        boolean boolean6 = cachedDateTimeZone2.equals((java.lang.Object) (-10L));
//        java.lang.String str8 = cachedDateTimeZone2.getShortName((long) (byte) 10);
//        java.lang.String str10 = cachedDateTimeZone2.getNameKey((-57599900L));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.File file4 = null;
        java.io.File[] fileArray5 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = zoneInfoCompiler0.compile(file4, fileArray5);
        java.io.File file7 = null;
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler8 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file9 = null;
        java.io.File[] fileArray10 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = zoneInfoCompiler8.compile(file9, fileArray10);
        java.io.File file12 = null;
        java.io.File[] fileArray13 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap14 = zoneInfoCompiler8.compile(file12, fileArray13);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap15 = zoneInfoCompiler0.compile(file7, fileArray13);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap15);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(fileArray5);
        org.junit.Assert.assertNotNull(strMap6);
        org.junit.Assert.assertNotNull(fileArray10);
        org.junit.Assert.assertNotNull(strMap11);
        org.junit.Assert.assertNotNull(fileArray13);
        org.junit.Assert.assertNotNull(strMap14);
        org.junit.Assert.assertNotNull(strMap15);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) 'a');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(19349999999L);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal(10L);
        long long12 = fixedDateTimeZone4.previousTransition((-210858134399967L));
        boolean boolean13 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-210858134399967L) + "'", long12 == (-210858134399967L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dateTimeZone14);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.PeriodType periodType3 = period1.getPeriodType();
        java.lang.String str4 = periodType3.getName();
        int int5 = periodType3.size();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = periodType3.indexOf(durationFieldType6);
        org.joda.time.Period period9 = org.joda.time.Period.hours(100);
        org.joda.time.Period period10 = period9.negated();
        int int11 = period10.size();
        org.joda.time.Period period12 = new org.joda.time.Period();
        int int13 = period12.size();
        org.joda.time.Period period14 = period12.negated();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = period14.indexOf(durationFieldType15);
        org.joda.time.DurationFieldType durationFieldType18 = period14.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(durationFieldType18, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.Period period24 = period10.withFieldAdded(durationFieldType18, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology25.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology29 = gregorianChronology25.withZone(dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone32 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone31);
        int int34 = cachedDateTimeZone32.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone35 = cachedDateTimeZone32.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology36 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology25, dateTimeZone35);
        org.joda.time.Chronology chronology37 = zonedChronology36.withUTC();
        org.joda.time.Period period38 = new org.joda.time.Period();
        int int39 = period38.size();
        org.joda.time.Period period40 = period38.negated();
        int int41 = period38.getDays();
        boolean boolean42 = zonedChronology36.equals((java.lang.Object) int41);
        boolean boolean43 = period10.equals((java.lang.Object) zonedChronology36);
        boolean boolean44 = periodType3.equals((java.lang.Object) period10);
        org.joda.time.Period period45 = new org.joda.time.Period((long) (-5325), periodType3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Standard" + "'", str4.equals("Standard"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(cachedDateTimeZone32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(zonedChronology36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 8 + "'", int39 == 8);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period0.getFieldTypes();
        int int6 = period0.getWeeks();
        org.joda.time.Period period8 = period0.minusWeeks((int) (byte) 100);
        org.joda.time.Period period10 = period8.plusMillis((-5325));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) ' ');
        org.joda.time.Period period2 = period1.toPeriod();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        int int6 = period3.getDays();
        org.joda.time.Period period8 = period3.withYears(8);
        int int10 = period8.getValue(0);
        org.joda.time.PeriodType periodType11 = period8.getPeriodType();
        org.joda.time.PeriodType periodType12 = periodType11.withMillisRemoved();
        org.joda.time.Period period13 = period2.withPeriodType(periodType12);
        org.joda.time.Period period14 = new org.joda.time.Period();
        int int15 = period14.size();
        org.joda.time.Period period16 = period14.negated();
        int int17 = period14.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter18 = null;
        java.lang.String str19 = period14.toString(periodFormatter18);
        org.joda.time.DurationFieldType durationFieldType21 = period14.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField22 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType21);
        int int23 = period13.indexOf(durationFieldType21);
        try {
            org.joda.time.Hours hours24 = period13.toStandardHours();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Hours as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "PT0S" + "'", str19.equals("PT0S"));
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertNotNull(unsupportedDurationField22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        long long32 = dividedDateTimeField28.add((-3935130120000000L), (long) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField28, 10);
        org.joda.time.ReadablePartial readablePartial35 = null;
        int int36 = dividedDateTimeField28.getMinimumValue(readablePartial35);
        int int37 = dividedDateTimeField28.getDivisor();
        java.util.Locale locale39 = null;
        java.lang.String str40 = dividedDateTimeField28.getAsText(31449600004L, locale39);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) ' ');
        long long47 = offsetDateTimeField44.add(3200L, (int) (short) 1);
        int int49 = offsetDateTimeField44.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial50 = null;
        int int51 = offsetDateTimeField44.getMinimumValue(readablePartial50);
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField44.getAsText((long) 8, locale53);
        int int56 = offsetDateTimeField44.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology57.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField(dateTimeField58, (int) ' ');
        long long63 = offsetDateTimeField60.add(3200L, (int) (short) 1);
        int int65 = offsetDateTimeField60.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial66 = null;
        java.util.Locale locale68 = null;
        java.lang.String str69 = offsetDateTimeField60.getAsShortText(readablePartial66, (int) '4', locale68);
        java.util.Locale locale70 = null;
        int int71 = offsetDateTimeField60.getMaximumShortTextLength(locale70);
        org.joda.time.chrono.GregorianChronology gregorianChronology72 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology72.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField75 = new org.joda.time.field.OffsetDateTimeField(dateTimeField73, (int) ' ');
        long long78 = offsetDateTimeField75.add(3200L, (int) (short) 1);
        int int80 = offsetDateTimeField75.get((long) (short) 100);
        int int82 = offsetDateTimeField75.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType83 = offsetDateTimeField75.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField85 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField60, dateTimeFieldType83, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField87 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField44, dateTimeFieldType83, (int) 'a');
        java.lang.Number number88 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException91 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType83, number88, (java.lang.Number) 10L, (java.lang.Number) 3);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField93 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField28, dateTimeFieldType83, 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3934918440000000L) + "'", long32 == (-3934918440000000L));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "8" + "'", str40.equals("8"));
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 604803200L + "'", long47 == 604803200L);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 33 + "'", int49 == 33);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 33 + "'", int51 == 33);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "33" + "'", str54.equals("33"));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 85 + "'", int56 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 604803200L + "'", long63 == 604803200L);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 33 + "'", int65 == 33);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "52" + "'", str69.equals("52"));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2 + "'", int71 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology72);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 604803200L + "'", long78 == 604803200L);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 33 + "'", int80 == 33);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 33 + "'", int82 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType83);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period2 = new org.joda.time.Period();
        int int3 = period2.size();
        org.joda.time.Period period4 = period2.negated();
        boolean boolean5 = gregorianChronology1.equals((java.lang.Object) period4);
        org.joda.time.Chronology chronology6 = gregorianChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology1.getZone();
        org.joda.time.Chronology chronology8 = gregorianChronology0.withZone(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone9);
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = cachedDateTimeZone10.isLocalDateTimeGap(localDateTime11);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        org.joda.time.Period period0 = new org.joda.time.Period();
        boolean boolean2 = period0.equals((java.lang.Object) false);
        org.joda.time.Period period4 = period0.plusMillis((int) (byte) 1);
        org.joda.time.Weeks weeks5 = period0.toStandardWeeks();
        org.joda.time.Period period7 = period0.minusSeconds((int) (byte) 10);
        org.joda.time.Period period9 = period7.withYears(2);
        org.joda.time.Period period11 = org.joda.time.Period.hours(100);
        org.joda.time.Period period12 = period11.negated();
        org.joda.time.Period period14 = period11.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass15 = period14.getClass();
        org.joda.time.Period period17 = period14.minusMonths((int) (short) 10);
        org.joda.time.Period period18 = period7.withFields((org.joda.time.ReadablePeriod) period14);
        org.joda.time.Period period20 = period14.withMonths(8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(weeks5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-5325L), 466560000000004L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2484432000000021300L) + "'", long2 == (-2484432000000021300L));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        int int10 = offsetDateTimeField3.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField3.getType();
        long long14 = offsetDateTimeField3.getDifferenceAsLong(1260000000L, (long) (short) 1);
        boolean boolean15 = offsetDateTimeField3.isLenient();
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField3.getWrappedField();
        long long18 = offsetDateTimeField3.roundHalfCeiling(6048000100L);
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField3.getAsShortText(256, locale20);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 5788799900L + "'", long18 == 5788799900L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "256" + "'", str21.equals("256"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Coordinated Universal Time");
        java.security.Permission permission2 = null;
        boolean boolean3 = jodaTimePermission1.implies(permission2);
        java.lang.String str4 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.hours(100);
        org.joda.time.Period period3 = period2.negated();
        org.joda.time.Period period5 = period2.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass6 = period5.getClass();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType8 = periodType7.withSecondsRemoved();
        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType7);
        org.joda.time.Period period10 = period5.normalizedStandard(periodType9);
        org.joda.time.Period period11 = new org.joda.time.Period();
        int int12 = period11.size();
        org.joda.time.Period period13 = period11.negated();
        org.joda.time.DurationFieldType durationFieldType14 = null;
        int int15 = period13.indexOf(durationFieldType14);
        org.joda.time.DurationFieldType durationFieldType17 = period13.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(durationFieldType17, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField22 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType17);
        int int23 = period10.indexOf(durationFieldType17);
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField24 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType17);
        org.junit.Assert.assertNotNull(unsupportedDurationField22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        long long31 = dividedDateTimeField28.roundFloor((-35424164159999948L));
        int int32 = dividedDateTimeField28.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-35424165024000100L) + "'", long31 == (-35424165024000100L));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (-10256), 2940L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        try {
            long long14 = unsupportedDurationField11.getMillis(0, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField12 = iSOChronology11.weekyears();
        java.lang.String str13 = iSOChronology11.toString();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType17 = periodType16.withSecondsRemoved();
        org.joda.time.PeriodType periodType18 = periodType17.withYearsRemoved();
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (-230400000L), periodType17);
        int[] intArray22 = iSOChronology11.get((org.joda.time.ReadablePeriod) period19, (-210866673600000L), 590400052L);
        try {
            int[] intArray24 = offsetDateTimeField3.set(readablePartial9, (int) (short) 10, intArray22, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2 for weekOfWeekyear must be in the range [33,85]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ISOChronology[UTC]" + "'", str13.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("+00:00:00.100", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "53");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        boolean boolean13 = unsupportedDurationField11.isPrecise();
        boolean boolean14 = unsupportedDurationField11.isSupported();
        try {
            long long17 = unsupportedDurationField11.add((long) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.PeriodType periodType5 = period0.getPeriodType();
        int int6 = period0.getMonths();
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.Period period10 = period0.withPeriodType(periodType9);
        org.joda.time.Period period12 = period0.withMillis((int) (short) 10);
        org.joda.time.Period period14 = period12.minusMinutes((int) 'a');
        org.joda.time.Period period16 = period14.minusHours((int) (byte) 10);
        org.joda.time.PeriodType periodType17 = period16.getPeriodType();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(periodType17);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        long long32 = dividedDateTimeField28.add((-3935130120000000L), (long) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField28, 10);
        org.joda.time.ReadablePartial readablePartial35 = null;
        int int36 = dividedDateTimeField28.getMinimumValue(readablePartial35);
        int int37 = dividedDateTimeField28.getDivisor();
        long long39 = dividedDateTimeField28.remainder(365785006809600004L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-3934918440000000L) + "'", long32 == (-3934918440000000L));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 365784994713600004L + "'", long39 == 365784994713600004L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int4 = cachedDateTimeZone2.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone5 = cachedDateTimeZone2.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone6 = cachedDateTimeZone2.getUncachedZone();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology7.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.centuryOfEra();
        long long12 = gregorianChronology0.getDateTimeMillis(4, 4, 8, (int) (byte) 100);
        java.lang.String str13 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62032521600000L) + "'", long12 == (-62032521600000L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "GregorianChronology[PT100H]" + "'", str13.equals("GregorianChronology[PT100H]"));
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) ' ');
        long long9 = offsetDateTimeField6.add(3200L, (int) (short) 1);
        int int11 = offsetDateTimeField6.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField6.getAsShortText(readablePartial12, (int) '4', locale14);
        java.util.Locale locale16 = null;
        int int17 = offsetDateTimeField6.getMaximumShortTextLength(locale16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) ' ');
        long long24 = offsetDateTimeField21.add(3200L, (int) (short) 1);
        int int26 = offsetDateTimeField21.get((long) (short) 100);
        int int28 = offsetDateTimeField21.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField21.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType29, (int) (byte) 10);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 2);
        java.util.Locale locale34 = null;
        int int35 = dividedDateTimeField33.getMaximumTextLength(locale34);
        boolean boolean36 = dividedDateTimeField33.isSupported();
        org.joda.time.ReadablePartial readablePartial37 = null;
        int int38 = dividedDateTimeField33.getMaximumValue(readablePartial37);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 604803200L + "'", long9 == 604803200L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "52" + "'", str15.equals("52"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 604803200L + "'", long24 == 604803200L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 33 + "'", int26 == 33);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 33 + "'", int28 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 5 + "'", int38 == 5);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.yearOfEra();
        org.joda.time.Period period7 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.Period period9 = period7.minusMillis((int) '#');
        org.joda.time.Period period11 = period9.withYears(10);
        org.joda.time.Period period13 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType14 = period13.getPeriodType();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.weeks();
        org.joda.time.Period period17 = org.joda.time.Period.hours(100);
        org.joda.time.Period period18 = period17.negated();
        int int19 = period18.size();
        org.joda.time.Period period20 = new org.joda.time.Period();
        int int21 = period20.size();
        org.joda.time.Period period22 = period20.negated();
        org.joda.time.DurationFieldType durationFieldType23 = null;
        int int24 = period22.indexOf(durationFieldType23);
        org.joda.time.DurationFieldType durationFieldType26 = period22.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException30 = new org.joda.time.IllegalFieldValueException(durationFieldType26, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.Period period32 = period18.withFieldAdded(durationFieldType26, (int) (byte) 100);
        boolean boolean33 = periodType15.isSupported(durationFieldType26);
        int int34 = period13.get(durationFieldType26);
        int int35 = period9.get(durationFieldType26);
        org.joda.time.Period period37 = period9.minusYears((int) (byte) 1);
        org.joda.time.Period period39 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period41 = period39.withPeriodType(periodType40);
        org.joda.time.Period period43 = period41.minusWeeks(0);
        org.joda.time.Period period44 = new org.joda.time.Period();
        int int45 = period44.size();
        org.joda.time.Period period46 = period44.negated();
        org.joda.time.DurationFieldType durationFieldType47 = null;
        int int48 = period44.indexOf(durationFieldType47);
        org.joda.time.Period period49 = period43.withFields((org.joda.time.ReadablePeriod) period44);
        org.joda.time.Period period51 = org.joda.time.Period.hours(100);
        org.joda.time.Period period52 = period51.negated();
        org.joda.time.Days days53 = period52.toStandardDays();
        org.joda.time.Period period55 = period52.plusHours(1);
        org.joda.time.Period period56 = new org.joda.time.Period();
        int int57 = period56.size();
        org.joda.time.PeriodType periodType58 = period56.getPeriodType();
        org.joda.time.DurationFieldType durationFieldType59 = null;
        boolean boolean60 = periodType58.isSupported(durationFieldType59);
        org.joda.time.Period period61 = new org.joda.time.Period();
        int int62 = period61.size();
        org.joda.time.Period period63 = period61.negated();
        org.joda.time.DurationFieldType durationFieldType64 = null;
        int int65 = period63.indexOf(durationFieldType64);
        org.joda.time.DurationFieldType durationFieldType67 = period63.getFieldType((int) (short) 0);
        int int68 = periodType58.indexOf(durationFieldType67);
        org.joda.time.IllegalFieldValueException illegalFieldValueException72 = new org.joda.time.IllegalFieldValueException(durationFieldType67, (java.lang.Number) (byte) 100, (java.lang.Number) 10.0d, (java.lang.Number) 1.0f);
        org.joda.time.Period period74 = period55.withField(durationFieldType67, (int) '#');
        boolean boolean75 = period43.isSupported(durationFieldType67);
        boolean boolean76 = period9.equals((java.lang.Object) boolean75);
        java.lang.Class<?> wildcardClass77 = period9.getClass();
        boolean boolean78 = gregorianChronology0.equals((java.lang.Object) wildcardClass77);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 8 + "'", int19 == 8);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 8 + "'", int21 == 8);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 8 + "'", int45 == 8);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(days53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 8 + "'", int57 == 8);
        org.junit.Assert.assertNotNull(periodType58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 8 + "'", int62 == 8);
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.dayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withDaysRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withWeeksRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period4 = new org.joda.time.Period();
        int int5 = period4.size();
        org.joda.time.Period period6 = period4.negated();
        boolean boolean7 = gregorianChronology3.equals((java.lang.Object) period6);
        org.joda.time.DurationField durationField8 = gregorianChronology3.weeks();
        org.joda.time.DurationField durationField9 = gregorianChronology3.millis();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology3.weekyearOfCentury();
        org.joda.time.DurationField durationField11 = gregorianChronology3.years();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology3.year();
        org.joda.time.DurationField durationField13 = gregorianChronology3.weeks();
        org.joda.time.Period period15 = org.joda.time.Period.hours(100);
        org.joda.time.Period period16 = period15.negated();
        org.joda.time.Period period18 = period15.minusMinutes((int) (short) 0);
        org.joda.time.Period period20 = period18.plusSeconds(100);
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType22 = periodType21.withSecondsRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.DateTimeUtils.getPeriodType(periodType21);
        org.joda.time.DurationFieldType durationFieldType24 = null;
        int int25 = periodType23.indexOf(durationFieldType24);
        boolean boolean26 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period20, (java.lang.Object) periodType23);
        org.joda.time.PeriodType periodType27 = periodType23.withMillisRemoved();
        org.joda.time.PeriodType periodType28 = periodType27.withWeeksRemoved();
        boolean boolean29 = gregorianChronology3.equals((java.lang.Object) periodType28);
        boolean boolean30 = periodType2.equals((java.lang.Object) boolean29);
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period32 = new org.joda.time.Period();
        int int33 = period32.size();
        org.joda.time.Period period34 = period32.negated();
        boolean boolean35 = gregorianChronology31.equals((java.lang.Object) period34);
        org.joda.time.DurationField durationField36 = gregorianChronology31.weeks();
        org.joda.time.DurationField durationField37 = gregorianChronology31.millis();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology31.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology31.centuryOfEra();
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.Period period42 = new org.joda.time.Period();
        int int43 = period42.size();
        org.joda.time.PeriodType periodType44 = period42.getPeriodType();
        org.joda.time.Period period45 = new org.joda.time.Period(readableDuration40, readableInstant41, periodType44);
        org.joda.time.PeriodType periodType46 = periodType44.withYearsRemoved();
        org.joda.time.PeriodType periodType47 = periodType44.withWeeksRemoved();
        boolean boolean48 = gregorianChronology31.equals((java.lang.Object) periodType44);
        boolean boolean49 = org.joda.time.field.FieldUtils.equals((java.lang.Object) periodType2, (java.lang.Object) periodType44);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 8 + "'", int33 == 8);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 8 + "'", int43 == 8);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(periodType46);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.getDifferenceAsLong((long) (-5325), (-244803200L));
        java.lang.String str41 = unsupportedDateTimeField34.getName();
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField34.getDurationField();
        java.util.Locale locale45 = null;
        try {
            long long46 = unsupportedDateTimeField34.set(18000000L, "PeriodType[YearDayTime]", locale45);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "weekOfWeekyear" + "'", str41.equals("weekOfWeekyear"));
        org.junit.Assert.assertNotNull(durationField42);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter4 = null;
        java.lang.String str5 = period0.toString(periodFormatter4);
        int int6 = period0.getMonths();
        org.joda.time.Seconds seconds7 = period0.toStandardSeconds();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0S" + "'", str5.equals("PT0S"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(seconds7);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        int int10 = offsetDateTimeField3.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField3.getType();
        long long14 = offsetDateTimeField3.getDifferenceAsLong(1260000000L, (long) (short) 1);
        boolean boolean15 = offsetDateTimeField3.isLenient();
        org.joda.time.DateTimeField dateTimeField16 = offsetDateTimeField3.getWrappedField();
        int int18 = offsetDateTimeField3.getMinimumValue(19349999999L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 33 + "'", int18 == 33);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int4 = cachedDateTimeZone2.getOffset(0L);
        boolean boolean6 = cachedDateTimeZone2.equals((java.lang.Object) (-10L));
        org.joda.time.Period period8 = org.joda.time.Period.hours(100);
        org.joda.time.Period period9 = period8.negated();
        org.joda.time.Period period11 = period8.plusMonths((int) (short) 10);
        boolean boolean12 = cachedDateTimeZone2.equals((java.lang.Object) period11);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField3 = gregorianChronology2.eras();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        java.lang.String str6 = cachedDateTimeZone5.toString();
        org.joda.time.Chronology chronology7 = lenientChronology1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone5);
        java.lang.String str9 = cachedDateTimeZone5.getNameKey((-30680376L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT100H" + "'", str6.equals("PT100H"));
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "8" + "'", str9.equals("8"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.hours(100);
        org.joda.time.Period period3 = period2.negated();
        org.joda.time.Period period5 = period2.minusMinutes((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period2.toDurationTo(readableInstant6);
        long long8 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration7);
        long long9 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration7);
        long long10 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration7);
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7);
        long long12 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration7);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 360000000L + "'", long8 == 360000000L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 360000000L + "'", long9 == 360000000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 360000000L + "'", long10 == 360000000L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 360000000L + "'", long12 == 360000000L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getDays();
        org.joda.time.format.PeriodFormatter periodFormatter4 = null;
        java.lang.String str5 = period0.toString(periodFormatter4);
        org.joda.time.DurationFieldType durationFieldType7 = period0.getFieldType(0);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField8 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType7);
        org.joda.time.Period period9 = new org.joda.time.Period();
        int int10 = period9.size();
        org.joda.time.Period period11 = period9.negated();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        int int13 = period11.indexOf(durationFieldType12);
        org.joda.time.DurationFieldType durationFieldType15 = period11.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType15, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType15);
        boolean boolean21 = unsupportedDurationField20.isPrecise();
        long long22 = unsupportedDurationField20.getUnitMillis();
        boolean boolean23 = unsupportedDurationField20.isSupported();
        int int24 = unsupportedDurationField8.compareTo((org.joda.time.DurationField) unsupportedDurationField20);
        try {
            long long27 = unsupportedDurationField20.add((-35424164159999948L), (-19357200001L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: years field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT0S" + "'", str5.equals("PT0S"));
        org.junit.Assert.assertNotNull(durationFieldType7);
        org.junit.Assert.assertNotNull(unsupportedDurationField8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int30 = dividedDateTimeField28.get((-57599900L));
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
        long long37 = offsetDateTimeField34.add(3200L, (int) (short) 1);
        int int39 = offsetDateTimeField34.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = offsetDateTimeField34.getMinimumValue(readablePartial40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField34.getAsText((long) 8, locale43);
        int int46 = offsetDateTimeField34.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) ' ');
        long long53 = offsetDateTimeField50.add(3200L, (int) (short) 1);
        int int55 = offsetDateTimeField50.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial56 = null;
        java.util.Locale locale58 = null;
        java.lang.String str59 = offsetDateTimeField50.getAsShortText(readablePartial56, (int) '4', locale58);
        java.util.Locale locale60 = null;
        int int61 = offsetDateTimeField50.getMaximumShortTextLength(locale60);
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology62.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, (int) ' ');
        long long68 = offsetDateTimeField65.add(3200L, (int) (short) 1);
        int int70 = offsetDateTimeField65.get((long) (short) 100);
        int int72 = offsetDateTimeField65.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = offsetDateTimeField65.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType73, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType73, (int) 'a');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField78 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType73);
        long long80 = remainderDateTimeField78.roundHalfCeiling((long) (-43104900));
        int int81 = remainderDateTimeField78.getMinimumValue();
        int int82 = remainderDateTimeField78.getMaximumValue();
        long long84 = remainderDateTimeField78.roundHalfCeiling((long) 3499);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604803200L + "'", long37 == 604803200L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 33 + "'", int41 == 33);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "33" + "'", str44.equals("33"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 85 + "'", int46 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 604803200L + "'", long53 == 604803200L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 33 + "'", int55 == 33);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "52" + "'", str59.equals("52"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604803200L + "'", long68 == 604803200L);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 33 + "'", int70 == 33);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 33 + "'", int72 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-259200100L) + "'", long80 == (-259200100L));
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 9 + "'", int82 == 9);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + (-259200100L) + "'", long84 == (-259200100L));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology2 = lenientChronology1.withUTC();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        long long8 = dateTimeZone6.convertUTCToLocal(1L);
        long long10 = dateTimeZone4.getMillisKeepLocal(dateTimeZone6, (long) 1);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.Chronology chronology12 = lenientChronology1.withZone(dateTimeZone4);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) ' ');
        long long20 = offsetDateTimeField17.add((long) (-1), (int) ' ');
        org.joda.time.ReadablePartial readablePartial21 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period23 = new org.joda.time.Period();
        int int24 = period23.size();
        org.joda.time.Period period25 = period23.negated();
        boolean boolean26 = gregorianChronology22.equals((java.lang.Object) period25);
        org.joda.time.DurationField durationField27 = gregorianChronology22.weeks();
        org.joda.time.DurationField durationField28 = gregorianChronology22.millis();
        org.joda.time.DurationField durationField29 = gregorianChronology22.hours();
        org.joda.time.Period period30 = new org.joda.time.Period();
        boolean boolean32 = period30.equals((java.lang.Object) false);
        org.joda.time.Period period34 = period30.plusMillis((int) (byte) 1);
        int[] intArray37 = gregorianChronology22.get((org.joda.time.ReadablePeriod) period30, (-10L), (long) (short) 0);
        int int38 = offsetDateTimeField17.getMinimumValue(readablePartial21, intArray37);
        try {
            lenientChronology1.validate(readablePartial13, intArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 19353599999L + "'", long20 == 19353599999L);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 33 + "'", int38 == 33);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int30 = dividedDateTimeField28.get((-57599900L));
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology31.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField(dateTimeField32, (int) ' ');
        long long37 = offsetDateTimeField34.add(3200L, (int) (short) 1);
        int int39 = offsetDateTimeField34.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial40 = null;
        int int41 = offsetDateTimeField34.getMinimumValue(readablePartial40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = offsetDateTimeField34.getAsText((long) 8, locale43);
        int int46 = offsetDateTimeField34.getMaximumValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology47.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) ' ');
        long long53 = offsetDateTimeField50.add(3200L, (int) (short) 1);
        int int55 = offsetDateTimeField50.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial56 = null;
        java.util.Locale locale58 = null;
        java.lang.String str59 = offsetDateTimeField50.getAsShortText(readablePartial56, (int) '4', locale58);
        java.util.Locale locale60 = null;
        int int61 = offsetDateTimeField50.getMaximumShortTextLength(locale60);
        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology62.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, (int) ' ');
        long long68 = offsetDateTimeField65.add(3200L, (int) (short) 1);
        int int70 = offsetDateTimeField65.get((long) (short) 100);
        int int72 = offsetDateTimeField65.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = offsetDateTimeField65.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField50, dateTimeFieldType73, (int) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField34, dateTimeFieldType73, (int) 'a');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField78 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28, dateTimeFieldType73);
        boolean boolean79 = remainderDateTimeField78.isSupported();
        long long81 = remainderDateTimeField78.roundHalfCeiling((long) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 604803200L + "'", long37 == 604803200L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 33 + "'", int39 == 33);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 33 + "'", int41 == 33);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "33" + "'", str44.equals("33"));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 85 + "'", int46 == 85);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 604803200L + "'", long53 == 604803200L);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 33 + "'", int55 == 33);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "52" + "'", str59.equals("52"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 604803200L + "'", long68 == 604803200L);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 33 + "'", int70 == 33);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 33 + "'", int72 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-259200100L) + "'", long81 == (-259200100L));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Throwable[] throwableArray8 = illegalFieldValueException4.getSuppressed();
        java.lang.Number number9 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str10 = illegalFieldValueException4.getFieldName();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.String str12 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value 10.0 for Standard must be in the range [10.0,1]"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10.0d + "'", number9.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Standard" + "'", str10.equals("Standard"));
        org.junit.Assert.assertNull(dateTimeFieldType11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField8 = gregorianChronology0.years();
        long long14 = gregorianChronology0.getDateTimeMillis((long) '4', 4, (int) (short) 1, (int) '#', (int) (byte) 100);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.hourOfHalfday();
        int int16 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 14495000L + "'", long14 == 14495000L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.Period period7 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period9 = period7.withPeriodType(periodType8);
        boolean boolean10 = fixedDateTimeZone4.equals((java.lang.Object) periodType8);
        int int12 = fixedDateTimeZone4.getStandardOffset(350L);
        java.util.TimeZone timeZone13 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean15 = fixedDateTimeZone4.isFixed();
        long long17 = fixedDateTimeZone4.nextTransition(0L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 10, 0, 8, 0);
        org.joda.time.Period period6 = period4.plusDays((int) (short) 1);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        java.lang.String str11 = decoratedDurationField10.getName();
        boolean boolean12 = decoratedDurationField10.isSupported();
        long long15 = decoratedDurationField10.getDifferenceAsLong((long) (byte) 100, (long) 100);
        java.lang.String str16 = decoratedDurationField10.toString();
        long long17 = decoratedDurationField10.getUnitMillis();
        java.lang.String str18 = decoratedDurationField10.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "years" + "'", str11.equals("years"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DurationField[years]" + "'", str16.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 3600000L + "'", long17 == 3600000L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "years" + "'", str18.equals("years"));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        try {
            int int37 = unsupportedDateTimeField34.get(1000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(gregorianChronology7);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField8 = gregorianChronology0.years();
        boolean boolean10 = gregorianChronology0.equals((java.lang.Object) "UTC");
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.Chronology chronology16 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        java.util.TimeZone timeZone22 = fixedDateTimeZone21.toTimeZone();
        org.joda.time.Period period24 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period26 = period24.withPeriodType(periodType25);
        boolean boolean27 = fixedDateTimeZone21.equals((java.lang.Object) periodType25);
        int int29 = fixedDateTimeZone21.getStandardOffset((-230400000L));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        long long32 = fixedDateTimeZone21.previousTransition((-210858134399967L));
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone21);
        try {
            long long38 = gregorianChronology0.getDateTimeMillis((-72), 66, 5, 213);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 66 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 32 + "'", int29 == 32);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-210858134399967L) + "'", long32 == (-210858134399967L));
        org.junit.Assert.assertNotNull(zonedChronology33);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.Chronology chronology12 = zonedChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.clockhourOfDay();
        java.lang.String str14 = zonedChronology11.toString();
        org.joda.time.Chronology chronology15 = zonedChronology11.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.Chronology chronology21 = zonedChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = zonedChronology11.minuteOfHour();
        java.lang.Object obj23 = null;
        boolean boolean24 = zonedChronology11.equals(obj23);
        org.joda.time.DateTimeField dateTimeField25 = zonedChronology11.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str14.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTimeField25);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        long long18 = zonedChronology11.getDateTimeMillis((-210858120000000L), 8, 0, (int) (byte) 0, 33);
        org.joda.time.DateTimeField dateTimeField19 = zonedChronology11.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField20 = zonedChronology11.yearOfEra();
        org.joda.time.DurationField durationField21 = zonedChronology11.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-210858134399967L) + "'", long18 == (-210858134399967L));
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.PeriodType periodType5 = period0.getPeriodType();
        int int6 = period0.getMonths();
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.Period period10 = period0.withPeriodType(periodType9);
        org.joda.time.Period period11 = period0.negated();
        org.joda.time.Period period13 = org.joda.time.Period.hours(100);
        org.joda.time.Period period14 = period13.negated();
        org.joda.time.Period period16 = period13.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass17 = period16.getClass();
        org.joda.time.Period period19 = period16.minusMonths((int) (short) 10);
        org.joda.time.Period period20 = period19.normalizedStandard();
        org.joda.time.PeriodType periodType21 = null;
        org.joda.time.Period period22 = period19.withPeriodType(periodType21);
        org.joda.time.Period period23 = period11.minus((org.joda.time.ReadablePeriod) period19);
        org.joda.time.Period period25 = period23.plusSeconds((int) (byte) 0);
        int[] intArray26 = period23.getValues();
        int int28 = period23.getValue((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int4 = cachedDateTimeZone2.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone5 = cachedDateTimeZone2.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone6 = cachedDateTimeZone2.getUncachedZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekOfWeekyear();
        org.joda.time.DurationField durationField9 = gregorianChronology7.hours();
        org.joda.time.Period period10 = new org.joda.time.Period();
        int int11 = period10.size();
        org.joda.time.Period period12 = period10.negated();
        org.joda.time.DurationFieldType durationFieldType13 = null;
        int int14 = period12.indexOf(durationFieldType13);
        org.joda.time.DurationFieldType durationFieldType16 = period12.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField17 = new org.joda.time.field.DecoratedDurationField(durationField9, durationFieldType16);
        org.joda.time.DurationField durationField18 = decoratedDurationField17.getWrappedField();
        boolean boolean19 = cachedDateTimeZone2.equals((java.lang.Object) decoratedDurationField17);
        int int22 = decoratedDurationField17.getDifference((-6912000000L), 604803200L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-2088) + "'", int22 == (-2088));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.Period period7 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period9 = period7.withPeriodType(periodType8);
        boolean boolean10 = fixedDateTimeZone4.equals((java.lang.Object) periodType8);
        int int12 = fixedDateTimeZone4.getStandardOffset((-230400000L));
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long15 = fixedDateTimeZone4.previousTransition((-210858134399967L));
        boolean boolean16 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-210858134399967L) + "'", long15 == (-210858134399967L));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        boolean boolean31 = dividedDateTimeField28.isLeap(604803200L);
        int int33 = dividedDateTimeField28.get(19349999999L);
        long long36 = dividedDateTimeField28.getDifferenceAsLong(110L, (long) 3);
        org.joda.time.ReadablePartial readablePartial37 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField40 = gregorianChronology39.minutes();
        org.joda.time.Chronology chronology41 = gregorianChronology39.withUTC();
        org.joda.time.Period period43 = org.joda.time.Period.months((int) '4');
        int[] intArray45 = gregorianChronology39.get((org.joda.time.ReadablePeriod) period43, (long) 10);
        try {
            int[] intArray47 = dividedDateTimeField28.set(readablePartial37, (-43104900), intArray45, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [3,8]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(intArray45);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        boolean boolean12 = unsupportedDurationField11.isPrecise();
        boolean boolean13 = unsupportedDurationField11.isSupported();
        java.lang.String str14 = unsupportedDurationField11.getName();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "years" + "'", str14.equals("years"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int4 = cachedDateTimeZone2.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone5 = cachedDateTimeZone2.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone6 = cachedDateTimeZone2.getUncachedZone();
        java.lang.String str8 = cachedDateTimeZone2.getNameKey((-864000000L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        boolean boolean36 = unsupportedDateTimeField34.isLenient();
        long long39 = unsupportedDateTimeField34.add((-43104900L), (-1));
        try {
            int int41 = unsupportedDateTimeField34.getMaximumValue((-19357200001L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-3155716704900L) + "'", long39 == (-3155716704900L));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology2 = lenientChronology1.withUTC();
        org.joda.time.Chronology chronology3 = lenientChronology1.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(lenientChronology1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test313");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        int int4 = cachedDateTimeZone2.getOffset(0L);
//        int int6 = cachedDateTimeZone2.getOffsetFromLocal((long) (short) -1);
//        int int8 = cachedDateTimeZone2.getOffset((long) ' ');
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = cachedDateTimeZone2.getShortName((long) 32, locale10);
//        int int13 = cachedDateTimeZone2.getOffset(0L);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType9 = periodType8.withSecondsRemoved();
        org.joda.time.PeriodType periodType10 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
        org.joda.time.PeriodType periodType11 = periodType10.withMinutesRemoved();
        org.joda.time.PeriodType periodType12 = periodType11.withWeeksRemoved();
        org.joda.time.PeriodType periodType13 = periodType12.withMonthsRemoved();
        org.joda.time.PeriodType periodType14 = periodType13.withSecondsRemoved();
        try {
            org.joda.time.Period period15 = new org.joda.time.Period(256, (-33), (int) (short) 100, (-43104900), 5, (-33), 100, 213, periodType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.PeriodType periodType5 = period0.getPeriodType();
        int int6 = period0.getMonths();
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.Period period10 = period0.withPeriodType(periodType9);
        org.joda.time.Period period11 = period0.negated();
        org.joda.time.Period period13 = period11.minusMinutes(35);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withSecondsRemoved();
        org.joda.time.PeriodType periodType16 = periodType14.withWeeksRemoved();
        boolean boolean17 = period13.equals((java.lang.Object) periodType16);
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(periodType18);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        boolean boolean36 = unsupportedDateTimeField34.isSupported();
        try {
            long long38 = unsupportedDateTimeField34.roundCeiling((long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        org.joda.time.ReadablePartial readablePartial41 = null;
        java.util.Locale locale43 = null;
        try {
            java.lang.String str44 = unsupportedDateTimeField34.getAsShortText(readablePartial41, (int) (byte) 1, locale43);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) ' ');
        long long9 = offsetDateTimeField6.add(3200L, (int) (short) 1);
        int int11 = offsetDateTimeField6.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField6.getAsShortText(readablePartial12, (int) '4', locale14);
        java.util.Locale locale16 = null;
        int int17 = offsetDateTimeField6.getMaximumShortTextLength(locale16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, (int) ' ');
        long long24 = offsetDateTimeField21.add(3200L, (int) (short) 1);
        int int26 = offsetDateTimeField21.get((long) (short) 100);
        int int28 = offsetDateTimeField21.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField21.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField31 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType29, (int) (byte) 10);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 2);
        java.util.Locale locale34 = null;
        int int35 = dividedDateTimeField33.getMaximumTextLength(locale34);
        long long38 = dividedDateTimeField33.add((long) (byte) 1, 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 604803200L + "'", long9 == 604803200L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 33 + "'", int11 == 33);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "52" + "'", str15.equals("52"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 604803200L + "'", long24 == 604803200L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 33 + "'", int26 == 33);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 33 + "'", int28 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        org.joda.time.Period period3 = org.joda.time.Period.hours(100);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.Period period6 = period3.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass7 = period6.getClass();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType9 = periodType8.withSecondsRemoved();
        org.joda.time.PeriodType periodType10 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
        org.joda.time.Period period11 = period6.normalizedStandard(periodType10);
        org.joda.time.Period period12 = new org.joda.time.Period(31449600004L, periodType10);
        org.joda.time.PeriodType periodType13 = periodType10.withMillisRemoved();
        org.joda.time.Period period14 = new org.joda.time.Period((long) 213, periodType10);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType13);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        org.joda.time.Period period1 = org.joda.time.Period.months((-33));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        org.joda.time.DurationField durationField11 = decoratedDurationField10.getWrappedField();
        long long12 = decoratedDurationField10.getUnitMillis();
        long long14 = decoratedDurationField10.getMillis(1L);
        long long16 = decoratedDurationField10.getValueAsLong((long) 604803200);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3600000L + "'", long12 == 3600000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3600000L + "'", long14 == 3600000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 168L + "'", long16 == 168L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.Period period6 = org.joda.time.Period.hours(100);
        org.joda.time.Period period7 = period6.negated();
        org.joda.time.Period period9 = period6.minusMinutes((int) (short) 0);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = period9.indexOf(durationFieldType10);
        long long14 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period9, (long) (byte) -1, 0);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology0.dayOfWeek();
        try {
            long long20 = gregorianChronology0.getDateTimeMillis((int) (short) 0, 85, 35, 168);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 85 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period3 = period1.withPeriodType(periodType2);
        org.joda.time.Period period5 = period3.minusWeeks(0);
        try {
            org.joda.time.Period period7 = period3.withSeconds((-43104900));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        int int3 = period2.size();
        org.joda.time.Period period4 = new org.joda.time.Period();
        int int5 = period4.size();
        org.joda.time.Period period6 = period4.negated();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period6.indexOf(durationFieldType7);
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(durationFieldType10, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.Period period16 = period2.withFieldAdded(durationFieldType10, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology21 = gregorianChronology17.withZone(dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone23);
        int int26 = cachedDateTimeZone24.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone27 = cachedDateTimeZone24.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology17, dateTimeZone27);
        org.joda.time.Chronology chronology29 = zonedChronology28.withUTC();
        org.joda.time.Period period30 = new org.joda.time.Period();
        int int31 = period30.size();
        org.joda.time.Period period32 = period30.negated();
        int int33 = period30.getDays();
        boolean boolean34 = zonedChronology28.equals((java.lang.Object) int33);
        boolean boolean35 = period2.equals((java.lang.Object) zonedChronology28);
        org.joda.time.DateTimeField dateTimeField36 = zonedChronology28.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone37 = zonedChronology28.getZone();
        java.lang.String str38 = zonedChronology28.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(zonedChronology28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 8 + "'", int31 == 8);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str38.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        org.joda.time.Days days3 = period2.toStandardDays();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.Period period5 = period2.withFields(readablePeriod4);
        org.joda.time.Period period7 = period5.plusSeconds((-43104900));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(days3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        java.util.TimeZone timeZone12 = fixedDateTimeZone11.toTimeZone();
        org.joda.time.Period period14 = org.joda.time.Period.hours(100);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period16 = period14.withPeriodType(periodType15);
        boolean boolean17 = fixedDateTimeZone11.equals((java.lang.Object) periodType15);
        int int19 = fixedDateTimeZone11.getStandardOffset(350L);
        java.lang.Object obj20 = null;
        boolean boolean21 = fixedDateTimeZone11.equals(obj20);
        org.joda.time.Chronology chronology22 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        java.lang.String str24 = fixedDateTimeZone11.getName(12L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 32 + "'", int19 == 32);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.100" + "'", str24.equals("+00:00:00.100"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        long long31 = dividedDateTimeField28.remainder((long) (-10256));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-10256L) + "'", long31 == (-10256L));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        java.lang.Number number3 = illegalFieldValueException2.getLowerBound();
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Standard", (java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Number) (short) 1);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        boolean boolean6 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.joda.time.Period period8 = org.joda.time.Period.hours(100);
        org.joda.time.Period period9 = period8.negated();
        org.joda.time.Period period11 = period8.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass12 = period11.getClass();
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withSecondsRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType13);
        org.joda.time.Period period16 = period11.normalizedStandard(periodType15);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.hourOfHalfday();
        int int20 = gregorianChronology17.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology17.minuteOfHour();
        long long25 = gregorianChronology17.add((long) 4, (long) '4', 0);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology17.dayOfYear();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology17.millisOfDay();
        try {
            org.joda.time.Period period28 = new org.joda.time.Period((java.lang.Object) boolean6, periodType15, (org.joda.time.Chronology) gregorianChronology17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 4L + "'", long25 == 4L);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        int int29 = dividedDateTimeField28.getDivisor();
        org.joda.time.DurationField durationField30 = dividedDateTimeField28.getDurationField();
        int int31 = dividedDateTimeField28.getDivisor();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField32 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField28);
        boolean boolean33 = remainderDateTimeField32.isSupported();
        int int34 = remainderDateTimeField32.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 10 + "'", int31 == 10);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getDays();
        org.joda.time.Period period5 = period0.withYears(8);
        int int7 = period5.getValue(0);
        org.joda.time.Period period9 = period5.minusMillis((-2));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField8 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.year();
        org.joda.time.DurationField durationField10 = gregorianChronology0.days();
        try {
            long long18 = gregorianChronology0.getDateTimeMillis(1673545, (int) (byte) 0, (int) (short) -1, 33, 0, (-10256), 360000035);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 33 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.Chronology chronology12 = zonedChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.clockhourOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.hourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) ' ');
        long long23 = offsetDateTimeField20.add(3200L, (int) (short) 1);
        int int25 = offsetDateTimeField20.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial26 = null;
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField20.getAsShortText(readablePartial26, (int) '4', locale28);
        java.util.Locale locale30 = null;
        int int31 = offsetDateTimeField20.getMaximumShortTextLength(locale30);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (int) ' ');
        long long38 = offsetDateTimeField35.add(3200L, (int) (short) 1);
        int int40 = offsetDateTimeField35.get((long) (short) 100);
        int int42 = offsetDateTimeField35.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = offsetDateTimeField35.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField20, dateTimeFieldType43, (int) (byte) 10);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField47 = new org.joda.time.field.DividedDateTimeField(dateTimeField16, dateTimeFieldType43, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField49 = new org.joda.time.field.DividedDateTimeField(dateTimeField13, dateTimeFieldType43, (int) '#');
        org.joda.time.IllegalFieldValueException illegalFieldValueException51 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType43, "8");
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 604803200L + "'", long23 == 604803200L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "52" + "'", str29.equals("52"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 604803200L + "'", long38 == 604803200L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 33 + "'", int40 == 33);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 33 + "'", int42 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.DurationFieldType durationFieldType6 = period2.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException10 = new org.joda.time.IllegalFieldValueException(durationFieldType6, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField11 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType6);
        java.lang.String str12 = unsupportedDurationField11.getName();
        java.lang.String str13 = unsupportedDurationField11.getName();
        org.joda.time.DurationField durationField14 = null;
        int int15 = unsupportedDurationField11.compareTo(durationField14);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType6);
        org.junit.Assert.assertNotNull(unsupportedDurationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "years" + "'", str12.equals("years"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "years" + "'", str13.equals("years"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField2 = gregorianChronology0.hours();
        org.joda.time.Period period3 = new org.joda.time.Period();
        int int4 = period3.size();
        org.joda.time.Period period5 = period3.negated();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.DurationFieldType durationFieldType9 = period5.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField10 = new org.joda.time.field.DecoratedDurationField(durationField2, durationFieldType9);
        org.joda.time.DurationField durationField11 = decoratedDurationField10.getWrappedField();
        java.lang.String str12 = decoratedDurationField10.toString();
        long long15 = decoratedDurationField10.getDifferenceAsLong((-210858120000000L), (long) (byte) 10);
        long long18 = decoratedDurationField10.add((long) 85, (int) ' ');
        long long21 = decoratedDurationField10.getMillis(4, 0L);
        long long24 = decoratedDurationField10.getMillis((-99), (long) (-2));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType9);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DurationField[years]" + "'", str12.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-58571700L) + "'", long15 == (-58571700L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 115200085L + "'", long18 == 115200085L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 14400000L + "'", long21 == 14400000L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-356400000L) + "'", long24 == (-356400000L));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.Period period6 = new org.joda.time.Period((long) 66, (long) (-10256), periodType5);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        java.lang.String str41 = unsupportedDateTimeField34.toString();
        java.util.Locale locale44 = null;
        try {
            long long45 = unsupportedDateTimeField34.set((-604800000L), "3", locale44);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "UnsupportedDateTimeField" + "'", str41.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        org.joda.time.Period period1 = new org.joda.time.Period((long) 604803200);
        org.joda.time.Period period3 = period1.withSeconds((int) '#');
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        org.joda.time.Period period1 = org.joda.time.Period.years(10);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(8212L, "");
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.weeks();
        org.joda.time.DurationField durationField6 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField8 = gregorianChronology0.years();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology0.getZone();
        org.joda.time.LocalDateTime localDateTime10 = null;
        boolean boolean11 = dateTimeZone9.isLocalDateTimeGap(localDateTime10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        boolean boolean36 = unsupportedDateTimeField34.isLenient();
        long long39 = unsupportedDateTimeField34.add((-43104900L), (-1));
        int int42 = unsupportedDateTimeField34.getDifference(673920072000100L, (-19357200001L));
        java.util.Locale locale44 = null;
        try {
            java.lang.String str45 = unsupportedDateTimeField34.getAsShortText((-244803200L), locale44);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-3155716704900L) + "'", long39 == (-3155716704900L));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 213 + "'", int42 == 213);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Period period1 = new org.joda.time.Period();
        int int2 = period1.size();
        org.joda.time.Period period3 = period1.negated();
        boolean boolean4 = gregorianChronology0.equals((java.lang.Object) period3);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withUTC();
        java.lang.String str6 = gregorianChronology0.toString();
        int int7 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.chrono.LenientChronology lenientChronology8 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.PeriodType periodType11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant9, readableDuration10, periodType11);
        org.joda.time.Period period14 = period12.plusYears(0);
        boolean boolean15 = lenientChronology8.equals((java.lang.Object) period14);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[PT100H]" + "'", str6.equals("GregorianChronology[PT100H]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(lenientChronology8);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        int int10 = offsetDateTimeField3.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField3.getType();
        long long14 = offsetDateTimeField3.getDifferenceAsLong(1260000000L, (long) (short) 1);
        boolean boolean15 = offsetDateTimeField3.isLenient();
        long long17 = offsetDateTimeField3.roundHalfCeiling(3200L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33 + "'", int10 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 2L + "'", long14 == 2L);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-259200100L) + "'", long17 == (-259200100L));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        int int2 = period0.getMonths();
        org.joda.time.Period period4 = period0.plusMinutes(8);
        org.joda.time.Period period6 = period4.plusSeconds(360000035);
        org.joda.time.Period period8 = period6.plusDays((-5325));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.Period period4 = org.joda.time.Period.months((int) '4');
        int[] intArray6 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period4, (long) 10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone15 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone15);
        org.joda.time.Chronology chronology17 = zonedChronology12.withZone(dateTimeZone16);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(cachedDateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period3 = org.joda.time.Period.hours(100);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.Period period6 = period3.minusMinutes((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationTo(readableInstant7);
        long long9 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        long long10 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        long long11 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration8);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withSecondsRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        org.joda.time.PeriodType periodType17 = periodType16.withSecondsRemoved();
        org.joda.time.PeriodType periodType18 = periodType17.withSecondsRemoved();
        org.joda.time.Period period19 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant13, periodType17);
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 360000000L + "'", long9 == 360000000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 360000000L + "'", long10 == 360000000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 360000000L + "'", long11 == 360000000L);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("P8Y");
        org.joda.time.Period period3 = org.joda.time.Period.hours(100);
        org.joda.time.Period period4 = period3.negated();
        org.joda.time.Period period6 = period3.minusMinutes((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period3.toDurationTo(readableInstant7);
        long long9 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        long long10 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant13);
        org.joda.time.Period period16 = period14.plusHours(3);
        jodaTimePermission1.checkGuard((java.lang.Object) period14);
        org.joda.time.JodaTimePermission jodaTimePermission19 = new org.joda.time.JodaTimePermission("P8Y");
        org.joda.time.Period period21 = org.joda.time.Period.hours(100);
        org.joda.time.Period period22 = period21.negated();
        org.joda.time.Period period24 = period21.minusMinutes((int) (short) 0);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.Duration duration26 = period21.toDurationTo(readableInstant25);
        long long27 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration26);
        long long28 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration26);
        org.joda.time.ReadableInstant readableInstant29 = null;
        org.joda.time.Period period30 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration26, readableInstant29);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Period period32 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration26, readableInstant31);
        org.joda.time.Period period34 = period32.plusHours(3);
        jodaTimePermission19.checkGuard((java.lang.Object) period32);
        java.lang.String str36 = jodaTimePermission19.getName();
        org.joda.time.JodaTimePermission jodaTimePermission38 = new org.joda.time.JodaTimePermission("P8Y");
        boolean boolean39 = jodaTimePermission19.implies((java.security.Permission) jodaTimePermission38);
        boolean boolean40 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission19);
        java.lang.String str41 = jodaTimePermission19.toString();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 360000000L + "'", long9 == 360000000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 360000000L + "'", long10 == 360000000L);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(duration26);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 360000000L + "'", long27 == 360000000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 360000000L + "'", long28 == 360000000L);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "P8Y" + "'", str36.equals("P8Y"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"P8Y\")" + "'", str41.equals("(\"org.joda.time.JodaTimePermission\" \"P8Y\")"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int4 = cachedDateTimeZone2.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone5 = cachedDateTimeZone2.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone6 = cachedDateTimeZone2.getUncachedZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekOfWeekyear();
        org.joda.time.DurationField durationField9 = gregorianChronology7.hours();
        org.joda.time.Period period10 = new org.joda.time.Period();
        int int11 = period10.size();
        org.joda.time.Period period12 = period10.negated();
        org.joda.time.DurationFieldType durationFieldType13 = null;
        int int14 = period12.indexOf(durationFieldType13);
        org.joda.time.DurationFieldType durationFieldType16 = period12.getFieldType((int) (short) 0);
        org.joda.time.field.DecoratedDurationField decoratedDurationField17 = new org.joda.time.field.DecoratedDurationField(durationField9, durationFieldType16);
        org.joda.time.DurationField durationField18 = decoratedDurationField17.getWrappedField();
        boolean boolean19 = cachedDateTimeZone2.equals((java.lang.Object) decoratedDurationField17);
        int int22 = decoratedDurationField17.getDifference((long) 1673, (-210866803200100L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 58574112 + "'", int22 == 58574112);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset(32);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder2.toDateTimeZone("GregorianChronology[PT100H]", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder2.setFixedSavings("ZonedChronology[GregorianChronology[UTC], UTC]", 230400000);
        java.io.OutputStream outputStream10 = null;
        try {
            dateTimeZoneBuilder2.writeTo("10", outputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        java.lang.String str35 = unsupportedDateTimeField34.getName();
        boolean boolean36 = unsupportedDateTimeField34.isSupported();
        org.joda.time.DurationField durationField37 = unsupportedDateTimeField34.getLeapDurationField();
        boolean boolean38 = unsupportedDateTimeField34.isLenient();
        try {
            java.lang.String str40 = unsupportedDateTimeField34.getAsText((-312413760000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "weekOfWeekyear" + "'", str35.equals("weekOfWeekyear"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(durationField37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        org.joda.time.Period period0 = new org.joda.time.Period();
        int int1 = period0.size();
        org.joda.time.Period period2 = period0.negated();
        int int3 = period0.getMillis();
        int int4 = period0.getMonths();
        org.joda.time.PeriodType periodType5 = period0.getPeriodType();
        int int6 = period0.getMonths();
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) -1);
        org.joda.time.PeriodType periodType9 = period8.getPeriodType();
        org.joda.time.Period period10 = period0.withPeriodType(periodType9);
        org.joda.time.Period period12 = period0.withMillis((int) (short) 10);
        org.joda.time.Period period14 = period0.plusMinutes((int) (short) 1);
        org.joda.time.Period period16 = period14.minusYears((-5325));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology4 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone10);
        org.joda.time.Chronology chronology12 = zonedChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.clockhourOfDay();
        java.lang.String str14 = zonedChronology11.toString();
        org.joda.time.Chronology chronology15 = zonedChronology11.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("PT100H", "8", 100, (int) ' ');
        org.joda.time.Chronology chronology21 = zonedChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        int int23 = fixedDateTimeZone20.getOffset(1560615134061L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str14.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        org.joda.time.ReadablePartial readablePartial38 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology40.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) ' ');
        long long46 = offsetDateTimeField43.add((long) (-1), (int) ' ');
        long long49 = offsetDateTimeField43.add((long) (short) 0, (long) (byte) 1);
        org.joda.time.ReadablePartial readablePartial50 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField52 = gregorianChronology51.minutes();
        org.joda.time.Chronology chronology53 = gregorianChronology51.withUTC();
        org.joda.time.Period period55 = org.joda.time.Period.months((int) '4');
        int[] intArray57 = gregorianChronology51.get((org.joda.time.ReadablePeriod) period55, (long) 10);
        int int58 = offsetDateTimeField43.getMinimumValue(readablePartial50, intArray57);
        try {
            int[] intArray60 = unsupportedDateTimeField34.set(readablePartial38, 360000000, intArray57, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 19353599999L + "'", long46 == 19353599999L);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 604800000L + "'", long49 == 604800000L);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(durationField52);
        org.junit.Assert.assertNotNull(chronology53);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 33 + "'", int58 == 33);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
        boolean boolean2 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.minutes();
        org.joda.time.Chronology chronology2 = gregorianChronology0.withUTC();
        org.joda.time.Period period4 = org.joda.time.Period.hours(100);
        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) period4);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.hourOfHalfday();
        int int10 = gregorianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology7.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology7.yearOfEra();
        boolean boolean13 = gregorianChronology0.equals((java.lang.Object) gregorianChronology7);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int4 = cachedDateTimeZone2.getOffset(0L);
        int int6 = cachedDateTimeZone2.getOffsetFromLocal((long) (short) -1);
        long long8 = cachedDateTimeZone2.nextTransition((long) 4);
        java.lang.String str10 = cachedDateTimeZone2.getNameKey((-58571700L));
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        long long15 = cachedDateTimeZone2.convertLocalToUTC(1814400001L, true, (long) 6);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 4L + "'", long8 == 4L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1814400001L + "'", long15 == 1814400001L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField1, (int) ' ');
        long long6 = offsetDateTimeField3.add(3200L, (int) (short) 1);
        int int8 = offsetDateTimeField3.get((long) (short) 100);
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField3.getAsShortText(readablePartial9, (int) '4', locale11);
        java.util.Locale locale13 = null;
        int int14 = offsetDateTimeField3.getMaximumShortTextLength(locale13);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.weekOfWeekyear();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) ' ');
        long long21 = offsetDateTimeField18.add(3200L, (int) (short) 1);
        int int23 = offsetDateTimeField18.get((long) (short) 100);
        int int25 = offsetDateTimeField18.get((-10L));
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField18.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField28 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField3, dateTimeFieldType26, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        boolean boolean31 = iSOChronology29.equals((java.lang.Object) (byte) -1);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology29.dayOfWeek();
        org.joda.time.DurationField durationField33 = iSOChronology29.centuries();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField34 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField33);
        long long37 = unsupportedDateTimeField34.getDifferenceAsLong(31449600004L, (-1L));
        long long40 = unsupportedDateTimeField34.add((long) '4', (int) '#');
        int int43 = unsupportedDateTimeField34.getDifference((long) (short) 1, 604800000L);
        org.joda.time.ReadablePartial readablePartial44 = null;
        org.joda.time.Period period47 = org.joda.time.Period.years(100);
        org.joda.time.Period period49 = period47.plusHours(35);
        org.joda.time.Period period51 = period47.minusYears(1);
        int[] intArray52 = period47.getValues();
        try {
            int[] intArray54 = unsupportedDateTimeField34.addWrapField(readablePartial44, (-5325), intArray52, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 604803200L + "'", long6 == 604803200L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33 + "'", int8 == 33);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "52" + "'", str12.equals("52"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 604803200L + "'", long21 == 604803200L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 33 + "'", int23 == 33);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 33 + "'", int25 == 33);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 110449353600052L + "'", long40 == 110449353600052L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(intArray52);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        org.joda.time.Period period0 = new org.joda.time.Period();
        boolean boolean2 = period0.equals((java.lang.Object) false);
        org.joda.time.Period period4 = period0.plusMillis((int) (byte) 1);
        org.joda.time.Weeks weeks5 = period0.toStandardWeeks();
        org.joda.time.Period period7 = period0.minusSeconds((int) (byte) 10);
        org.joda.time.Period period9 = period7.withYears(2);
        org.joda.time.Period period11 = org.joda.time.Period.hours(100);
        org.joda.time.Period period12 = period11.negated();
        org.joda.time.Period period14 = period11.minusMinutes((int) (short) 0);
        java.lang.Class<?> wildcardClass15 = period14.getClass();
        org.joda.time.Period period17 = period14.minusMonths((int) (short) 10);
        org.joda.time.Period period18 = period7.withFields((org.joda.time.ReadablePeriod) period14);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period14.toDurationFrom(readableInstant19);
        org.joda.time.MutablePeriod mutablePeriod21 = period14.toMutablePeriod();
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.Period period23 = period14.plus(readablePeriod22);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(weeks5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertNotNull(mutablePeriod21);
        org.junit.Assert.assertNotNull(period23);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        org.joda.time.Period period1 = org.joda.time.Period.months(66);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.joda.time.Period period2 = period1.negated();
        int int3 = period2.size();
        org.joda.time.Period period4 = new org.joda.time.Period();
        int int5 = period4.size();
        org.joda.time.Period period6 = period4.negated();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period6.indexOf(durationFieldType7);
        org.joda.time.DurationFieldType durationFieldType10 = period6.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(durationFieldType10, (java.lang.Number) (-1L), (java.lang.Number) 10, (java.lang.Number) (byte) -1);
        org.joda.time.Period period16 = period2.withFieldAdded(durationFieldType10, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.Chronology chronology21 = gregorianChronology17.withZone(dateTimeZone20);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetMillis(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone23);
        int int26 = cachedDateTimeZone24.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone27 = cachedDateTimeZone24.getUncachedZone();
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology17, dateTimeZone27);
        org.joda.time.Chronology chronology29 = zonedChronology28.withUTC();
        org.joda.time.Period period30 = new org.joda.time.Period();
        int int31 = period30.size();
        org.joda.time.Period period32 = period30.negated();
        int int33 = period30.getDays();
        boolean boolean34 = zonedChronology28.equals((java.lang.Object) int33);
        boolean boolean35 = period2.equals((java.lang.Object) zonedChronology28);
        int int36 = period2.getSeconds();
        org.joda.time.Period period37 = new org.joda.time.Period();
        int int38 = period37.size();
        org.joda.time.Period period39 = period37.negated();
        int int40 = period37.getDays();
        org.joda.time.Period period42 = period37.withYears(8);
        int int44 = period42.getValue(0);
        org.joda.time.PeriodType periodType45 = period42.getPeriodType();
        org.joda.time.Period period46 = period2.withPeriodType(periodType45);
        org.joda.time.Period period47 = period46.toPeriod();
        java.lang.String str48 = period46.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(zonedChronology28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 8 + "'", int31 == 8);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 8 + "'", int38 == 8);
        org.junit.Assert.assertNotNull(period39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 8 + "'", int44 == 8);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "PT-100H" + "'", str48.equals("PT-100H"));
    }
}

