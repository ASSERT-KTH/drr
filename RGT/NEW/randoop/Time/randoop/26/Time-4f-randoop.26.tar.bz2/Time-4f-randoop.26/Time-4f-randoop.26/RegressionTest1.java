import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "-4712");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear((-1));
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        java.lang.String str9 = cachedDateTimeZone7.toString();
        long long12 = cachedDateTimeZone7.adjustOffset(0L, true);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.Chronology chronology14 = zonedChronology13.withUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.halfdayOfDay();
        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology15);
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.halfdayOfDay();
        org.joda.time.LocalDate localDate20 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology18);
        org.joda.time.LocalDate localDate21 = localDate17.withFields((org.joda.time.ReadablePartial) localDate20);
        org.joda.time.LocalDate.Property property22 = localDate21.dayOfWeek();
        org.joda.time.LocalDate localDate23 = property22.roundHalfEvenCopy();
        int[] intArray25 = zonedChronology13.get((org.joda.time.ReadablePartial) localDate23, 17135452800001L);
        try {
            long long31 = zonedChronology13.getDateTimeMillis(79744521600000L, (-292275053), (int) (byte) -1, 2000, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292275053 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.halfdayOfDay();
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.LocalDate localDate6 = localDate2.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate.Property property7 = localDate6.dayOfWeek();
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.DateMidnight dateMidnight11 = localDate6.toDateMidnight(dateTimeZone9);
        org.joda.time.Instant instant12 = dateMidnight11.toInstant();
        org.joda.time.MutableDateTime mutableDateTime13 = instant12.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("97");
        org.joda.time.Instant instant2 = instant1.toInstant();
        org.joda.time.Instant instant4 = instant1.withMillis(1L);
        org.joda.time.Instant instant6 = instant1.minus((long) 16);
        org.joda.time.Instant instant9 = instant1.withDurationAdded((long) 365, 3600000);
        org.joda.time.DateTime dateTime10 = instant9.toDateTimeISO();
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("org.joda.time.IllegalInstantException: 0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalInstantExce...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
        org.joda.time.DateTime dateTime11 = dateTime8.withYear((int) (short) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.halfdayOfDay();
        org.joda.time.LocalDate localDate14 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology12);
        org.joda.time.Chronology chronology15 = localDate14.getChronology();
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.DateTime dateTime17 = localDate14.toDateTime(readableInstant16);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded(readableDuration18, (int) '4');
        org.joda.time.DateTime dateTime22 = dateTime20.minusDays((int) '4');
        org.joda.time.DateTime dateTime24 = dateTime22.plusYears((int) (short) -1);
        org.joda.time.DateTime dateTime26 = dateTime22.minusWeeks(2562);
        java.util.Date date27 = dateTime22.toDate();
        int int28 = dateTime11.compareTo((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter29.withDefaultYear((-1));
        java.util.TimeZone timeZone32 = null;
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forTimeZone(timeZone32);
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now(dateTimeZone33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone35 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone33);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone35);
        org.joda.time.DateTime dateTime37 = dateTime11.toDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone35);
        long long39 = cachedDateTimeZone35.previousTransition((long) (byte) 1);
        boolean boolean41 = cachedDateTimeZone35.equals((java.lang.Object) "2562-06-16");
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(cachedDateTimeZone35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-5756400001L) + "'", long39 == (-5756400001L));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear((-1));
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
//        java.lang.String str9 = cachedDateTimeZone7.toString();
//        long long12 = cachedDateTimeZone7.adjustOffset(0L, true);
//        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
//        org.joda.time.Chronology chronology14 = zonedChronology13.withUTC();
//        org.joda.time.DateTimeField dateTimeField15 = zonedChronology13.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
//        long long20 = offsetDateTimeField17.add((long) 58458305, 2527);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.halfdayOfDay();
//        org.joda.time.LocalDate localDate23 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology21);
//        org.joda.time.Chronology chronology24 = localDate23.getChronology();
//        org.joda.time.ReadableInstant readableInstant25 = null;
//        org.joda.time.DateTime dateTime26 = localDate23.toDateTime(readableInstant25);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField29 = buddhistChronology28.dayOfYear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField30 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29);
//        int int32 = delegatedDateTimeField30.getMinimumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology33.halfdayOfDay();
//        org.joda.time.LocalDate localDate35 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology33);
//        org.joda.time.Chronology chronology36 = localDate35.getChronology();
//        org.joda.time.ReadableInstant readableInstant37 = null;
//        org.joda.time.DateTime dateTime38 = localDate35.toDateTime(readableInstant37);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField40 = buddhistChronology39.halfdayOfDay();
//        org.joda.time.LocalDate localDate41 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology39);
//        org.joda.time.Chronology chronology42 = localDate41.getChronology();
//        int int43 = localDate35.compareTo((org.joda.time.ReadablePartial) localDate41);
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = delegatedDateTimeField30.getAsShortText((org.joda.time.ReadablePartial) localDate35, locale44);
//        org.joda.time.ReadablePartial readablePartial46 = null;
//        int[] intArray52 = new int[] { 62, 36600, (byte) 10, 3, (short) 100 };
//        int int53 = delegatedDateTimeField30.getMinimumValue(readablePartial46, intArray52);
//        int[] intArray55 = offsetDateTimeField17.addWrapPartial((org.joda.time.ReadablePartial) localDate23, 4, intArray52, (int) 'a');
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(zonedChronology13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 79744580058305L + "'", long20 == 79744580058305L);
//        org.junit.Assert.assertNotNull(buddhistChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(buddhistChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(buddhistChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertNotNull(chronology42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "166" + "'", str45.equals("166"));
//        org.junit.Assert.assertNotNull(intArray52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertNotNull(intArray55);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.halfdayOfDay();
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.Chronology chronology5 = localDate4.getChronology();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.DateTime dateTime7 = localDate4.toDateTime(readableInstant6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.halfdayOfDay();
        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.Chronology chronology11 = localDate10.getChronology();
        int int12 = localDate4.compareTo((org.joda.time.ReadablePartial) localDate10);
        java.util.Date date13 = localDate10.toDate();
        boolean boolean14 = jodaTimePermission1.equals((java.lang.Object) localDate10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.halfdayOfDay();
        org.joda.time.LocalDate localDate19 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology17);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((-17L), (org.joda.time.Chronology) buddhistChronology17);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 19, (org.joda.time.Chronology) buddhistChronology17);
        boolean boolean22 = jodaTimePermission1.equals((java.lang.Object) buddhistChronology17);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(58458305);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfMinute(58454092, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatter7.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder2.appendOptional(dateTimeParser8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeParser8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(58458305);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfMinute(58454092, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendFractionOfDay(3, 2513);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder2.appendTimeZoneName(strMap9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((-1));
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        java.lang.String str8 = cachedDateTimeZone6.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) gregorianChronology9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("97");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.MutableDateTime mutableDateTime3 = instant1.toMutableDateTime(dateTimeZone2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.DateMidnight dateMidnight6 = localDate5.toDateMidnight();
        try {
            org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateMidnight6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(dateMidnight6);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.halfdayOfDay();
//        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.halfdayOfDay();
//        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.LocalDate localDate8 = localDate4.withFields((org.joda.time.ReadablePartial) localDate7);
//        long long10 = gJChronology1.set((org.joda.time.ReadablePartial) localDate8, 1L);
//        org.joda.time.DateTimeField dateTimeField11 = gJChronology1.era();
//        try {
//            long long16 = gJChronology1.getDateTimeMillis(36600, (int) 'a', 2, (-1));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 18696092400001L + "'", long10 == 18696092400001L);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.halfdayOfDay();
//        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.halfdayOfDay();
//        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.LocalDate localDate8 = localDate4.withFields((org.joda.time.ReadablePartial) localDate7);
//        long long10 = gJChronology1.set((org.joda.time.ReadablePartial) localDate8, 1L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withDefaultYear((-1));
//        java.util.TimeZone timeZone14 = null;
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter11.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
//        org.joda.time.DateMidnight dateMidnight19 = localDate8.toDateMidnight((org.joda.time.DateTimeZone) cachedDateTimeZone17);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.halfdayOfDay();
//        org.joda.time.LocalDate localDate22 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology20);
//        org.joda.time.Chronology chronology23 = localDate22.getChronology();
//        org.joda.time.ReadableInstant readableInstant24 = null;
//        org.joda.time.DateTime dateTime25 = localDate22.toDateTime(readableInstant24);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology26.halfdayOfDay();
//        org.joda.time.LocalDate localDate28 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology26);
//        org.joda.time.Chronology chronology29 = localDate28.getChronology();
//        int int30 = localDate22.compareTo((org.joda.time.ReadablePartial) localDate28);
//        boolean boolean31 = dateMidnight19.equals((java.lang.Object) localDate28);
//        boolean boolean33 = dateMidnight19.isBefore((long) (-3600000));
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(localDate8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 18696092400001L + "'", long10 == 18696092400001L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateMidnight19);
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(dateTimeZone3);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.halfdayOfDay();
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.LocalDate localDate6 = localDate2.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate.Property property7 = localDate2.centuryOfEra();
        org.joda.time.DateTime dateTime8 = localDate2.toDateTimeAtStartOfDay();
        org.joda.time.LocalDate localDate10 = localDate2.plusMonths((int) (short) 1);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate10);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.halfdayOfDay();
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.LocalDate localDate6 = localDate2.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate.Property property7 = localDate6.dayOfWeek();
        org.joda.time.LocalDate localDate8 = property7.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate9 = property7.roundHalfCeilingCopy();
        int int10 = property7.getMaximumValueOverall();
        org.joda.time.LocalDate localDate11 = property7.roundFloorCopy();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 7 + "'", int10 == 7);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
        boolean boolean10 = dateTime5.isBefore((long) (short) 0);
        org.joda.time.DateTime dateTime12 = dateTime5.minus((long) (short) -1);
        try {
            org.joda.time.DateTime dateTime17 = dateTime12.withTime((int) (short) -1, (int) (short) 10, 6, 2922789);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
//        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.Chronology chronology3 = localDate2.getChronology();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
//        boolean boolean10 = dateTime5.isBefore((long) (short) 0);
//        org.joda.time.DateTime dateTime12 = dateTime5.withEra(0);
//        int int13 = dateTime5.getMonthOfYear();
//        org.joda.time.DateTime dateTime15 = dateTime5.withEra((int) (byte) 0);
//        org.joda.time.DateTime dateTime17 = dateTime5.minusMonths(0);
//        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.halfdayOfDay();
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology19);
//        org.joda.time.Chronology chronology22 = localDate21.getChronology();
//        org.joda.time.ReadableInstant readableInstant23 = null;
//        org.joda.time.DateTime dateTime24 = localDate21.toDateTime(readableInstant23);
//        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime27 = dateTime24.withMillisOfSecond((int) '4');
//        int int28 = dateTime24.getHourOfDay();
//        int int29 = dateTime24.getCenturyOfEra();
//        boolean boolean30 = property18.equals((java.lang.Object) dateTime24);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(buddhistChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(chronology22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 16 + "'", int28 == 16);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 25 + "'", int29 == 25);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.halfdayOfDay();
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.LocalDate localDate6 = localDate2.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate.Property property7 = localDate6.dayOfWeek();
        org.joda.time.LocalDate localDate8 = property7.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate10 = localDate8.plusMonths(100);
        org.joda.time.LocalDate localDate12 = localDate8.minusYears((int) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.halfdayOfDay();
        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology13);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology16.halfdayOfDay();
        org.joda.time.LocalDate localDate18 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.LocalDate localDate19 = localDate15.withFields((org.joda.time.ReadablePartial) localDate18);
        org.joda.time.LocalDate localDate20 = localDate8.withFields((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.Interval interval22 = localDate19.toInterval(dateTimeZone21);
        org.joda.time.ReadableInterval readableInterval23 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval22);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(interval22);
        org.junit.Assert.assertNotNull(readableInterval23);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((-1));
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.halfdayOfDay();
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology9);
        org.joda.time.Chronology chronology12 = localDate11.getChronology();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.DateTime dateTime14 = localDate11.toDateTime(readableInstant13);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.halfdayOfDay();
        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology15);
        org.joda.time.Chronology chronology18 = localDate17.getChronology();
        int int19 = localDate11.compareTo((org.joda.time.ReadablePartial) localDate17);
        int[] intArray21 = iSOChronology8.get((org.joda.time.ReadablePartial) localDate11, 0L);
        org.joda.time.DateTimeField dateTimeField22 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology8, dateTimeField22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray21);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.minus(readablePeriod3);
//        org.joda.time.DateTime dateTime6 = dateTime2.withMillis((long) 365);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.dayOfYear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8);
//        int int11 = delegatedDateTimeField9.getMinimumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.halfdayOfDay();
//        org.joda.time.LocalDate localDate14 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology12);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.halfdayOfDay();
//        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology15);
//        org.joda.time.LocalDate localDate18 = localDate14.withFields((org.joda.time.ReadablePartial) localDate17);
//        org.joda.time.LocalDate.Property property19 = localDate18.dayOfWeek();
//        org.joda.time.LocalDate localDate20 = property19.roundHalfEvenCopy();
//        org.joda.time.LocalDate localDate21 = property19.roundHalfCeilingCopy();
//        int int22 = localDate21.getYearOfCentury();
//        int int23 = delegatedDateTimeField9.getMaximumValue((org.joda.time.ReadablePartial) localDate21);
//        int int24 = dateTime2.get((org.joda.time.DateTimeField) delegatedDateTimeField9);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology25.halfdayOfDay();
//        org.joda.time.LocalDate localDate27 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology25);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField29 = buddhistChronology28.halfdayOfDay();
//        org.joda.time.LocalDate localDate30 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology28);
//        org.joda.time.LocalDate localDate31 = localDate27.withFields((org.joda.time.ReadablePartial) localDate30);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.halfdayOfDay();
//        org.joda.time.LocalDate localDate34 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology32);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology35 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology35.halfdayOfDay();
//        org.joda.time.LocalDate localDate37 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology35);
//        org.joda.time.LocalDate localDate38 = localDate34.withFields((org.joda.time.ReadablePartial) localDate37);
//        org.joda.time.LocalDate.Property property39 = localDate38.dayOfWeek();
//        org.joda.time.LocalDate localDate40 = property39.roundHalfEvenCopy();
//        org.joda.time.LocalDate localDate41 = property39.roundHalfCeilingCopy();
//        int int42 = localDate41.getYearOfCentury();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology43.dayOfYear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField45 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44);
//        long long48 = delegatedDateTimeField45.set(0L, 62);
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = delegatedDateTimeField45.getType();
//        boolean boolean50 = localDate41.isSupported(dateTimeFieldType49);
//        org.joda.time.LocalDate.Property property51 = localDate31.property(dateTimeFieldType49);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField52 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField9, dateTimeFieldType49);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType49, (java.lang.Number) (-198328L), "97");
//        java.lang.Number number56 = illegalFieldValueException55.getLowerBound();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(buddhistChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 62 + "'", int22 == 62);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 366 + "'", int23 == 366);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 166 + "'", int24 == 166);
//        org.junit.Assert.assertNotNull(buddhistChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(buddhistChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertNotNull(buddhistChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(buddhistChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 62 + "'", int42 == 62);
//        org.junit.Assert.assertNotNull(buddhistChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-26179200000L) + "'", long48 == (-26179200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
//        org.junit.Assert.assertNotNull(property51);
//        org.junit.Assert.assertNull(number56);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        java.lang.String str1 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[UTC]" + "'", str1.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.halfdayOfDay();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Chronology chronology4 = localDate3.getChronology();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.DateTime dateTime6 = localDate3.toDateTime(readableInstant5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 100, chronology7);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("Wednesday");
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.halfdayOfDay();
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((-17L), (org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) 19, (org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((int) (short) 1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        int int6 = delegatedDateTimeField4.getMinimumValue(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.halfdayOfDay();
        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.halfdayOfDay();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology10);
        org.joda.time.LocalDate localDate13 = localDate9.withFields((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.LocalDate.Property property14 = localDate13.dayOfWeek();
        org.joda.time.LocalDate localDate15 = property14.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate16 = property14.roundHalfCeilingCopy();
        int int17 = localDate16.getYearOfCentury();
        int int18 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4);
        int int21 = skipDateTimeField20.getMinimumValue();
        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology22.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
        long long27 = delegatedDateTimeField24.set(0L, 62);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField24.getType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField29 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipDateTimeField20, dateTimeFieldType28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 62 + "'", int17 == 62);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 366 + "'", int18 == 366);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-26179200000L) + "'", long27 == (-26179200000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 1, (int) (byte) 0);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getShortName((long) 1970, locale4);
        org.joda.time.Instant instant7 = org.joda.time.Instant.parse("97");
        org.joda.time.Instant instant8 = instant7.toInstant();
        int int9 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) instant8);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Instant instant12 = instant8.withDurationAdded(readableDuration10, 2527);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Instant instant14 = instant8.minus(readableDuration13);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+01:00" + "'", str5.equals("+01:00"));
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3600000 + "'", int9 == 3600000);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(instant14);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long8 = gregorianChronology0.getDateTimeMillis(166, 2512, 2, (int) (short) 1, (int) (short) -1, 365, 366);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
//        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.LocalDate.Property property5 = localDate2.weekyear();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2562-06-15" + "'", str4.equals("2562-06-15"));
//        org.junit.Assert.assertNotNull(property5);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        int int6 = delegatedDateTimeField4.getMinimumValue(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.halfdayOfDay();
        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.halfdayOfDay();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology10);
        org.joda.time.LocalDate localDate13 = localDate9.withFields((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.LocalDate.Property property14 = localDate13.dayOfWeek();
        org.joda.time.LocalDate localDate15 = property14.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate16 = property14.roundHalfCeilingCopy();
        int int17 = localDate16.getYearOfCentury();
        int int18 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4);
        try {
            long long23 = skipDateTimeField20.set((-210863995200000L), 166);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000-07:52:58 (BuddhistChronology[America/Los_Angeles])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 62 + "'", int17 == 62);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 366 + "'", int18 == 366);
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(58458305);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfMinute(58454092, (int) (short) 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneName(strMap6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendHourOfDay((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder5.appendFractionOfSecond(2512, 28800000);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(strMap6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-28800000), false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfMonth(100);
//        java.util.TimeZone timeZone6 = null;
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime8.minus(readablePeriod9);
//        org.joda.time.DateTime dateTime12 = dateTime8.withMillis((long) 365);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.dayOfYear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
//        int int17 = delegatedDateTimeField15.getMinimumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.halfdayOfDay();
//        org.joda.time.LocalDate localDate20 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology18);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.halfdayOfDay();
//        org.joda.time.LocalDate localDate23 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology21);
//        org.joda.time.LocalDate localDate24 = localDate20.withFields((org.joda.time.ReadablePartial) localDate23);
//        org.joda.time.LocalDate.Property property25 = localDate24.dayOfWeek();
//        org.joda.time.LocalDate localDate26 = property25.roundHalfEvenCopy();
//        org.joda.time.LocalDate localDate27 = property25.roundHalfCeilingCopy();
//        int int28 = localDate27.getYearOfCentury();
//        int int29 = delegatedDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) localDate27);
//        int int30 = dateTime8.get((org.joda.time.DateTimeField) delegatedDateTimeField15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.halfdayOfDay();
//        org.joda.time.LocalDate localDate33 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology31);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology34.halfdayOfDay();
//        org.joda.time.LocalDate localDate36 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology34);
//        org.joda.time.LocalDate localDate37 = localDate33.withFields((org.joda.time.ReadablePartial) localDate36);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology38 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField39 = buddhistChronology38.halfdayOfDay();
//        org.joda.time.LocalDate localDate40 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology38);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology41.halfdayOfDay();
//        org.joda.time.LocalDate localDate43 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology41);
//        org.joda.time.LocalDate localDate44 = localDate40.withFields((org.joda.time.ReadablePartial) localDate43);
//        org.joda.time.LocalDate.Property property45 = localDate44.dayOfWeek();
//        org.joda.time.LocalDate localDate46 = property45.roundHalfEvenCopy();
//        org.joda.time.LocalDate localDate47 = property45.roundHalfCeilingCopy();
//        int int48 = localDate47.getYearOfCentury();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology49 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField50 = buddhistChronology49.dayOfYear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField51 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField50);
//        long long54 = delegatedDateTimeField51.set(0L, 62);
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = delegatedDateTimeField51.getType();
//        boolean boolean56 = localDate47.isSupported(dateTimeFieldType55);
//        org.joda.time.LocalDate.Property property57 = localDate37.property(dateTimeFieldType55);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField58 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField15, dateTimeFieldType55);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder3.appendDecimal(dateTimeFieldType55, 1, 3600000);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder63 = dateTimeFormatterBuilder61.appendSecondOfMinute(2922789);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(buddhistChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(buddhistChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(localDate26);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 62 + "'", int28 == 62);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 366 + "'", int29 == 366);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 166 + "'", int30 == 166);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(buddhistChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertNotNull(buddhistChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(buddhistChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertNotNull(localDate47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 62 + "'", int48 == 62);
//        org.junit.Assert.assertNotNull(buddhistChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-26179200000L) + "'", long54 == (-26179200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder63);
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
//        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.Chronology chronology3 = localDate2.getChronology();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
//        boolean boolean10 = dateTime5.isBefore((long) (short) 0);
//        org.joda.time.DateTime dateTime12 = dateTime5.minusMonths((int) (byte) -1);
//        org.joda.time.DateTime dateTime14 = dateTime5.plusSeconds(44);
//        int int15 = dateTime14.getHourOfDay();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.halfdayOfDay();
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.Chronology chronology5 = localDate4.getChronology();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.DateTime dateTime7 = localDate4.toDateTime(readableInstant6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.halfdayOfDay();
        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.Chronology chronology11 = localDate10.getChronology();
        int int12 = localDate4.compareTo((org.joda.time.ReadablePartial) localDate10);
        java.util.Date date13 = localDate10.toDate();
        boolean boolean14 = jodaTimePermission1.equals((java.lang.Object) localDate10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.halfdayOfDay();
        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology15);
        org.joda.time.Chronology chronology18 = localDate17.getChronology();
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.DateTime dateTime20 = localDate17.toDateTime(readableInstant19);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.toDateTime(dateTimeZone22);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime20);
        org.joda.time.DateTime.Property property25 = dateTime20.era();
        int int26 = property25.get();
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField[] dateTimeFieldArray2 = localDate1.getFields();
        int int3 = localDate1.getWeekyear();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeFieldArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2562 + "'", int3 == 2562);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) gJChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(localDate1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.halfdayOfDay();
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.LocalDate localDate6 = localDate2.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate.Property property7 = localDate6.dayOfWeek();
        org.joda.time.LocalDate localDate8 = property7.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate9 = property7.roundHalfCeilingCopy();
        int int10 = localDate9.getYearOfCentury();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        long long16 = delegatedDateTimeField13.set(0L, 62);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = delegatedDateTimeField13.getType();
        boolean boolean18 = localDate9.isSupported(dateTimeFieldType17);
        org.joda.time.LocalDate.Property property19 = localDate9.dayOfWeek();
        int int20 = property19.getMinimumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = property19.getFieldType();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 62 + "'", int10 == 62);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-26179200000L) + "'", long16 == (-26179200000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
        boolean boolean10 = dateTime5.isBefore((long) (short) 0);
        org.joda.time.DateTime dateTime12 = dateTime5.withEra(0);
        int int13 = dateTime5.getYearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.withYearOfCentury(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withDefaultYear((-1));
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone20);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter16.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone22);
        org.joda.time.DateTime dateTime25 = dateTime15.withChronology((org.joda.time.Chronology) iSOChronology24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        long long29 = iSOChronology24.add(readablePeriod26, 14L, 2512);
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology24.hourOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2562 + "'", int13 == 2562);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 14L + "'", long29 == 14L);
        org.junit.Assert.assertNotNull(dateTimeField30);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        int int6 = delegatedDateTimeField4.getMinimumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.halfdayOfDay();
//        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology7);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.halfdayOfDay();
//        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology10);
//        org.joda.time.LocalDate localDate13 = localDate9.withFields((org.joda.time.ReadablePartial) localDate12);
//        org.joda.time.LocalDate.Property property14 = localDate13.dayOfWeek();
//        org.joda.time.LocalDate localDate15 = property14.roundHalfEvenCopy();
//        org.joda.time.LocalDate localDate16 = property14.roundHalfCeilingCopy();
//        int int17 = localDate16.getYearOfCentury();
//        int int18 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate16);
//        org.joda.time.DurationField durationField19 = delegatedDateTimeField4.getRangeDurationField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4);
//        int int21 = skipDateTimeField20.getMinimumValue();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology22.halfdayOfDay();
//        org.joda.time.LocalDate localDate24 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology22);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology25.halfdayOfDay();
//        org.joda.time.LocalDate localDate27 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology25);
//        org.joda.time.LocalDate localDate28 = localDate24.withFields((org.joda.time.ReadablePartial) localDate27);
//        org.joda.time.LocalDate.Property property29 = localDate28.dayOfWeek();
//        org.joda.time.Interval interval30 = property29.toInterval();
//        org.joda.time.LocalDate localDate31 = property29.withMaximumValue();
//        java.lang.String str33 = localDate31.toString("2562-06-15");
//        java.lang.String str34 = localDate31.toString();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.dayOfYear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField37);
//        int int40 = delegatedDateTimeField38.getMinimumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology41.halfdayOfDay();
//        org.joda.time.LocalDate localDate43 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology41);
//        org.joda.time.Chronology chronology44 = localDate43.getChronology();
//        org.joda.time.ReadableInstant readableInstant45 = null;
//        org.joda.time.DateTime dateTime46 = localDate43.toDateTime(readableInstant45);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField48 = buddhistChronology47.halfdayOfDay();
//        org.joda.time.LocalDate localDate49 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology47);
//        org.joda.time.Chronology chronology50 = localDate49.getChronology();
//        int int51 = localDate43.compareTo((org.joda.time.ReadablePartial) localDate49);
//        java.util.Locale locale52 = null;
//        java.lang.String str53 = delegatedDateTimeField38.getAsShortText((org.joda.time.ReadablePartial) localDate43, locale52);
//        org.joda.time.ReadablePartial readablePartial54 = null;
//        int[] intArray60 = new int[] { 62, 36600, (byte) 10, 3, (short) 100 };
//        int int61 = delegatedDateTimeField38.getMinimumValue(readablePartial54, intArray60);
//        int[] intArray63 = skipDateTimeField20.addWrapPartial((org.joda.time.ReadablePartial) localDate31, 0, intArray60, 2562);
//        java.util.TimeZone timeZone64 = null;
//        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeZone.forTimeZone(timeZone64);
//        java.lang.String str66 = dateTimeZone65.toString();
//        org.joda.time.Interval interval67 = localDate31.toInterval(dateTimeZone65);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 62 + "'", int17 == 62);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 366 + "'", int18 == 366);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//        org.junit.Assert.assertNotNull(buddhistChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(buddhistChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(interval30);
//        org.junit.Assert.assertNotNull(localDate31);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "2562-06-15" + "'", str33.equals("2562-06-15"));
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2562-06-16" + "'", str34.equals("2562-06-16"));
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertNotNull(buddhistChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(chronology44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(buddhistChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "166" + "'", str53.equals("166"));
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
//        org.junit.Assert.assertNotNull(intArray63);
//        org.junit.Assert.assertNotNull(dateTimeZone65);
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "America/Los_Angeles" + "'", str66.equals("America/Los_Angeles"));
//        org.junit.Assert.assertNotNull(interval67);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear((-1));
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        java.lang.String str9 = cachedDateTimeZone7.toString();
        long long12 = cachedDateTimeZone7.adjustOffset(0L, true);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        try {
            long long18 = zonedChronology13.getDateTimeMillis(10, (int) 'a', 28800000, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology13);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
//        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.minuteOfHour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusWeeks(2);
//        org.joda.time.DateTime.Property property12 = dateTime9.monthOfYear();
//        org.joda.time.format.DateTimePrinter dateTimePrinter13 = null;
//        org.joda.time.format.DateTimeParser dateTimeParser14 = null;
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter13, dateTimeParser14);
//        boolean boolean16 = dateTimeFormatter15.isOffsetParsed();
//        java.lang.Integer int17 = dateTimeFormatter15.getPivotYear();
//        try {
//            java.lang.String str18 = dateTime9.toString(dateTimeFormatter15);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2562-06-15" + "'", str4.equals("2562-06-15"));
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNull(int17);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear((-1));
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
//        java.lang.String str9 = cachedDateTimeZone7.toString();
//        long long12 = cachedDateTimeZone7.adjustOffset(0L, true);
//        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
//        org.joda.time.Chronology chronology14 = zonedChronology13.withUTC();
//        org.joda.time.DateTimeField dateTimeField15 = zonedChronology13.year();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
//        long long20 = offsetDateTimeField17.add(0L, 2527);
//        int int22 = offsetDateTimeField17.get(1209600016L);
//        long long24 = offsetDateTimeField17.roundFloor((long) 15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology25.halfdayOfDay();
//        org.joda.time.LocalDate localDate27 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology25);
//        org.joda.time.Chronology chronology28 = localDate27.getChronology();
//        org.joda.time.ReadableInstant readableInstant29 = null;
//        org.joda.time.DateTime dateTime30 = localDate27.toDateTime(readableInstant29);
//        org.joda.time.LocalDate localDate32 = localDate27.plusWeeks((int) (short) 0);
//        java.util.TimeZone timeZone33 = null;
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forTimeZone(timeZone33);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone34);
//        org.joda.time.DateMidnight dateMidnight36 = localDate27.toDateMidnight(dateTimeZone34);
//        int int37 = localDate27.getMonthOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology38 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField39 = buddhistChronology38.dayOfYear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField39);
//        int int42 = delegatedDateTimeField40.getMinimumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology43.halfdayOfDay();
//        org.joda.time.LocalDate localDate45 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology43);
//        org.joda.time.Chronology chronology46 = localDate45.getChronology();
//        org.joda.time.ReadableInstant readableInstant47 = null;
//        org.joda.time.DateTime dateTime48 = localDate45.toDateTime(readableInstant47);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology49 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField50 = buddhistChronology49.halfdayOfDay();
//        org.joda.time.LocalDate localDate51 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology49);
//        org.joda.time.Chronology chronology52 = localDate51.getChronology();
//        int int53 = localDate45.compareTo((org.joda.time.ReadablePartial) localDate51);
//        java.util.Locale locale54 = null;
//        java.lang.String str55 = delegatedDateTimeField40.getAsShortText((org.joda.time.ReadablePartial) localDate45, locale54);
//        boolean boolean56 = localDate27.equals((java.lang.Object) localDate45);
//        java.util.Locale locale57 = null;
//        java.lang.String str58 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) localDate27, locale57);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(zonedChronology13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 79744521600000L + "'", long20 == 79744521600000L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1971 + "'", int22 == 1971);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-31507200000L) + "'", long24 == (-31507200000L));
//        org.junit.Assert.assertNotNull(buddhistChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateMidnight36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertNotNull(buddhistChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(buddhistChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(buddhistChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(localDate51);
//        org.junit.Assert.assertNotNull(chronology52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "166" + "'", str55.equals("166"));
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "2562" + "'", str58.equals("2562"));
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.halfdayOfDay();
        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.LocalDate localDate6 = localDate2.withFields((org.joda.time.ReadablePartial) localDate5);
        org.joda.time.LocalDate.Property property7 = localDate6.dayOfWeek();
        org.joda.time.LocalDate localDate8 = property7.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate9 = property7.roundFloorCopy();
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.halfdayOfDay();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology10);
        org.joda.time.Chronology chronology13 = localDate12.getChronology();
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.DateTime dateTime15 = localDate12.toDateTime(readableInstant14);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.toDateTime(dateTimeZone17);
        long long19 = property7.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.halfdayOfDay();
        org.joda.time.LocalDate localDate22 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology20);
        org.joda.time.Chronology chronology23 = localDate22.getChronology();
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.DateTime dateTime25 = localDate22.toDateTime(readableInstant24);
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology26.halfdayOfDay();
        org.joda.time.LocalDate localDate28 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology26);
        org.joda.time.Chronology chronology29 = localDate28.getChronology();
        int int30 = localDate22.compareTo((org.joda.time.ReadablePartial) localDate28);
        java.util.Date date31 = localDate28.toDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = null;
        int int33 = localDate28.indexOf(dateTimeFieldType32);
        org.joda.time.LocalDate localDate35 = localDate28.withYear((int) '4');
        org.joda.time.DateTimeField[] dateTimeFieldArray36 = localDate35.getFields();
        java.util.TimeZone timeZone37 = null;
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.forTimeZone(timeZone37);
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone38);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone40 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone38);
        org.joda.time.DateMidnight dateMidnight41 = localDate35.toDateMidnight((org.joda.time.DateTimeZone) cachedDateTimeZone40);
        org.joda.time.LocalDate localDate43 = localDate35.minusMonths((int) (short) 100);
        org.joda.time.DateTime dateTime44 = localDate35.toDateTimeAtMidnight();
        org.joda.time.DateTime dateTime45 = dateTime15.withFields((org.joda.time.ReadablePartial) localDate35);
        try {
            org.joda.time.LocalDate localDate47 = localDate35.minusWeeks(36600);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (BuddhistChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-198327L) + "'", long19 == (-198327L));
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(dateTimeFieldArray36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(cachedDateTimeZone40);
        org.junit.Assert.assertNotNull(dateMidnight41);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime45);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.halfdayOfDay();
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.Chronology chronology5 = localDate4.getChronology();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.DateTime dateTime7 = localDate4.toDateTime(readableInstant6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.halfdayOfDay();
        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.Chronology chronology11 = localDate10.getChronology();
        int int12 = localDate4.compareTo((org.joda.time.ReadablePartial) localDate10);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
//        int int6 = delegatedDateTimeField4.getMinimumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.halfdayOfDay();
//        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology7);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.halfdayOfDay();
//        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology10);
//        org.joda.time.LocalDate localDate13 = localDate9.withFields((org.joda.time.ReadablePartial) localDate12);
//        org.joda.time.LocalDate.Property property14 = localDate13.dayOfWeek();
//        org.joda.time.LocalDate localDate15 = property14.roundHalfEvenCopy();
//        org.joda.time.LocalDate localDate16 = property14.roundHalfCeilingCopy();
//        int int17 = localDate16.getYearOfCentury();
//        int int18 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate16);
//        org.joda.time.DurationField durationField19 = delegatedDateTimeField4.getRangeDurationField();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4);
//        org.joda.time.ReadablePartial readablePartial21 = null;
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField24 = gJChronology23.days();
//        org.joda.time.DateTimeZone dateTimeZone25 = gJChronology23.getZone();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology26.dayOfYear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27);
//        int int30 = delegatedDateTimeField28.getMinimumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.halfdayOfDay();
//        org.joda.time.LocalDate localDate34 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology32);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str36 = localDate34.toString(dateTimeFormatter35);
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37);
//        org.joda.time.DateTimeField dateTimeField39 = gJChronology38.minuteOfHour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter35.withChronology((org.joda.time.Chronology) gJChronology38);
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology38);
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((java.lang.Object) (-198328L), (org.joda.time.Chronology) gJChronology38);
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = delegatedDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate42, locale43);
//        int[] intArray46 = gJChronology23.get((org.joda.time.ReadablePartial) localDate42, (long) (short) 1);
//        try {
//            int[] intArray48 = delegatedDateTimeField4.set(readablePartial21, (int) (byte) 100, intArray46, 3);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(buddhistChronology7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(buddhistChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 62 + "'", int17 == 62);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 366 + "'", int18 == 366);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(buddhistChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
//        org.junit.Assert.assertNotNull(buddhistChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(dateTimeFormatter35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2562-06-15" + "'", str36.equals("2562-06-15"));
//        org.junit.Assert.assertNotNull(gJChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "365" + "'", str44.equals("365"));
//        org.junit.Assert.assertNotNull(intArray46);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("2513-01-04", true);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(62);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder5.setStandardOffset(4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
//        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.Chronology chronology3 = localDate2.getChronology();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
//        boolean boolean10 = dateTime5.isBefore((long) (short) 0);
//        org.joda.time.DateTime dateTime12 = dateTime5.withEra(0);
//        java.lang.String str13 = dateTime12.toString();
//        org.joda.time.DateTime.Property property14 = dateTime12.weekOfWeekyear();
//        org.joda.time.DateTime.Property property15 = dateTime12.secondOfDay();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-2562-06-15T16:15:36.478-07:52:58" + "'", str13.equals("-2562-06-15T16:15:36.478-07:52:58"));
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.halfdayOfDay();
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.Chronology chronology9 = localDate8.getChronology();
        int int10 = localDate2.compareTo((org.joda.time.ReadablePartial) localDate8);
        java.util.Date date11 = localDate8.toDate();
        org.joda.time.LocalDate.Property property12 = localDate8.monthOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.halfdayOfDay();
        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology13);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology16.halfdayOfDay();
        org.joda.time.LocalDate localDate18 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology16);
        org.joda.time.LocalDate localDate19 = localDate15.withFields((org.joda.time.ReadablePartial) localDate18);
        org.joda.time.LocalDate.Property property20 = localDate19.dayOfWeek();
        org.joda.time.LocalDate localDate21 = property20.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate22 = property20.roundHalfCeilingCopy();
        int int23 = localDate22.getYearOfCentury();
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology24.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField26 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField25);
        long long29 = delegatedDateTimeField26.set(0L, 62);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = delegatedDateTimeField26.getType();
        boolean boolean31 = localDate22.isSupported(dateTimeFieldType30);
        int int32 = localDate8.indexOf(dateTimeFieldType30);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType30, (int) (short) 0, 366, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [366,2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 62 + "'", int23 == 62);
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-26179200000L) + "'", long29 == (-26179200000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withDefaultYear((-1));
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        java.lang.String str10 = cachedDateTimeZone8.toString();
        long long13 = cachedDateTimeZone8.adjustOffset(0L, true);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) cachedDateTimeZone8);
        org.joda.time.Chronology chronology15 = zonedChronology14.withUTC();
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.JodaTimePermission jodaTimePermission18 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.halfdayOfDay();
        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology19);
        org.joda.time.Chronology chronology22 = localDate21.getChronology();
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.DateTime dateTime24 = localDate21.toDateTime(readableInstant23);
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology25.halfdayOfDay();
        org.joda.time.LocalDate localDate27 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology25);
        org.joda.time.Chronology chronology28 = localDate27.getChronology();
        int int29 = localDate21.compareTo((org.joda.time.ReadablePartial) localDate27);
        java.util.Date date30 = localDate27.toDate();
        boolean boolean31 = jodaTimePermission18.equals((java.lang.Object) localDate27);
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        int int36 = delegatedDateTimeField34.getMinimumValue(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = buddhistChronology37.halfdayOfDay();
        org.joda.time.LocalDate localDate39 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology37);
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.halfdayOfDay();
        org.joda.time.LocalDate localDate42 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology40);
        org.joda.time.LocalDate localDate43 = localDate39.withFields((org.joda.time.ReadablePartial) localDate42);
        org.joda.time.LocalDate.Property property44 = localDate43.dayOfWeek();
        org.joda.time.LocalDate localDate45 = property44.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate46 = property44.roundHalfCeilingCopy();
        int int47 = localDate46.getYearOfCentury();
        int int48 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDate46);
        int int49 = localDate27.compareTo((org.joda.time.ReadablePartial) localDate46);
        org.joda.time.LocalDate localDate51 = localDate46.plusMonths((int) ' ');
        java.util.TimeZone timeZone52 = null;
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forTimeZone(timeZone52);
        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now(dateTimeZone53);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone55 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone53);
        org.joda.time.Interval interval56 = localDate51.toInterval((org.joda.time.DateTimeZone) cachedDateTimeZone55);
        org.joda.time.Chronology chronology57 = copticChronology16.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone55);
        org.joda.time.Chronology chronology58 = zonedChronology14.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone55);
        org.joda.time.Chronology chronology59 = julianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone55);
        java.lang.String str60 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 62 + "'", int47 == 62);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 366 + "'", int48 == 366);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(cachedDateTimeZone55);
        org.junit.Assert.assertNotNull(interval56);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "JulianChronology[UTC]" + "'", str60.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear((-1));
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        java.lang.String str9 = cachedDateTimeZone7.toString();
        long long12 = cachedDateTimeZone7.adjustOffset(0L, true);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.Chronology chronology14 = zonedChronology13.withUTC();
        org.joda.time.DateTimeField dateTimeField15 = zonedChronology13.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        java.lang.String str18 = offsetDateTimeField17.getName();
        long long21 = offsetDateTimeField17.getDifferenceAsLong((long) 2512, 2000L);
        long long23 = offsetDateTimeField17.roundCeiling((long) 58454092);
        int int25 = offsetDateTimeField17.getMinimumValue((long) 9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "year" + "'", str18.equals("year"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 31564800000L + "'", long23 == 31564800000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275053) + "'", int25 == (-292275053));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.LocalDate.Property property2 = localDate1.year();
        org.joda.time.LocalDate localDate4 = property2.addToCopy(91);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withDefaultYear((-1));
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        java.lang.String str14 = cachedDateTimeZone12.toString();
        long long17 = cachedDateTimeZone12.adjustOffset(0L, true);
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology5, (org.joda.time.DateTimeZone) cachedDateTimeZone12);
        try {
            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(2515, 100, 7, 1, 0, (org.joda.time.DateTimeZone) cachedDateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "America/Los_Angeles" + "'", str14.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology18);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.halfdayOfDay();
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.halfdayOfDay();
        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.LocalDate localDate8 = localDate4.withFields((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.LocalDate.Property property9 = localDate8.dayOfWeek();
        java.util.TimeZone timeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.DateMidnight dateMidnight13 = localDate8.toDateMidnight(dateTimeZone11);
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        long long19 = dateTimeZone11.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone17, (long) 2000);
        boolean boolean21 = cachedDateTimeZone17.equals((java.lang.Object) (-28800000));
        org.joda.time.Chronology chronology22 = buddhistChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology23);
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology25.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26);
        int int29 = delegatedDateTimeField27.getMinimumValue(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology30.halfdayOfDay();
        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology30);
        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology33.halfdayOfDay();
        org.joda.time.LocalDate localDate35 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology33);
        org.joda.time.LocalDate localDate36 = localDate32.withFields((org.joda.time.ReadablePartial) localDate35);
        org.joda.time.LocalDate.Property property37 = localDate36.dayOfWeek();
        org.joda.time.LocalDate localDate38 = property37.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate39 = property37.roundHalfCeilingCopy();
        int int40 = localDate39.getYearOfCentury();
        int int41 = delegatedDateTimeField27.getMaximumValue((org.joda.time.ReadablePartial) localDate39);
        org.joda.time.DurationField durationField42 = delegatedDateTimeField27.getRangeDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology23, (org.joda.time.DateTimeField) delegatedDateTimeField27);
        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology23.hourOfHalfday();
        boolean boolean45 = cachedDateTimeZone17.equals((java.lang.Object) buddhistChronology23);
        java.lang.String str47 = cachedDateTimeZone17.getNameKey((long) 166);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2000L + "'", long19 == 2000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(buddhistChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 62 + "'", int40 == 62);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 366 + "'", int41 == 366);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "PST" + "'", str47.equals("PST"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField2 = gJChronology1.hours();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.minuteOfHour();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gJChronology1);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withDefaultYear((-1));
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        java.lang.String str10 = cachedDateTimeZone8.toString();
        long long13 = cachedDateTimeZone8.adjustOffset(0L, true);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) cachedDateTimeZone8);
        org.joda.time.Chronology chronology15 = zonedChronology14.withUTC();
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.JodaTimePermission jodaTimePermission18 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.halfdayOfDay();
        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology19);
        org.joda.time.Chronology chronology22 = localDate21.getChronology();
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.DateTime dateTime24 = localDate21.toDateTime(readableInstant23);
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology25.halfdayOfDay();
        org.joda.time.LocalDate localDate27 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology25);
        org.joda.time.Chronology chronology28 = localDate27.getChronology();
        int int29 = localDate21.compareTo((org.joda.time.ReadablePartial) localDate27);
        java.util.Date date30 = localDate27.toDate();
        boolean boolean31 = jodaTimePermission18.equals((java.lang.Object) localDate27);
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        int int36 = delegatedDateTimeField34.getMinimumValue(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = buddhistChronology37.halfdayOfDay();
        org.joda.time.LocalDate localDate39 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology37);
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.halfdayOfDay();
        org.joda.time.LocalDate localDate42 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology40);
        org.joda.time.LocalDate localDate43 = localDate39.withFields((org.joda.time.ReadablePartial) localDate42);
        org.joda.time.LocalDate.Property property44 = localDate43.dayOfWeek();
        org.joda.time.LocalDate localDate45 = property44.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate46 = property44.roundHalfCeilingCopy();
        int int47 = localDate46.getYearOfCentury();
        int int48 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDate46);
        int int49 = localDate27.compareTo((org.joda.time.ReadablePartial) localDate46);
        org.joda.time.LocalDate localDate51 = localDate46.plusMonths((int) ' ');
        java.util.TimeZone timeZone52 = null;
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forTimeZone(timeZone52);
        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now(dateTimeZone53);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone55 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone53);
        org.joda.time.Interval interval56 = localDate51.toInterval((org.joda.time.DateTimeZone) cachedDateTimeZone55);
        org.joda.time.Chronology chronology57 = copticChronology16.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone55);
        org.joda.time.Chronology chronology58 = zonedChronology14.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone55);
        org.joda.time.Chronology chronology59 = julianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone55);
        org.joda.time.DurationField durationField60 = julianChronology0.weekyears();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 62 + "'", int47 == 62);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 366 + "'", int48 == 366);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(cachedDateTimeZone55);
        org.junit.Assert.assertNotNull(interval56);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(durationField60);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
        org.joda.time.DateTime dateTime11 = dateTime8.withYear((int) (short) 0);
        org.joda.time.DateTime dateTime13 = dateTime8.withYearOfCentury(15);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
        org.joda.time.DateTime dateTime10 = dateTime5.minusHours((int) '#');
        org.joda.time.DateTime dateTime11 = dateTime10.toDateTimeISO();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("97", (java.lang.Number) 2440587.500000116d, (java.lang.Number) 17135452800000L, (java.lang.Number) (byte) 0);
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException4.getDurationFieldType();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 0 + "'", number6.equals((byte) 0));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.halfdayOfDay();
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.Chronology chronology5 = localDate4.getChronology();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.DateTime dateTime7 = localDate4.toDateTime(readableInstant6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.halfdayOfDay();
        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.Chronology chronology11 = localDate10.getChronology();
        int int12 = localDate4.compareTo((org.joda.time.ReadablePartial) localDate10);
        java.util.Date date13 = localDate10.toDate();
        boolean boolean14 = jodaTimePermission1.equals((java.lang.Object) localDate10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
        int int19 = delegatedDateTimeField17.getMinimumValue(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.halfdayOfDay();
        org.joda.time.LocalDate localDate22 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology20);
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.halfdayOfDay();
        org.joda.time.LocalDate localDate25 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology23);
        org.joda.time.LocalDate localDate26 = localDate22.withFields((org.joda.time.ReadablePartial) localDate25);
        org.joda.time.LocalDate.Property property27 = localDate26.dayOfWeek();
        org.joda.time.LocalDate localDate28 = property27.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate29 = property27.roundHalfCeilingCopy();
        int int30 = localDate29.getYearOfCentury();
        int int31 = delegatedDateTimeField17.getMaximumValue((org.joda.time.ReadablePartial) localDate29);
        int int32 = localDate10.compareTo((org.joda.time.ReadablePartial) localDate29);
        org.joda.time.LocalDate localDate34 = localDate29.plusMonths((int) ' ');
        java.util.TimeZone timeZone35 = null;
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forTimeZone(timeZone35);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now(dateTimeZone36);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone38 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone36);
        org.joda.time.Interval interval39 = localDate34.toInterval((org.joda.time.DateTimeZone) cachedDateTimeZone38);
        try {
            org.joda.time.LocalDate localDate41 = localDate34.withEra((-97));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -97 for era must be in the range [1,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 62 + "'", int30 == 62);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 366 + "'", int31 == 366);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(cachedDateTimeZone38);
        org.junit.Assert.assertNotNull(interval39);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-28800000), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfMonth(100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatterBuilder5.toFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendFractionOfDay(100, 2000);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder5.appendTimeZoneName(strMap10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        try {
            long long8 = julianChronology0.getDateTimeMillis((int) (byte) 0, (int) (short) 100, 2527, 19, 0, 12, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
        org.joda.time.DateTime dateTime10 = dateTime8.minusDays((int) '4');
        org.joda.time.DateTime dateTime12 = dateTime10.plusYears((int) (short) -1);
        org.joda.time.DateTime dateTime14 = dateTime10.minusWeeks(2562);
        org.joda.time.DateTime.Property property15 = dateTime10.yearOfEra();
        org.joda.time.DateTime dateTime16 = property15.roundHalfEvenCopy();
        int int17 = property15.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 292278993 + "'", int17 == 292278993);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.joda.time.Partial partial0 = new org.joda.time.Partial();
//        int[] intArray1 = partial0.getValues();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.halfdayOfDay();
//        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology3);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str7 = localDate5.toString(dateTimeFormatter6);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeField dateTimeField10 = gJChronology9.minuteOfHour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter6.withChronology((org.joda.time.Chronology) gJChronology9);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology9);
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((java.lang.Object) (-198328L), (org.joda.time.Chronology) gJChronology9);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.dayOfYear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
//        int int18 = delegatedDateTimeField16.getMinimumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.halfdayOfDay();
//        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology19);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology22.halfdayOfDay();
//        org.joda.time.LocalDate localDate24 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology22);
//        org.joda.time.LocalDate localDate25 = localDate21.withFields((org.joda.time.ReadablePartial) localDate24);
//        org.joda.time.LocalDate.Property property26 = localDate25.dayOfWeek();
//        org.joda.time.LocalDate localDate27 = property26.roundHalfEvenCopy();
//        org.joda.time.LocalDate localDate28 = property26.roundHalfCeilingCopy();
//        int int29 = localDate28.getYearOfCentury();
//        int int30 = delegatedDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
//        org.joda.time.DurationField durationField31 = delegatedDateTimeField16.getRangeDurationField();
//        java.lang.String str32 = delegatedDateTimeField16.toString();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology33.halfdayOfDay();
//        org.joda.time.LocalDate localDate35 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology33);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.halfdayOfDay();
//        org.joda.time.LocalDate localDate38 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology36);
//        org.joda.time.LocalDate localDate39 = localDate35.withFields((org.joda.time.ReadablePartial) localDate38);
//        org.joda.time.LocalDate.Property property40 = localDate39.dayOfWeek();
//        org.joda.time.LocalDate localDate41 = property40.roundHalfEvenCopy();
//        org.joda.time.LocalDate localDate42 = property40.roundHalfCeilingCopy();
//        int int43 = localDate42.getYearOfCentury();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology44 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField45 = buddhistChronology44.dayOfYear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField45);
//        long long49 = delegatedDateTimeField46.set(0L, 62);
//        org.joda.time.DateTimeFieldType dateTimeFieldType50 = delegatedDateTimeField46.getType();
//        boolean boolean51 = localDate42.isSupported(dateTimeFieldType50);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField52 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, dateTimeFieldType50);
//        boolean boolean53 = localDate13.isSupported(dateTimeFieldType50);
//        try {
//            org.joda.time.Partial partial55 = partial0.withField(dateTimeFieldType50, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfYear' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray1);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2562-06-15" + "'", str7.equals("2562-06-15"));
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(buddhistChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(buddhistChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(localDate24);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 62 + "'", int29 == 62);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 366 + "'", int30 == 366);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "DateTimeField[dayOfYear]" + "'", str32.equals("DateTimeField[dayOfYear]"));
//        org.junit.Assert.assertNotNull(buddhistChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertNotNull(buddhistChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(localDate41);
//        org.junit.Assert.assertNotNull(localDate42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 62 + "'", int43 == 62);
//        org.junit.Assert.assertNotNull(buddhistChronology44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-26179200000L) + "'", long49 == (-26179200000L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(58458305);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfMinute(58454092, (int) (short) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendTwoDigitWeekyear((int) (byte) 10, false);
        boolean boolean9 = dateTimeFormatterBuilder8.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DurationField durationField1 = gJChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.minuteOfHour();
        java.lang.Class<?> wildcardClass3 = gJChronology0.getClass();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear((-1));
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        java.lang.String str9 = cachedDateTimeZone7.toString();
        long long12 = cachedDateTimeZone7.adjustOffset(0L, true);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.Chronology chronology14 = zonedChronology13.withUTC();
        org.joda.time.DateTimeField dateTimeField15 = zonedChronology13.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        long long19 = offsetDateTimeField17.roundCeiling((long) 2513);
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField17.getAsText(4, locale21);
        long long24 = offsetDateTimeField17.remainder(57600001L);
        int int25 = offsetDateTimeField17.getMinimumValue();
        long long27 = offsetDateTimeField17.roundHalfFloor((long) 9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800000L + "'", long19 == 28800000L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "4" + "'", str22.equals("4"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28800001L + "'", long24 == 28800001L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-292275053) + "'", int25 == (-292275053));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28800000L + "'", long27 == 28800000L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear((-1));
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        java.lang.String str9 = cachedDateTimeZone7.toString();
        long long12 = cachedDateTimeZone7.adjustOffset(0L, true);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.Chronology chronology14 = zonedChronology13.withUTC();
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withDefaultYear((-1));
        java.util.TimeZone timeZone19 = null;
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forTimeZone(timeZone19);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone20);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = dateTimeFormatter16.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
        java.lang.String str24 = cachedDateTimeZone22.toString();
        long long27 = cachedDateTimeZone22.adjustOffset(0L, true);
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology15, (org.joda.time.DateTimeZone) cachedDateTimeZone22);
        org.joda.time.Chronology chronology29 = zonedChronology13.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
        org.joda.time.DateTimeField dateTimeField30 = zonedChronology13.weekyearOfCentury();
        long long36 = zonedChronology13.getDateTimeMillis(100L, (int) (short) 1, 0, 10, (int) 'a');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "America/Los_Angeles" + "'", str24.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-53989903L) + "'", long36 == (-53989903L));
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
//        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.halfdayOfDay();
//        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology3);
//        org.joda.time.LocalDate localDate6 = localDate2.withFields((org.joda.time.ReadablePartial) localDate5);
//        org.joda.time.LocalDate.Property property7 = localDate6.dayOfWeek();
//        org.joda.time.Interval interval8 = property7.toInterval();
//        org.joda.time.LocalDate localDate9 = property7.withMaximumValue();
//        java.lang.String str11 = localDate9.toString("2562-06-15");
//        java.lang.String str12 = localDate9.toString();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.halfdayOfDay();
//        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology13);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology16.halfdayOfDay();
//        org.joda.time.LocalDate localDate18 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology16);
//        org.joda.time.LocalDate localDate19 = localDate15.withFields((org.joda.time.ReadablePartial) localDate18);
//        org.joda.time.LocalDate.Property property20 = localDate19.dayOfWeek();
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone22);
//        org.joda.time.DateMidnight dateMidnight24 = localDate19.toDateMidnight(dateTimeZone22);
//        java.util.TimeZone timeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forTimeZone(timeZone25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(dateTimeZone26);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone28 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone26);
//        long long30 = dateTimeZone22.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone28, (long) 2000);
//        long long34 = dateTimeZone22.convertLocalToUTC((long) (byte) 10, true, (-1L));
//        org.joda.time.Interval interval35 = localDate9.toInterval(dateTimeZone22);
//        int int36 = localDate9.getCenturyOfEra();
//        try {
//            org.joda.time.LocalDate localDate38 = localDate9.withEra(58454092);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58454092 for era must be in the range [1,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(interval8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2562-06-15" + "'", str11.equals("2562-06-15"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2562-06-16" + "'", str12.equals("2562-06-16"));
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateMidnight24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2000L + "'", long30 == 2000L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 28800010L + "'", long34 == 28800010L);
//        org.junit.Assert.assertNotNull(interval35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 26 + "'", int36 == 26);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
//        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.Chronology chronology3 = localDate2.getChronology();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
//        org.joda.time.DateTime dateTime10 = dateTime8.minusDays((int) '4');
//        org.joda.time.DateTime dateTime12 = dateTime10.plusYears((int) (short) -1);
//        org.joda.time.JodaTimePermission jodaTimePermission14 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.halfdayOfDay();
//        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology15);
//        org.joda.time.Chronology chronology18 = localDate17.getChronology();
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        org.joda.time.DateTime dateTime20 = localDate17.toDateTime(readableInstant19);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.halfdayOfDay();
//        org.joda.time.LocalDate localDate23 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology21);
//        org.joda.time.Chronology chronology24 = localDate23.getChronology();
//        int int25 = localDate17.compareTo((org.joda.time.ReadablePartial) localDate23);
//        java.util.Date date26 = localDate23.toDate();
//        boolean boolean27 = jodaTimePermission14.equals((java.lang.Object) localDate23);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField29 = buddhistChronology28.halfdayOfDay();
//        org.joda.time.LocalDate localDate30 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology28);
//        org.joda.time.Chronology chronology31 = localDate30.getChronology();
//        org.joda.time.ReadableInstant readableInstant32 = null;
//        org.joda.time.DateTime dateTime33 = localDate30.toDateTime(readableInstant32);
//        org.joda.time.Chronology chronology34 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime33.toDateTime(dateTimeZone35);
//        jodaTimePermission14.checkGuard((java.lang.Object) dateTime33);
//        org.joda.time.DateTime.Property property38 = dateTime33.era();
//        long long39 = property38.remainder();
//        org.joda.time.DateTime dateTime40 = property38.withMinimumValue();
//        org.joda.time.Chronology chronology41 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime12, (org.joda.time.ReadableInstant) dateTime40);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(buddhistChronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 80831664939698L + "'", long39 == 80831664939698L);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(chronology41);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.LocalDate.Property property2 = localDate1.year();
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.minus(readablePeriod6);
        org.joda.time.DateTime dateTime9 = dateTime5.withMillis((long) 365);
        long long10 = property2.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime9);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 49L + "'", long10 == 49L);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear((-1));
//        java.util.TimeZone timeZone4 = null;
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
//        java.lang.String str9 = cachedDateTimeZone7.toString();
//        long long12 = cachedDateTimeZone7.adjustOffset(0L, true);
//        org.joda.time.Chronology chronology13 = buddhistChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.dayOfYear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
//        int int18 = delegatedDateTimeField16.getMinimumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.halfdayOfDay();
//        org.joda.time.LocalDate localDate22 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology20);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str24 = localDate22.toString(dateTimeFormatter23);
//        org.joda.time.DateTimeZone dateTimeZone25 = null;
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.minuteOfHour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter23.withChronology((org.joda.time.Chronology) gJChronology26);
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology26);
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((java.lang.Object) (-198328L), (org.joda.time.Chronology) gJChronology26);
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = delegatedDateTimeField16.getAsShortText((org.joda.time.ReadablePartial) localDate30, locale31);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField33 = new org.joda.time.field.SkipUndoDateTimeField(chronology13, (org.joda.time.DateTimeField) delegatedDateTimeField16);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2562-06-15" + "'", str24.equals("2562-06-15"));
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "365" + "'", str32.equals("365"));
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-28800000), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendSecondOfDay(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendYearOfEra(2512, (int) 'a');
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.halfdayOfDay();
        org.joda.time.LocalDate localDate11 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology9);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.halfdayOfDay();
        org.joda.time.LocalDate localDate14 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology12);
        org.joda.time.LocalDate localDate15 = localDate11.withFields((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.LocalDate.Property property16 = localDate15.dayOfWeek();
        org.joda.time.LocalDate localDate17 = property16.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate18 = property16.roundHalfCeilingCopy();
        int int19 = localDate18.getYearOfCentury();
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField22 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField21);
        long long25 = delegatedDateTimeField22.set(0L, 62);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = delegatedDateTimeField22.getType();
        boolean boolean27 = localDate18.isSupported(dateTimeFieldType26);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder5.appendText(dateTimeFieldType26);
        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology29.halfdayOfDay();
        org.joda.time.LocalDate localDate31 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology29);
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.halfdayOfDay();
        org.joda.time.LocalDate localDate34 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology32);
        org.joda.time.LocalDate localDate35 = localDate31.withFields((org.joda.time.ReadablePartial) localDate34);
        org.joda.time.LocalDate.Property property36 = localDate35.dayOfWeek();
        org.joda.time.LocalDate localDate37 = property36.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate38 = property36.roundHalfCeilingCopy();
        int int39 = localDate38.getYearOfCentury();
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField42 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField41);
        long long45 = delegatedDateTimeField42.set(0L, 62);
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = delegatedDateTimeField42.getType();
        boolean boolean47 = localDate38.isSupported(dateTimeFieldType46);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder28.appendFraction(dateTimeFieldType46, (int) (byte) 10, (int) (byte) 100);
        org.joda.time.IllegalFieldValueException illegalFieldValueException52 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType46, "ZonedChronology[ISOChronology[UTC], America/Los_Angeles]");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 62 + "'", int19 == 62);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-26179200000L) + "'", long25 == (-26179200000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(buddhistChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 62 + "'", int39 == 62);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-26179200000L) + "'", long45 == (-26179200000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 7, (int) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 29 + "'", int3 == 29);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("97", (java.lang.Number) 2440587.500000116d, (java.lang.Number) 17135452800000L, (java.lang.Number) (byte) 0);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("hi!", "hi!");
        boolean boolean10 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException9);
        boolean boolean11 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException9);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 2440587.500000116d + "'", number6.equals(2440587.500000116d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
//        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.date();
//        java.lang.String str4 = localDate2.toString(dateTimeFormatter3);
//        org.joda.time.DateTimeZone dateTimeZone5 = null;
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
//        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.minuteOfHour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gJChronology6);
//        org.joda.time.DateTimeField dateTimeField9 = gJChronology6.hourOfHalfday();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withDefaultYear((-1));
//        java.util.TimeZone timeZone13 = null;
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forTimeZone(timeZone13);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone14);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter10.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone16);
//        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone16);
//        org.joda.time.Chronology chronology19 = gJChronology6.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone16);
//        try {
//            long long24 = gJChronology6.getDateTimeMillis(3600000, (int) (byte) 1, 0, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2562-06-15" + "'", str4.equals("2562-06-15"));
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(iSOChronology18);
//        org.junit.Assert.assertNotNull(chronology19);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
//        int int4 = delegatedDateTimeField2.getMinimumValue(0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.halfdayOfDay();
//        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology5);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.halfdayOfDay();
//        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.LocalDate localDate11 = localDate7.withFields((org.joda.time.ReadablePartial) localDate10);
//        org.joda.time.LocalDate.Property property12 = localDate11.dayOfWeek();
//        org.joda.time.LocalDate localDate13 = property12.roundHalfEvenCopy();
//        org.joda.time.LocalDate localDate14 = property12.roundHalfCeilingCopy();
//        int int15 = localDate14.getYearOfCentury();
//        int int16 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) localDate14);
//        org.joda.time.DurationField durationField17 = null;
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField19 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, durationField17, dateTimeFieldType18);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.halfdayOfDay();
//        org.joda.time.LocalDate localDate22 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology20);
//        org.joda.time.Chronology chronology23 = localDate22.getChronology();
//        org.joda.time.ReadableInstant readableInstant24 = null;
//        org.joda.time.DateTime dateTime25 = localDate22.toDateTime(readableInstant24);
//        org.joda.time.LocalDate localDate27 = localDate22.plusWeeks((int) (short) 0);
//        int int28 = delegatedDateTimeField19.getMinimumValue((org.joda.time.ReadablePartial) localDate22);
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.halfdayOfDay();
//        org.joda.time.LocalDate localDate33 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology31);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField35 = buddhistChronology34.halfdayOfDay();
//        org.joda.time.LocalDate localDate36 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology34);
//        org.joda.time.LocalDate localDate37 = localDate33.withFields((org.joda.time.ReadablePartial) localDate36);
//        long long39 = gJChronology30.set((org.joda.time.ReadablePartial) localDate37, 1L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = dateTimeFormatter40.withDefaultYear((-1));
//        java.util.TimeZone timeZone43 = null;
//        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forTimeZone(timeZone43);
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now(dateTimeZone44);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone46 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone44);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = dateTimeFormatter40.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone46);
//        org.joda.time.DateMidnight dateMidnight48 = localDate37.toDateMidnight((org.joda.time.DateTimeZone) cachedDateTimeZone46);
//        org.joda.time.DateTime dateTime49 = localDate22.toDateTimeAtCurrentTime((org.joda.time.DateTimeZone) cachedDateTimeZone46);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(buddhistChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(localDate7);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 62 + "'", int15 == 62);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 366 + "'", int16 == 366);
//        org.junit.Assert.assertNotNull(buddhistChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(localDate22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localDate27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(buddhistChronology34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 18696092400001L + "'", long39 == 18696092400001L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone46);
//        org.junit.Assert.assertNotNull(dateTimeFormatter47);
//        org.junit.Assert.assertNotNull(dateMidnight48);
//        org.junit.Assert.assertNotNull(dateTime49);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear((-1));
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        java.lang.String str9 = cachedDateTimeZone7.toString();
        long long12 = cachedDateTimeZone7.adjustOffset(0L, true);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.Chronology chronology14 = zonedChronology13.withUTC();
        org.joda.time.DateTimeField dateTimeField15 = zonedChronology13.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        long long19 = offsetDateTimeField17.roundCeiling((long) 2513);
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField17.getAsText(4, locale21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField17.getAsText((long) (short) 10, locale24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField17.getType();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800000L + "'", long19 == 28800000L);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "4" + "'", str22.equals("4"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1970" + "'", str25.equals("1970"));
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
//        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.Chronology chronology3 = localDate2.getChronology();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
//        boolean boolean10 = dateTime5.isBefore((long) (short) 0);
//        org.joda.time.DateTime dateTime12 = dateTime5.minusMonths((int) (byte) -1);
//        int int13 = dateTime12.getMinuteOfHour();
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.plus(readablePeriod14);
//        org.joda.time.DateTime dateTime16 = dateTime12.withTimeAtStartOfDay();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        int int1 = partial0.size();
        java.lang.String str2 = partial0.toStringList();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[]" + "'", str2.equals("[]"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology6 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology6.halfdayOfDay();
        org.joda.time.LocalDate localDate8 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology6);
        org.joda.time.Chronology chronology9 = localDate8.getChronology();
        int int10 = localDate2.compareTo((org.joda.time.ReadablePartial) localDate8);
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology11.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField13 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField12);
        long long16 = delegatedDateTimeField13.set(0L, 62);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = delegatedDateTimeField13.getType();
        org.joda.time.LocalDate.Property property18 = localDate2.property(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(buddhistChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-26179200000L) + "'", long16 == (-26179200000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.weekyear();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withDefaultYear((-1));
        java.util.TimeZone timeZone7 = null;
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forTimeZone(timeZone7);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone10 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter4.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone10);
        java.lang.String str12 = cachedDateTimeZone10.toString();
        long long15 = cachedDateTimeZone10.adjustOffset(0L, true);
        org.joda.time.chrono.ZonedChronology zonedChronology16 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology3, (org.joda.time.DateTimeZone) cachedDateTimeZone10);
        org.joda.time.Chronology chronology17 = zonedChronology16.withUTC();
        org.joda.time.DateTimeField dateTimeField18 = zonedChronology16.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, 1);
        long long23 = offsetDateTimeField20.add(0L, 2527);
        int int25 = offsetDateTimeField20.get(1209600016L);
        long long27 = offsetDateTimeField20.roundFloor((long) 15);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField20, (-1));
        org.joda.time.DurationField durationField30 = skipUndoDateTimeField29.getDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(cachedDateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "America/Los_Angeles" + "'", str12.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 79744521600000L + "'", long23 == 79744521600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1971 + "'", int25 == 1971);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-31507200000L) + "'", long27 == (-31507200000L));
        org.junit.Assert.assertNotNull(durationField30);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.halfdayOfDay();
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.Chronology chronology5 = localDate4.getChronology();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.DateTime dateTime7 = localDate4.toDateTime(readableInstant6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.halfdayOfDay();
        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.Chronology chronology11 = localDate10.getChronology();
        int int12 = localDate4.compareTo((org.joda.time.ReadablePartial) localDate10);
        java.util.Date date13 = localDate10.toDate();
        boolean boolean14 = jodaTimePermission1.equals((java.lang.Object) localDate10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.halfdayOfDay();
        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology15);
        org.joda.time.Chronology chronology18 = localDate17.getChronology();
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.DateTime dateTime20 = localDate17.toDateTime(readableInstant19);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.toDateTime(dateTimeZone22);
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime20);
        org.joda.time.DateTime.Property property25 = dateTime20.era();
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = buddhistChronology26.halfdayOfDay();
        org.joda.time.LocalDate localDate28 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology26);
        org.joda.time.Chronology chronology29 = localDate28.getChronology();
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.DateTime dateTime31 = localDate28.toDateTime(readableInstant30);
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.halfdayOfDay();
        org.joda.time.LocalDate localDate34 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology32);
        org.joda.time.Chronology chronology35 = localDate34.getChronology();
        int int36 = localDate28.compareTo((org.joda.time.ReadablePartial) localDate34);
        java.util.Date date37 = localDate34.toDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = null;
        int int39 = localDate34.indexOf(dateTimeFieldType38);
        org.joda.time.LocalDate localDate41 = localDate34.withYear((int) '4');
        org.joda.time.DateTimeField[] dateTimeFieldArray42 = localDate41.getFields();
        java.util.TimeZone timeZone43 = null;
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forTimeZone(timeZone43);
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now(dateTimeZone44);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone46 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone44);
        org.joda.time.DateMidnight dateMidnight47 = localDate41.toDateMidnight((org.joda.time.DateTimeZone) cachedDateTimeZone46);
        java.util.TimeZone timeZone48 = cachedDateTimeZone46.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone49 = cachedDateTimeZone46.getUncachedZone();
        org.joda.time.DateTime dateTime50 = dateTime20.toDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone46);
        org.joda.time.DateTime dateTime52 = dateTime20.plusMinutes(0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(dateTimeFieldArray42);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(cachedDateTimeZone46);
        org.junit.Assert.assertNotNull(dateMidnight47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-28800000), false);
        boolean boolean4 = dateTimeFormatterBuilder3.canBuildFormatter();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.halfdayOfDay();
        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.halfdayOfDay();
        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.LocalDate localDate11 = localDate7.withFields((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.LocalDate.Property property12 = localDate11.dayOfWeek();
        org.joda.time.LocalDate localDate13 = property12.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate14 = property12.roundHalfCeilingCopy();
        int int15 = localDate14.getYearOfCentury();
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology16.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        long long21 = delegatedDateTimeField18.set(0L, 62);
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = delegatedDateTimeField18.getType();
        boolean boolean23 = localDate14.isSupported(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder3.appendText(dateTimeFieldType22);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder3.appendLiteral("-4712");
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 62 + "'", int15 == 62);
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-26179200000L) + "'", long21 == (-26179200000L));
        org.junit.Assert.assertNotNull(dateTimeFieldType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.set(0L, 62);
        long long7 = delegatedDateTimeField2.roundFloor(18696092400001L);
        int int9 = delegatedDateTimeField2.get(19L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-26179200000L) + "'", long5 == (-26179200000L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 18696034800000L + "'", long7 == 18696034800000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.halfdayOfDay();
//        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology2);
//        org.joda.time.Chronology chronology5 = localDate4.getChronology();
//        org.joda.time.ReadableInstant readableInstant6 = null;
//        org.joda.time.DateTime dateTime7 = localDate4.toDateTime(readableInstant6);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.halfdayOfDay();
//        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology8);
//        org.joda.time.Chronology chronology11 = localDate10.getChronology();
//        int int12 = localDate4.compareTo((org.joda.time.ReadablePartial) localDate10);
//        java.util.Date date13 = localDate10.toDate();
//        boolean boolean14 = jodaTimePermission1.equals((java.lang.Object) localDate10);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.halfdayOfDay();
//        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology15);
//        org.joda.time.Chronology chronology18 = localDate17.getChronology();
//        org.joda.time.ReadableInstant readableInstant19 = null;
//        org.joda.time.DateTime dateTime20 = localDate17.toDateTime(readableInstant19);
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime20.toDateTime(dateTimeZone22);
//        jodaTimePermission1.checkGuard((java.lang.Object) dateTime20);
//        org.joda.time.DateTime.Property property25 = dateTime20.era();
//        long long26 = property25.remainder();
//        org.joda.time.DateTime dateTime27 = property25.roundCeilingCopy();
//        org.junit.Assert.assertNotNull(buddhistChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(buddhistChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 80831664942720L + "'", long26 == 80831664942720L);
//        org.junit.Assert.assertNotNull(dateTime27);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfSecond((int) '4');
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime11 = dateTime5.withDurationAdded(readableDuration9, (int) ' ');
        org.joda.time.DateTime dateTime13 = dateTime11.plusDays(100);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        int[] intArray1 = partial0.getValues();
        java.lang.String str2 = partial0.toString();
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            boolean boolean4 = partial0.isMatch(readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[]" + "'", str2.equals("[]"));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.halfdayOfDay();
        org.joda.time.LocalDate localDate3 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.Chronology chronology4 = localDate3.getChronology();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.DateTime dateTime6 = localDate3.toDateTime(readableInstant5);
        org.joda.time.LocalDate localDate8 = localDate3.plusWeeks((int) (short) 0);
        java.util.TimeZone timeZone9 = null;
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateMidnight dateMidnight12 = localDate3.toDateMidnight(dateTimeZone10);
        int int14 = dateTimeZone10.getOffsetFromLocal((long) 1);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(28800000L, dateTimeZone10);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((-1));
        java.util.TimeZone timeZone3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forTimeZone(timeZone3);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        java.lang.String str8 = cachedDateTimeZone6.toString();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) cachedDateTimeZone6);
        org.joda.time.LocalDate localDate12 = localDate10.withYearOfEra(15);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "America/Los_Angeles" + "'", str8.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendClockhourOfDay(7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMonthOfYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        int int3 = dateTimeFormatter2.getDefaultYear();
        java.lang.StringBuffer stringBuffer4 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.halfdayOfDay();
        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.Chronology chronology8 = localDate7.getChronology();
        try {
            dateTimeFormatter2.printTo(stringBuffer4, (org.joda.time.ReadablePartial) localDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("org.joda.time.IllegalInstantException: 0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalInstantExce...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("97");
        org.joda.time.Instant instant2 = instant1.toInstant();
        org.joda.time.Instant instant4 = instant1.withMillis(1L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.halfdayOfDay();
        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.Chronology chronology8 = localDate7.getChronology();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.DateTime dateTime10 = localDate7.toDateTime(readableInstant9);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) 1L, chronology11);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
//        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.Chronology chronology3 = localDate2.getChronology();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
//        boolean boolean10 = dateTime5.isBefore((long) (short) 0);
//        org.joda.time.DateTime dateTime12 = dateTime5.withEra(0);
//        java.lang.String str13 = dateTime12.toString();
//        org.joda.time.DateTime.Property property14 = dateTime12.weekOfWeekyear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.dayOfYear();
//        org.joda.time.DateTime dateTime17 = dateTime12.toDateTime((org.joda.time.Chronology) buddhistChronology15);
//        org.joda.time.DateTime dateTime19 = dateTime12.minus((long) 19);
//        org.joda.time.DateTime dateTime21 = dateTime12.minusHours(19);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-2562-06-15T16:15:43.191-07:52:58" + "'", str13.equals("-2562-06-15T16:15:43.191-07:52:58"));
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = gJChronology1.yearOfEra();
        org.joda.time.DurationField durationField3 = gJChronology1.eras();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withDefaultYear((-1));
        java.util.TimeZone timeZone5 = null;
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forTimeZone(timeZone5);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        java.lang.String str10 = cachedDateTimeZone8.toString();
        long long13 = cachedDateTimeZone8.adjustOffset(0L, true);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, (org.joda.time.DateTimeZone) cachedDateTimeZone8);
        org.joda.time.Chronology chronology15 = zonedChronology14.withUTC();
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.JodaTimePermission jodaTimePermission18 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology19.halfdayOfDay();
        org.joda.time.LocalDate localDate21 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology19);
        org.joda.time.Chronology chronology22 = localDate21.getChronology();
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.DateTime dateTime24 = localDate21.toDateTime(readableInstant23);
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology25.halfdayOfDay();
        org.joda.time.LocalDate localDate27 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology25);
        org.joda.time.Chronology chronology28 = localDate27.getChronology();
        int int29 = localDate21.compareTo((org.joda.time.ReadablePartial) localDate27);
        java.util.Date date30 = localDate27.toDate();
        boolean boolean31 = jodaTimePermission18.equals((java.lang.Object) localDate27);
        org.joda.time.chrono.BuddhistChronology buddhistChronology32 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology32.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
        int int36 = delegatedDateTimeField34.getMinimumValue(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = buddhistChronology37.halfdayOfDay();
        org.joda.time.LocalDate localDate39 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology37);
        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField41 = buddhistChronology40.halfdayOfDay();
        org.joda.time.LocalDate localDate42 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology40);
        org.joda.time.LocalDate localDate43 = localDate39.withFields((org.joda.time.ReadablePartial) localDate42);
        org.joda.time.LocalDate.Property property44 = localDate43.dayOfWeek();
        org.joda.time.LocalDate localDate45 = property44.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate46 = property44.roundHalfCeilingCopy();
        int int47 = localDate46.getYearOfCentury();
        int int48 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) localDate46);
        int int49 = localDate27.compareTo((org.joda.time.ReadablePartial) localDate46);
        org.joda.time.LocalDate localDate51 = localDate46.plusMonths((int) ' ');
        java.util.TimeZone timeZone52 = null;
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forTimeZone(timeZone52);
        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now(dateTimeZone53);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone55 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone53);
        org.joda.time.Interval interval56 = localDate51.toInterval((org.joda.time.DateTimeZone) cachedDateTimeZone55);
        org.joda.time.Chronology chronology57 = copticChronology16.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone55);
        org.joda.time.Chronology chronology58 = zonedChronology14.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone55);
        org.joda.time.Chronology chronology59 = julianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone55);
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone55);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(buddhistChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(buddhistChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 62 + "'", int47 == 62);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 366 + "'", int48 == 366);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(cachedDateTimeZone55);
        org.junit.Assert.assertNotNull(interval56);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(gregorianChronology60);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
//        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.halfdayOfDay();
//        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology3);
//        org.joda.time.LocalDate localDate6 = localDate2.withFields((org.joda.time.ReadablePartial) localDate5);
//        org.joda.time.LocalDate.Property property7 = localDate6.dayOfWeek();
//        org.joda.time.Interval interval8 = property7.toInterval();
//        org.joda.time.LocalDate localDate9 = property7.withMaximumValue();
//        java.lang.String str11 = localDate9.toString("2562-06-15");
//        java.lang.String str12 = localDate9.toString();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.halfdayOfDay();
//        org.joda.time.LocalDate localDate15 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology13);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology16.halfdayOfDay();
//        org.joda.time.LocalDate localDate18 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology16);
//        org.joda.time.LocalDate localDate19 = localDate15.withFields((org.joda.time.ReadablePartial) localDate18);
//        org.joda.time.LocalDate.Property property20 = localDate19.dayOfWeek();
//        java.util.TimeZone timeZone21 = null;
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone22);
//        org.joda.time.DateMidnight dateMidnight24 = localDate19.toDateMidnight(dateTimeZone22);
//        java.util.TimeZone timeZone25 = null;
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forTimeZone(timeZone25);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(dateTimeZone26);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone28 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone26);
//        long long30 = dateTimeZone22.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone28, (long) 2000);
//        long long34 = dateTimeZone22.convertLocalToUTC((long) (byte) 10, true, (-1L));
//        org.joda.time.Interval interval35 = localDate9.toInterval(dateTimeZone22);
//        int int36 = localDate9.getCenturyOfEra();
//        org.joda.time.ReadablePeriod readablePeriod37 = null;
//        org.joda.time.LocalDate localDate39 = localDate9.withPeriodAdded(readablePeriod37, (int) (byte) 0);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(interval8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "2562-06-15" + "'", str11.equals("2562-06-15"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2562-06-16" + "'", str12.equals("2562-06-16"));
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(localDate18);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateMidnight24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 2000L + "'", long30 == 2000L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 28800010L + "'", long34 == 28800010L);
//        org.junit.Assert.assertNotNull(interval35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 26 + "'", int36 == 26);
//        org.junit.Assert.assertNotNull(localDate39);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
        boolean boolean10 = dateTime5.isBefore((long) (short) 0);
        org.joda.time.DateTime dateTime12 = dateTime5.withEra(0);
        int int13 = dateTime5.getYearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.withYearOfCentury(0);
        org.joda.time.DateTime.Property property16 = dateTime5.secondOfDay();
        org.joda.time.DurationField durationField17 = property16.getRangeDurationField();
        org.joda.time.DateTime dateTime18 = property16.withMaximumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2562 + "'", int13 == 2562);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        long long2 = org.joda.time.field.FieldUtils.safeDivide(113605027200000001L, 18696034800000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6076L + "'", long2 == 6076L);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
//        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.Chronology chronology3 = localDate2.getChronology();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
//        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
//        java.lang.String str10 = property9.getAsText();
//        org.joda.time.DateTime dateTime11 = property9.roundHalfEvenCopy();
//        int int12 = property9.getMaximumValue();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "44" + "'", str10.equals("44"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
//    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear((-1));
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        java.lang.String str9 = cachedDateTimeZone7.toString();
        long long12 = cachedDateTimeZone7.adjustOffset(0L, true);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.Chronology chronology14 = zonedChronology13.withUTC();
        try {
            long long19 = zonedChronology13.getDateTimeMillis(0, 0, (int) '4', 14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.ReadableInstant readableInstant0 = null;
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readablePeriod4);
        int int6 = dateTime5.getCenturyOfEra();
        org.joda.time.DateTime.Property property7 = dateTime5.monthOfYear();
        int int8 = dateTime5.getWeekyear();
        org.joda.time.DateTime.Property property9 = dateTime5.weekyear();
        org.joda.time.DateTime dateTime11 = dateTime5.plusHours(1970);
        org.joda.time.DateTime.Property property12 = dateTime5.yearOfEra();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, (org.joda.time.ReadableInstant) dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 20 + "'", int6 == 20);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        int int6 = delegatedDateTimeField4.getMinimumValue(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.halfdayOfDay();
        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.halfdayOfDay();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology10);
        org.joda.time.LocalDate localDate13 = localDate9.withFields((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.LocalDate.Property property14 = localDate13.dayOfWeek();
        org.joda.time.LocalDate localDate15 = property14.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate16 = property14.roundHalfCeilingCopy();
        int int17 = localDate16.getYearOfCentury();
        int int18 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4);
        int int21 = skipDateTimeField20.getMinimumValue();
        org.joda.time.JodaTimePermission jodaTimePermission23 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology24.halfdayOfDay();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology24);
        org.joda.time.Chronology chronology27 = localDate26.getChronology();
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.DateTime dateTime29 = localDate26.toDateTime(readableInstant28);
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology30.halfdayOfDay();
        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology30);
        org.joda.time.Chronology chronology33 = localDate32.getChronology();
        int int34 = localDate26.compareTo((org.joda.time.ReadablePartial) localDate32);
        java.util.Date date35 = localDate32.toDate();
        boolean boolean36 = jodaTimePermission23.equals((java.lang.Object) localDate32);
        org.joda.time.chrono.BuddhistChronology buddhistChronology37 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = buddhistChronology37.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField39 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField38);
        int int41 = delegatedDateTimeField39.getMinimumValue(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology42 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology42.halfdayOfDay();
        org.joda.time.LocalDate localDate44 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology42);
        org.joda.time.chrono.BuddhistChronology buddhistChronology45 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField46 = buddhistChronology45.halfdayOfDay();
        org.joda.time.LocalDate localDate47 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology45);
        org.joda.time.LocalDate localDate48 = localDate44.withFields((org.joda.time.ReadablePartial) localDate47);
        org.joda.time.LocalDate.Property property49 = localDate48.dayOfWeek();
        org.joda.time.LocalDate localDate50 = property49.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate51 = property49.roundHalfCeilingCopy();
        int int52 = localDate51.getYearOfCentury();
        int int53 = delegatedDateTimeField39.getMaximumValue((org.joda.time.ReadablePartial) localDate51);
        int int54 = localDate32.compareTo((org.joda.time.ReadablePartial) localDate51);
        org.joda.time.LocalDate localDate56 = localDate51.plusMonths((int) ' ');
        org.joda.time.ReadablePeriod readablePeriod57 = null;
        org.joda.time.LocalDate localDate59 = localDate56.withPeriodAdded(readablePeriod57, 0);
        int int60 = skipDateTimeField20.getMinimumValue((org.joda.time.ReadablePartial) localDate56);
        java.lang.String str61 = skipDateTimeField20.getName();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 62 + "'", int17 == 62);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 366 + "'", int18 == 366);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(buddhistChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertNotNull(buddhistChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(localDate47);
        org.junit.Assert.assertNotNull(localDate48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertNotNull(localDate51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 62 + "'", int52 == 62);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 366 + "'", int53 == 366);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertNotNull(localDate59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "dayOfYear" + "'", str61.equals("dayOfYear"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear((-1));
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        java.lang.String str9 = cachedDateTimeZone7.toString();
        long long12 = cachedDateTimeZone7.adjustOffset(0L, true);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.Chronology chronology14 = zonedChronology13.withUTC();
        org.joda.time.DateTimeField dateTimeField15 = zonedChronology13.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 1);
        long long20 = offsetDateTimeField17.add(0L, 2527);
        java.lang.String str21 = offsetDateTimeField17.getName();
        int int23 = offsetDateTimeField17.getMaximumValue((long) 16);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 79744521600000L + "'", long20 == 79744521600000L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "year" + "'", str21.equals("year"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 292278994 + "'", int23 == 292278994);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
//        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology3.halfdayOfDay();
//        org.joda.time.LocalDate localDate5 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology3);
//        org.joda.time.LocalDate localDate6 = localDate2.withFields((org.joda.time.ReadablePartial) localDate5);
//        org.joda.time.LocalDate.Property property7 = localDate6.dayOfWeek();
//        org.joda.time.Interval interval8 = property7.toInterval();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property7.getAsText(locale9);
//        org.joda.time.LocalDate localDate11 = property7.roundHalfCeilingCopy();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.LocalDate localDate14 = localDate11.withPeriodAdded(readablePeriod12, 366);
//        try {
//            org.joda.time.LocalDate localDate16 = localDate11.withEra((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for era must be in the range [1,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(interval8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Saturday" + "'", str10.equals("Saturday"));
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(localDate14);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        int int6 = delegatedDateTimeField4.getMinimumValue(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.halfdayOfDay();
        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.halfdayOfDay();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology10);
        org.joda.time.LocalDate localDate13 = localDate9.withFields((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.LocalDate.Property property14 = localDate13.dayOfWeek();
        org.joda.time.LocalDate localDate15 = property14.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate16 = property14.roundHalfCeilingCopy();
        int int17 = localDate16.getYearOfCentury();
        int int18 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4);
        java.util.Locale locale22 = null;
        java.lang.String str23 = delegatedDateTimeField4.getAsText((-30239999999L), locale22);
        java.lang.String str25 = delegatedDateTimeField4.getAsText((-56984000L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 62 + "'", int17 == 62);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 366 + "'", int18 == 366);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "15" + "'", str23.equals("15"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "365" + "'", str25.equals("365"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
        org.joda.time.DateTime dateTime11 = dateTime8.withYear((int) (short) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology12.halfdayOfDay();
        org.joda.time.LocalDate localDate14 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology12);
        org.joda.time.Chronology chronology15 = localDate14.getChronology();
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.DateTime dateTime17 = localDate14.toDateTime(readableInstant16);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded(readableDuration18, (int) '4');
        org.joda.time.DateTime dateTime22 = dateTime20.minusDays((int) '4');
        org.joda.time.DateTime dateTime24 = dateTime22.plusYears((int) (short) -1);
        org.joda.time.DateTime dateTime26 = dateTime22.minusWeeks(2562);
        java.util.Date date27 = dateTime22.toDate();
        int int28 = dateTime11.compareTo((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter29.withDefaultYear((-1));
        java.util.TimeZone timeZone32 = null;
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forTimeZone(timeZone32);
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now(dateTimeZone33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone35 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone33);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = dateTimeFormatter29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone35);
        org.joda.time.DateTime dateTime37 = dateTime11.toDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone35);
        org.joda.time.DateTime dateTime39 = dateTime11.minusMonths(58458305);
        org.joda.time.MutableDateTime mutableDateTime40 = dateTime11.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(cachedDateTimeZone35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(mutableDateTime40);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "Pacific Daylight Time", (-292275054), 3);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        int int6 = delegatedDateTimeField4.getMinimumValue(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.halfdayOfDay();
        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.halfdayOfDay();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology10);
        org.joda.time.LocalDate localDate13 = localDate9.withFields((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.LocalDate.Property property14 = localDate13.dayOfWeek();
        org.joda.time.LocalDate localDate15 = property14.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate16 = property14.roundHalfCeilingCopy();
        int int17 = localDate16.getYearOfCentury();
        int int18 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4);
        boolean boolean22 = skipDateTimeField20.isLeap((long) (short) 1);
        long long24 = skipDateTimeField20.roundHalfCeiling((long) '4');
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 62 + "'", int17 == 62);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 366 + "'", int18 == 366);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28800000L + "'", long24 == 28800000L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        java.lang.String str2 = partial0.toString("365");
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "365" + "'", str2.equals("365"));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
        boolean boolean10 = dateTime5.isBefore((long) (short) 0);
        org.joda.time.DateTime dateTime12 = dateTime5.withEra(0);
        org.joda.time.Instant instant13 = dateTime5.toInstant();
        org.joda.time.MutableDateTime mutableDateTime14 = instant13.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("13", "97", 0, 25);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
//        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.Chronology chronology3 = localDate2.getChronology();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
//        boolean boolean10 = dateTime5.isBefore((long) (short) 0);
//        org.joda.time.DateTime dateTime12 = dateTime5.withEra(0);
//        int int13 = dateTime5.getMonthOfYear();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField15 = buddhistChronology14.halfdayOfDay();
//        org.joda.time.LocalDate localDate16 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology14);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.halfdayOfDay();
//        org.joda.time.LocalDate localDate19 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology17);
//        org.joda.time.LocalDate localDate20 = localDate16.withFields((org.joda.time.ReadablePartial) localDate19);
//        org.joda.time.LocalDate.Property property21 = localDate20.dayOfWeek();
//        org.joda.time.Interval interval22 = property21.toInterval();
//        org.joda.time.LocalDate localDate23 = property21.withMaximumValue();
//        java.lang.String str25 = localDate23.toString("2562-06-15");
//        java.lang.String str26 = localDate23.toString();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology27.halfdayOfDay();
//        org.joda.time.LocalDate localDate29 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology27);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology30.halfdayOfDay();
//        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology30);
//        org.joda.time.LocalDate localDate33 = localDate29.withFields((org.joda.time.ReadablePartial) localDate32);
//        org.joda.time.LocalDate.Property property34 = localDate33.dayOfWeek();
//        java.util.TimeZone timeZone35 = null;
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forTimeZone(timeZone35);
//        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now(dateTimeZone36);
//        org.joda.time.DateMidnight dateMidnight38 = localDate33.toDateMidnight(dateTimeZone36);
//        java.util.TimeZone timeZone39 = null;
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forTimeZone(timeZone39);
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now(dateTimeZone40);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone42 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
//        long long44 = dateTimeZone36.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone42, (long) 2000);
//        long long48 = dateTimeZone36.convertLocalToUTC((long) (byte) 10, true, (-1L));
//        org.joda.time.Interval interval49 = localDate23.toInterval(dateTimeZone36);
//        int int50 = localDate23.getCenturyOfEra();
//        org.joda.time.DateTime dateTime51 = dateTime5.withFields((org.joda.time.ReadablePartial) localDate23);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(buddhistChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(localDate19);
//        org.junit.Assert.assertNotNull(localDate20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(interval22);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "2562-06-15" + "'", str25.equals("2562-06-15"));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "2562-06-16" + "'", str26.equals("2562-06-16"));
//        org.junit.Assert.assertNotNull(buddhistChronology27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(localDate29);
//        org.junit.Assert.assertNotNull(buddhistChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertNotNull(localDate33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateMidnight38);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 2000L + "'", long44 == 2000L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 28800010L + "'", long48 == 28800010L);
//        org.junit.Assert.assertNotNull(interval49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 26 + "'", int50 == 26);
//        org.junit.Assert.assertNotNull(dateTime51);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-28800000), false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendDayOfMonth(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear(58458305);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfMinute(58454092, (int) (short) 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap12 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder8.appendTimeZoneShortName(strMap12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder3.appendTimeZoneShortName(strMap12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(strMap12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        int[] intArray1 = partial0.getValues();
        java.util.TimeZone timeZone2 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readablePeriod5);
        org.joda.time.DateTime dateTime8 = dateTime6.withYear((int) (byte) 100);
        java.util.Locale locale9 = null;
        java.util.Calendar calendar10 = dateTime6.toCalendar(locale9);
        boolean boolean11 = partial0.isMatch((org.joda.time.ReadableInstant) dateTime6);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(calendar10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMinutes(0);
        org.joda.time.DateTime dateTime13 = dateTime8.withMillis(0L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withDefaultYear((-1));
        java.util.TimeZone timeZone4 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forTimeZone(timeZone4);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter1.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        java.lang.String str9 = cachedDateTimeZone7.toString();
        long long12 = cachedDateTimeZone7.adjustOffset(0L, true);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.Chronology chronology14 = zonedChronology13.withUTC();
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.JodaTimePermission jodaTimePermission17 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.halfdayOfDay();
        org.joda.time.LocalDate localDate20 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology18);
        org.joda.time.Chronology chronology21 = localDate20.getChronology();
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.DateTime dateTime23 = localDate20.toDateTime(readableInstant22);
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField25 = buddhistChronology24.halfdayOfDay();
        org.joda.time.LocalDate localDate26 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology24);
        org.joda.time.Chronology chronology27 = localDate26.getChronology();
        int int28 = localDate20.compareTo((org.joda.time.ReadablePartial) localDate26);
        java.util.Date date29 = localDate26.toDate();
        boolean boolean30 = jodaTimePermission17.equals((java.lang.Object) localDate26);
        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField32 = buddhistChronology31.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField33 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField32);
        int int35 = delegatedDateTimeField33.getMinimumValue(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology36 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology36.halfdayOfDay();
        org.joda.time.LocalDate localDate38 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology36);
        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField40 = buddhistChronology39.halfdayOfDay();
        org.joda.time.LocalDate localDate41 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology39);
        org.joda.time.LocalDate localDate42 = localDate38.withFields((org.joda.time.ReadablePartial) localDate41);
        org.joda.time.LocalDate.Property property43 = localDate42.dayOfWeek();
        org.joda.time.LocalDate localDate44 = property43.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate45 = property43.roundHalfCeilingCopy();
        int int46 = localDate45.getYearOfCentury();
        int int47 = delegatedDateTimeField33.getMaximumValue((org.joda.time.ReadablePartial) localDate45);
        int int48 = localDate26.compareTo((org.joda.time.ReadablePartial) localDate45);
        org.joda.time.LocalDate localDate50 = localDate45.plusMonths((int) ' ');
        java.util.TimeZone timeZone51 = null;
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forTimeZone(timeZone51);
        org.joda.time.DateTime dateTime53 = org.joda.time.DateTime.now(dateTimeZone52);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone54 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone52);
        org.joda.time.Interval interval55 = localDate50.toInterval((org.joda.time.DateTimeZone) cachedDateTimeZone54);
        org.joda.time.Chronology chronology56 = copticChronology15.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone54);
        org.joda.time.Chronology chronology57 = zonedChronology13.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone54);
        java.util.TimeZone timeZone58 = null;
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.forTimeZone(timeZone58);
        org.joda.time.Chronology chronology60 = zonedChronology13.withZone(dateTimeZone59);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(buddhistChronology31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(buddhistChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(localDate41);
        org.junit.Assert.assertNotNull(localDate42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 62 + "'", int46 == 62);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 366 + "'", int47 == 366);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(cachedDateTimeZone54);
        org.junit.Assert.assertNotNull(interval55);
        org.junit.Assert.assertNotNull(chronology56);
        org.junit.Assert.assertNotNull(chronology57);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(chronology60);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
        org.joda.time.DateTime dateTime11 = dateTime8.plusMinutes(0);
        org.joda.time.DateTime.Property property12 = dateTime11.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology13.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        int int17 = delegatedDateTimeField15.getMinimumValue(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology18.halfdayOfDay();
        org.joda.time.LocalDate localDate20 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology18);
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.halfdayOfDay();
        org.joda.time.LocalDate localDate23 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology21);
        org.joda.time.LocalDate localDate24 = localDate20.withFields((org.joda.time.ReadablePartial) localDate23);
        org.joda.time.LocalDate.Property property25 = localDate24.dayOfWeek();
        org.joda.time.LocalDate localDate26 = property25.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate27 = property25.roundHalfCeilingCopy();
        int int28 = localDate27.getYearOfCentury();
        int int29 = delegatedDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) localDate27);
        org.joda.time.DurationField durationField30 = delegatedDateTimeField15.getRangeDurationField();
        boolean boolean31 = property12.equals((java.lang.Object) durationField30);
        org.joda.time.DateTime dateTime32 = property12.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(localDate24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(localDate27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 62 + "'", int28 == 62);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 366 + "'", int29 == 366);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTime32);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
//        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
//        org.joda.time.Chronology chronology3 = localDate2.getChronology();
//        org.joda.time.ReadableInstant readableInstant4 = null;
//        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
//        boolean boolean10 = dateTime5.isBefore((long) (short) 0);
//        org.joda.time.DateTime dateTime12 = dateTime5.withEra(0);
//        java.lang.String str13 = dateTime12.toString();
//        org.joda.time.DateTime.Property property14 = dateTime12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime15 = property14.roundCeilingCopy();
//        org.joda.time.DateTimeField dateTimeField16 = property14.getField();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(localDate2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-2562-06-15T16:15:47.783-07:52:58" + "'", str13.equals("-2562-06-15T16:15:47.783-07:52:58"));
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.halfdayOfDay();
        org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.Chronology chronology3 = localDate2.getChronology();
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.DateTime dateTime5 = localDate2.toDateTime(readableInstant4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, (int) '4');
        boolean boolean10 = dateTime5.isBefore((long) (short) 0);
        org.joda.time.DateTime dateTime12 = dateTime5.withEra(0);
        int int13 = dateTime5.getMonthOfYear();
        org.joda.time.DateTime dateTime15 = dateTime5.withEra((int) (byte) 0);
        org.joda.time.DateTime dateTime17 = dateTime5.minusMonths(0);
        org.joda.time.DateTime.Property property18 = dateTime17.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, 58454092);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 58454092");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField4 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField3);
        int int6 = delegatedDateTimeField4.getMinimumValue(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology7.halfdayOfDay();
        org.joda.time.LocalDate localDate9 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology7);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology10.halfdayOfDay();
        org.joda.time.LocalDate localDate12 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology10);
        org.joda.time.LocalDate localDate13 = localDate9.withFields((org.joda.time.ReadablePartial) localDate12);
        org.joda.time.LocalDate.Property property14 = localDate13.dayOfWeek();
        org.joda.time.LocalDate localDate15 = property14.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate16 = property14.roundHalfCeilingCopy();
        int int17 = localDate16.getYearOfCentury();
        int int18 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate16);
        org.joda.time.DurationField durationField19 = delegatedDateTimeField4.getRangeDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField20 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField4);
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology21.halfdayOfDay();
        org.joda.time.LocalDate localDate23 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology21);
        org.joda.time.Chronology chronology24 = localDate23.getChronology();
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.DateTime dateTime26 = localDate23.toDateTime(readableInstant25);
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology27.halfdayOfDay();
        org.joda.time.LocalDate localDate29 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology27);
        org.joda.time.Chronology chronology30 = localDate29.getChronology();
        int int31 = localDate23.compareTo((org.joda.time.ReadablePartial) localDate29);
        java.util.Date date32 = localDate29.toDate();
        org.joda.time.LocalDate localDate34 = localDate29.withWeekOfWeekyear((int) (short) 10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology35 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology35.halfdayOfDay();
        org.joda.time.LocalDate localDate37 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology35);
        org.joda.time.Chronology chronology38 = localDate37.getChronology();
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.DateTime dateTime40 = localDate37.toDateTime(readableInstant39);
        org.joda.time.chrono.BuddhistChronology buddhistChronology41 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology41.halfdayOfDay();
        org.joda.time.LocalDate localDate43 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology41);
        org.joda.time.Chronology chronology44 = localDate43.getChronology();
        int int45 = localDate37.compareTo((org.joda.time.ReadablePartial) localDate43);
        java.util.Date date46 = localDate43.toDate();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = null;
        int int48 = localDate43.indexOf(dateTimeFieldType47);
        org.joda.time.LocalDate localDate50 = localDate43.withYear((int) '4');
        int[] intArray51 = localDate50.getValues();
        int int52 = delegatedDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localDate29, intArray51);
        int int53 = delegatedDateTimeField4.getMaximumValue();
        java.util.Locale locale55 = null;
        java.lang.String str56 = delegatedDateTimeField4.getAsText((long) 91, locale55);
        int int58 = delegatedDateTimeField4.getMinimumValue((long) 100);
        org.joda.time.DurationField durationField59 = delegatedDateTimeField4.getRangeDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 62 + "'", int17 == 62);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 366 + "'", int18 == 366);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(buddhistChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(localDate37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(buddhistChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(localDate50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 366 + "'", int52 == 366);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 366 + "'", int53 == 366);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "365" + "'", str56.equals("365"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertNotNull(durationField59);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.dayOfYear();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.halfdayOfDay();
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology5.halfdayOfDay();
        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.LocalDate localDate8 = localDate4.withFields((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.LocalDate.Property property9 = localDate8.dayOfWeek();
        java.util.TimeZone timeZone10 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forTimeZone(timeZone10);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.DateMidnight dateMidnight13 = localDate8.toDateMidnight(dateTimeZone11);
        java.util.TimeZone timeZone14 = null;
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        long long19 = dateTimeZone11.getMillisKeepLocal((org.joda.time.DateTimeZone) cachedDateTimeZone17, (long) 2000);
        boolean boolean21 = cachedDateTimeZone17.equals((java.lang.Object) (-28800000));
        org.joda.time.Chronology chronology22 = buddhistChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone17);
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology23);
        org.joda.time.chrono.BuddhistChronology buddhistChronology25 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology25.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField27 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26);
        int int29 = delegatedDateTimeField27.getMinimumValue(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology30.halfdayOfDay();
        org.joda.time.LocalDate localDate32 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology30);
        org.joda.time.chrono.BuddhistChronology buddhistChronology33 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology33.halfdayOfDay();
        org.joda.time.LocalDate localDate35 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology33);
        org.joda.time.LocalDate localDate36 = localDate32.withFields((org.joda.time.ReadablePartial) localDate35);
        org.joda.time.LocalDate.Property property37 = localDate36.dayOfWeek();
        org.joda.time.LocalDate localDate38 = property37.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate39 = property37.roundHalfCeilingCopy();
        int int40 = localDate39.getYearOfCentury();
        int int41 = delegatedDateTimeField27.getMaximumValue((org.joda.time.ReadablePartial) localDate39);
        org.joda.time.DurationField durationField42 = delegatedDateTimeField27.getRangeDurationField();
        org.joda.time.field.SkipDateTimeField skipDateTimeField43 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology23, (org.joda.time.DateTimeField) delegatedDateTimeField27);
        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology23.hourOfHalfday();
        boolean boolean45 = cachedDateTimeZone17.equals((java.lang.Object) buddhistChronology23);
        java.util.TimeZone timeZone46 = null;
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forTimeZone(timeZone46);
        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now(dateTimeZone47);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone49 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone47);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone50 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone47);
        org.joda.time.Chronology chronology51 = buddhistChronology23.withZone(dateTimeZone47);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2000L + "'", long19 == 2000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(buddhistChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(buddhistChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 62 + "'", int40 == 62);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 366 + "'", int41 == 366);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(cachedDateTimeZone49);
        org.junit.Assert.assertNotNull(cachedDateTimeZone50);
        org.junit.Assert.assertNotNull(chronology51);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology2.halfdayOfDay();
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.Chronology chronology5 = localDate4.getChronology();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.DateTime dateTime7 = localDate4.toDateTime(readableInstant6);
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology8.halfdayOfDay();
        org.joda.time.LocalDate localDate10 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology8);
        org.joda.time.Chronology chronology11 = localDate10.getChronology();
        int int12 = localDate4.compareTo((org.joda.time.ReadablePartial) localDate10);
        java.util.Date date13 = localDate10.toDate();
        boolean boolean14 = jodaTimePermission1.equals((java.lang.Object) localDate10);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology15.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
        int int19 = delegatedDateTimeField17.getMinimumValue(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology20.halfdayOfDay();
        org.joda.time.LocalDate localDate22 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology20);
        org.joda.time.chrono.BuddhistChronology buddhistChronology23 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = buddhistChronology23.halfdayOfDay();
        org.joda.time.LocalDate localDate25 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology23);
        org.joda.time.LocalDate localDate26 = localDate22.withFields((org.joda.time.ReadablePartial) localDate25);
        org.joda.time.LocalDate.Property property27 = localDate26.dayOfWeek();
        org.joda.time.LocalDate localDate28 = property27.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate29 = property27.roundHalfCeilingCopy();
        int int30 = localDate29.getYearOfCentury();
        int int31 = delegatedDateTimeField17.getMaximumValue((org.joda.time.ReadablePartial) localDate29);
        int int32 = localDate10.compareTo((org.joda.time.ReadablePartial) localDate29);
        org.joda.time.LocalDate localDate34 = localDate29.plusMonths((int) ' ');
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter36 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter36.withDefaultYear((-1));
        java.util.TimeZone timeZone39 = null;
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forTimeZone(timeZone39);
        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now(dateTimeZone40);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone42 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = dateTimeFormatter36.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone42);
        java.lang.String str44 = cachedDateTimeZone42.toString();
        long long47 = cachedDateTimeZone42.adjustOffset(0L, true);
        org.joda.time.chrono.ZonedChronology zonedChronology48 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology35, (org.joda.time.DateTimeZone) cachedDateTimeZone42);
        org.joda.time.Chronology chronology49 = zonedChronology48.withUTC();
        org.joda.time.DateTimeField dateTimeField50 = zonedChronology48.year();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 1);
        long long55 = offsetDateTimeField52.add(0L, 2527);
        long long58 = offsetDateTimeField52.set(17135452800001L, 100);
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDate localDate60 = org.joda.time.LocalDate.now(dateTimeZone59);
        int int61 = offsetDateTimeField52.getMinimumValue((org.joda.time.ReadablePartial) localDate60);
        boolean boolean62 = localDate29.isBefore((org.joda.time.ReadablePartial) localDate60);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(buddhistChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(localDate25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(localDate29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 62 + "'", int30 == 62);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 366 + "'", int31 == 366);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeFormatter36);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(cachedDateTimeZone42);
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "America/Los_Angeles" + "'", str44.equals("America/Los_Angeles"));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
        org.junit.Assert.assertNotNull(zonedChronology48);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 79744521600000L + "'", long55 == 79744521600000L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-59011459621999L) + "'", long58 == (-59011459621999L));
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(localDate60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-292275053) + "'", int61 == (-292275053));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }
}

