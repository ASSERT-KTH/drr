import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology3.weekyearOfCentury();
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) (short) 0, (org.joda.time.Chronology) copticChronology3);
//        int int8 = monthDay7.getDayOfMonth();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime15 = dateTime12.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        org.joda.time.DateTime dateTime17 = dateTime12.withFields(readablePartial16);
//        org.joda.time.DateTime dateTime19 = dateTime17.withSecondOfMinute(10);
//        org.joda.time.LocalDateTime localDateTime20 = dateTime19.toLocalDateTime();
//        java.lang.String str21 = dateTimeFormatter9.print((org.joda.time.ReadablePartial) localDateTime20);
//        try {
//            int int22 = monthDay7.compareTo((org.joda.time.ReadablePartial) localDateTime20);
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 22 + "'", int8 == 22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0049W123T105410.321" + "'", str21.equals("0049W123T105410.321"));
//    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.LocalDateTime localDateTime4 = dateTime2.toLocalDateTime();
//        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
//        long long6 = property5.remainder();
//        java.lang.String str7 = property5.toString();
//        org.joda.time.DurationField durationField8 = property5.getDurationField();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(localDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 212062432L + "'", long6 == 212062432L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[weekOfWeekyear]" + "'", str7.equals("Property[weekOfWeekyear]"));
//        org.junit.Assert.assertNotNull(durationField8);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GJChronology[+10:00,cutover=2019-06-15T20:56:43.615Z]", "10.0", 20, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffset((long) 166);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 20 + "'", int6 == 20);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.withFields(readablePartial9);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.YearMonthDay yearMonthDay12 = dateTime10.toYearMonthDay();
//        org.joda.time.DateTime.Property property13 = dateTime10.monthOfYear();
//        boolean boolean14 = dateTime10.isEqualNow();
//        org.joda.time.DateTime dateTime16 = dateTime10.minusSeconds((int) (byte) -1);
//        try {
//            org.joda.time.DateTime dateTime18 = dateTime10.withWeekOfWeekyear(0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
//        org.junit.Assert.assertNotNull(yearMonthDay12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.withFields(readablePartial9);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        int int12 = dateTime10.getDayOfYear();
//        org.joda.time.DateTime dateTime16 = dateTime10.withDate((int) (byte) -1, 10, (int) (short) 10);
//        org.joda.time.DateTime dateTime18 = dateTime16.withWeekyear(0);
//        org.joda.time.DateTime dateTime20 = dateTime16.minus(1560632170499L);
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, (org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, (org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.DateTime dateTime31 = dateTime28.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime28.withFields(readablePartial32);
//        org.joda.time.DateTime dateTime35 = dateTime33.withSecondOfMinute(10);
//        org.joda.time.LocalDateTime localDateTime36 = dateTime35.toLocalDateTime();
//        boolean boolean37 = dateTimeZone22.isLocalDateTimeGap(localDateTime36);
//        org.joda.time.DateTime dateTime38 = dateTime20.toDateTime(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 83 + "'", int12 == 83);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(copticChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(gJChronology29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(localDateTime36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTime38);
//    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
//        org.joda.time.Chronology chronology5 = copticChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology2.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime14.withFields(readablePartial18);
//        java.lang.String str20 = dateTimeFormatter9.print((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime.Property property21 = dateTime19.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, (org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
//        int int27 = property21.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime28 = property21.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
//        org.joda.time.DateTime.Property property34 = dateTime31.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        boolean boolean36 = dateTime28.isSupported(dateTimeFieldType35);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType35, (-35));
//        int int39 = offsetDateTimeField38.getMaximumValue();
//        int int40 = offsetDateTimeField38.getMinimumValue();
//        java.lang.String str42 = offsetDateTimeField38.getAsShortText((long) (-34));
//        java.util.Locale locale44 = null;
//        java.lang.String str45 = offsetDateTimeField38.getAsText((long) 13060, locale44);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(localDateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-34) + "'", int39 == (-34));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-34) + "'", int40 == (-34));
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "-34" + "'", str42.equals("-34"));
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "-34" + "'", str45.equals("-34"));
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology3.weekyearOfCentury();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) (short) 0, (org.joda.time.Chronology) copticChronology3);
        org.joda.time.MonthDay.Property property8 = monthDay7.dayOfMonth();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property8.getAsShortText(locale9);
        org.joda.time.DateTimeField dateTimeField11 = property8.getField();
        java.lang.String str12 = property8.toString();
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "22" + "'", str10.equals("22"));
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[dayOfMonth]" + "'", str12.equals("Property[dayOfMonth]"));
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
//        org.joda.time.Chronology chronology5 = copticChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology2.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime14.withFields(readablePartial18);
//        java.lang.String str20 = dateTimeFormatter9.print((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime.Property property21 = dateTime19.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, (org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
//        int int27 = property21.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime28 = property21.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
//        org.joda.time.DateTime.Property property34 = dateTime31.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        boolean boolean36 = dateTime28.isSupported(dateTimeFieldType35);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType35, (-35));
//        boolean boolean39 = offsetDateTimeField38.isSupported();
//        int int41 = offsetDateTimeField38.getLeapAmount(36500L);
//        org.joda.time.DateTimeField dateTimeField42 = offsetDateTimeField38.getWrappedField();
//        int int44 = offsetDateTimeField38.get((long) 0);
//        try {
//            long long46 = offsetDateTimeField38.roundHalfFloor((long) 24);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(localDateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-34) + "'", int44 == (-34));
//    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
//        org.joda.time.Chronology chronology5 = copticChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology2.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime14.withFields(readablePartial18);
//        java.lang.String str20 = dateTimeFormatter9.print((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime.Property property21 = dateTime19.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, (org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
//        int int27 = property21.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime28 = property21.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
//        org.joda.time.DateTime.Property property34 = dateTime31.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        boolean boolean36 = dateTime28.isSupported(dateTimeFieldType35);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType35, (-35));
//        int int39 = offsetDateTimeField38.getMaximumValue();
//        long long41 = offsetDateTimeField38.remainder(100L);
//        long long43 = offsetDateTimeField38.remainder((long) 100);
//        org.joda.time.DurationField durationField44 = offsetDateTimeField38.getRangeDurationField();
//        int int45 = offsetDateTimeField38.getMaximumValue();
//        int int46 = offsetDateTimeField38.getMinimumValue();
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(localDateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-34) + "'", int39 == (-34));
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 9223372036825975908L + "'", long41 == 9223372036825975908L);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036825975908L + "'", long43 == 9223372036825975908L);
//        org.junit.Assert.assertNull(durationField44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-34) + "'", int45 == (-34));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-34) + "'", int46 == (-34));
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime dateTime5 = dateTime2.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime2.withFields(readablePartial6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withSecondOfMinute(10);
//        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
//        int int11 = dateTime9.getYearOfCentury();
//        org.joda.time.DateTime dateTime13 = dateTime9.plusYears((-34));
//        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone15 = copticChronology14.getZone();
//        org.joda.time.MutableDateTime mutableDateTime16 = dateTime13.toMutableDateTime(dateTimeZone15);
//        int int17 = dateTime13.getDayOfWeek();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 49 + "'", int11 == 49);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(copticChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "Wed");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology3.weekyearOfCentury();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) (short) 0, (org.joda.time.Chronology) copticChronology3);
        org.joda.time.MonthDay.Property property8 = monthDay7.dayOfMonth();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property8.getAsShortText(locale9);
        int int11 = property8.getMaximumValue();
        int int12 = property8.get();
        org.joda.time.MonthDay monthDay14 = property8.addWrapFieldToCopy(12);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "22" + "'", str10.equals("22"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 30 + "'", int11 == 30);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 22 + "'", int12 == 22);
        org.junit.Assert.assertNotNull(monthDay14);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology2, dateTimeZone4);
        try {
            long long16 = zonedChronology8.getDateTimeMillis(30, 57600000, (int) (byte) 10, 1, 1970, (int) (byte) 10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(zonedChronology8);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.withFields(readablePartial9);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        int int12 = dateTime10.getDayOfYear();
//        org.joda.time.DateTime.Property property13 = dateTime10.secondOfMinute();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 83 + "'", int12 == 83);
//        org.junit.Assert.assertNotNull(property13);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GJChronology[+10:00,cutover=2019-06-15T20:56:43.615Z]", "10.0", 20, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
        org.joda.time.DurationField durationField7 = iSOChronology5.months();
        boolean boolean8 = fixedDateTimeZone4.equals((java.lang.Object) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        java.lang.Object obj2 = null;
        boolean boolean3 = gJChronology0.equals(obj2);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.Chronology chronology3 = buddhistChronology0.withZone(dateTimeZone2);
        org.joda.time.DurationField durationField4 = buddhistChronology0.halfdays();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone4, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology6.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology6.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology6.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.hourOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology6, dateTimeField13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipDateTimeField14.getAsShortText(2019, locale16);
//        java.lang.String str19 = skipDateTimeField14.getAsShortText(1L);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone20, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.centuryOfEra();
//        org.joda.time.Chronology chronology25 = copticChronology22.withUTC();
//        org.joda.time.DateTimeField dateTimeField26 = copticChronology22.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = copticChronology22.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField28 = copticChronology22.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter29.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33, (org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTime dateTime37 = dateTime34.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial38 = null;
//        org.joda.time.DateTime dateTime39 = dateTime34.withFields(readablePartial38);
//        java.lang.String str40 = dateTimeFormatter29.print((org.joda.time.ReadableInstant) dateTime39);
//        org.joda.time.DateTime.Property property41 = dateTime39.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone43, (org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.LocalDateTime localDateTime46 = dateTime44.toLocalDateTime();
//        int int47 = property41.getDifference((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTime dateTime48 = property41.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50, (org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.LocalDateTime localDateTime53 = dateTime51.toLocalDateTime();
//        org.joda.time.DateTime.Property property54 = dateTime51.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property54.getFieldType();
//        boolean boolean56 = dateTime48.isSupported(dateTimeFieldType55);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType55, (-35));
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField14, dateTimeFieldType55, 69, (int) (short) 0, (int) (short) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType55, (int) (short) 100);
//        long long66 = remainderDateTimeField64.roundCeiling((long) 365);
//        long long68 = remainderDateTimeField64.roundHalfCeiling((long) ' ');
//        long long70 = remainderDateTimeField64.roundHalfCeiling((long) ' ');
//        long long73 = remainderDateTimeField64.addWrapField((long) ' ', 10);
//        try {
//            long long75 = remainderDateTimeField64.roundFloor((-62174322795046L));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "16" + "'", str19.equals("16"));
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10" + "'", str40.equals("10"));
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(gJChronology45);
//        org.junit.Assert.assertNotNull(localDateTime46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(gJChronology52);
//        org.junit.Assert.assertNotNull(localDateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 22143600000L + "'", long66 == 22143600000L);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-9910800000L) + "'", long68 == (-9910800000L));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-9910800000L) + "'", long70 == (-9910800000L));
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 315705600032L + "'", long73 == 315705600032L);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = julianChronology4.withUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime dateTime14 = dateTime11.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime11.withFields(readablePartial15);
//        java.lang.String str17 = dateTimeFormatter6.print((org.joda.time.ReadableInstant) dateTime16);
//        int int18 = dateTime16.getDayOfYear();
//        org.joda.time.DateTime dateTime22 = dateTime16.withDate((int) (byte) -1, 10, (int) (short) 10);
//        int int23 = dateTime22.getDayOfMonth();
//        org.joda.time.DateTime dateTime25 = dateTime22.withYearOfEra(22);
//        boolean boolean26 = julianChronology4.equals((java.lang.Object) 22);
//        org.joda.time.DateTimeField dateTimeField27 = julianChronology4.hourOfDay();
//        int int28 = julianChronology4.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField29 = julianChronology4.monthOfYear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10" + "'", str17.equals("10"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 83 + "'", int18 == 83);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.withFields(readablePartial9);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        int int12 = dateTime10.getDayOfYear();
//        org.joda.time.DateTime dateTime16 = dateTime10.withDate((int) (byte) -1, 10, (int) (short) 10);
//        int int17 = dateTime16.getDayOfMonth();
//        org.joda.time.DateTime dateTime19 = dateTime16.withYearOfEra(22);
//        org.joda.time.DateTime.Property property20 = dateTime19.weekOfWeekyear();
//        boolean boolean21 = property20.isLeap();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.parse("2019-W24-6", dateTimeFormatter23);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((java.lang.Object) "2019-W24-6");
//        org.joda.time.DateTime dateTime27 = dateTime25.withWeekyear((int) '4');
//        long long28 = dateTime27.getMillis();
//        org.joda.time.DateTime.Property property29 = dateTime27.year();
//        boolean boolean30 = property20.equals((java.lang.Object) property29);
//        boolean boolean31 = property20.isLeap();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 83 + "'", int12 == 83);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-60511853222000L) + "'", long28 == (-60511853222000L));
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (byte) 100);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(960, 30, 960, 4, (int) (short) -1, 12, (-28800000), (org.joda.time.Chronology) iSOChronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(iSOChronology10);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.minus((long) (byte) 1);
        org.joda.time.Instant instant4 = instant2.minus((long) 2019);
        org.joda.time.Instant instant5 = instant4.toInstant();
        org.joda.time.Chronology chronology6 = instant4.getChronology();
        org.joda.time.Instant instant7 = instant4.toInstant();
        org.joda.time.MutableDateTime mutableDateTime8 = instant7.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.plus(readablePeriod1);
//        int int3 = dateTime0.getMinuteOfDay();
//        int int4 = dateTime0.getYearOfCentury();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 654 + "'", int3 == 654);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 49 + "'", int4 == 49);
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
//        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
//        java.lang.Appendable appendable3 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        long long13 = dateTimeZone8.getMillisKeepLocal(dateTimeZone11, 1560632192898L);
//        java.lang.String str15 = dateTimeZone11.getName((long) (byte) 100);
//        org.joda.time.Chronology chronology16 = iSOChronology4.withZone(dateTimeZone11);
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20, (org.joda.time.ReadableInstant) dateTime21);
//        org.joda.time.LocalDateTime localDateTime23 = dateTime21.toLocalDateTime();
//        org.joda.time.DateTime.Property property24 = dateTime21.dayOfYear();
//        int int25 = dateTime21.getMinuteOfDay();
//        org.joda.time.DateTime dateTime27 = dateTime21.withMillisOfDay(2019);
//        int int28 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime27);
//        try {
//            dateTimeFormatter1.printTo(appendable3, (org.joda.time.ReadableInstant) dateTime27);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNull(locale2);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(julianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560632192898L + "'", long13 == 1560632192898L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+10:00" + "'", str15.equals("+10:00"));
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(julianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(localDateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 654 + "'", int25 == 654);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 36000000 + "'", int28 == 36000000);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("Property[weekOfWeekyear]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: Property[weekOfWeekyear]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone4, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology6.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology6.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology6.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.hourOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology6, dateTimeField13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipDateTimeField14.getAsShortText(2019, locale16);
//        java.lang.String str19 = skipDateTimeField14.getAsShortText(1L);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone20, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.centuryOfEra();
//        org.joda.time.Chronology chronology25 = copticChronology22.withUTC();
//        org.joda.time.DateTimeField dateTimeField26 = copticChronology22.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = copticChronology22.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField28 = copticChronology22.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter29.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33, (org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTime dateTime37 = dateTime34.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial38 = null;
//        org.joda.time.DateTime dateTime39 = dateTime34.withFields(readablePartial38);
//        java.lang.String str40 = dateTimeFormatter29.print((org.joda.time.ReadableInstant) dateTime39);
//        org.joda.time.DateTime.Property property41 = dateTime39.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone43, (org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.LocalDateTime localDateTime46 = dateTime44.toLocalDateTime();
//        int int47 = property41.getDifference((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTime dateTime48 = property41.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50, (org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.LocalDateTime localDateTime53 = dateTime51.toLocalDateTime();
//        org.joda.time.DateTime.Property property54 = dateTime51.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property54.getFieldType();
//        boolean boolean56 = dateTime48.isSupported(dateTimeFieldType55);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType55, (-35));
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField14, dateTimeFieldType55, 69, (int) (short) 0, (int) (short) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType55, (int) (short) 100);
//        long long66 = remainderDateTimeField64.roundCeiling((long) 365);
//        long long68 = remainderDateTimeField64.roundHalfCeiling((long) ' ');
//        long long70 = remainderDateTimeField64.roundHalfCeiling((long) 83);
//        int int72 = remainderDateTimeField64.get((long) 0);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "16" + "'", str19.equals("16"));
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10" + "'", str40.equals("10"));
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(gJChronology45);
//        org.junit.Assert.assertNotNull(localDateTime46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(gJChronology52);
//        org.junit.Assert.assertNotNull(localDateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 22143600000L + "'", long66 == 22143600000L);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-9910800000L) + "'", long68 == (-9910800000L));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + (-9910800000L) + "'", long70 == (-9910800000L));
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 86 + "'", int72 == 86);
//    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.Chronology chronology5 = julianChronology4.withUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime dateTime14 = dateTime11.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime11.withFields(readablePartial15);
//        java.lang.String str17 = dateTimeFormatter6.print((org.joda.time.ReadableInstant) dateTime16);
//        int int18 = dateTime16.getDayOfYear();
//        org.joda.time.DateTime dateTime22 = dateTime16.withDate((int) (byte) -1, 10, (int) (short) 10);
//        int int23 = dateTime22.getDayOfMonth();
//        org.joda.time.DateTime dateTime25 = dateTime22.withYearOfEra(22);
//        boolean boolean26 = julianChronology4.equals((java.lang.Object) 22);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.Chronology chronology28 = julianChronology4.withZone(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(iSOChronology3);
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10" + "'", str17.equals("10"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 83 + "'", int18 == 83);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(chronology28);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime2.toLocalDateTime();
        org.joda.time.DateTime.Property property5 = dateTime2.millisOfSecond();
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
        int int7 = property6.getMaximumValueOverall();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.plus(readablePeriod9);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.plus(readableDuration11);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.MutableDateTime mutableDateTime14 = dateTime12.toMutableDateTime((org.joda.time.Chronology) copticChronology13);
        long long15 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1439 + "'", int7 == 1439);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime dateTime5 = dateTime2.withMillisOfDay((int) (byte) 10);
//        org.joda.time.DateTime dateTime7 = dateTime5.plus((long) 1);
//        int int8 = dateTime7.getDayOfWeek();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.withFields(readablePartial9);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.YearMonthDay yearMonthDay12 = dateTime10.toYearMonthDay();
//        org.joda.time.DateTime dateTime14 = dateTime10.plusMonths((int) (short) 1);
//        int int15 = dateTime10.getYearOfCentury();
//        org.joda.time.DateTime dateTime17 = dateTime10.plusWeeks(836);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
//        org.junit.Assert.assertNotNull(yearMonthDay12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 49 + "'", int15 == 49);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withLocale(locale2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime dateTime9 = dateTime6.withMillisOfDay((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = dateTime12.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.DateTime dateTime17 = dateTime12.withFields(readablePartial16);
        org.joda.time.DateTime dateTime19 = dateTime17.withSecondOfMinute(10);
        org.joda.time.DateTime dateTime20 = dateTime19.toDateTime();
        int int21 = dateTime9.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime23 = dateTime9.withWeekOfWeekyear(20);
        org.joda.time.DateTime dateTime25 = dateTime9.withYearOfEra(166);
        java.lang.String str26 = dateTimeFormatter3.print((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.Instant instant27 = org.joda.time.Instant.now();
        org.joda.time.Instant instant29 = instant27.minus((long) (byte) 1);
        org.joda.time.Instant instant31 = instant29.minus((long) 2019);
        org.joda.time.Instant instant32 = instant31.toInstant();
        org.joda.time.MutableDateTime mutableDateTime33 = instant31.toMutableDateTime();
        int int36 = dateTimeFormatter3.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime33, "weekOfWeekyear", 83);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "00" + "'", str26.equals("00"));
        org.junit.Assert.assertNotNull(instant27);
        org.junit.Assert.assertNotNull(instant29);
        org.junit.Assert.assertNotNull(instant31);
        org.junit.Assert.assertNotNull(instant32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-84) + "'", int36 == (-84));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.DateTime dateTime18 = dateTime13.withFields(readablePartial17);
        boolean boolean19 = copticChronology2.equals((java.lang.Object) dateTime13);
        org.joda.time.DateTime dateTime20 = dateTime13.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime22 = dateTime13.minusMillis(0);
        org.joda.time.DateTime dateTime24 = dateTime13.withDayOfYear(1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = skipDateTimeField10.getAsShortText(2019, locale12);
//        java.lang.String str15 = skipDateTimeField10.getAsShortText(1L);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone16, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = copticChronology18.centuryOfEra();
//        org.joda.time.Chronology chronology21 = copticChronology18.withUTC();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology18.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology18.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter25.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, (org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTime dateTime33 = dateTime30.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime30.withFields(readablePartial34);
//        java.lang.String str36 = dateTimeFormatter25.print((org.joda.time.ReadableInstant) dateTime35);
//        org.joda.time.DateTime.Property property37 = dateTime35.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone39, (org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.LocalDateTime localDateTime42 = dateTime40.toLocalDateTime();
//        int int43 = property37.getDifference((org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.DateTime dateTime44 = property37.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, (org.joda.time.ReadableInstant) dateTime47);
//        org.joda.time.LocalDateTime localDateTime49 = dateTime47.toLocalDateTime();
//        org.joda.time.DateTime.Property property50 = dateTime47.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
//        boolean boolean52 = dateTime44.isSupported(dateTimeFieldType51);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, dateTimeFieldType51, (-35));
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType51, 69, (int) (short) 0, (int) (short) 1);
//        long long60 = offsetDateTimeField58.roundHalfEven((long) 1439);
//        long long62 = offsetDateTimeField58.roundCeiling(365L);
//        try {
//            int int64 = offsetDateTimeField58.get((-62174322795046L));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "16" + "'", str15.equals("16"));
//        org.junit.Assert.assertNotNull(copticChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10" + "'", str36.equals("10"));
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(localDateTime42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(localDateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 3600000L + "'", long62 == 3600000L);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) ' ', (int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology3.weekyearOfCentury();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) (short) 0, (org.joda.time.Chronology) copticChronology3);
        org.joda.time.MonthDay.Property property8 = monthDay7.dayOfMonth();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property8.getAsShortText(locale9);
        org.joda.time.DateTimeField dateTimeField11 = property8.getField();
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(0L);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay15 = monthDay13.minus(readablePeriod14);
        org.joda.time.MonthDay monthDay17 = monthDay13.minusMonths(100);
        int int18 = property8.compareTo((org.joda.time.ReadablePartial) monthDay13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter19.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone21, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField24 = copticChronology23.hourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = dateTimeFormatter19.withChronology((org.joda.time.Chronology) copticChronology23);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter25.withPivotYear(9);
        java.lang.String str28 = monthDay13.toString(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "22" + "'", str10.equals("22"));
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "��:��:��" + "'", str28.equals("��:��:��"));
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = skipDateTimeField10.getAsShortText(2019, locale12);
//        java.lang.String str15 = skipDateTimeField10.getAsShortText(1L);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone16, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = copticChronology18.centuryOfEra();
//        org.joda.time.Chronology chronology21 = copticChronology18.withUTC();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology18.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology18.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter25.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, (org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTime dateTime33 = dateTime30.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime30.withFields(readablePartial34);
//        java.lang.String str36 = dateTimeFormatter25.print((org.joda.time.ReadableInstant) dateTime35);
//        org.joda.time.DateTime.Property property37 = dateTime35.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone39, (org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.LocalDateTime localDateTime42 = dateTime40.toLocalDateTime();
//        int int43 = property37.getDifference((org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.DateTime dateTime44 = property37.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, (org.joda.time.ReadableInstant) dateTime47);
//        org.joda.time.LocalDateTime localDateTime49 = dateTime47.toLocalDateTime();
//        org.joda.time.DateTime.Property property50 = dateTime47.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
//        boolean boolean52 = dateTime44.isSupported(dateTimeFieldType51);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, dateTimeFieldType51, (-35));
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType51, 69, (int) (short) 0, (int) (short) 1);
//        long long60 = offsetDateTimeField58.roundHalfEven((long) 1439);
//        long long62 = offsetDateTimeField58.roundHalfEven(1560632170499L);
//        org.joda.time.DateTimeField dateTimeField63 = offsetDateTimeField58.getWrappedField();
//        java.lang.String str65 = offsetDateTimeField58.getAsShortText((long) 365);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "16" + "'", str15.equals("16"));
//        org.junit.Assert.assertNotNull(copticChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10" + "'", str36.equals("10"));
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(localDateTime42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(localDateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560632400000L + "'", long62 == 1560632400000L);
//        org.junit.Assert.assertNotNull(dateTimeField63);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "85" + "'", str65.equals("85"));
//    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfHour();
//        org.joda.time.DurationField durationField2 = iSOChronology0.months();
//        org.joda.time.DurationField durationField3 = iSOChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfHalfday();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = dateTime10.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime10.withFields(readablePartial14);
//        java.lang.String str16 = dateTimeFormatter5.print((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime.Property property17 = dateTime15.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, (org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.LocalDateTime localDateTime22 = dateTime20.toLocalDateTime();
//        int int23 = property17.getDifference((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime24 = property17.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26, (org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.LocalDateTime localDateTime29 = dateTime27.toLocalDateTime();
//        org.joda.time.DateTime.Property property30 = dateTime27.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        boolean boolean32 = dateTime24.isSupported(dateTimeFieldType31);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType31, (int) '#', (int) (short) -1, 1);
//        int int38 = offsetDateTimeField36.get((long) 836);
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField36.getType();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10" + "'", str16.equals("10"));
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(localDateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(localDateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 39 + "'", int38 == 39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType39);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType2);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
//        org.joda.time.Chronology chronology8 = julianChronology7.withUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime14.withFields(readablePartial18);
//        java.lang.String str20 = dateTimeFormatter9.print((org.joda.time.ReadableInstant) dateTime19);
//        int int21 = dateTime19.getDayOfYear();
//        org.joda.time.DateTime dateTime25 = dateTime19.withDate((int) (byte) -1, 10, (int) (short) 10);
//        int int26 = dateTime25.getDayOfMonth();
//        org.joda.time.DateTime dateTime28 = dateTime25.withYearOfEra(22);
//        boolean boolean29 = julianChronology7.equals((java.lang.Object) 22);
//        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology7.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone31 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone30);
//        org.joda.time.Chronology chronology32 = gregorianChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone31);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone33, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField37 = copticChronology35.centuryOfEra();
//        org.joda.time.Chronology chronology38 = copticChronology35.withUTC();
//        org.joda.time.DateTimeField dateTimeField39 = copticChronology35.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField40 = copticChronology35.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField41 = copticChronology35.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter42.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, (org.joda.time.ReadableInstant) dateTime47);
//        org.joda.time.DateTime dateTime50 = dateTime47.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial51 = null;
//        org.joda.time.DateTime dateTime52 = dateTime47.withFields(readablePartial51);
//        java.lang.String str53 = dateTimeFormatter42.print((org.joda.time.ReadableInstant) dateTime52);
//        org.joda.time.DateTime.Property property54 = dateTime52.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime57 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone56, (org.joda.time.ReadableInstant) dateTime57);
//        org.joda.time.LocalDateTime localDateTime59 = dateTime57.toLocalDateTime();
//        int int60 = property54.getDifference((org.joda.time.ReadableInstant) dateTime57);
//        org.joda.time.DateTime dateTime61 = property54.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone63 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone63, (org.joda.time.ReadableInstant) dateTime64);
//        org.joda.time.LocalDateTime localDateTime66 = dateTime64.toLocalDateTime();
//        org.joda.time.DateTime.Property property67 = dateTime64.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType68 = property67.getFieldType();
//        boolean boolean69 = dateTime61.isSupported(dateTimeFieldType68);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField71 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, dateTimeFieldType68, (-35));
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField73 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology2, (org.joda.time.DateTimeField) offsetDateTimeField71, 1);
//        org.joda.time.Chronology chronology74 = gregorianChronology2.withUTC();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 83 + "'", int21 == 83);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone31);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(copticChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(chronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "10" + "'", str53.equals("10"));
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(gJChronology58);
//        org.junit.Assert.assertNotNull(localDateTime59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(dateTimeZone63);
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(gJChronology65);
//        org.junit.Assert.assertNotNull(localDateTime66);
//        org.junit.Assert.assertNotNull(property67);
//        org.junit.Assert.assertNotNull(dateTimeFieldType68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
//        org.junit.Assert.assertNotNull(chronology74);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("2019-W24-6", dateTimeFormatter1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) "2019-W24-6");
        org.joda.time.DateTime.Property property4 = dateTime3.year();
        java.lang.String str5 = property4.toString();
        org.joda.time.DateTime dateTime6 = property4.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(monthDay2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Property[year]" + "'", str5.equals("Property[year]"));
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        long long1 = dateTime0.getMillis();
//        int int2 = dateTime0.getMillisOfSecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-60613679552086L) + "'", long1 == (-60613679552086L));
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 914 + "'", int2 == 914);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField10.getAsShortText(2019, locale12);
        java.lang.String str15 = skipDateTimeField10.getAsShortText(1L);
        int int17 = skipDateTimeField10.get(0L);
        java.util.Locale locale19 = null;
        java.lang.String str20 = skipDateTimeField10.getAsShortText((int) 'a', locale19);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "16" + "'", str15.equals("16"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "97" + "'", str20.equals("97"));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology3.weekyearOfCentury();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) (short) 0, (org.joda.time.Chronology) copticChronology3);
        org.joda.time.MonthDay.Property property8 = monthDay7.dayOfMonth();
        java.lang.String str9 = property8.getAsShortText();
        java.util.Locale locale10 = null;
        int int11 = property8.getMaximumShortTextLength(locale10);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "22" + "'", str9.equals("22"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("13", "");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        java.lang.String str5 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Number number6 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField10.getAsShortText(2019, locale12);
        java.lang.String str15 = skipDateTimeField10.getAsShortText(1L);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone17, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology19.hourOfDay();
        org.joda.time.DateTimeField dateTimeField21 = copticChronology19.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField22 = copticChronology19.weekyearOfCentury();
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((long) (short) 0, (org.joda.time.Chronology) copticChronology19);
        org.joda.time.MonthDay.Property property24 = monthDay23.dayOfMonth();
        org.joda.time.LocalDate localDate26 = monthDay23.toLocalDate(2019);
        int[] intArray28 = null;
        java.util.Locale locale30 = null;
        try {
            int[] intArray31 = skipDateTimeField10.set((org.joda.time.ReadablePartial) monthDay23, 20, intArray28, "", locale30);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for hourOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "16" + "'", str15.equals("16"));
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(localDate26);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        long long13 = skipDateTimeField10.addWrapField(0L, (int) (short) -1);
        org.joda.time.DurationField durationField14 = skipDateTimeField10.getDurationField();
        org.joda.time.DurationField durationField15 = skipDateTimeField10.getLeapDurationField();
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField10.getAsText((long) 0, locale17);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-3600000L) + "'", long13 == (-3600000L));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "16" + "'", str18.equals("16"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.plus(readablePeriod1);
        org.joda.time.DateTime.Property property3 = dateTime0.yearOfEra();
        org.joda.time.DateTime dateTime5 = dateTime0.plusSeconds(0);
        org.joda.time.DateTime dateTime7 = dateTime0.withWeekyear(654);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        long long9 = dateTimeZone4.getMillisKeepLocal(dateTimeZone7, 1560632192898L);
//        java.lang.String str11 = dateTimeZone7.getName((long) (byte) 100);
//        org.joda.time.Chronology chronology12 = iSOChronology0.withZone(dateTimeZone7);
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, (org.joda.time.ReadableInstant) dateTime17);
//        org.joda.time.LocalDateTime localDateTime19 = dateTime17.toLocalDateTime();
//        org.joda.time.DateTime.Property property20 = dateTime17.dayOfYear();
//        int int21 = dateTime17.getMinuteOfDay();
//        org.joda.time.DateTime dateTime23 = dateTime17.withMillisOfDay(2019);
//        int int24 = dateTimeZone14.getOffset((org.joda.time.ReadableInstant) dateTime23);
//        boolean boolean26 = dateTimeZone14.isStandardOffset(1L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560632192898L + "'", long9 == 1560632192898L);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+10:00" + "'", str11.equals("+10:00"));
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 654 + "'", int21 == 654);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 36000000 + "'", int24 == 36000000);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology3.weekyearOfCentury();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) (short) 0, (org.joda.time.Chronology) copticChronology3);
        org.joda.time.MonthDay.Property property8 = monthDay7.dayOfMonth();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property8.getAsShortText(locale9);
        int int11 = property8.getMaximumValue();
        int int12 = property8.get();
        java.lang.String str13 = property8.getAsText();
        java.lang.String str14 = property8.getAsString();
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "22" + "'", str10.equals("22"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 30 + "'", int11 == 30);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 22 + "'", int12 == 22);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "22" + "'", str13.equals("22"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "22" + "'", str14.equals("22"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTime dateTime5 = dateTime2.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.withFields(readablePartial6);
        org.joda.time.DateTime dateTime9 = dateTime7.withSecondOfMinute(10);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTime();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology19 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology13, dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone20 = zonedChronology19.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology21.minuteOfDay();
        boolean boolean24 = zonedChronology19.equals((java.lang.Object) dateTimeField23);
        org.joda.time.Chronology chronology25 = zonedChronology19.withUTC();
        org.joda.time.DateTime dateTime26 = dateTime9.toDateTime(chronology25);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(zonedChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        long long13 = skipDateTimeField10.addWrapField(0L, (int) (short) -1);
        org.joda.time.DurationField durationField14 = skipDateTimeField10.getDurationField();
        org.joda.time.DurationField durationField15 = skipDateTimeField10.getLeapDurationField();
        java.util.Locale locale17 = null;
        java.lang.String str18 = skipDateTimeField10.getAsShortText(23, locale17);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-3600000L) + "'", long13 == (-3600000L));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "23" + "'", str18.equals("23"));
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.withFields(readablePartial9);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        int int12 = dateTime10.getDayOfYear();
//        org.joda.time.DateTime dateTime16 = dateTime10.withDate((int) (byte) -1, 10, (int) (short) 10);
//        int int17 = dateTime16.getDayOfMonth();
//        org.joda.time.DateTime dateTime19 = dateTime16.withYearOfEra(22);
//        org.joda.time.DateTime dateTime20 = dateTime19.withEarlierOffsetAtOverlap();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 83 + "'", int12 == 83);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str1.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.Instant instant1 = org.joda.time.Instant.now();
        org.joda.time.Instant instant3 = instant1.minus((long) (byte) 1);
        org.joda.time.Instant instant5 = instant3.minus((long) 2019);
        org.joda.time.Instant instant6 = instant5.toInstant();
        org.joda.time.MutableDateTime mutableDateTime7 = instant5.toMutableDateTime();
        org.joda.time.Chronology chronology8 = mutableDateTime7.getChronology();
        int int11 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime7, "84", 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(instant1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-3) + "'", int11 == (-3));
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
//        org.joda.time.Chronology chronology5 = copticChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology2.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime14.withFields(readablePartial18);
//        java.lang.String str20 = dateTimeFormatter9.print((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime.Property property21 = dateTime19.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, (org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
//        int int27 = property21.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime28 = property21.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
//        org.joda.time.DateTime.Property property34 = dateTime31.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        boolean boolean36 = dateTime28.isSupported(dateTimeFieldType35);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType35, (-35));
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = buddhistChronology39.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField40);
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = unsupportedDateTimeField41.getType();
//        java.util.Locale locale44 = null;
//        try {
//            java.lang.String str45 = unsupportedDateTimeField41.getAsShortText(10L, locale44);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(localDateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone4, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology6.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology6.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology6.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.hourOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology6, dateTimeField13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipDateTimeField14.getAsShortText(2019, locale16);
//        java.lang.String str19 = skipDateTimeField14.getAsShortText(1L);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone20, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.centuryOfEra();
//        org.joda.time.Chronology chronology25 = copticChronology22.withUTC();
//        org.joda.time.DateTimeField dateTimeField26 = copticChronology22.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = copticChronology22.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField28 = copticChronology22.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter29.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33, (org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTime dateTime37 = dateTime34.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial38 = null;
//        org.joda.time.DateTime dateTime39 = dateTime34.withFields(readablePartial38);
//        java.lang.String str40 = dateTimeFormatter29.print((org.joda.time.ReadableInstant) dateTime39);
//        org.joda.time.DateTime.Property property41 = dateTime39.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone43, (org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.LocalDateTime localDateTime46 = dateTime44.toLocalDateTime();
//        int int47 = property41.getDifference((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTime dateTime48 = property41.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50, (org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.LocalDateTime localDateTime53 = dateTime51.toLocalDateTime();
//        org.joda.time.DateTime.Property property54 = dateTime51.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property54.getFieldType();
//        boolean boolean56 = dateTime48.isSupported(dateTimeFieldType55);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType55, (-35));
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField14, dateTimeFieldType55, 69, (int) (short) 0, (int) (short) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType55, (int) (short) 100);
//        long long66 = remainderDateTimeField64.remainder((long) ' ');
//        org.joda.time.DurationField durationField67 = remainderDateTimeField64.getDurationField();
//        java.util.Locale locale70 = null;
//        try {
//            long long71 = remainderDateTimeField64.set((-60613679602950L), "-34", locale70);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -34 for weekOfWeekyear must be in the range [0,99]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "16" + "'", str19.equals("16"));
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10" + "'", str40.equals("10"));
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(gJChronology45);
//        org.junit.Assert.assertNotNull(localDateTime46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(gJChronology52);
//        org.junit.Assert.assertNotNull(localDateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 9907200032L + "'", long66 == 9907200032L);
//        org.junit.Assert.assertNotNull(durationField67);
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = skipDateTimeField10.getAsShortText(2019, locale12);
//        java.lang.String str15 = skipDateTimeField10.getAsShortText(1L);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone16, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = copticChronology18.centuryOfEra();
//        org.joda.time.Chronology chronology21 = copticChronology18.withUTC();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology18.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology18.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter25.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, (org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTime dateTime33 = dateTime30.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime30.withFields(readablePartial34);
//        java.lang.String str36 = dateTimeFormatter25.print((org.joda.time.ReadableInstant) dateTime35);
//        org.joda.time.DateTime.Property property37 = dateTime35.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone39, (org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.LocalDateTime localDateTime42 = dateTime40.toLocalDateTime();
//        int int43 = property37.getDifference((org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.DateTime dateTime44 = property37.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, (org.joda.time.ReadableInstant) dateTime47);
//        org.joda.time.LocalDateTime localDateTime49 = dateTime47.toLocalDateTime();
//        org.joda.time.DateTime.Property property50 = dateTime47.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
//        boolean boolean52 = dateTime44.isSupported(dateTimeFieldType51);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, dateTimeFieldType51, (-35));
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType51, 69, (int) (short) 0, (int) (short) 1);
//        int int60 = offsetDateTimeField58.getMinimumValue((long) 836);
//        long long62 = offsetDateTimeField58.roundHalfCeiling((long) 914);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "16" + "'", str15.equals("16"));
//        org.junit.Assert.assertNotNull(copticChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10" + "'", str36.equals("10"));
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(localDateTime42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(localDateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 70 + "'", int60 == 70);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
//    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.withFields(readablePartial9);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property12 = dateTime10.dayOfWeek();
//        org.joda.time.DateTime dateTime13 = property12.roundHalfFloorCopy();
//        boolean boolean15 = dateTime13.isAfter((-115260021L));
//        int int16 = dateTime13.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField10.getAsShortText(2019, locale12);
        java.lang.String str15 = skipDateTimeField10.getAsShortText(1L);
        int int17 = skipDateTimeField10.get(0L);
        java.lang.String str18 = skipDateTimeField10.getName();
        int int19 = skipDateTimeField10.getMaximumValue();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "16" + "'", str15.equals("16"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "hourOfDay" + "'", str18.equals("hourOfDay"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 23 + "'", int19 == 23);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        long long6 = dateTimeZone1.getMillisKeepLocal(dateTimeZone4, 1560632192898L);
//        java.lang.String str8 = dateTimeZone4.getName((long) (byte) 100);
//        java.lang.Class<?> wildcardClass9 = dateTimeZone4.getClass();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter10.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime18 = dateTime15.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime15.withFields(readablePartial19);
//        java.lang.String str21 = dateTimeFormatter10.print((org.joda.time.ReadableInstant) dateTime20);
//        int int22 = dateTime20.getDayOfYear();
//        org.joda.time.DateTime dateTime26 = dateTime20.withDate((int) (byte) -1, 10, (int) (short) 10);
//        long long27 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime26);
//        org.joda.time.DateTime.Property property29 = dateTime26.secondOfMinute();
//        org.joda.time.DateTime.Property property30 = dateTime26.dayOfYear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560632192898L + "'", long6 == 1560632192898L);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+10:00" + "'", str8.equals("+10:00"));
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "10" + "'", str21.equals("10"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 83 + "'", int22 == 83);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-62174322748997L) + "'", long27 == (-62174322748997L));
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(property30);
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone4, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology6.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology6.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology6.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.hourOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology6, dateTimeField13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipDateTimeField14.getAsShortText(2019, locale16);
//        java.lang.String str19 = skipDateTimeField14.getAsShortText(1L);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone20, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.centuryOfEra();
//        org.joda.time.Chronology chronology25 = copticChronology22.withUTC();
//        org.joda.time.DateTimeField dateTimeField26 = copticChronology22.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = copticChronology22.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField28 = copticChronology22.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter29.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33, (org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTime dateTime37 = dateTime34.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial38 = null;
//        org.joda.time.DateTime dateTime39 = dateTime34.withFields(readablePartial38);
//        java.lang.String str40 = dateTimeFormatter29.print((org.joda.time.ReadableInstant) dateTime39);
//        org.joda.time.DateTime.Property property41 = dateTime39.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone43, (org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.LocalDateTime localDateTime46 = dateTime44.toLocalDateTime();
//        int int47 = property41.getDifference((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTime dateTime48 = property41.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50, (org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.LocalDateTime localDateTime53 = dateTime51.toLocalDateTime();
//        org.joda.time.DateTime.Property property54 = dateTime51.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property54.getFieldType();
//        boolean boolean56 = dateTime48.isSupported(dateTimeFieldType55);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType55, (-35));
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField14, dateTimeFieldType55, 69, (int) (short) 0, (int) (short) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType55, (int) (short) 100);
//        long long66 = remainderDateTimeField64.roundCeiling((long) 365);
//        org.joda.time.DurationField durationField67 = remainderDateTimeField64.getRangeDurationField();
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "16" + "'", str19.equals("16"));
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10" + "'", str40.equals("10"));
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(gJChronology45);
//        org.junit.Assert.assertNotNull(localDateTime46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(gJChronology52);
//        org.junit.Assert.assertNotNull(localDateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 22143600000L + "'", long66 == 22143600000L);
//        org.junit.Assert.assertNotNull(durationField67);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("GJChronology[+10:00,cutover=2019-06-15T20:56:38.423Z]");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.lang.String str3 = jodaTimePermission1.getActions();
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("GJChronology[+10:00,cutover=2019-06-15T20:56:38.423Z]");
        boolean boolean6 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime12 = dateTime9.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTime dateTime14 = dateTime9.withFields(readablePartial13);
        org.joda.time.DateTime dateTime16 = dateTime14.withSecondOfMinute(10);
        org.joda.time.DateTime dateTime18 = dateTime16.withYear((int) (short) 0);
        org.joda.time.DateTime dateTime19 = dateTime16.withLaterOffsetAtOverlap();
        jodaTimePermission5.checkGuard((java.lang.Object) dateTime16);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime16.minus(readableDuration21);
        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
        org.joda.time.DateTime dateTime25 = dateTime22.plusMinutes(9);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"GJChronology[+10:00,cutover=2019-06-15T20:56:38.423Z]\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"GJChronology[+10:00,cutover=2019-06-15T20:56:38.423Z]\")"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("4", dateTimeFormatter1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology4);
        org.joda.time.DateTimeField dateTimeField6 = julianChronology4.monthOfYear();
        org.joda.time.DurationField durationField7 = julianChronology4.hours();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GJChronology[+10:00,cutover=2019-06-15T20:56:43.615Z]", "10.0", 20, (int) (byte) 10);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 49);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) 30);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10.0" + "'", str6.equals("10.0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 20 + "'", int8 == 20);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.withFields(readablePartial9);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property12 = dateTime10.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.LocalDateTime localDateTime17 = dateTime15.toLocalDateTime();
//        int int18 = property12.getDifference((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime19 = property12.roundFloorCopy();
//        int int20 = dateTime19.getSecondOfDay();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(localDateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology3.weekyearOfCentury();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) (short) 0, (org.joda.time.Chronology) copticChronology3);
        org.joda.time.MonthDay.Property property8 = monthDay7.dayOfMonth();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property8.getAsShortText(locale9);
        int int11 = property8.getMaximumValue();
        java.util.Locale locale12 = null;
        int int13 = property8.getMaximumShortTextLength(locale12);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField18 = copticChronology17.hourOfDay();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology17.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology17.weekyearOfCentury();
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((long) (short) 0, (org.joda.time.Chronology) copticChronology17);
        int int22 = monthDay21.getDayOfMonth();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray23 = monthDay21.getFieldTypes();
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(0L);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.MonthDay monthDay27 = monthDay25.minus(readablePeriod26);
        org.joda.time.MonthDay monthDay29 = monthDay25.minusMonths(100);
        boolean boolean30 = monthDay21.isEqual((org.joda.time.ReadablePartial) monthDay25);
        int int31 = property8.compareTo((org.joda.time.ReadablePartial) monthDay25);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "22" + "'", str10.equals("22"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 30 + "'", int11 == 30);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 22 + "'", int22 == 22);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray23);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfHour();
        org.joda.time.DurationField durationField2 = iSOChronology0.months();
        org.joda.time.DurationField durationField3 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfHalfday();
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatterBuilder0.toFormatter();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Both printing and parsing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime2.toLocalDateTime();
        org.joda.time.DateTime.Property property5 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = property5.withMinimumValue();
        java.lang.String str7 = property5.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[millisOfSecond]" + "'", str7.equals("Property[millisOfSecond]"));
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        long long9 = copticChronology2.add(readablePeriod6, 0L, (int) (byte) 100);
//        org.joda.time.DurationField durationField10 = copticChronology2.days();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
//        org.joda.time.Chronology chronology16 = julianChronology15.withUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter17.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTime dateTime25 = dateTime22.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime22.withFields(readablePartial26);
//        java.lang.String str28 = dateTimeFormatter17.print((org.joda.time.ReadableInstant) dateTime27);
//        int int29 = dateTime27.getDayOfYear();
//        org.joda.time.DateTime dateTime33 = dateTime27.withDate((int) (byte) -1, 10, (int) (short) 10);
//        int int34 = dateTime33.getDayOfMonth();
//        org.joda.time.DateTime dateTime36 = dateTime33.withYearOfEra(22);
//        boolean boolean37 = julianChronology15.equals((java.lang.Object) 22);
//        org.joda.time.DateTimeZone dateTimeZone38 = julianChronology15.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone39 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone38);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.tTime();
//        boolean boolean41 = cachedDateTimeZone39.equals((java.lang.Object) dateTimeFormatter40);
//        long long43 = cachedDateTimeZone39.nextTransition((-60613679583090L));
//        boolean boolean44 = cachedDateTimeZone39.isFixed();
//        org.joda.time.chrono.ZonedChronology zonedChronology45 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology2, (org.joda.time.DateTimeZone) cachedDateTimeZone39);
//        org.joda.time.DateTimeField dateTimeField46 = zonedChronology45.secondOfMinute();
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(julianChronology15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "10" + "'", str28.equals("10"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 83 + "'", int29 == 83);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-60613679583090L) + "'", long43 == (-60613679583090L));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertNotNull(zonedChronology45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone4, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology6.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology6.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology6.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField13 = copticChronology12.hourOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField14 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology6, dateTimeField13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipDateTimeField14.getAsShortText(2019, locale16);
//        java.lang.String str19 = skipDateTimeField14.getAsShortText(1L);
//        org.joda.time.DateTimeZone dateTimeZone20 = null;
//        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone20, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology22.centuryOfEra();
//        org.joda.time.Chronology chronology25 = copticChronology22.withUTC();
//        org.joda.time.DateTimeField dateTimeField26 = copticChronology22.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = copticChronology22.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField28 = copticChronology22.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter29.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33, (org.joda.time.ReadableInstant) dateTime34);
//        org.joda.time.DateTime dateTime37 = dateTime34.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial38 = null;
//        org.joda.time.DateTime dateTime39 = dateTime34.withFields(readablePartial38);
//        java.lang.String str40 = dateTimeFormatter29.print((org.joda.time.ReadableInstant) dateTime39);
//        org.joda.time.DateTime.Property property41 = dateTime39.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone43, (org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.LocalDateTime localDateTime46 = dateTime44.toLocalDateTime();
//        int int47 = property41.getDifference((org.joda.time.ReadableInstant) dateTime44);
//        org.joda.time.DateTime dateTime48 = property41.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50, (org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.LocalDateTime localDateTime53 = dateTime51.toLocalDateTime();
//        org.joda.time.DateTime.Property property54 = dateTime51.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property54.getFieldType();
//        boolean boolean56 = dateTime48.isSupported(dateTimeFieldType55);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, dateTimeFieldType55, (-35));
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField14, dateTimeFieldType55, 69, (int) (short) 0, (int) (short) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dateTimeField3, dateTimeFieldType55, (int) (short) 100);
//        long long66 = remainderDateTimeField64.roundCeiling((long) 365);
//        long long68 = remainderDateTimeField64.roundFloor((long) 1970);
//        long long71 = remainderDateTimeField64.add((long) 53, 0);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(copticChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "16" + "'", str19.equals("16"));
//        org.junit.Assert.assertNotNull(copticChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter31);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gJChronology35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10" + "'", str40.equals("10"));
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(gJChronology45);
//        org.junit.Assert.assertNotNull(localDateTime46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(gJChronology52);
//        org.junit.Assert.assertNotNull(localDateTime53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 22143600000L + "'", long66 == 22143600000L);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-9910800000L) + "'", long68 == (-9910800000L));
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 53L + "'", long71 == 53L);
//    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology5.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.hourOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology5, dateTimeField12);
//        long long16 = skipDateTimeField13.addWrapField(0L, (int) (short) -1);
//        long long19 = skipDateTimeField13.add((long) (short) 10, 22);
//        java.lang.String str21 = skipDateTimeField13.getAsShortText((long) (-34));
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone22, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField25 = copticChronology24.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField26 = copticChronology24.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = copticChronology24.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.chrono.CopticChronology copticChronology30 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone28, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField31 = copticChronology30.hourOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField32 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology24, dateTimeField31);
//        java.util.Locale locale34 = null;
//        java.lang.String str35 = skipDateTimeField32.getAsShortText(2019, locale34);
//        java.lang.String str37 = skipDateTimeField32.getAsShortText(1L);
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.CopticChronology copticChronology40 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone38, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField41 = copticChronology40.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField42 = copticChronology40.centuryOfEra();
//        org.joda.time.Chronology chronology43 = copticChronology40.withUTC();
//        org.joda.time.DateTimeField dateTimeField44 = copticChronology40.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField45 = copticChronology40.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField46 = copticChronology40.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = dateTimeFormatter47.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone51, (org.joda.time.ReadableInstant) dateTime52);
//        org.joda.time.DateTime dateTime55 = dateTime52.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial56 = null;
//        org.joda.time.DateTime dateTime57 = dateTime52.withFields(readablePartial56);
//        java.lang.String str58 = dateTimeFormatter47.print((org.joda.time.ReadableInstant) dateTime57);
//        org.joda.time.DateTime.Property property59 = dateTime57.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime62 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone61, (org.joda.time.ReadableInstant) dateTime62);
//        org.joda.time.LocalDateTime localDateTime64 = dateTime62.toLocalDateTime();
//        int int65 = property59.getDifference((org.joda.time.ReadableInstant) dateTime62);
//        org.joda.time.DateTime dateTime66 = property59.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology70 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone68, (org.joda.time.ReadableInstant) dateTime69);
//        org.joda.time.LocalDateTime localDateTime71 = dateTime69.toLocalDateTime();
//        org.joda.time.DateTime.Property property72 = dateTime69.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType73 = property72.getFieldType();
//        boolean boolean74 = dateTime66.isSupported(dateTimeFieldType73);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField76 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, dateTimeFieldType73, (-35));
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField80 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField32, dateTimeFieldType73, 69, (int) (short) 0, (int) (short) 1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField81 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField13, dateTimeFieldType73);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField82 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField81);
//        org.joda.time.DurationField durationField83 = gJChronology0.eras();
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(copticChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-3600000L) + "'", long16 == (-3600000L));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 79200010L + "'", long19 == 79200010L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "15" + "'", str21.equals("15"));
//        org.junit.Assert.assertNotNull(copticChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(copticChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "16" + "'", str37.equals("16"));
//        org.junit.Assert.assertNotNull(copticChronology40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(chronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertNotNull(dateTimeFormatter47);
//        org.junit.Assert.assertNotNull(dateTimeFormatter49);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(gJChronology53);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "10" + "'", str58.equals("10"));
//        org.junit.Assert.assertNotNull(property59);
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(gJChronology63);
//        org.junit.Assert.assertNotNull(localDateTime64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(gJChronology70);
//        org.junit.Assert.assertNotNull(localDateTime71);
//        org.junit.Assert.assertNotNull(property72);
//        org.junit.Assert.assertNotNull(dateTimeFieldType73);
//        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
//        org.junit.Assert.assertNotNull(durationField83);
//    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfHour();
//        org.joda.time.DurationField durationField2 = iSOChronology0.months();
//        org.joda.time.DurationField durationField3 = iSOChronology0.weeks();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfHalfday();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime dateTime13 = dateTime10.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime10.withFields(readablePartial14);
//        java.lang.String str16 = dateTimeFormatter5.print((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime.Property property17 = dateTime15.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19, (org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.LocalDateTime localDateTime22 = dateTime20.toLocalDateTime();
//        int int23 = property17.getDifference((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime24 = property17.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone26, (org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.LocalDateTime localDateTime29 = dateTime27.toLocalDateTime();
//        org.joda.time.DateTime.Property property30 = dateTime27.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property30.getFieldType();
//        boolean boolean32 = dateTime24.isSupported(dateTimeFieldType31);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType31, (int) '#', (int) (short) -1, 1);
//        java.util.Locale locale38 = null;
//        java.lang.String str39 = offsetDateTimeField36.getAsShortText(3, locale38);
//        org.joda.time.DurationField durationField40 = offsetDateTimeField36.getLeapDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "10" + "'", str16.equals("10"));
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertNotNull(localDateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(localDateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "3" + "'", str39.equals("3"));
//        org.junit.Assert.assertNull(durationField40);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("GJChronology[+10:00,cutover=2019-06-15T20:56:38.423Z]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: GJChronology[+10:00,cutover=2019-06-15T20:56:38.423Z]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.withFields(readablePartial9);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        int int12 = dateTime10.getDayOfYear();
//        org.joda.time.DateTime dateTime16 = dateTime10.withDate((int) (byte) -1, 10, (int) (short) 10);
//        int int17 = dateTime16.getDayOfMonth();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (short) 10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 83 + "'", int12 == 83);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTime dateTime5 = dateTime2.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime2.withFields(readablePartial6);
//        boolean boolean8 = dateTime2.isBeforeNow();
//        org.joda.time.DateTime.Property property9 = dateTime2.minuteOfHour();
//        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
//        org.joda.time.DateTime dateTime12 = dateTime10.withCenturyOfEra(1970);
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime10.minus(readableDuration13);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfHour();
        org.joda.time.DurationField durationField2 = iSOChronology0.months();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime10 = dateTime7.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial11 = null;
        org.joda.time.DateTime dateTime12 = dateTime7.withFields(readablePartial11);
        boolean boolean13 = iSOChronology0.equals((java.lang.Object) readablePartial11);
        boolean boolean15 = iSOChronology0.equals((java.lang.Object) "hi!");
        try {
            long long21 = iSOChronology0.getDateTimeMillis(0L, (-35), 70, (int) (short) 0, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.lang.Appendable appendable2 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.LocalDateTime localDateTime7 = dateTime5.toLocalDateTime();
        org.joda.time.DateTime.Property property8 = dateTime5.millisOfSecond();
        try {
            dateTimeFormatter1.printTo(appendable2, (org.joda.time.ReadableInstant) dateTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
        org.joda.time.LocalDate localDate2 = monthDay0.toLocalDate(960);
        java.util.Locale locale4 = null;
        try {
            java.lang.String str5 = monthDay0.toString("UTC", locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: U");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate2);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = skipDateTimeField10.getAsShortText(2019, locale12);
//        java.lang.String str15 = skipDateTimeField10.getAsShortText(1L);
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone16, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField20 = copticChronology18.centuryOfEra();
//        org.joda.time.Chronology chronology21 = copticChronology18.withUTC();
//        org.joda.time.DateTimeField dateTimeField22 = copticChronology18.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField24 = copticChronology18.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter25.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, (org.joda.time.ReadableInstant) dateTime30);
//        org.joda.time.DateTime dateTime33 = dateTime30.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime30.withFields(readablePartial34);
//        java.lang.String str36 = dateTimeFormatter25.print((org.joda.time.ReadableInstant) dateTime35);
//        org.joda.time.DateTime.Property property37 = dateTime35.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone39, (org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.LocalDateTime localDateTime42 = dateTime40.toLocalDateTime();
//        int int43 = property37.getDifference((org.joda.time.ReadableInstant) dateTime40);
//        org.joda.time.DateTime dateTime44 = property37.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, (org.joda.time.ReadableInstant) dateTime47);
//        org.joda.time.LocalDateTime localDateTime49 = dateTime47.toLocalDateTime();
//        org.joda.time.DateTime.Property property50 = dateTime47.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
//        boolean boolean52 = dateTime44.isSupported(dateTimeFieldType51);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, dateTimeFieldType51, (-35));
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType51, 69, (int) (short) 0, (int) (short) 1);
//        long long60 = offsetDateTimeField58.roundHalfEven((long) 1439);
//        long long62 = offsetDateTimeField58.roundCeiling((long) '4');
//        java.util.Locale locale64 = null;
//        java.lang.String str65 = offsetDateTimeField58.getAsShortText(0L, locale64);
//        java.util.Locale locale68 = null;
//        try {
//            long long69 = offsetDateTimeField58.set((long) 40, "4", locale68);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for weekOfWeekyear must be in the range [70,1]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(copticChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "16" + "'", str15.equals("16"));
//        org.junit.Assert.assertNotNull(copticChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "10" + "'", str36.equals("10"));
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(localDateTime42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertNotNull(localDateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 3600000L + "'", long62 == 3600000L);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "85" + "'", str65.equals("85"));
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GJChronology[+10:00,cutover=2019-06-15T20:56:34.792Z]", "hi!");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str4 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        java.lang.Class<?> wildcardClass4 = iSOChronology3.getClass();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology3.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant2 = instant0.minus((long) (short) 10);
//        long long3 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) instant2);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-60613679544959L) + "'", long3 == (-60613679544959L));
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime3);
//        java.lang.String str5 = gJChronology4.toString();
//        java.lang.String str6 = gJChronology4.toString();
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((-35999978L), (org.joda.time.Chronology) gJChronology4);
//        org.joda.time.DateTimeZone dateTimeZone8 = gJChronology4.getZone();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "GJChronology[+10:00,cutover=0049-03-24T18:47:35.075Z]" + "'", str5.equals("GJChronology[+10:00,cutover=0049-03-24T18:47:35.075Z]"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GJChronology[+10:00,cutover=0049-03-24T18:47:35.075Z]" + "'", str6.equals("GJChronology[+10:00,cutover=0049-03-24T18:47:35.075Z]"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology3.weekyearOfCentury();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) (short) 0, (org.joda.time.Chronology) copticChronology3);
        org.joda.time.MonthDay.Property property8 = monthDay7.dayOfMonth();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property8.getAsShortText(locale9);
        int int11 = property8.getMaximumValue();
        int int12 = property8.get();
        org.joda.time.DurationField durationField13 = property8.getDurationField();
        java.lang.String str14 = property8.getName();
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "22" + "'", str10.equals("22"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 30 + "'", int11 == 30);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 22 + "'", int12 == 22);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "dayOfMonth" + "'", str14.equals("dayOfMonth"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology1.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        long long10 = dateTimeZone5.getMillisKeepLocal(dateTimeZone8, 1560632192898L);
        java.lang.String str12 = dateTimeZone8.getName((long) (byte) 100);
        org.joda.time.Chronology chronology13 = iSOChronology1.withZone(dateTimeZone8);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        boolean boolean17 = dateTimeZone15.isStandardOffset((long) (byte) -1);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((-57599999L), dateTimeZone15);
        long long19 = dateTime18.getMillis();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560632192898L + "'", long10 == 1560632192898L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+10:00" + "'", str12.equals("+10:00"));
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-57599999L) + "'", long19 == (-57599999L));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendFractionOfHour((int) (short) -1, 86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime2.toLocalDateTime();
        org.joda.time.DateTime.Property property5 = dateTime2.millisOfSecond();
        org.joda.time.Interval interval6 = property5.toInterval();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) 9);
        org.joda.time.DateTime dateTime10 = dateTime8.minusDays(9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology3.weekyearOfCentury();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) (short) 0, (org.joda.time.Chronology) copticChronology3);
        org.joda.time.JodaTimePermission jodaTimePermission9 = new org.joda.time.JodaTimePermission("GJChronology[+10:00,cutover=2019-06-15T20:56:38.423Z]");
        java.lang.String str10 = jodaTimePermission9.toString();
        java.lang.String str11 = jodaTimePermission9.getActions();
        org.joda.time.JodaTimePermission jodaTimePermission13 = new org.joda.time.JodaTimePermission("GJChronology[+10:00,cutover=2019-06-15T20:56:38.423Z]");
        boolean boolean14 = jodaTimePermission9.implies((java.security.Permission) jodaTimePermission13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime20 = dateTime17.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial21 = null;
        org.joda.time.DateTime dateTime22 = dateTime17.withFields(readablePartial21);
        org.joda.time.DateTime dateTime24 = dateTime22.withSecondOfMinute(10);
        org.joda.time.DateTime dateTime26 = dateTime24.withYear((int) (short) 0);
        org.joda.time.DateTime dateTime27 = dateTime24.withLaterOffsetAtOverlap();
        jodaTimePermission13.checkGuard((java.lang.Object) dateTime24);
        org.joda.time.ReadableDuration readableDuration29 = null;
        org.joda.time.DateTime dateTime30 = dateTime24.minus(readableDuration29);
        org.joda.time.DateTime dateTime32 = dateTime24.withWeekyear(0);
        org.joda.time.DateTime dateTime33 = monthDay7.toDateTime((org.joda.time.ReadableInstant) dateTime24);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"GJChronology[+10:00,cutover=2019-06-15T20:56:38.423Z]\")" + "'", str10.equals("(\"org.joda.time.JodaTimePermission\" \"GJChronology[+10:00,cutover=2019-06-15T20:56:38.423Z]\")"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.DateTime dateTime18 = dateTime13.withFields(readablePartial17);
        boolean boolean19 = copticChronology2.equals((java.lang.Object) dateTime13);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology2.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.LocalDateTime localDateTime4 = dateTime2.toLocalDateTime();
//        org.joda.time.DateTime.Property property5 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
//        int int7 = property6.getMaximumValue();
//        java.lang.String str8 = property6.getAsShortText();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(localDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1439 + "'", int7 == 1439);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "654" + "'", str8.equals("654"));
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.plus(readablePeriod1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readableDuration3);
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withEra(69);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime2.toLocalDateTime();
        org.joda.time.DateTime.Property property5 = dateTime2.millisOfSecond();
        org.joda.time.Interval interval6 = property5.toInterval();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) 9);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.minus((long) (byte) 1);
        org.joda.time.Instant instant3 = instant2.toInstant();
        org.joda.time.MutableDateTime mutableDateTime4 = instant3.toMutableDateTime();
        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime4.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gJChronology0.getZone();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant2 = instant0.minus((long) (byte) 1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology5.weekyearOfCentury();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        long long12 = copticChronology5.add(readablePeriod9, 0L, (int) (byte) 100);
//        org.joda.time.DateTime dateTime13 = instant2.toDateTime((org.joda.time.Chronology) copticChronology5);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusHours(0);
//        try {
//            org.joda.time.DateTime dateTime17 = dateTime15.minusMillis((int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertNotNull(copticChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
//        org.joda.time.Chronology chronology5 = copticChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology2.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime14.withFields(readablePartial18);
//        java.lang.String str20 = dateTimeFormatter9.print((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime.Property property21 = dateTime19.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, (org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
//        int int27 = property21.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime28 = property21.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
//        org.joda.time.DateTime.Property property34 = dateTime31.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        boolean boolean36 = dateTime28.isSupported(dateTimeFieldType35);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType35, (-35));
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = buddhistChronology39.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField40);
//        org.joda.time.DurationField durationField42 = unsupportedDateTimeField41.getLeapDurationField();
//        org.joda.time.DurationField durationField43 = unsupportedDateTimeField41.getRangeDurationField();
//        try {
//            java.lang.String str45 = unsupportedDateTimeField41.getAsShortText((long) 2019);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(localDateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertNull(durationField42);
//        org.junit.Assert.assertNull(durationField43);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone5);
        org.joda.time.chrono.ZonedChronology zonedChronology9 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) julianChronology3, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone10 = zonedChronology9.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology11.minuteOfDay();
        boolean boolean14 = zonedChronology9.equals((java.lang.Object) dateTimeField13);
        org.joda.time.Chronology chronology15 = zonedChronology9.withUTC();
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay((long) (-35), (org.joda.time.Chronology) zonedChronology9);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(zonedChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology15);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
//        org.joda.time.Chronology chronology5 = copticChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology2.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime14.withFields(readablePartial18);
//        java.lang.String str20 = dateTimeFormatter9.print((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime.Property property21 = dateTime19.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, (org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
//        int int27 = property21.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime28 = property21.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
//        org.joda.time.DateTime.Property property34 = dateTime31.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        boolean boolean36 = dateTime28.isSupported(dateTimeFieldType35);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType35, (-35));
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = buddhistChronology39.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField40);
//        org.joda.time.DurationField durationField42 = unsupportedDateTimeField41.getLeapDurationField();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.chrono.CopticChronology copticChronology47 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone45, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField48 = copticChronology47.hourOfDay();
//        org.joda.time.DurationField durationField49 = copticChronology47.millis();
//        org.joda.time.MonthDay monthDay50 = new org.joda.time.MonthDay(3, 24, (org.joda.time.Chronology) copticChronology47);
//        java.util.Locale locale51 = null;
//        try {
//            java.lang.String str52 = unsupportedDateTimeField41.getAsShortText((org.joda.time.ReadablePartial) monthDay50, locale51);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(localDateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertNull(durationField42);
//        org.junit.Assert.assertNotNull(copticChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(durationField49);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
//        org.joda.time.Chronology chronology5 = copticChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology2.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime14.withFields(readablePartial18);
//        java.lang.String str20 = dateTimeFormatter9.print((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime.Property property21 = dateTime19.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, (org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
//        int int27 = property21.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime28 = property21.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
//        org.joda.time.DateTime.Property property34 = dateTime31.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        boolean boolean36 = dateTime28.isSupported(dateTimeFieldType35);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType35, (-35));
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = buddhistChronology39.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField40);
//        try {
//            int int43 = unsupportedDateTimeField41.get((long) (-21));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(localDateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.minuteOfHour();
        org.joda.time.DurationField durationField3 = iSOChronology1.months();
        org.joda.time.DurationField durationField4 = iSOChronology1.weeks();
        org.joda.time.DurationField durationField5 = iSOChronology1.centuries();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) iSOChronology1);
        java.io.Writer writer9 = null;
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone11, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology13.hourOfDay();
        org.joda.time.DateTimeField dateTimeField15 = copticChronology13.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField16 = copticChronology13.weekyearOfCentury();
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay((long) (short) 0, (org.joda.time.Chronology) copticChronology13);
        int int18 = monthDay17.getDayOfMonth();
        org.joda.time.LocalDate localDate20 = monthDay17.toLocalDate(10);
        try {
            dateTimeFormatter8.printTo(writer9, (org.joda.time.ReadablePartial) monthDay17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 22 + "'", int18 == 22);
        org.junit.Assert.assertNotNull(localDate20);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GJChronology[+10:00,cutover=2019-06-15T20:56:43.615Z]", "10.0", 20, (int) (byte) 10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.minuteOfHour();
        org.joda.time.DurationField durationField7 = iSOChronology5.months();
        boolean boolean8 = fixedDateTimeZone4.equals((java.lang.Object) iSOChronology5);
        long long10 = fixedDateTimeZone4.nextTransition(212040193L);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 212040193L + "'", long10 == 212040193L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.minus((long) (byte) 1);
        org.joda.time.Instant instant4 = instant2.minus((long) 2019);
        org.joda.time.Instant instant5 = instant4.toInstant();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant8 = instant5.withDurationAdded(readableDuration6, 23);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant8);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.LocalDateTime localDateTime4 = dateTime2.toLocalDateTime();
//        org.joda.time.DateTime.Property property5 = dateTime2.weekOfWeekyear();
//        long long6 = property5.remainder();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property5.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, (java.lang.Number) (-62174322795046L), (java.lang.Number) 315705600032L, (java.lang.Number) 1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(localDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 212078929L + "'", long6 == 212078929L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology3.weekyearOfCentury();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) (short) 0, (org.joda.time.Chronology) copticChronology3);
        org.joda.time.MonthDay.Property property8 = monthDay7.dayOfMonth();
        try {
            org.joda.time.MonthDay monthDay10 = monthDay7.withMonthOfYear(16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 16 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        try {
            org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField10.getAsShortText(2019, locale12);
        java.lang.String str15 = skipDateTimeField10.getAsShortText(1L);
        long long18 = skipDateTimeField10.getDifferenceAsLong((long) 19, (long) (byte) 1);
        java.lang.String str20 = skipDateTimeField10.getAsText((long) (short) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = skipDateTimeField10.getType();
        java.lang.String str22 = skipDateTimeField10.getName();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "16" + "'", str15.equals("16"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "16" + "'", str20.equals("16"));
        org.junit.Assert.assertNotNull(dateTimeFieldType21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hourOfDay" + "'", str22.equals("hourOfDay"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        long long7 = dateTimeZone2.getMillisKeepLocal(dateTimeZone5, 1560632192898L);
        java.lang.String str9 = dateTimeZone5.getName((long) (byte) 100);
        org.joda.time.Chronology chronology10 = iSOChronology0.withZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.Chronology chronology12 = iSOChronology0.withZone(dateTimeZone11);
        org.joda.time.DurationField durationField13 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560632192898L + "'", long7 == 1560632192898L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+10:00" + "'", str9.equals("+10:00"));
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("Property[weekOfWeekyear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[weekOfWeekyear]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime2.toLocalDateTime();
        org.joda.time.DateTime.Property property5 = dateTime2.millisOfSecond();
        org.joda.time.Interval interval6 = property5.toInterval();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) 9);
        int int9 = property5.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
//        org.joda.time.Chronology chronology5 = copticChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField7 = copticChronology2.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField8 = copticChronology2.era();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime14.withFields(readablePartial18);
//        java.lang.String str20 = dateTimeFormatter9.print((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime.Property property21 = dateTime19.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, (org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
//        int int27 = property21.getDifference((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.DateTime dateTime28 = property21.roundFloorCopy();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (org.joda.time.ReadableInstant) dateTime31);
//        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
//        org.joda.time.DateTime.Property property34 = dateTime31.weekOfWeekyear();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        boolean boolean36 = dateTime28.isSupported(dateTimeFieldType35);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType35, (-35));
//        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField40 = buddhistChronology39.weeks();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField40);
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = unsupportedDateTimeField41.getType();
//        int int45 = unsupportedDateTimeField41.getDifference((long) (-21), (long) (short) -1);
//        try {
//            boolean boolean47 = unsupportedDateTimeField41.isLeap((-62174304421993L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(chronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10" + "'", str20.equals("10"));
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(localDateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(buddhistChronology39);
//        org.junit.Assert.assertNotNull(durationField40);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.DateTime dateTime2 = dateTime0.plus(readablePeriod1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readableDuration3);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTime2.getZone();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.minus(readableDuration6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.LocalDateTime localDateTime12 = dateTime10.toLocalDateTime();
        org.joda.time.DateTime.Property property13 = dateTime10.weekOfWeekyear();
        org.joda.time.DateTime dateTime15 = dateTime10.withYearOfCentury(49);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime2, (org.joda.time.ReadableInstant) dateTime15);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.hourOfDay();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology3.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology3.weekyearOfCentury();
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((long) (short) 0, (org.joda.time.Chronology) copticChronology3);
        org.joda.time.MonthDay.Property property8 = monthDay7.dayOfMonth();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property8.getAsShortText(locale9);
        int int11 = property8.getMaximumValue();
        int int12 = property8.get();
        java.lang.String str13 = property8.getAsText();
        org.joda.time.DurationField durationField14 = property8.getRangeDurationField();
        org.joda.time.DurationField durationField15 = property8.getDurationField();
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "22" + "'", str10.equals("22"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 30 + "'", int11 == 30);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 22 + "'", int12 == 22);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "22" + "'", str13.equals("22"));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (-35));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfHour();
        org.joda.time.DurationField durationField2 = iSOChronology0.months();
        org.joda.time.DurationField durationField3 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.yearOfCentury();
        org.joda.time.Chronology chronology6 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.withFields(readablePartial9);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.DateTime.Property property12 = dateTime10.dayOfWeek();
//        long long13 = dateTime10.getMillis();
//        org.joda.time.DateTime dateTime15 = dateTime10.withWeekyear(100);
//        int int16 = dateTime10.getMillisOfDay();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13" + "'", str11.equals("13"));
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560632286413L + "'", long13 == 1560632286413L);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 50286413 + "'", int16 == 50286413);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4);
//        org.joda.time.Chronology chronology8 = julianChronology7.withUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime14.withFields(readablePartial18);
//        java.lang.String str20 = dateTimeFormatter9.print((org.joda.time.ReadableInstant) dateTime19);
//        int int21 = dateTime19.getDayOfYear();
//        org.joda.time.DateTime dateTime25 = dateTime19.withDate((int) (byte) -1, 10, (int) (short) 10);
//        int int26 = dateTime25.getDayOfMonth();
//        org.joda.time.DateTime dateTime28 = dateTime25.withYearOfEra(22);
//        boolean boolean29 = julianChronology7.equals((java.lang.Object) 22);
//        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology7.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone31 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone30);
//        org.joda.time.Chronology chronology32 = gregorianChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone31);
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.Chronology chronology34 = gregorianChronology2.withZone(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(chronology34);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(julianChronology5);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13" + "'", str20.equals("13"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 166 + "'", int21 == 166);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 10 + "'", int26 == 10);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone31);
//        org.junit.Assert.assertNotNull(chronology32);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(dateTime35);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.LocalDateTime localDateTime8 = dateTime6.toLocalDateTime();
        org.joda.time.DateTime.Property property9 = dateTime6.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter12 = dateTimeFormatter11.getPrinter();
        boolean boolean13 = property9.equals((java.lang.Object) dateTimePrinter12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder3.append(dateTimePrinter12);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimePrinter12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField10.getAsShortText(2019, locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField10.getAsShortText(1560632170527L, locale15);
        org.joda.time.DurationField durationField17 = skipDateTimeField10.getLeapDurationField();
        java.util.Locale locale18 = null;
        int int19 = skipDateTimeField10.getMaximumTextLength(locale18);
        try {
            long long22 = skipDateTimeField10.set((-60613679583090L), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for hourOfDay must be in the range [1,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13" + "'", str16.equals("13"));
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField10.getAsShortText(2019, locale12);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.CopticChronology copticChronology17 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone15, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField18 = copticChronology17.hourOfDay();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology17.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology17.weekyearOfCentury();
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay((long) (short) 0, (org.joda.time.Chronology) copticChronology17);
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone23, (int) (short) 1);
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        boolean boolean28 = monthDay26.isSupported(dateTimeFieldType27);
        int[] intArray30 = copticChronology22.get((org.joda.time.ReadablePartial) monthDay26, (long) '#');
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime31.plus(readablePeriod32);
        org.joda.time.DateTime dateTime34 = monthDay26.toDateTime((org.joda.time.ReadableInstant) dateTime31);
        int[] intArray36 = copticChronology17.get((org.joda.time.ReadablePartial) monthDay26, (long) '4');
        int[] intArray41 = new int[] { 0, (short) -1, (-1) };
        int[] intArray43 = skipDateTimeField10.addWrapPartial((org.joda.time.ReadablePartial) monthDay26, 100, intArray41, 0);
        java.util.Locale locale44 = null;
        int int45 = skipDateTimeField10.getMaximumTextLength(locale44);
        long long47 = skipDateTimeField10.roundHalfEven((long) 6);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertNotNull(copticChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(copticChronology25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2 + "'", int45 == 2);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("0", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
//        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        long long9 = copticChronology2.add(readablePeriod6, 0L, (int) (byte) 100);
//        org.joda.time.DurationField durationField10 = copticChronology2.days();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
//        org.joda.time.Chronology chronology16 = julianChronology15.withUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter17.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.DateTime dateTime25 = dateTime22.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial26 = null;
//        org.joda.time.DateTime dateTime27 = dateTime22.withFields(readablePartial26);
//        java.lang.String str28 = dateTimeFormatter17.print((org.joda.time.ReadableInstant) dateTime27);
//        int int29 = dateTime27.getDayOfYear();
//        org.joda.time.DateTime dateTime33 = dateTime27.withDate((int) (byte) -1, 10, (int) (short) 10);
//        int int34 = dateTime33.getDayOfMonth();
//        org.joda.time.DateTime dateTime36 = dateTime33.withYearOfEra(22);
//        boolean boolean37 = julianChronology15.equals((java.lang.Object) 22);
//        org.joda.time.DateTimeZone dateTimeZone38 = julianChronology15.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone39 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone38);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.tTime();
//        boolean boolean41 = cachedDateTimeZone39.equals((java.lang.Object) dateTimeFormatter40);
//        long long43 = cachedDateTimeZone39.nextTransition((-60613679583090L));
//        boolean boolean44 = cachedDateTimeZone39.isFixed();
//        org.joda.time.chrono.ZonedChronology zonedChronology45 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) copticChronology2, (org.joda.time.DateTimeZone) cachedDateTimeZone39);
//        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField47 = iSOChronology46.minuteOfHour();
//        org.joda.time.DateTimeField dateTimeField48 = iSOChronology46.minuteOfDay();
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone50);
//        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        long long55 = dateTimeZone50.getMillisKeepLocal(dateTimeZone53, 1560632192898L);
//        java.lang.String str57 = dateTimeZone53.getName((long) (byte) 100);
//        org.joda.time.Chronology chronology58 = iSOChronology46.withZone(dateTimeZone53);
//        org.joda.time.chrono.JulianChronology julianChronology59 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone53);
//        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeUtils.getZone(dateTimeZone53);
//        org.joda.time.Chronology chronology61 = zonedChronology45.withZone(dateTimeZone53);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(julianChronology13);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(julianChronology15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "13" + "'", str28.equals("13"));
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 166 + "'", int29 == 166);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-60613679583090L) + "'", long43 == (-60613679583090L));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertNotNull(zonedChronology45);
//        org.junit.Assert.assertNotNull(iSOChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(julianChronology51);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1560632192898L + "'", long55 == 1560632192898L);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "+10:00" + "'", str57.equals("+10:00"));
//        org.junit.Assert.assertNotNull(chronology58);
//        org.junit.Assert.assertNotNull(julianChronology59);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertNotNull(chronology61);
//    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.withFields(readablePartial9);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        org.joda.time.YearMonthDay yearMonthDay12 = dateTime10.toYearMonthDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter13.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17, (org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime21 = dateTime18.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime18.withFields(readablePartial22);
//        java.lang.String str24 = dateTimeFormatter13.print((org.joda.time.ReadableInstant) dateTime23);
//        org.joda.time.YearMonthDay yearMonthDay25 = dateTime23.toYearMonthDay();
//        org.joda.time.DateTime.Property property26 = dateTime23.monthOfYear();
//        boolean boolean27 = dateTime23.isEqualNow();
//        org.joda.time.DateTime dateTime29 = dateTime23.minusSeconds((int) (byte) -1);
//        org.joda.time.DateTime dateTime30 = yearMonthDay12.toDateTime((org.joda.time.ReadableInstant) dateTime29);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13" + "'", str11.equals("13"));
//        org.junit.Assert.assertNotNull(yearMonthDay12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "13" + "'", str24.equals("13"));
//        org.junit.Assert.assertNotNull(yearMonthDay25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField10.getAsShortText(2019, locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField10.getAsShortText(1560632170527L, locale15);
        org.joda.time.DurationField durationField17 = skipDateTimeField10.getLeapDurationField();
        org.joda.time.DateTimeField dateTimeField18 = skipDateTimeField10.getWrappedField();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.minuteOfHour();
        org.joda.time.DurationField durationField21 = iSOChronology19.months();
        org.joda.time.DurationField durationField22 = iSOChronology19.weeks();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology19.hourOfHalfday();
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology19);
        int[] intArray32 = new int[] { (short) 10, (-3), (-35), 0, 166, (byte) -1 };
        try {
            int[] intArray34 = skipDateTimeField10.addWrapPartial((org.joda.time.ReadablePartial) monthDay24, 13060, intArray32, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 13060");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13" + "'", str16.equals("13"));
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(intArray32);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField10.getAsShortText(2019, locale12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField10.getAsShortText(1560632170527L, locale15);
        org.joda.time.DurationField durationField17 = skipDateTimeField10.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial18 = null;
        int[] intArray22 = new int[] { 69, 9 };
        int[] intArray24 = skipDateTimeField10.add(readablePartial18, (-1), intArray22, (int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField29 = copticChronology28.hourOfDay();
        org.joda.time.DateTimeField dateTimeField30 = copticChronology28.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField31 = copticChronology28.weekyearOfCentury();
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay((long) (short) 0, (org.joda.time.Chronology) copticChronology28);
        int int33 = monthDay32.getDayOfMonth();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray34 = monthDay32.getFieldTypes();
        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay(0L);
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.MonthDay monthDay38 = monthDay36.minus(readablePeriod37);
        org.joda.time.MonthDay monthDay40 = monthDay36.minusMonths(100);
        boolean boolean41 = monthDay32.isEqual((org.joda.time.ReadablePartial) monthDay36);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipDateTimeField10.getAsText((org.joda.time.ReadablePartial) monthDay32, 4, locale43);
        try {
            long long47 = skipDateTimeField10.set((long) (-28800000), 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for hourOfDay must be in the range [1,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "13" + "'", str16.equals("13"));
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(copticChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 22 + "'", int33 == 22);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray34);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "4" + "'", str44.equals("4"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.minuteOfHour();
        org.joda.time.DurationField durationField6 = iSOChronology4.months();
        org.joda.time.DurationField durationField7 = iSOChronology4.weeks();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology4.hourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((java.lang.Integer) 0);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.DateTime dateTime19 = dateTime14.withFields(readablePartial18);
        java.lang.String str20 = dateTimeFormatter9.print((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime.Property property21 = dateTime19.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, (org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
        int int27 = property21.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime28 = property21.roundFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
        org.joda.time.DateTime.Property property34 = dateTime31.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
        boolean boolean36 = dateTime28.isSupported(dateTimeFieldType35);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType35, (int) '#', (int) (short) -1, 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder3.appendSignedDecimal(dateTimeFieldType35, 16, 13060);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13" + "'", str20.equals("13"));
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test137");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime5);
//        org.joda.time.DateTime dateTime8 = dateTime5.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime5.withFields(readablePartial9);
//        java.lang.String str11 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime10);
//        int int12 = dateTime10.getDayOfYear();
//        org.joda.time.DateTime dateTime16 = dateTime10.withDate((int) (byte) -1, 10, (int) (short) 10);
//        int int17 = dateTime16.getDayOfMonth();
//        org.joda.time.DateTime dateTime19 = dateTime16.withYearOfEra(22);
//        org.joda.time.DateTime.Property property20 = dateTime19.weekOfWeekyear();
//        org.joda.time.DateTime.Property property21 = dateTime19.weekyear();
//        org.joda.time.DateTime dateTime22 = property21.roundHalfEvenCopy();
//        org.joda.time.ReadableDuration readableDuration23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.minus(readableDuration23);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "13" + "'", str11.equals("13"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 166 + "'", int12 == 166);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime10 = dateTime7.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.withFields(readablePartial11);
//        org.joda.time.DateTime dateTime14 = dateTime12.withSecondOfMinute(10);
//        org.joda.time.LocalDateTime localDateTime15 = dateTime14.toLocalDateTime();
//        boolean boolean16 = dateTimeZone1.isLocalDateTimeGap(localDateTime15);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
//        java.lang.String str18 = localDateTime15.toString(dateTimeFormatter17);
//        try {
//            org.joda.time.DateTimeField dateTimeField20 = localDateTime15.getField(914);
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 914");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(copticChronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(localDateTime15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "2019-06-15" + "'", str18.equals("2019-06-15"));
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime7 = dateTime4.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial8 = null;
        org.joda.time.DateTime dateTime9 = dateTime4.withFields(readablePartial8);
        org.joda.time.TimeOfDay timeOfDay10 = dateTime9.toTimeOfDay();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) timeOfDay10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(timeOfDay10);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.Chronology chronology5 = copticChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology2.era();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((java.lang.Integer) 0);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.DateTime dateTime19 = dateTime14.withFields(readablePartial18);
        java.lang.String str20 = dateTimeFormatter9.print((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime.Property property21 = dateTime19.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, (org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
        int int27 = property21.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime28 = property21.roundFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
        org.joda.time.DateTime.Property property34 = dateTime31.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
        boolean boolean36 = dateTime28.isSupported(dateTimeFieldType35);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType35, (-35));
        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField40 = buddhistChronology39.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = unsupportedDateTimeField41.getType();
        org.joda.time.DurationField durationField43 = unsupportedDateTimeField41.getLeapDurationField();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13" + "'", str20.equals("13"));
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(buddhistChronology39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNull(durationField43);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(0L);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay3 = monthDay1.minus(readablePeriod2);
        org.joda.time.Chronology chronology4 = monthDay3.getChronology();
        org.junit.Assert.assertNotNull(monthDay3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateParser();
//        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("2019-W24-6", dateTimeFormatter1);
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) "2019-W24-6");
//        org.joda.time.DateTime.Property property4 = dateTime3.year();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime10 = dateTime7.withMillisOfDay((int) (byte) 10);
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.withFields(readablePartial11);
//        boolean boolean13 = dateTime7.isBeforeNow();
//        org.joda.time.DateTime.Property property14 = dateTime7.minuteOfHour();
//        org.joda.time.DateTime dateTime16 = dateTime7.minusMinutes(16);
//        org.joda.time.DateTime dateTime18 = dateTime16.plusMonths(0);
//        int int19 = property4.compareTo((org.joda.time.ReadableInstant) dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(monthDay2);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.Chronology chronology5 = copticChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology2.era();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((java.lang.Integer) 0);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.DateTime dateTime19 = dateTime14.withFields(readablePartial18);
        java.lang.String str20 = dateTimeFormatter9.print((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime.Property property21 = dateTime19.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, (org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
        int int27 = property21.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime28 = property21.roundFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
        org.joda.time.DateTime.Property property34 = dateTime31.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
        boolean boolean36 = dateTime28.isSupported(dateTimeFieldType35);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType35, (-35));
        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField40 = buddhistChronology39.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField40);
        org.joda.time.DurationField durationField42 = unsupportedDateTimeField41.getLeapDurationField();
        org.joda.time.DurationField durationField43 = unsupportedDateTimeField41.getRangeDurationField();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = dateTimeFormatter44.withPivotYear((java.lang.Integer) 0);
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime49 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone48, (org.joda.time.ReadableInstant) dateTime49);
        org.joda.time.DateTime dateTime52 = dateTime49.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial53 = null;
        org.joda.time.DateTime dateTime54 = dateTime49.withFields(readablePartial53);
        java.lang.String str55 = dateTimeFormatter44.print((org.joda.time.ReadableInstant) dateTime54);
        org.joda.time.YearMonthDay yearMonthDay56 = dateTime54.toYearMonthDay();
        java.util.Locale locale57 = null;
        try {
            java.lang.String str58 = unsupportedDateTimeField41.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay56, locale57);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13" + "'", str20.equals("13"));
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(buddhistChronology39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertNull(durationField43);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(dateTimeFormatter46);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "13" + "'", str55.equals("13"));
        org.junit.Assert.assertNotNull(yearMonthDay56);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField10.getAsShortText(2019, locale12);
        java.lang.String str15 = skipDateTimeField10.getAsShortText(1L);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone16, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.hourOfDay();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology18.centuryOfEra();
        org.joda.time.Chronology chronology21 = copticChronology18.withUTC();
        org.joda.time.DateTimeField dateTimeField22 = copticChronology18.yearOfEra();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology18.era();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter25.withPivotYear((java.lang.Integer) 0);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime33 = dateTime30.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        org.joda.time.DateTime dateTime35 = dateTime30.withFields(readablePartial34);
        java.lang.String str36 = dateTimeFormatter25.print((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime.Property property37 = dateTime35.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone39, (org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.LocalDateTime localDateTime42 = dateTime40.toLocalDateTime();
        int int43 = property37.getDifference((org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DateTime dateTime44 = property37.roundFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, (org.joda.time.ReadableInstant) dateTime47);
        org.joda.time.LocalDateTime localDateTime49 = dateTime47.toLocalDateTime();
        org.joda.time.DateTime.Property property50 = dateTime47.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        boolean boolean52 = dateTime44.isSupported(dateTimeFieldType51);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, dateTimeFieldType51, (-35));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType51, 69, (int) (short) 0, (int) (short) 1);
        long long60 = offsetDateTimeField58.roundHalfEven((long) 1439);
        int int62 = offsetDateTimeField58.getLeapAmount((long) 166);
        long long64 = offsetDateTimeField58.roundHalfEven(0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType65 = offsetDateTimeField58.getType();
        try {
            long long68 = offsetDateTimeField58.add((-9910800000L), (long) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for weekOfWeekyear must be in the range [70,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "16" + "'", str15.equals("16"));
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13" + "'", str36.equals("13"));
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(localDateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(localDateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType65);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfHour();
        org.joda.time.DurationField durationField2 = iSOChronology0.months();
        org.joda.time.DurationField durationField3 = iSOChronology0.weeks();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.minuteOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        long long13 = dateTimeZone8.getMillisKeepLocal(dateTimeZone11, 1560632192898L);
        java.lang.String str15 = dateTimeZone11.getName((long) (byte) 100);
        org.joda.time.Chronology chronology16 = iSOChronology4.withZone(dateTimeZone11);
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        boolean boolean18 = iSOChronology0.equals((java.lang.Object) julianChronology17);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone19, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.hourOfDay();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology21.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology21.weekyearOfCentury();
        org.joda.time.field.SkipDateTimeField skipDateTimeField26 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology17, dateTimeField24, (int) (short) -1);
        long long28 = skipDateTimeField26.roundHalfCeiling((long) '#');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560632192898L + "'", long13 == 1560632192898L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+10:00" + "'", str15.equals("+10:00"));
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-9910800000L) + "'", long28 == (-9910800000L));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.Chronology chronology5 = copticChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology2.era();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((java.lang.Integer) 0);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.DateTime dateTime19 = dateTime14.withFields(readablePartial18);
        java.lang.String str20 = dateTimeFormatter9.print((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime.Property property21 = dateTime19.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, (org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
        int int27 = property21.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime28 = property21.roundFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
        org.joda.time.DateTime.Property property34 = dateTime31.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
        boolean boolean36 = dateTime28.isSupported(dateTimeFieldType35);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType35, (-35));
        org.joda.time.chrono.BuddhistChronology buddhistChronology39 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField40 = buddhistChronology39.weeks();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField41 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType35, durationField40);
        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay();
        org.joda.time.LocalDate localDate44 = monthDay42.toLocalDate(960);
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField47 = iSOChronology46.minuteOfHour();
        org.joda.time.DurationField durationField48 = iSOChronology46.months();
        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology46);
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology46.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime53 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone52, (org.joda.time.ReadableInstant) dateTime53);
        org.joda.time.DateTime dateTime56 = dateTime53.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial57 = null;
        org.joda.time.DateTime dateTime58 = dateTime53.withFields(readablePartial57);
        boolean boolean59 = iSOChronology46.equals((java.lang.Object) readablePartial57);
        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime62 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone61, (org.joda.time.ReadableInstant) dateTime62);
        org.joda.time.DateTime dateTime65 = dateTime62.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial66 = null;
        org.joda.time.DateTime dateTime67 = dateTime62.withFields(readablePartial66);
        org.joda.time.TimeOfDay timeOfDay68 = dateTime62.toTimeOfDay();
        int[] intArray70 = iSOChronology46.get((org.joda.time.ReadablePartial) timeOfDay68, (long) 22);
        try {
            int[] intArray72 = unsupportedDateTimeField41.add((org.joda.time.ReadablePartial) localDate44, 9, intArray70, 69);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: weekOfWeekyear field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13" + "'", str20.equals("13"));
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(buddhistChronology39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField41);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(gJChronology54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(gJChronology63);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertNotNull(timeOfDay68);
        org.junit.Assert.assertNotNull(intArray70);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(13060, 365);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4766900 + "'", int2 == 4766900);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.Chronology chronology5 = copticChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = copticChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology2.era();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withPivotYear((java.lang.Integer) 0);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial18 = null;
        org.joda.time.DateTime dateTime19 = dateTime14.withFields(readablePartial18);
        java.lang.String str20 = dateTimeFormatter9.print((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime.Property property21 = dateTime19.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23, (org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.LocalDateTime localDateTime26 = dateTime24.toLocalDateTime();
        int int27 = property21.getDifference((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime28 = property21.roundFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30, (org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.LocalDateTime localDateTime33 = dateTime31.toLocalDateTime();
        org.joda.time.DateTime.Property property34 = dateTime31.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
        boolean boolean36 = dateTime28.isSupported(dateTimeFieldType35);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType35, (-35));
        boolean boolean39 = offsetDateTimeField38.isSupported();
        int int41 = offsetDateTimeField38.getLeapAmount(36500L);
        long long43 = offsetDateTimeField38.roundCeiling((long) (byte) 0);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "13" + "'", str20.equals("13"));
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-9223372036825975809L) + "'", long43 == (-9223372036825975809L));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.weeks();
        java.lang.String str2 = buddhistChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone3, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField6 = copticChronology5.hourOfDay();
        org.joda.time.DateTimeField dateTimeField7 = copticChronology5.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology5.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField12 = copticChronology11.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField13 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology5, dateTimeField12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipDateTimeField13.getAsShortText(2019, locale15);
        java.lang.String str18 = skipDateTimeField13.getAsShortText(1L);
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone19, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.hourOfDay();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology21.centuryOfEra();
        org.joda.time.Chronology chronology24 = copticChronology21.withUTC();
        org.joda.time.DateTimeField dateTimeField25 = copticChronology21.yearOfEra();
        org.joda.time.DateTimeField dateTimeField26 = copticChronology21.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField27 = copticChronology21.era();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter28.withPivotYear((java.lang.Integer) 0);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32, (org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.DateTime dateTime36 = dateTime33.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial37 = null;
        org.joda.time.DateTime dateTime38 = dateTime33.withFields(readablePartial37);
        java.lang.String str39 = dateTimeFormatter28.print((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTime.Property property40 = dateTime38.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone42, (org.joda.time.ReadableInstant) dateTime43);
        org.joda.time.LocalDateTime localDateTime45 = dateTime43.toLocalDateTime();
        int int46 = property40.getDifference((org.joda.time.ReadableInstant) dateTime43);
        org.joda.time.DateTime dateTime47 = property40.roundFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49, (org.joda.time.ReadableInstant) dateTime50);
        org.joda.time.LocalDateTime localDateTime52 = dateTime50.toLocalDateTime();
        org.joda.time.DateTime.Property property53 = dateTime50.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property53.getFieldType();
        boolean boolean55 = dateTime47.isSupported(dateTimeFieldType54);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType54, (-35));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField61 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField13, dateTimeFieldType54, 69, (int) (short) 0, (int) (short) 1);
        long long63 = offsetDateTimeField61.roundHalfEven((long) 1439);
        int int65 = offsetDateTimeField61.getLeapAmount((long) 166);
        long long67 = offsetDateTimeField61.roundHalfEven(0L);
        boolean boolean69 = offsetDateTimeField61.isLeap(1560632400000L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField71 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, (org.joda.time.DateTimeField) offsetDateTimeField61, 4);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(copticChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "16" + "'", str18.equals("16"));
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeFormatter28);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "13" + "'", str39.equals("13"));
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(localDateTime45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(localDateTime52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 0L + "'", long63 == 0L);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology2);
        org.joda.time.MonthDay monthDay5 = monthDay3.plusDays((int) (short) -1);
        int[] intArray6 = monthDay5.getValues();
        org.joda.time.MonthDay.Property property7 = monthDay5.monthOfYear();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay9 = monthDay5.plus(readablePeriod8);
        int int10 = monthDay5.getMonthOfYear();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime dateTime16 = dateTime13.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.DateTime dateTime18 = dateTime13.withFields(readablePartial17);
        boolean boolean19 = copticChronology2.equals((java.lang.Object) dateTime13);
        java.lang.Class<?> wildcardClass20 = dateTime13.getClass();
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField3 = copticChronology2.hourOfDay();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology2.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology2.weekyearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone6, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.hourOfDay();
        org.joda.time.field.SkipDateTimeField skipDateTimeField10 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology2, dateTimeField9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipDateTimeField10.getAsShortText(2019, locale12);
        java.lang.String str15 = skipDateTimeField10.getAsShortText(1L);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone16, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.hourOfDay();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology18.centuryOfEra();
        org.joda.time.Chronology chronology21 = copticChronology18.withUTC();
        org.joda.time.DateTimeField dateTimeField22 = copticChronology18.yearOfEra();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology18.weekyearOfCentury();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology18.era();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = dateTimeFormatter25.withPivotYear((java.lang.Integer) 0);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, (org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime33 = dateTime30.withMillisOfDay((int) (byte) 10);
        org.joda.time.ReadablePartial readablePartial34 = null;
        org.joda.time.DateTime dateTime35 = dateTime30.withFields(readablePartial34);
        java.lang.String str36 = dateTimeFormatter25.print((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime.Property property37 = dateTime35.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone39, (org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.LocalDateTime localDateTime42 = dateTime40.toLocalDateTime();
        int int43 = property37.getDifference((org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DateTime dateTime44 = property37.roundFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46, (org.joda.time.ReadableInstant) dateTime47);
        org.joda.time.LocalDateTime localDateTime49 = dateTime47.toLocalDateTime();
        org.joda.time.DateTime.Property property50 = dateTime47.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
        boolean boolean52 = dateTime44.isSupported(dateTimeFieldType51);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, dateTimeFieldType51, (-35));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField10, dateTimeFieldType51, 69, (int) (short) 0, (int) (short) 1);
        long long60 = offsetDateTimeField58.roundHalfEven((long) 1439);
        int int62 = offsetDateTimeField58.getLeapAmount((long) 166);
        long long64 = offsetDateTimeField58.roundHalfEven(0L);
        boolean boolean66 = offsetDateTimeField58.isLeap(1560632400000L);
        java.util.Locale locale68 = null;
        java.lang.String str69 = offsetDateTimeField58.getAsText(166, locale68);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "16" + "'", str15.equals("16"));
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTimeFormatter27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13" + "'", str36.equals("13"));
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(localDateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(localDateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 0L + "'", long64 == 0L);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "166" + "'", str69.equals("166"));
    }
}

