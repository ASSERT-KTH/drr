import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Partial partial2 = new org.joda.time.Partial((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.Partial partial4 = partial2.without(dateTimeFieldType3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.Partial partial7 = partial2.withPeriodAdded(readablePeriod5, 0);
        java.lang.String str8 = partial2.toString();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.Partial partial11 = partial2.withFieldAdded(durationFieldType9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(partial4);
        org.junit.Assert.assertNotNull(partial7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[]" + "'", str8.equals("[]"));
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (short) 1, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendLiteral('#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean8 = fixedDateTimeZone5.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.util.Locale locale11 = null;
        java.util.Calendar calendar12 = dateTime10.toCalendar(locale11);
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfEra();
        org.joda.time.DateTime.Property property14 = dateTime10.secondOfDay();
        java.lang.String str15 = property14.getName();
        org.joda.time.DateTime dateTime17 = property14.addWrapFieldToCopy(0);
        boolean boolean18 = property14.isLeap();
        org.joda.time.DateTime dateTime20 = property14.addWrapFieldToCopy(0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        boolean boolean29 = fixedDateTimeZone26.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.DateTime dateTime33 = dateTime31.minusSeconds((int) (byte) 100);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime39 = dateTime31.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone38);
        org.joda.time.DateTime dateTime41 = dateTime31.withWeekOfWeekyear((int) (byte) 10);
        org.joda.time.DateTime.Property property42 = dateTime31.era();
        int int43 = dateTime31.getYearOfCentury();
        org.joda.time.DateTime.Property property44 = dateTime31.minuteOfDay();
        boolean boolean45 = dateTime20.isBefore((org.joda.time.ReadableInstant) dateTime31);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(calendar12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "secondOfDay" + "'", str15.equals("secondOfDay"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 70 + "'", int43 == 70);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean8 = fixedDateTimeZone5.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.util.Locale locale11 = null;
        java.util.Calendar calendar12 = dateTime10.toCalendar(locale11);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime10.plus(readableDuration13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.LocalDate localDate17 = dateTimeFormatter15.parseLocalDate("1969-12-31");
        org.joda.time.LocalDate localDate19 = localDate17.withWeekOfWeekyear((int) (byte) 10);
        org.joda.time.DateTime dateTime20 = dateTime14.withFields((org.joda.time.ReadablePartial) localDate17);
        boolean boolean22 = dateTime20.isAfter((long) 12);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(calendar12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean8 = fixedDateTimeZone5.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime12 = dateTime10.withDayOfYear((int) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis(0);
        org.joda.time.DateTime dateTime16 = dateTime12.minusSeconds((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone19 = iSOChronology18.getZone();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime16, (org.joda.time.ReadableInstant) dateTime20);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology21);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.hourOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        boolean boolean10 = fixedDateTimeZone7.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.LocalDate.Property property12 = localDate11.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
        org.joda.time.DurationField durationField14 = property12.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, durationField14, dateTimeFieldType15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        boolean boolean24 = fixedDateTimeZone21.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        org.joda.time.LocalDate.Property property26 = localDate25.dayOfMonth();
        int int27 = property26.getLeapAmount();
        org.joda.time.LocalDate localDate28 = property26.getLocalDate();
        org.joda.time.Interval interval29 = localDate28.toInterval();
        org.joda.time.LocalDate.Property property30 = localDate28.centuryOfEra();
        org.joda.time.LocalDate localDate32 = localDate28.withYearOfCentury((int) (byte) 1);
        org.joda.time.LocalTime localTime33 = null;
        org.joda.time.DateTime dateTime34 = localDate32.toDateTime(localTime33);
        org.joda.time.LocalDate.Property property35 = localDate32.weekOfWeekyear();
        org.joda.time.LocalDate localDate36 = property35.getLocalDate();
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.LocalDate localDate38 = localDate36.plus(readablePeriod37);
        int int39 = delegatedDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) localDate38);
        try {
            long long42 = delegatedDateTimeField16.set(0L, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(interval29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(localDate32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 23 + "'", int39 == 23);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        try {
            org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatterBuilder0.toPrinter();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(292278993);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.append(dateTimePrinter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitYear(9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendSecondOfMinute((int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test09() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test09");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        java.lang.String str3 = dateTimeFormatter0.print(0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970-W01-4T00:00:00+00:00:00.100" + "'", str3.equals("1970-W01-4T00:00:00+00:00:00.100"));
//    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(1L);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfCentury(4);
        org.joda.time.DateTime dateTime4 = localDate3.toDateTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(localDate3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate(1L);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        boolean boolean10 = fixedDateTimeZone7.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTime dateTime12 = localDate2.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTime.Property property13 = dateTime12.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime12.plusYears((int) (short) 10);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.plus(readablePeriod16);
        org.joda.time.DateTime dateTime19 = dateTime15.plusWeeks((int) (byte) 100);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        boolean boolean28 = fixedDateTimeZone25.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.joda.time.DateTime dateTime32 = dateTime30.minusSeconds((int) (byte) 100);
        org.joda.time.DateTime.Property property33 = dateTime32.monthOfYear();
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone35 = iSOChronology34.getZone();
        org.joda.time.DateTime dateTime36 = dateTime32.toDateTime(dateTimeZone35);
        org.joda.time.DateTime dateTime37 = dateTime15.withZone(dateTimeZone35);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter0.withZone(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean7 = fixedDateTimeZone4.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.LocalDate.Property property9 = localDate8.dayOfMonth();
        int int10 = property9.getLeapAmount();
        org.joda.time.LocalDate localDate11 = property9.getLocalDate();
        org.joda.time.Interval interval12 = localDate11.toInterval();
        org.joda.time.LocalDate.Property property13 = localDate11.centuryOfEra();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        boolean boolean21 = fixedDateTimeZone18.equals((java.lang.Object) '#');
        org.joda.time.DateTime dateTime22 = localDate11.toDateTimeAtMidnight((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        java.lang.String str24 = fixedDateTimeZone18.getNameKey((long) (-1970));
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(interval12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
    }

//    @Test
//    public void test13() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test13");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.centuryOfEra();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int3 = julianChronology2.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.hourOfDay();
//        org.joda.time.DurationField durationField5 = julianChronology2.hours();
//        org.joda.time.DurationField durationField6 = julianChronology2.weeks();
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int8 = julianChronology7.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField9 = julianChronology7.hourOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone14);
//        boolean boolean17 = fixedDateTimeZone14.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone14);
//        org.joda.time.LocalDate.Property property19 = localDate18.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField20 = property19.getField();
//        org.joda.time.DurationField durationField21 = property19.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, durationField21, dateTimeFieldType22);
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(1L);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone30 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone30);
//        boolean boolean33 = fixedDateTimeZone30.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone30);
//        org.joda.time.DateTime dateTime35 = localDate25.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) fixedDateTimeZone30);
//        org.joda.time.LocalDate localDate37 = localDate25.minusWeeks((int) (byte) 0);
//        int int38 = localDate37.getYearOfCentury();
//        int int39 = delegatedDateTimeField23.getMaximumValue((org.joda.time.ReadablePartial) localDate37);
//        long long42 = delegatedDateTimeField23.add((-86400100L), (long) 4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = delegatedDateTimeField23.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField45 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, durationField6, dateTimeFieldType43, 2019);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone50 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone50);
//        boolean boolean53 = fixedDateTimeZone50.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate54 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone50);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone59 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone59);
//        boolean boolean62 = fixedDateTimeZone59.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate63 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone59);
//        org.joda.time.LocalDate localDate65 = localDate63.withWeekOfWeekyear(1);
//        int int66 = localDate54.compareTo((org.joda.time.ReadablePartial) localDate65);
//        int int67 = remainderDateTimeField45.getMinimumValue((org.joda.time.ReadablePartial) localDate54);
//        long long69 = remainderDateTimeField45.roundHalfEven((long) 70);
//        org.joda.time.chrono.JulianChronology julianChronology70 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int71 = julianChronology70.getMinimumDaysInFirstWeek();
//        org.joda.time.Partial partial72 = new org.joda.time.Partial((org.joda.time.Chronology) julianChronology70);
//        int[] intArray80 = new int[] { 1979, (-9), 0, 1, 12, 3 };
//        try {
//            int[] intArray82 = remainderDateTimeField45.addWrapField((org.joda.time.ReadablePartial) partial72, 69, intArray80, 132);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 69");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 70 + "'", int38 == 70);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 23 + "'", int39 == 23);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-72000100L) + "'", long42 == (-72000100L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(gJChronology60);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(localDate65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-378691200000L) + "'", long69 == (-378691200000L));
//        org.junit.Assert.assertNotNull(julianChronology70);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 4 + "'", int71 == 4);
//        org.junit.Assert.assertNotNull(intArray80);
//    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Partial partial2 = new org.joda.time.Partial((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.Partial partial4 = partial2.without(dateTimeFieldType3);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray5 = partial4.getFieldTypes();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(partial4);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray5);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean8 = fixedDateTimeZone5.equals((java.lang.Object) '#');
        int int10 = fixedDateTimeZone5.getOffsetFromLocal(1L);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        boolean boolean23 = fixedDateTimeZone20.equals((java.lang.Object) '#');
        int int25 = fixedDateTimeZone20.getOffsetFromLocal(1L);
        long long27 = fixedDateTimeZone15.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone20, (long) (short) 10);
        long long29 = fixedDateTimeZone5.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone15, (long) 4);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 15, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.chrono.ISOChronology iSOChronology31 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 4L + "'", long29 == 4L);
        org.junit.Assert.assertNotNull(iSOChronology31);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        int int2 = julianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.Partial partial3 = new org.joda.time.Partial((org.joda.time.Chronology) julianChronology1);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        org.joda.time.Partial partial5 = partial3.without(dateTimeFieldType4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.Partial partial8 = partial3.withPeriodAdded(readablePeriod6, 0);
        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) partial3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(partial5);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "��:��:��.000" + "'", str9.equals("��:��:��.000"));
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean8 = fixedDateTimeZone5.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime12 = dateTime10.withDayOfYear((int) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis(0);
        org.joda.time.DateTime dateTime16 = dateTime12.minusSeconds((int) ' ');
        org.joda.time.DateTime dateTime18 = dateTime12.withCenturyOfEra((int) (byte) 100);
        org.joda.time.DateTime dateTime20 = dateTime12.minusWeeks(6);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean8 = fixedDateTimeZone5.equals((java.lang.Object) '#');
        int int10 = fixedDateTimeZone5.getOffsetFromLocal(1L);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        boolean boolean23 = fixedDateTimeZone20.equals((java.lang.Object) '#');
        int int25 = fixedDateTimeZone20.getOffsetFromLocal(1L);
        long long27 = fixedDateTimeZone15.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone20, (long) (short) 10);
        long long29 = fixedDateTimeZone5.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone15, (long) 4);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) 15, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.chrono.JulianChronology julianChronology31 = org.joda.time.chrono.JulianChronology.getInstance();
        int int32 = julianChronology31.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField33 = julianChronology31.hourOfDay();
        org.joda.time.DateTime dateTime34 = dateTime30.toDateTime((org.joda.time.Chronology) julianChronology31);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 4L + "'", long29 == 4L);
        org.junit.Assert.assertNotNull(julianChronology31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTime34);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean8 = fixedDateTimeZone5.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (byte) 100);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime10.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        org.joda.time.DateTimeZone dateTimeZone19 = mutableDateTime18.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.hourOfDay();
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((java.lang.Object) mutableDateTime18, (org.joda.time.Chronology) iSOChronology20);
        org.joda.time.DateTime.Property property23 = dateTime22.weekyear();
        org.joda.time.DateTime dateTime24 = property23.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        try {
            org.joda.time.LocalTime localTime3 = dateTimeFormatter0.parseLocalTime("1970-01");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970-01\" is malformed at \"-01\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test21");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        boolean boolean7 = fixedDateTimeZone4.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.LocalDate.Property property9 = localDate8.dayOfMonth();
//        org.joda.time.DurationField durationField10 = property9.getDurationField();
//        java.lang.String str11 = property9.getAsText();
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "15" + "'", str11.equals("15"));
//    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException2.prependMessage("+00:00:00.100");
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Number number6 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean7 = fixedDateTimeZone4.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.LocalDate.Property property9 = localDate8.dayOfMonth();
        int int10 = property9.getLeapAmount();
        org.joda.time.LocalDate localDate11 = property9.getLocalDate();
        org.joda.time.LocalDate localDate13 = property9.addWrapFieldToCopy((int) (short) 10);
        org.joda.time.LocalDate localDate14 = property9.withMinimumValue();
        java.util.Locale locale15 = null;
        int int16 = property9.getMaximumShortTextLength(locale15);
        org.joda.time.LocalDate localDate17 = property9.withMaximumValue();
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(localDate17);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Partial partial2 = new org.joda.time.Partial((org.joda.time.Chronology) julianChronology0);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        org.joda.time.Partial partial4 = partial2.without(dateTimeFieldType3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = partial2.getFormatter();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.Partial partial8 = partial2.withPeriodAdded(readablePeriod6, 23);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray9 = partial8.getFieldTypes();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(partial4);
        org.junit.Assert.assertNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(partial8);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray9);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        long long2 = org.joda.time.field.FieldUtils.safeDivide((long) '#', (long) (-1970));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate(1L);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        boolean boolean9 = fixedDateTimeZone6.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTime dateTime11 = localDate1.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) copticChronology12);
        org.joda.time.Chronology chronology14 = copticChronology12.withUTC();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(chronology14);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(292278993);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay((int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendFractionOfMinute((int) (short) 1, (int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendClockhourOfDay(32);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean8 = fixedDateTimeZone5.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (byte) 100);
        org.joda.time.DateTime.Property property13 = dateTime12.monthOfYear();
        org.joda.time.DateTime dateTime14 = property13.roundHalfCeilingCopy();
        long long15 = property13.remainder();
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2678300132L + "'", long15 == 2678300132L);
    }

//    @Test
//    public void test31() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test31");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.centuryOfEra();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int3 = julianChronology2.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.hourOfDay();
//        org.joda.time.DurationField durationField5 = julianChronology2.hours();
//        org.joda.time.DurationField durationField6 = julianChronology2.weeks();
//        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int8 = julianChronology7.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField9 = julianChronology7.hourOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone14);
//        boolean boolean17 = fixedDateTimeZone14.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone14);
//        org.joda.time.LocalDate.Property property19 = localDate18.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField20 = property19.getField();
//        org.joda.time.DurationField durationField21 = property19.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9, durationField21, dateTimeFieldType22);
//        org.joda.time.LocalDate localDate25 = new org.joda.time.LocalDate(1L);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone30 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone30);
//        boolean boolean33 = fixedDateTimeZone30.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone30);
//        org.joda.time.DateTime dateTime35 = localDate25.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) fixedDateTimeZone30);
//        org.joda.time.LocalDate localDate37 = localDate25.minusWeeks((int) (byte) 0);
//        int int38 = localDate37.getYearOfCentury();
//        int int39 = delegatedDateTimeField23.getMaximumValue((org.joda.time.ReadablePartial) localDate37);
//        long long42 = delegatedDateTimeField23.add((-86400100L), (long) 4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = delegatedDateTimeField23.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField45 = new org.joda.time.field.RemainderDateTimeField(dateTimeField1, durationField6, dateTimeFieldType43, 2019);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone50 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone50);
//        boolean boolean53 = fixedDateTimeZone50.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate54 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone50);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone59 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology60 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone59);
//        boolean boolean62 = fixedDateTimeZone59.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate63 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone59);
//        org.joda.time.LocalDate localDate65 = localDate63.withWeekOfWeekyear(1);
//        int int66 = localDate54.compareTo((org.joda.time.ReadablePartial) localDate65);
//        int int67 = remainderDateTimeField45.getMinimumValue((org.joda.time.ReadablePartial) localDate54);
//        long long69 = remainderDateTimeField45.roundHalfEven((long) 70);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone74 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology75 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone74);
//        boolean boolean77 = fixedDateTimeZone74.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate78 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone74);
//        org.joda.time.LocalDate.Property property79 = localDate78.dayOfMonth();
//        int int80 = property79.getLeapAmount();
//        org.joda.time.LocalDate localDate81 = property79.getLocalDate();
//        org.joda.time.Interval interval82 = localDate81.toInterval();
//        org.joda.time.LocalDate.Property property83 = localDate81.centuryOfEra();
//        org.joda.time.LocalDate localDate85 = localDate81.withYearOfCentury((int) (byte) 1);
//        org.joda.time.LocalTime localTime86 = null;
//        org.joda.time.DateTime dateTime87 = localDate85.toDateTime(localTime86);
//        org.joda.time.LocalDate.Property property88 = localDate85.weekOfWeekyear();
//        org.joda.time.LocalDate localDate89 = property88.getLocalDate();
//        org.joda.time.ReadablePeriod readablePeriod90 = null;
//        org.joda.time.LocalDate localDate91 = localDate89.plus(readablePeriod90);
//        int int92 = remainderDateTimeField45.getMinimumValue((org.joda.time.ReadablePartial) localDate89);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(julianChronology7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(localDate37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 70 + "'", int38 == 70);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 23 + "'", int39 == 23);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-72000100L) + "'", long42 == (-72000100L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(gJChronology51);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(gJChronology60);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertNotNull(localDate65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + (-378691200000L) + "'", long69 == (-378691200000L));
//        org.junit.Assert.assertNotNull(gJChronology75);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//        org.junit.Assert.assertNotNull(property79);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
//        org.junit.Assert.assertNotNull(localDate81);
//        org.junit.Assert.assertNotNull(interval82);
//        org.junit.Assert.assertNotNull(property83);
//        org.junit.Assert.assertNotNull(localDate85);
//        org.junit.Assert.assertNotNull(dateTime87);
//        org.junit.Assert.assertNotNull(property88);
//        org.junit.Assert.assertNotNull(localDate89);
//        org.junit.Assert.assertNotNull(localDate91);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
//    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean7 = fixedDateTimeZone4.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        boolean boolean16 = fixedDateTimeZone13.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.LocalDate localDate19 = localDate17.withWeekOfWeekyear(1);
        int int20 = localDate8.compareTo((org.joda.time.ReadablePartial) localDate19);
        int int21 = localDate19.getYearOfEra();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        boolean boolean29 = fixedDateTimeZone26.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.LocalDate.Property property31 = localDate30.dayOfMonth();
        int int32 = property31.getLeapAmount();
        org.joda.time.LocalDate localDate33 = property31.getLocalDate();
        org.joda.time.Interval interval34 = localDate33.toInterval();
        org.joda.time.LocalDate.Property property35 = localDate33.centuryOfEra();
        boolean boolean36 = localDate19.isEqual((org.joda.time.ReadablePartial) localDate33);
        org.joda.time.DateTime dateTime37 = localDate19.toDateTimeAtMidnight();
        org.joda.time.DateTime dateTime38 = localDate19.toDateTimeAtStartOfDay();
        org.joda.time.DateTime dateTime40 = dateTime38.withMonthOfYear(11);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(interval34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
    }

//    @Test
//    public void test33() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test33");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.centuryOfEra();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int3 = julianChronology2.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.hourOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
//        boolean boolean12 = fixedDateTimeZone9.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone9);
//        org.joda.time.LocalDate.Property property14 = localDate13.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField15 = property14.getField();
//        org.joda.time.DurationField durationField16 = property14.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, durationField16, dateTimeFieldType17);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(1L);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone25);
//        boolean boolean28 = fixedDateTimeZone25.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone25);
//        org.joda.time.DateTime dateTime30 = localDate20.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) fixedDateTimeZone25);
//        org.joda.time.LocalDate localDate32 = localDate20.minusWeeks((int) (byte) 0);
//        int int33 = localDate32.getYearOfCentury();
//        int int34 = delegatedDateTimeField18.getMaximumValue((org.joda.time.ReadablePartial) localDate32);
//        long long37 = delegatedDateTimeField18.add((-86400100L), (long) 4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = delegatedDateTimeField18.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField39 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType38);
//        long long42 = delegatedDateTimeField39.getDifferenceAsLong((long) 52, 1L);
//        int int43 = delegatedDateTimeField39.getMinimumValue();
//        long long46 = delegatedDateTimeField39.add((long) (byte) 1, (long) (short) 100);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone51 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone51);
//        boolean boolean54 = fixedDateTimeZone51.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate55 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone51);
//        org.joda.time.LocalDate.Property property56 = localDate55.dayOfMonth();
//        int int57 = property56.getLeapAmount();
//        org.joda.time.LocalDate localDate58 = property56.getLocalDate();
//        org.joda.time.Interval interval59 = localDate58.toInterval();
//        org.joda.time.LocalDate.Property property60 = localDate58.year();
//        org.joda.time.LocalDate localDate61 = property60.roundHalfFloorCopy();
//        org.joda.time.ReadablePeriod readablePeriod62 = null;
//        org.joda.time.LocalDate localDate63 = localDate61.plus(readablePeriod62);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone69 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology70 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone69);
//        boolean boolean72 = fixedDateTimeZone69.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate73 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone69);
//        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone69);
//        java.util.Locale locale75 = null;
//        java.util.Calendar calendar76 = dateTime74.toCalendar(locale75);
//        org.joda.time.ReadableDuration readableDuration77 = null;
//        org.joda.time.DateTime dateTime78 = dateTime74.plus(readableDuration77);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter79 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
//        org.joda.time.LocalDate localDate81 = dateTimeFormatter79.parseLocalDate("1969-12-31");
//        org.joda.time.LocalDate localDate83 = localDate81.withWeekOfWeekyear((int) (byte) 10);
//        org.joda.time.DateTime dateTime84 = dateTime78.withFields((org.joda.time.ReadablePartial) localDate81);
//        int[] intArray85 = localDate81.getValues();
//        int int86 = delegatedDateTimeField39.getMaximumValue((org.joda.time.ReadablePartial) localDate63, intArray85);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 70 + "'", int33 == 70);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 23 + "'", int34 == 23);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-72000100L) + "'", long37 == (-72000100L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-2922685) + "'", int43 == (-2922685));
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 315569520000001L + "'", long46 == 315569520000001L);
//        org.junit.Assert.assertNotNull(gJChronology52);
//        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertNotNull(localDate58);
//        org.junit.Assert.assertNotNull(interval59);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(localDate61);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(gJChronology70);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(calendar76);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertNotNull(dateTimeFormatter79);
//        org.junit.Assert.assertNotNull(localDate81);
//        org.junit.Assert.assertNotNull(localDate83);
//        org.junit.Assert.assertNotNull(dateTime84);
//        org.junit.Assert.assertNotNull(intArray85);
//        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 2922796 + "'", int86 == 2922796);
//    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(292278993);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        boolean boolean11 = fixedDateTimeZone8.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate12 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds((int) (byte) 100);
        org.joda.time.DateTime.Property property16 = dateTime13.dayOfYear();
        org.joda.time.DateTime dateTime18 = dateTime13.withMillisOfDay(0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        boolean boolean27 = fixedDateTimeZone24.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime31 = dateTime29.minusSeconds((int) (byte) 100);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone36 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime37 = dateTime29.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone36);
        org.joda.time.DateTimeZone dateTimeZone38 = mutableDateTime37.getZone();
        org.joda.time.DateTime dateTime39 = dateTime18.withZoneRetainFields(dateTimeZone38);
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeZone dateTimeZone41 = gJChronology40.getZone();
        try {
            org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatterBuilder0, (org.joda.time.Chronology) gJChronology40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(0);
        java.util.Locale locale3 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(locale3);
    }

//    @Test
//    public void test36() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test36");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.hourOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
//        boolean boolean10 = fixedDateTimeZone7.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone7);
//        org.joda.time.LocalDate.Property property12 = localDate11.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
//        org.joda.time.DurationField durationField14 = property12.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, durationField14, dateTimeFieldType15);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(1L);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone23);
//        boolean boolean26 = fixedDateTimeZone23.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone23);
//        org.joda.time.DateTime dateTime28 = localDate18.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) fixedDateTimeZone23);
//        org.joda.time.LocalDate localDate30 = localDate18.minusWeeks((int) (byte) 0);
//        int int31 = localDate30.getYearOfCentury();
//        int int32 = delegatedDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) localDate30);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone37 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone37);
//        boolean boolean40 = fixedDateTimeZone37.equals((java.lang.Object) '#');
//        int int42 = fixedDateTimeZone37.getOffsetFromLocal(1L);
//        org.joda.time.LocalDate localDate43 = org.joda.time.LocalDate.now((org.joda.time.DateTimeZone) fixedDateTimeZone37);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone49 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone49);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone55 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology56 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone55);
//        boolean boolean58 = fixedDateTimeZone55.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate59 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone55);
//        org.joda.time.LocalDate.Property property60 = localDate59.dayOfMonth();
//        int int61 = property60.getLeapAmount();
//        org.joda.time.LocalDate localDate62 = property60.getLocalDate();
//        int[] intArray64 = gJChronology50.get((org.joda.time.ReadablePartial) localDate62, (long) (short) 100);
//        int[] intArray66 = delegatedDateTimeField16.addWrapPartial((org.joda.time.ReadablePartial) localDate43, 0, intArray64, (int) (byte) 10);
//        long long68 = delegatedDateTimeField16.roundFloor((long) (byte) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType69 = delegatedDateTimeField16.getType();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 70 + "'", int31 == 70);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 23 + "'", int32 == 23);
//        org.junit.Assert.assertNotNull(gJChronology38);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
//        org.junit.Assert.assertNotNull(localDate43);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(gJChronology56);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
//        org.junit.Assert.assertNotNull(localDate62);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertNotNull(intArray66);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-100L) + "'", long68 == (-100L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType69);
//    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(292278993);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.append(dateTimePrinter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendLiteral('#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendHourOfHalfday((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder9.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendYear(470, 19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean8 = fixedDateTimeZone5.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime12 = dateTime10.plusMinutes(52);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean8 = fixedDateTimeZone5.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.util.Locale locale11 = null;
        java.util.Calendar calendar12 = dateTime10.toCalendar(locale11);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime10.plus(readableDuration13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.LocalDate localDate17 = dateTimeFormatter15.parseLocalDate("1969-12-31");
        org.joda.time.LocalDate localDate19 = localDate17.withWeekOfWeekyear((int) (byte) 10);
        org.joda.time.DateTime dateTime20 = dateTime14.withFields((org.joda.time.ReadablePartial) localDate17);
        int int21 = localDate17.getWeekyear();
        org.joda.time.LocalDate localDate23 = localDate17.minusYears((int) '#');
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(calendar12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1970 + "'", int21 == 1970);
        org.junit.Assert.assertNotNull(localDate23);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

//    @Test
//    public void test41() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test41");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.centuryOfEra();
//        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int3 = julianChronology2.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField4 = julianChronology2.hourOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
//        boolean boolean12 = fixedDateTimeZone9.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone9);
//        org.joda.time.LocalDate.Property property14 = localDate13.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField15 = property14.getField();
//        org.joda.time.DurationField durationField16 = property14.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4, durationField16, dateTimeFieldType17);
//        org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate(1L);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone25);
//        boolean boolean28 = fixedDateTimeZone25.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone25);
//        org.joda.time.DateTime dateTime30 = localDate20.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) fixedDateTimeZone25);
//        org.joda.time.LocalDate localDate32 = localDate20.minusWeeks((int) (byte) 0);
//        int int33 = localDate32.getYearOfCentury();
//        int int34 = delegatedDateTimeField18.getMaximumValue((org.joda.time.ReadablePartial) localDate32);
//        long long37 = delegatedDateTimeField18.add((-86400100L), (long) 4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = delegatedDateTimeField18.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField39 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1, dateTimeFieldType38);
//        long long42 = delegatedDateTimeField39.add((long) 32, 23);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(julianChronology2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(localDate32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 70 + "'", int33 == 70);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 23 + "'", int34 == 23);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-72000100L) + "'", long37 == (-72000100L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 72581011200032L + "'", long42 == 72581011200032L);
//    }

//    @Test
//    public void test42() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test42");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.hourOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
//        boolean boolean10 = fixedDateTimeZone7.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone7);
//        org.joda.time.LocalDate.Property property12 = localDate11.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
//        org.joda.time.DurationField durationField14 = property12.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, durationField14, dateTimeFieldType15);
//        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate(1L);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone23);
//        boolean boolean26 = fixedDateTimeZone23.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate27 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone23);
//        org.joda.time.DateTime dateTime28 = localDate18.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) fixedDateTimeZone23);
//        org.joda.time.LocalDate localDate30 = localDate18.minusWeeks((int) (byte) 0);
//        int int31 = localDate30.getYearOfCentury();
//        int int32 = delegatedDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) localDate30);
//        long long35 = delegatedDateTimeField16.add((-86400100L), (long) 4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType36 = delegatedDateTimeField16.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) 10.0f, (java.lang.Number) 2070L, (java.lang.Number) 3);
//        java.lang.String str41 = illegalFieldValueException40.getIllegalStringValue();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(localDate30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 70 + "'", int31 == 70);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 23 + "'", int32 == 23);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-72000100L) + "'", long35 == (-72000100L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType36);
//        org.junit.Assert.assertNull(str41);
//    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate(1L);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        boolean boolean12 = fixedDateTimeZone9.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime14 = localDate4.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.LocalDate localDate16 = localDate4.minusWeeks((int) (byte) 0);
        org.joda.time.Partial partial17 = new org.joda.time.Partial((org.joda.time.ReadablePartial) localDate4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        boolean boolean31 = fixedDateTimeZone28.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        org.joda.time.LocalDate.Property property33 = localDate32.dayOfMonth();
        int int34 = property33.getLeapAmount();
        org.joda.time.LocalDate localDate35 = property33.getLocalDate();
        int[] intArray37 = gJChronology23.get((org.joda.time.ReadablePartial) localDate35, (long) (short) 100);
        julianChronology0.validate((org.joda.time.ReadablePartial) partial17, intArray37);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone45 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone45);
        boolean boolean48 = fixedDateTimeZone45.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate49 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone45);
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone45);
        org.joda.time.DateTime dateTime52 = dateTime50.minusSeconds((int) (byte) 100);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone57 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime58 = dateTime50.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone57);
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime((long) '#', (org.joda.time.DateTimeZone) fixedDateTimeZone57);
        long long62 = fixedDateTimeZone57.convertLocalToUTC((long) 166, false);
        org.joda.time.Chronology chronology63 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone57);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone64 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone57);
        java.lang.String str66 = cachedDateTimeZone64.getNameKey((long) (byte) 1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDate16);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(mutableDateTime58);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 66L + "'", long62 == 66L);
        org.junit.Assert.assertNotNull(chronology63);
        org.junit.Assert.assertNotNull(cachedDateTimeZone64);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "" + "'", str66.equals(""));
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean8 = fixedDateTimeZone5.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.util.Locale locale11 = null;
        java.util.Calendar calendar12 = dateTime10.toCalendar(locale11);
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfEra();
        org.joda.time.DateTime.Property property14 = dateTime10.secondOfDay();
        java.lang.String str15 = property14.getName();
        org.joda.time.DateTime dateTime17 = property14.addWrapFieldToCopy(0);
        boolean boolean18 = property14.isLeap();
        org.joda.time.DateTime dateTime20 = property14.addWrapFieldToCopy(0);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.lang.String str23 = dateTime20.toString(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(calendar12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "secondOfDay" + "'", str15.equals("secondOfDay"));
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "19700101" + "'", str23.equals("19700101"));
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean8 = fixedDateTimeZone5.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.util.Locale locale11 = null;
        java.util.Calendar calendar12 = dateTime10.toCalendar(locale11);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime10.plus(readableDuration13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.LocalDate localDate17 = dateTimeFormatter15.parseLocalDate("1969-12-31");
        org.joda.time.LocalDate localDate19 = localDate17.withWeekOfWeekyear((int) (byte) 10);
        org.joda.time.DateTime dateTime20 = dateTime14.withFields((org.joda.time.ReadablePartial) localDate17);
        int int21 = localDate17.getWeekyear();
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.LocalDate localDate24 = localDate17.withPeriodAdded(readablePeriod22, 2001);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(calendar12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1970 + "'", int21 == 1970);
        org.junit.Assert.assertNotNull(localDate24);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean7 = fixedDateTimeZone4.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        boolean boolean16 = fixedDateTimeZone13.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.LocalDate localDate19 = localDate17.withWeekOfWeekyear(1);
        int int20 = localDate8.compareTo((org.joda.time.ReadablePartial) localDate19);
        int int21 = localDate19.getYearOfEra();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        boolean boolean29 = fixedDateTimeZone26.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.LocalDate.Property property31 = localDate30.dayOfMonth();
        int int32 = property31.getLeapAmount();
        org.joda.time.LocalDate localDate33 = property31.getLocalDate();
        org.joda.time.Interval interval34 = localDate33.toInterval();
        org.joda.time.LocalDate.Property property35 = localDate33.year();
        int int36 = localDate19.compareTo((org.joda.time.ReadablePartial) localDate33);
        org.joda.time.LocalDate.Property property37 = localDate19.year();
        org.joda.time.LocalDate localDate39 = localDate19.plusYears((int) (short) 100);
        org.joda.time.LocalDate localDate41 = localDate19.minusYears(2019);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(interval34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(localDate41);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test48() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test48");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        boolean boolean7 = fixedDateTimeZone4.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        org.joda.time.LocalDate.Property property9 = localDate8.dayOfMonth();
//        int int10 = property9.getLeapAmount();
//        org.joda.time.LocalDate localDate11 = property9.getLocalDate();
//        org.joda.time.Interval interval12 = localDate11.toInterval();
//        org.joda.time.LocalDate.Property property13 = localDate11.centuryOfEra();
//        org.joda.time.LocalDate localDate15 = localDate11.withYearOfCentury((int) (byte) 1);
//        org.joda.time.LocalTime localTime16 = null;
//        org.joda.time.DateTime dateTime17 = localDate15.toDateTime(localTime16);
//        org.joda.time.LocalDate.Property property18 = localDate15.weekOfWeekyear();
//        int[] intArray19 = localDate15.getValues();
//        org.joda.time.LocalDate localDate21 = new org.joda.time.LocalDate(1L);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26);
//        boolean boolean29 = fixedDateTimeZone26.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone26);
//        org.joda.time.DateTime dateTime31 = localDate21.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) fixedDateTimeZone26);
//        java.lang.String str32 = fixedDateTimeZone26.toString();
//        org.joda.time.DateTime dateTime33 = localDate15.toDateTimeAtMidnight((org.joda.time.DateTimeZone) fixedDateTimeZone26);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder34.appendTwoDigitWeekyear(292278993);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
//        org.joda.time.format.DateTimePrinter dateTimePrinter38 = dateTimeFormatter37.getPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder36.append(dateTimePrinter38);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder41 = dateTimeFormatterBuilder36.appendLiteral('#');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder36.appendTimeZoneName();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField44 = buddhistChronology43.centuryOfEra();
//        org.joda.time.chrono.JulianChronology julianChronology45 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int46 = julianChronology45.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField47 = julianChronology45.hourOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone52 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone52);
//        boolean boolean55 = fixedDateTimeZone52.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone52);
//        org.joda.time.LocalDate.Property property57 = localDate56.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField58 = property57.getField();
//        org.joda.time.DurationField durationField59 = property57.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField61 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField47, durationField59, dateTimeFieldType60);
//        org.joda.time.LocalDate localDate63 = new org.joda.time.LocalDate(1L);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone68 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology69 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone68);
//        boolean boolean71 = fixedDateTimeZone68.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate72 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone68);
//        org.joda.time.DateTime dateTime73 = localDate63.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) fixedDateTimeZone68);
//        org.joda.time.LocalDate localDate75 = localDate63.minusWeeks((int) (byte) 0);
//        int int76 = localDate75.getYearOfCentury();
//        int int77 = delegatedDateTimeField61.getMaximumValue((org.joda.time.ReadablePartial) localDate75);
//        long long80 = delegatedDateTimeField61.add((-86400100L), (long) 4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType81 = delegatedDateTimeField61.getType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField82 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44, dateTimeFieldType81);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder42.appendText(dateTimeFieldType81);
//        boolean boolean84 = localDate15.isSupported(dateTimeFieldType81);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(localDate11);
//        org.junit.Assert.assertNotNull(interval12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertNotNull(dateTimePrinter38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder41);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//        org.junit.Assert.assertNotNull(buddhistChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(julianChronology45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(gJChronology53);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertNotNull(durationField59);
//        org.junit.Assert.assertNotNull(gJChronology69);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(localDate75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 70 + "'", int76 == 70);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 23 + "'", int77 == 23);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-72000100L) + "'", long80 == (-72000100L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType81);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
//    }

//    @Test
//    public void test49() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test49");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate1 = org.joda.time.LocalDate.now((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.secondOfMinute();
//        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((org.joda.time.Chronology) julianChronology0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = null;
//        java.lang.String str5 = localDate3.toString(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(localDate1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019-06-02" + "'", str5.equals("2019-06-02"));
//    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("1969-12-31");
        org.joda.time.LocalDate localDate4 = localDate2.withWeekOfWeekyear((int) (byte) 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder5.addRecurringSavings("", (int) (short) -1, 166, 4, ' ', 166, 1, (int) ' ', false, (int) (short) 10);
        boolean boolean17 = localDate4.equals((java.lang.Object) 166);
        org.joda.time.DateTime dateTime18 = localDate4.toDateTimeAtCurrentTime();
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks(20);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(localDate2);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

//    @Test
//    public void test51() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test51");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int1 = julianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.hourOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7);
//        boolean boolean10 = fixedDateTimeZone7.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone7);
//        org.joda.time.LocalDate.Property property12 = localDate11.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField13 = property12.getField();
//        org.joda.time.DurationField durationField14 = property12.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, durationField14, dateTimeFieldType15);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology17.centuryOfEra();
//        org.joda.time.chrono.JulianChronology julianChronology19 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int20 = julianChronology19.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField21 = julianChronology19.hourOfDay();
//        org.joda.time.DurationField durationField22 = julianChronology19.hours();
//        org.joda.time.DurationField durationField23 = julianChronology19.weeks();
//        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstance();
//        int int25 = julianChronology24.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField26 = julianChronology24.hourOfDay();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone31);
//        boolean boolean34 = fixedDateTimeZone31.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone31);
//        org.joda.time.LocalDate.Property property36 = localDate35.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField37 = property36.getField();
//        org.joda.time.DurationField durationField38 = property36.getDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType39 = null;
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField26, durationField38, dateTimeFieldType39);
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate(1L);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone47 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
//        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone47);
//        boolean boolean50 = fixedDateTimeZone47.equals((java.lang.Object) '#');
//        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone47);
//        org.joda.time.DateTime dateTime52 = localDate42.toDateTimeAtStartOfDay((org.joda.time.DateTimeZone) fixedDateTimeZone47);
//        org.joda.time.LocalDate localDate54 = localDate42.minusWeeks((int) (byte) 0);
//        int int55 = localDate54.getYearOfCentury();
//        int int56 = delegatedDateTimeField40.getMaximumValue((org.joda.time.ReadablePartial) localDate54);
//        long long59 = delegatedDateTimeField40.add((-86400100L), (long) 4);
//        org.joda.time.DateTimeFieldType dateTimeFieldType60 = delegatedDateTimeField40.getType();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField62 = new org.joda.time.field.RemainderDateTimeField(dateTimeField18, durationField23, dateTimeFieldType60, 2019);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField63 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField16, dateTimeFieldType60);
//        long long66 = delegatedDateTimeField63.set(1L, 0);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(gJChronology8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(buddhistChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(julianChronology19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(durationField22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(julianChronology24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(gJChronology48);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 70 + "'", int55 == 70);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 23 + "'", int56 == 23);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-72000100L) + "'", long59 == (-72000100L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType60);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1L + "'", long66 == 1L);
//    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        illegalFieldValueException2.prependMessage("+00:00:00.100");
        java.lang.Number number5 = illegalFieldValueException2.getUpperBound();
        boolean boolean6 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("JulianChronology[America/Los_Angeles]", "1970-01-01T00:00:00.132+00:00:00.100", (int) 'a', 0);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = fixedDateTimeZone4.isLocalDateTimeGap(localDateTime5);
        int int8 = fixedDateTimeZone4.getStandardOffset((long) 70);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.LocalDate localDate1 = new org.joda.time.LocalDate((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.LocalDate localDate3 = localDate1.withYearOfEra(105192);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(localDate3);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(1L);
        org.joda.time.Instant instant3 = instant1.minus(52L);
        org.joda.time.MutableDateTime mutableDateTime4 = instant3.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1970-01-01", "");
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean8 = fixedDateTimeZone5.equals((java.lang.Object) '#');
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) ' ', (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds((int) (byte) 100);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 100, (int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime10.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime10.withWeekOfWeekyear((int) (byte) 10);
        org.joda.time.DateTime.Property property21 = dateTime10.era();
        int int22 = dateTime10.getYearOfCentury();
        org.joda.time.DateTime.Property property23 = dateTime10.minuteOfDay();
        int int24 = property23.get();
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 70 + "'", int22 == 70);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }
}

