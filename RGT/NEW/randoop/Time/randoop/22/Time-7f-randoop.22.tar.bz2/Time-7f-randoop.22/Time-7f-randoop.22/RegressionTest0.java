import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            long long4 = gregorianChronology0.set(readablePartial2, (long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) 100.0d, chronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.append(dateTimePrinter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.io.Writer writer2 = null;
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            dateTimeFormatter0.printTo(writer2, readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test012");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (byte) 1, (int) '#', (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear(0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.millisOfDay();
        try {
            mutableDateTime3.setDayOfWeek(10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.millisOfDay();
        try {
            mutableDateTime3.setDateTime((int) ' ', 0, (int) '#', 0, (-25200000), (int) '#', 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        long long4 = mutableDateTime0.getMillis();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            mutableDateTime0.add(durationFieldType5, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime();
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadableInstant) mutableDateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.LocalDateTime localDateTime2 = null;
        try {
            boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond((int) (byte) 1, (int) '4');
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((java.lang.Object) '4', dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Character");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone7);
        try {
            org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone7, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfDay(0);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = null;
        org.joda.time.format.DateTimeParser dateTimeParser6 = null;
        org.joda.time.format.DateTimeParser[] dateTimeParserArray7 = new org.joda.time.format.DateTimeParser[] { dateTimeParser6 };
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.append(dateTimePrinter5, dateTimeParserArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No parser supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeParserArray7);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond((int) (byte) 1, (int) '4');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withChronology((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.append(dateTimeFormatter6);
        int int10 = dateTimeFormatter6.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2000 + "'", int10 == 2000);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, (-25200000), (int) (short) 10, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for monthOfYear must be in the range [10,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) mutableDateTime2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone14);
        int int17 = dateTimeZone14.getOffsetFromLocal((long) 6);
        try {
            org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime((int) (byte) 10, 0, (int) (byte) 10, (int) '4', (int) '#', (int) (byte) 1, (int) (byte) 100, dateTimeZone14);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType3, 0, (int) (byte) 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, (-28800000), (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.millisOfDay();
        org.joda.time.DateTimeField dateTimeField5 = property4.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField7 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.Instant instant4 = mutableDateTime0.toInstant();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(instant4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime dateTime3 = property2.getDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime dateTime7 = dateTime3.withChronology((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            int int9 = dateTime7.get(dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("4:00:00 PM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"4:00:00 PM\" is malformed at \":00:00 PM\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(0, (int) '4', 0, 10, (int) (byte) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        java.io.Writer writer1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime4.toMutableDateTime(dateTimeZone6);
        long long8 = mutableDateTime4.getMillis();
        mutableDateTime2.setMillis((org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime2.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime12 = property10.add((-1L));
        int int13 = mutableDateTime12.getRoundingMode();
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) mutableDateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, (int) (byte) -1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        long long13 = gregorianChronology8.add(readablePeriod10, (long) 1, (int) (short) 100);
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket15 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gregorianChronology8, locale14);
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(10, 0, (int) '#', (int) ' ', 6, 10, (int) ' ', (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.lang.String str8 = mutableDateTime3.toString(dateTimeFormatter7);
        org.joda.time.DateTime dateTime9 = mutableDateTime3.toDateTime();
        try {
            mutableDateTime3.setMillisOfDay((-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "4:00:00 PM" + "'", str8.equals("4:00:00 PM"));
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendLiteral("hi!");
        dateTimeFormatterBuilder8.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
        long long6 = mutableDateTime2.getMillis();
        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.dayOfYear();
        java.util.Date date9 = mutableDateTime0.toDate();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime3 = dateTime2.toLocalDateTime();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(localDateTime3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.Chronology chronology1 = null;
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) (-28800000), chronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: hi!");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("4:00:00 PM", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"4:00:00 PM\" is malformed at \" PM\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("hi!", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: hi!");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        mutableDateTime4.setZoneRetainFields(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime12 = dateTime10.minusHours((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now();
        int int14 = mutableDateTime13.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = mutableDateTime13.toMutableDateTime(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now();
        int int18 = mutableDateTime17.getMonthOfYear();
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime16, (org.joda.time.ReadableInstant) mutableDateTime17);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        mutableDateTime17.setZoneRetainFields(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = dateTime10.toMutableDateTime(dateTimeZone21);
        try {
            org.joda.time.DateTime dateTime25 = dateTime10.withYearOfCentury((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(mutableDateTime23);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.joda.time.MutableDateTime.ROUND_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        long long4 = mutableDateTime0.getMillis();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.weekOfWeekyear();
        try {
            mutableDateTime0.setRounding(dateTimeField6, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.plus((long) 100);
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withEra(57600000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600000 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimePrinter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        java.util.Locale locale16 = null;
        try {
            long long17 = skipUndoDateTimeField13.set((long) (short) 0, "", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime((int) (byte) 100, 9, (int) (byte) 0, (int) (short) 10, (int) '#', 10, (int) (short) 0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 12, (java.lang.Number) (byte) -1, (java.lang.Number) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(57600000);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFixedDecimal(dateTimeFieldType6, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
        long long6 = mutableDateTime2.getMillis();
        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
        boolean boolean8 = mutableDateTime2.isBeforeNow();
        try {
            mutableDateTime2.setMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = org.joda.time.MutableDateTime.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField3 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        boolean boolean2 = dateTimeZone0.isStandardOffset((long) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField3, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1969-12-31T16:00:00.000-08:00");
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime0.withYearOfEra((int) '4');
        org.joda.time.DateTime dateTime7 = dateTime5.minusDays(0);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime();
        boolean boolean9 = dateTime7.isBefore((org.joda.time.ReadableInstant) mutableDateTime8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) boolean9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(100, 1, (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime0.withYearOfEra((int) '4');
        boolean boolean7 = dateTime5.isEqual((long) (short) -1);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.plus(readableDuration8);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField3 = gregorianChronology1.millis();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 57600000, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime0.withYearOfEra((int) '4');
        org.joda.time.DateTime dateTime7 = dateTime5.minusDays(0);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime();
        boolean boolean9 = dateTime7.isBefore((org.joda.time.ReadableInstant) mutableDateTime8);
        try {
            mutableDateTime8.setTime((int) (byte) 100, 0, 31, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime2 = dateTime1.toLocalDateTime();
        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime2);
        boolean boolean4 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1969-12-31T16:00:00.000" + "'", str3.equals("1969-12-31T16:00:00.000"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        int int9 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(2000, 0, 10, (int) (short) -1, 0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("DateTimeField[millisOfDay]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: DateTimeField[millisOfDay]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
        long long6 = mutableDateTime2.getMillis();
        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1L));
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
        org.joda.time.DateTime.Property property13 = dateTime11.dayOfWeek();
        org.joda.time.DateTime.Property property14 = dateTime11.dayOfMonth();
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime11.minus(readableDuration15);
        boolean boolean17 = mutableDateTime10.isBefore((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime10.year();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        long long4 = mutableDateTime0.getMillis();
        java.lang.Class<?> wildcardClass5 = mutableDateTime0.getClass();
        mutableDateTime0.addMillis((int) (short) -1);
        int int8 = mutableDateTime0.getYear();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone14);
        long long18 = dateTimeZone14.convertLocalToUTC((long) (byte) 100, true);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeUtils.getZone(dateTimeZone14);
        try {
            org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((int) '#', 12, (int) ' ', 58200, 3, (-28800000), (-1), dateTimeZone19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58200 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800100L + "'", long18 == 28800100L);
        org.junit.Assert.assertNotNull(dateTimeZone19);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 100, (java.lang.Number) 1560344238929L, (java.lang.Number) 31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-97) + "'", int1 == (-97));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder1.append(dateTimePrinter5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder1.appendTimeZoneOffset("", "DateTimeField[millisOfDay]", true, 10, 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology13.getZone();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology13.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology13.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField19.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType20);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder0.appendDecimal(dateTimeFieldType20, (-28800000), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.yearOfCentury();
        boolean boolean4 = dateTime0.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime0.minuteOfDay();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (byte) 1);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology2.add(readablePeriod4, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime9 = dateTime8.toLocalDateTime();
        int[] intArray11 = gregorianChronology2.get((org.joda.time.ReadablePartial) localDateTime9, (long) ' ');
        boolean boolean12 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime9);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.yearOfCentury();
        boolean boolean4 = dateTime0.isEqualNow();
        org.joda.time.DateTime.Property property5 = dateTime0.minuteOfDay();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) 12);
        java.util.Locale locale8 = null;
        java.lang.String str9 = property5.getAsText(locale8);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "960" + "'", str9.equals("960"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        boolean boolean3 = mutableDateTime0.isEqual((long) ' ');
        int int4 = mutableDateTime0.getDayOfMonth();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 31 + "'", int4 == 31);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime dateTime3 = property2.getDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DateTime dateTime7 = dateTime3.withChronology((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.DateTime dateTime10 = dateTime7.withFieldAdded(durationFieldType8, 57600000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTwoDigitYear((int) (short) 1);
        boolean boolean4 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gregorianChronology6.add(readablePeriod8, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now();
        int int13 = mutableDateTime12.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.toMutableDateTime(dateTimeZone14);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.millisOfDay();
        org.joda.time.DateTimeField dateTimeField17 = property16.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField17, 6);
        int int21 = skipUndoDateTimeField19.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology22.getZone();
        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology22.getZone();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField19, dateTimeFieldType29, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder1.appendText(dateTimeFieldType29);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField33 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        int int15 = skipUndoDateTimeField13.getMinimumValue(28800032L);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime17 = dateTime16.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        long long24 = gregorianChronology19.add(readablePeriod21, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime26 = dateTime25.toLocalDateTime();
        int[] intArray28 = gregorianChronology19.get((org.joda.time.ReadablePartial) localDateTime26, (long) ' ');
        int[] intArray30 = skipUndoDateTimeField13.add((org.joda.time.ReadablePartial) localDateTime17, 0, intArray28, 0);
        java.util.Locale locale33 = null;
        try {
            long long34 = skipUndoDateTimeField13.set((long) (-1), "", locale33);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDateTime17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology1.add(readablePeriod3, (long) 1, (int) (short) 100);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gregorianChronology1, locale7);
        dateTimeParserBucket8.setPivotYear((java.lang.Integer) (-1));
        long long11 = dateTimeParserBucket8.computeMillis();
        long long14 = dateTimeParserBucket8.computeMillis(false, "4:00:00 PM");
        dateTimeParserBucket8.setPivotYear((java.lang.Integer) (-1));
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800032L + "'", long11 == 28800032L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28800032L + "'", long14 == 28800032L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.append(dateTimeFormatter1);
        boolean boolean3 = dateTimeFormatterBuilder2.canBuildFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
        long long9 = offsetDateTimeField6.add((long) (short) 10, 31);
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) (-1));
        long long14 = offsetDateTimeField6.set((long) (short) 10, 12);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31010L + "'", long9 == 31010L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "57598" + "'", str11.equals("57598"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-57586990L) + "'", long14 == (-57586990L));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.append(dateTimeFormatter1);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendDayOfYear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.Chronology chronology1 = mutableDateTime0.getChronology();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.monthOfYear();
        mutableDateTime0.setDayOfYear((int) (byte) 10);
        mutableDateTime0.setMonthOfYear(10);
        int int7 = mutableDateTime0.getEra();
        int int8 = mutableDateTime0.getCenturyOfEra();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        java.lang.String str14 = skipUndoDateTimeField13.toString();
        try {
            long long17 = skipUndoDateTimeField13.set((long) 31, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for millisOfDay must be in the range [1,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfDay]" + "'", str14.equals("DateTimeField[millisOfDay]"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        long long6 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDateTime4, 28800100L);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-28800000L) + "'", long6 == (-28800000L));
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTwoDigitYear((int) (short) 1);
        boolean boolean4 = dateTimeFormatterBuilder1.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gregorianChronology6.add(readablePeriod8, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now();
        int int13 = mutableDateTime12.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.toMutableDateTime(dateTimeZone14);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.millisOfDay();
        org.joda.time.DateTimeField dateTimeField17 = property16.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField17, 6);
        int int21 = skipUndoDateTimeField19.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology22.getZone();
        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology22.getZone();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField19, dateTimeFieldType29, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder1.appendText(dateTimeFieldType29);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField34 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType29, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology1.add(readablePeriod3, (long) 1, (int) (short) 100);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gregorianChronology1, locale7);
        dateTimeParserBucket8.setPivotYear((java.lang.Integer) (-1));
        java.lang.Integer int11 = dateTimeParserBucket8.getOffsetInteger();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNull(int11);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimePrinter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", "DateTimeField[millisOfDay]", true, 10, 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField18.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType19);
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology26.getZone();
        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology26.getZone();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone28);
        try {
            org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeFormatterBuilder11, dateTimeZone28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
        long long9 = offsetDateTimeField6.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField10 = offsetDateTimeField6.getRangeDurationField();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField13 = new org.joda.time.field.ScaledDurationField(durationField10, durationFieldType11, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344238L + "'", long9 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
        long long9 = offsetDateTimeField6.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField10 = offsetDateTimeField6.getRangeDurationField();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology11.getZone();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime15 = dateTime14.toLocalDateTime();
        long long17 = gregorianChronology11.set((org.joda.time.ReadablePartial) localDateTime15, 28800100L);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        long long24 = gregorianChronology19.add(readablePeriod21, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime25 = org.joda.time.MutableDateTime.now();
        int int26 = mutableDateTime25.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.MutableDateTime mutableDateTime28 = mutableDateTime25.toMutableDateTime(dateTimeZone27);
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.millisOfDay();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology19, dateTimeField30, 6);
        int int34 = skipUndoDateTimeField32.getMinimumValue(28800032L);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime36 = dateTime35.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology38.getZone();
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        long long43 = gregorianChronology38.add(readablePeriod40, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime45 = dateTime44.toLocalDateTime();
        int[] intArray47 = gregorianChronology38.get((org.joda.time.ReadablePartial) localDateTime45, (long) ' ');
        int[] intArray49 = skipUndoDateTimeField32.add((org.joda.time.ReadablePartial) localDateTime36, 0, intArray47, 0);
        try {
            int[] intArray51 = offsetDateTimeField6.addWrapPartial((org.joda.time.ReadablePartial) localDateTime15, (-25200000), intArray49, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -25200000");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344238L + "'", long9 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-28800000L) + "'", long17 == (-28800000L));
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(localDateTime36);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1L + "'", long43 == 1L);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(localDateTime45);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray49);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime3 = dateTime2.toLocalDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        org.joda.time.DateTime.Property property5 = dateTime2.secondOfDay();
        boolean boolean6 = iSOChronology0.equals((java.lang.Object) property5);
        org.joda.time.DateTime dateTime7 = property5.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.DateTime.Property property9 = dateTime7.property(dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(localDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        long long8 = gregorianChronology2.set((org.joda.time.ReadablePartial) localDateTime6, 28800100L);
        long long10 = gregorianChronology0.set((org.joda.time.ReadablePartial) localDateTime6, 0L);
        try {
            long long15 = gregorianChronology0.getDateTimeMillis(9, 9, 58200, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-28800000L) + "'", long8 == (-28800000L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
        long long6 = mutableDateTime2.getMillis();
        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
        java.util.Locale locale8 = null;
        java.util.Calendar calendar9 = mutableDateTime2.toCalendar(locale8);
        int int10 = mutableDateTime2.getYear();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(calendar9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1969 + "'", int10 == 1969);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime0.withYearOfEra((int) '4');
        org.joda.time.DateTime dateTime7 = dateTime5.minusDays(0);
        org.joda.time.DateTime dateTime8 = dateTime5.withTimeAtStartOfDay();
        try {
            org.joda.time.DateTime dateTime10 = dateTime5.withHourOfDay((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "1969-12-31T16:00:00.000-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.yearOfCentury();
        try {
            org.joda.time.DateTime dateTime5 = property3.setCopy("DateTimeField[millisOfDay]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[millisOfDay]\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime();
        org.joda.time.Chronology chronology5 = mutableDateTime4.getChronology();
        mutableDateTime4.add((long) (short) 10);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.dayOfYear();
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (org.joda.time.ReadableInstant) mutableDateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
        long long6 = mutableDateTime2.getMillis();
        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.dayOfYear();
        java.util.Locale locale10 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime11 = property8.set("secondOfDay", locale10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"secondOfDay\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.getActions();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("1969-12-31T16:00:00.000");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime0.withYearOfEra((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime7 = property6.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime0.withYearOfEra((int) '4');
        org.joda.time.DateTime dateTime7 = dateTime5.minusDays(0);
        org.joda.time.DateTime dateTime8 = dateTime5.withTimeAtStartOfDay();
        try {
            org.joda.time.DateTime dateTime10 = dateTime8.withEra(31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) mutableDateTime4);
        mutableDateTime3.addYears((int) (short) 100);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        java.lang.String str4 = property3.getName();
        java.lang.String str5 = property3.getAsString();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "secondOfDay" + "'", str4.equals("secondOfDay"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "57600" + "'", str5.equals("57600"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        int int7 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime6);
        int int9 = dateTimeZone5.getOffsetFromLocal((-1L));
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-28800000) + "'", int7 == (-28800000));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-28800000) + "'", int9 == (-28800000));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 86399999, (-57586990L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4975515878413010L) + "'", long2 == (-4975515878413010L));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfSecond((int) (byte) 1, (int) '4');
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder5.toPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.yearOfCentury();
        boolean boolean4 = dateTime0.isEqualNow();
        org.joda.time.DateTime dateTime6 = dateTime0.plusMinutes(1);
        org.joda.time.DateTime.Property property7 = dateTime6.weekyear();
        try {
            org.joda.time.DateTime dateTime11 = dateTime6.withDate((int) (short) -1, (int) (byte) -1, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("secondOfDay", 0, (int) (byte) 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for secondOfDay must be in the range [100,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(28800099L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.year();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis(5, 1, 0, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("57600063");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"57600063\" is malformed at \"600063\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        try {
            org.joda.time.DateTime dateTime3 = dateTime1.withDayOfMonth((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.now();
        int int2 = mutableDateTime1.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = mutableDateTime1.toMutableDateTime(dateTimeZone3);
        try {
            java.lang.String str5 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) mutableDateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 12 + "'", int2 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        int int0 = org.joda.time.MutableDateTime.ROUND_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.Chronology chronology1 = mutableDateTime0.getChronology();
        mutableDateTime0.add((long) (short) 10);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfYear();
        try {
            org.joda.time.MutableDateTime mutableDateTime6 = property4.set(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.Chronology chronology1 = null;
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket4 = new org.joda.time.format.DateTimeParserBucket((long) 5, chronology1, locale2, (java.lang.Integer) 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T23:59:59.999 (4:00:00 PM)");
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-1), (-1), (int) (short) -1, (int) (byte) -1, 57600000, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 6, 999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5994L + "'", long2 == 5994L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.dayOfMonth();
        org.joda.time.DurationField durationField4 = property3.getRangeDurationField();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("secondOfDay", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"secondOfDay\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, 2440588L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) '4', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5200L + "'", long2 == 5200L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 10, 0, 0, 9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
        long long9 = offsetDateTimeField6.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField10 = offsetDateTimeField6.getRangeDurationField();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField12 = new org.joda.time.field.DecoratedDurationField(durationField10, durationFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344238L + "'", long9 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        java.util.Locale locale3 = null;
        int int4 = property2.getMaximumTextLength(locale3);
        int int5 = property2.getMaximumValueOverall();
        org.joda.time.DurationField durationField6 = property2.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
        org.junit.Assert.assertNull(durationField6);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime0.withYearOfEra((int) '4');
        org.joda.time.DateTime dateTime7 = dateTime5.minusDays(0);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime();
        boolean boolean9 = dateTime7.isBefore((org.joda.time.ReadableInstant) mutableDateTime8);
        int int10 = dateTime7.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        java.lang.String str14 = skipUndoDateTimeField13.toString();
        boolean boolean16 = skipUndoDateTimeField13.isLeap((long) (short) -1);
        int int18 = skipUndoDateTimeField13.getMaximumValue((long) 'a');
        int int19 = skipUndoDateTimeField13.getMaximumValue();
        int int21 = skipUndoDateTimeField13.getLeapAmount(78L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfDay]" + "'", str14.equals("DateTimeField[millisOfDay]"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86399999 + "'", int18 == 86399999);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 86399999 + "'", int19 == 86399999);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        java.lang.String str14 = skipUndoDateTimeField13.toString();
        boolean boolean16 = skipUndoDateTimeField13.isLeap((long) (short) -1);
        int int18 = skipUndoDateTimeField13.getMaximumValue((long) 'a');
        int int19 = skipUndoDateTimeField13.getMaximumValue();
        try {
            long long22 = skipUndoDateTimeField13.set(0L, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for millisOfDay must be in the range [1,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfDay]" + "'", str14.equals("DateTimeField[millisOfDay]"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86399999 + "'", int18 == 86399999);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 86399999 + "'", int19 == 86399999);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime7 = dateTime6.toLocalDateTime();
        int[] intArray9 = gregorianChronology0.get((org.joda.time.ReadablePartial) localDateTime7, (long) ' ');
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(86400031, 86399999, 33, 33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        boolean boolean7 = jodaTimePermission1.equals((java.lang.Object) dateTimeFormatterBuilder6);
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
        int int9 = mutableDateTime8.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime8.toMutableDateTime(dateTimeZone10);
        boolean boolean12 = mutableDateTime8.isAfterNow();
        jodaTimePermission1.checkGuard((java.lang.Object) mutableDateTime8);
        org.joda.time.JodaTimePermission jodaTimePermission15 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMinuteOfDay(0);
        boolean boolean21 = jodaTimePermission15.equals((java.lang.Object) dateTimeFormatterBuilder20);
        java.security.PermissionCollection permissionCollection22 = jodaTimePermission15.newPermissionCollection();
        boolean boolean23 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(permissionCollection22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
        long long9 = offsetDateTimeField6.add((long) (short) 10, 31);
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) (-1));
        java.util.Locale locale14 = null;
        long long15 = offsetDateTimeField6.set((long) (-97), "-1", locale14);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31010L + "'", long9 == 31010L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "57598" + "'", str11.equals("57598"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-57599097L) + "'", long15 == (-57599097L));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.weekOfWeekyear();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) -1, 960, 1969, 9, (int) (short) 100, 7, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("1969-12-31T16:00:00.000");
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField6.getType();
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray10 = null;
        try {
            int[] intArray12 = offsetDateTimeField6.add(readablePartial8, (-1), intArray10, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
        long long6 = mutableDateTime2.getMillis();
        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.dayOfYear();
        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1L));
        int int11 = mutableDateTime10.getRoundingMode();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime10.minuteOfHour();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 12 + "'", int3 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime4.toMutableDateTime(dateTimeZone6);
        boolean boolean8 = mutableDateTime4.isAfterNow();
        int int11 = dateTimeFormatter3.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "57600", (int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-2) + "'", int11 == (-2));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        long long4 = mutableDateTime0.getMillis();
        java.lang.Class<?> wildcardClass5 = mutableDateTime0.getClass();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime0.secondOfMinute();
        boolean boolean7 = property6.isLeap();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (byte) 1, 5994L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5994 + "'", int2 == 5994);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        mutableDateTime4.setZoneRetainFields(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime12 = dateTime10.minusHours((int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now();
        int int14 = mutableDateTime13.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = mutableDateTime13.toMutableDateTime(dateTimeZone15);
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now();
        int int18 = mutableDateTime17.getMonthOfYear();
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime16, (org.joda.time.ReadableInstant) mutableDateTime17);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        mutableDateTime17.setZoneRetainFields(dateTimeZone21);
        org.joda.time.MutableDateTime mutableDateTime23 = dateTime10.toMutableDateTime(dateTimeZone21);
        try {
            mutableDateTime23.setMinuteOfHour((-97));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(mutableDateTime23);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.yearOfCentury();
        boolean boolean4 = dateTime0.isEqualNow();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        java.io.Writer writer1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField4 = iSOChronology3.hours();
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) 9, (org.joda.time.Chronology) iSOChronology3, locale5, (java.lang.Integer) 31, 1);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.hourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withChronology((org.joda.time.Chronology) gregorianChronology12);
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket(1L, (org.joda.time.Chronology) gregorianChronology12, locale14, (java.lang.Integer) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology17.getZone();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        long long23 = gregorianChronology17.set((org.joda.time.ReadablePartial) localDateTime21, 28800100L);
        long long25 = gregorianChronology12.set((org.joda.time.ReadablePartial) localDateTime21, (long) 1969);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology27.getZone();
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        long long32 = gregorianChronology27.add(readablePeriod29, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime34 = dateTime33.toLocalDateTime();
        int[] intArray36 = gregorianChronology27.get((org.joda.time.ReadablePartial) localDateTime34, (long) ' ');
        boolean boolean37 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime34);
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology38.getZone();
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        long long43 = gregorianChronology38.add(readablePeriod40, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime44 = org.joda.time.MutableDateTime.now();
        int int45 = mutableDateTime44.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.MutableDateTime mutableDateTime47 = mutableDateTime44.toMutableDateTime(dateTimeZone46);
        org.joda.time.MutableDateTime.Property property48 = mutableDateTime47.millisOfDay();
        org.joda.time.DateTimeField dateTimeField49 = property48.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField51 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology38, dateTimeField49, 6);
        int int53 = skipUndoDateTimeField51.getMinimumValue(28800032L);
        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime55 = dateTime54.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone58 = gregorianChronology57.getZone();
        org.joda.time.ReadablePeriod readablePeriod59 = null;
        long long62 = gregorianChronology57.add(readablePeriod59, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime63 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime64 = dateTime63.toLocalDateTime();
        int[] intArray66 = gregorianChronology57.get((org.joda.time.ReadablePartial) localDateTime64, (long) ' ');
        int[] intArray68 = skipUndoDateTimeField51.add((org.joda.time.ReadablePartial) localDateTime55, 0, intArray66, 0);
        iSOChronology26.validate((org.joda.time.ReadablePartial) localDateTime34, intArray68);
        iSOChronology3.validate((org.joda.time.ReadablePartial) localDateTime21, intArray68);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDateTime21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-28800000L) + "'", long23 == (-28800000L));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1L + "'", long32 == 1L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localDateTime34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1L + "'", long43 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 12 + "'", int45 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(localDateTime55);
        org.junit.Assert.assertNotNull(gregorianChronology57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1L + "'", long62 == 1L);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(localDateTime64);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray68);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMinuteOfDay(0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendFractionOfDay(86400031, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder1.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        long long16 = gregorianChronology11.add(readablePeriod13, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now();
        int int18 = mutableDateTime17.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone19 = null;
        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime17.toMutableDateTime(dateTimeZone19);
        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.millisOfDay();
        org.joda.time.DateTimeField dateTimeField22 = property21.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology11, dateTimeField22, 6);
        int int26 = skipUndoDateTimeField24.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology27.getZone();
        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology27.getZone();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology27.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = offsetDateTimeField33.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType34, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder6.appendText(dateTimeFieldType34);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder5.appendFraction(dateTimeFieldType34, (int) '4', 100);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType34, 57600000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        java.lang.String str4 = mutableDateTime3.toString();
        mutableDateTime3.setYear(0);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-12-31T16:00:00.000-08:00" + "'", str4.equals("1969-12-31T16:00:00.000-08:00"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime3 = dateTime2.toLocalDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        org.joda.time.DateTime.Property property5 = dateTime2.secondOfDay();
        boolean boolean6 = iSOChronology0.equals((java.lang.Object) property5);
        org.joda.time.DateTime dateTime7 = property5.roundHalfCeilingCopy();
        boolean boolean8 = property5.isLeap();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(localDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(19, (-28800000), 0, 5, (int) (short) 100, 1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone7);
        try {
            org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (long) (byte) 0, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 2000");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusMinutes((int) (byte) 100);
        org.joda.time.DateTime.Property property3 = dateTime2.secondOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.Chronology chronology1 = mutableDateTime0.getChronology();
        mutableDateTime0.add((long) (short) 10);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfYear();
        try {
            org.joda.time.MutableDateTime mutableDateTime6 = property4.set("57599");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57599 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfWeek();
        org.joda.time.DateTime.Property property10 = dateTime7.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology16.getZone();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime7.toDateTime(dateTimeZone18);
        java.lang.String str21 = dateTimeZone18.getID();
        try {
            org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime((int) (short) 0, (int) '4', 5994, (int) (short) 1, (int) '#', (int) 'a', (int) (short) -1, dateTimeZone18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "America/Los_Angeles" + "'", str21.equals("America/Los_Angeles"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField6.getType();
        long long9 = offsetDateTimeField6.remainder((long) (-1));
        long long11 = offsetDateTimeField6.roundHalfCeiling((long) (byte) 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 999L + "'", long9 == 999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        try {
            long long3 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        java.lang.String str14 = skipUndoDateTimeField13.toString();
        boolean boolean16 = skipUndoDateTimeField13.isLeap((long) (short) -1);
        int int18 = skipUndoDateTimeField13.getMaximumValue((long) 'a');
        java.util.Locale locale21 = null;
        try {
            long long22 = skipUndoDateTimeField13.set((long) 1, "-1", locale21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfDay]" + "'", str14.equals("DateTimeField[millisOfDay]"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86399999 + "'", int18 == 86399999);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        long long19 = gregorianChronology14.add(readablePeriod16, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime20 = org.joda.time.MutableDateTime.now();
        int int21 = mutableDateTime20.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.MutableDateTime mutableDateTime23 = mutableDateTime20.toMutableDateTime(dateTimeZone22);
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField25 = property24.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, dateTimeField25, 6);
        int int29 = skipUndoDateTimeField27.getMinimumValue(28800032L);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime31 = dateTime30.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology33.getZone();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        long long38 = gregorianChronology33.add(readablePeriod35, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        int[] intArray42 = gregorianChronology33.get((org.joda.time.ReadablePartial) localDateTime40, (long) ' ');
        int[] intArray44 = skipUndoDateTimeField27.add((org.joda.time.ReadablePartial) localDateTime31, 0, intArray42, 0);
        int int45 = skipUndoDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) localDateTime31);
        try {
            long long48 = skipUndoDateTimeField13.set(0L, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for millisOfDay must be in the range [1,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localDateTime31);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        boolean boolean3 = mutableDateTime0.isEqual((long) ' ');
        mutableDateTime0.addMonths((int) (short) 10);
        try {
            mutableDateTime0.setDateTime(9, 0, (int) (byte) 100, (int) (byte) 1, 5, 100, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.Chronology chronology1 = mutableDateTime0.getChronology();
        mutableDateTime0.add((long) (short) 10);
        mutableDateTime0.addYears((int) (short) 100);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField6.getType();
        org.joda.time.DurationField durationField8 = offsetDateTimeField6.getLeapDurationField();
        int int10 = offsetDateTimeField6.getLeapAmount((long) 1969);
        long long13 = offsetDateTimeField6.set((long) 3, "960");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendTwoDigitYear((int) (short) 1);
        boolean boolean17 = dateTimeFormatterBuilder14.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendMonthOfYear(1);
        boolean boolean23 = dateTimeFormatterBuilder22.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendTwoDigitYear((int) (short) 1);
        boolean boolean27 = dateTimeFormatterBuilder24.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder24.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        long long34 = gregorianChronology29.add(readablePeriod31, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime35 = org.joda.time.MutableDateTime.now();
        int int36 = mutableDateTime35.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.MutableDateTime mutableDateTime38 = mutableDateTime35.toMutableDateTime(dateTimeZone37);
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime38.millisOfDay();
        org.joda.time.DateTimeField dateTimeField40 = property39.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology29, dateTimeField40, 6);
        int int44 = skipUndoDateTimeField42.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology45.getZone();
        org.joda.time.DateTimeZone dateTimeZone47 = gregorianChronology45.getZone();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology45.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology45.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = offsetDateTimeField51.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField42, dateTimeFieldType52, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder24.appendText(dateTimeFieldType52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType52, 86400031);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField58 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-56638997L) + "'", long13 == (-56638997L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withUTC();
        try {
            long long14 = gregorianChronology0.getDateTimeMillis(0, 100, (int) (short) 0, 0, (int) (short) 0, 86399999, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399999 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField3 = iSOChronology2.hours();
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) 9, (org.joda.time.Chronology) iSOChronology2, locale4, (java.lang.Integer) 31, 1);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.hourOfDay();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket((long) 'a', (org.joda.time.Chronology) iSOChronology2, locale9, (java.lang.Integer) 0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (byte) -1, "4:00:00 PM");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 2000);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        try {
            org.joda.time.DateTime dateTime5 = dateTime0.withYearOfCentury(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        int int15 = skipUndoDateTimeField13.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology16.getZone();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology16.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology16.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField22.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, dateTimeFieldType23, (int) ' ');
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime27 = dateTime26.toLocalDateTime();
        int int28 = offsetDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) localDateTime27);
        java.lang.String str30 = offsetDateTimeField25.getAsShortText((long) 31);
        java.lang.String str31 = offsetDateTimeField25.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 86400031 + "'", int28 == 86400031);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "57600063" + "'", str30.equals("57600063"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "secondOfDay" + "'", str31.equals("secondOfDay"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "57600032");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("4:00:00 PM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"4:00:00 PM\" is malformed at \":00:00 PM\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.toDateTimeISO();
        org.joda.time.DateTime dateTime3 = dateTime0.toDateTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        boolean boolean7 = jodaTimePermission1.equals((java.lang.Object) dateTimeFormatterBuilder6);
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
        int int9 = mutableDateTime8.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime8.toMutableDateTime(dateTimeZone10);
        boolean boolean12 = mutableDateTime8.isAfterNow();
        jodaTimePermission1.checkGuard((java.lang.Object) mutableDateTime8);
        org.joda.time.MutableDateTime mutableDateTime14 = mutableDateTime8.copy();
        try {
            mutableDateTime14.setDayOfMonth(57);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(mutableDateTime14);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
//        org.joda.time.DateTime.Property property3 = dateTime0.yearOfCentury();
//        int int4 = dateTime0.getMinuteOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime0.plusWeeks((-28800000));
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(localDateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 357 + "'", int4 == 357);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
        int int28 = mutableDateTime27.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter51 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter53 = dateTimeFormatter51.withChronology((org.joda.time.Chronology) gregorianChronology52);
        org.joda.time.DurationField durationField54 = gregorianChronology52.minutes();
        org.joda.time.DurationField durationField55 = gregorianChronology52.centuries();
        org.joda.time.DurationField durationField56 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField57 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType44, durationField55, durationField56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeFormatter51);
        org.junit.Assert.assertNotNull(gregorianChronology52);
        org.junit.Assert.assertNotNull(dateTimeFormatter53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(durationField55);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        int int15 = skipUndoDateTimeField13.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology16.getZone();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology16.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology16.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField22.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, dateTimeFieldType23, (int) ' ');
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime27 = dateTime26.toLocalDateTime();
        int int28 = offsetDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) localDateTime27);
        long long30 = offsetDateTimeField25.roundHalfCeiling((long) 86399999);
        boolean boolean32 = offsetDateTimeField25.isLeap(2440588L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 86400031 + "'", int28 == 86400031);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 86399999L + "'", long30 == 86399999L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone1 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime2 = dateTime1.toLocalDateTime();
//        java.lang.String str3 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime2);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withOffsetParsed();
//        java.io.Writer writer5 = null;
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        try {
//            dateTimeFormatter4.printTo(writer5, readablePartial6);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(localDateTime2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019-06-12T05:57:46.886" + "'", str3.equals("2019-06-12T05:57:46.886"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        try {
            long long8 = buddhistChronology0.getDateTimeMillis((-97), 1, 1969, (int) (short) 0, 7, 10, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
//        int int7 = mutableDateTime6.getMonthOfYear();
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime5, (org.joda.time.ReadableInstant) mutableDateTime6);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.DateTimeFormat.mediumTime();
//        java.lang.String str10 = mutableDateTime5.toString(dateTimeFormatter9);
//        org.joda.time.DateTime dateTime11 = mutableDateTime5.toDateTime();
//        org.joda.time.MutableDateTime.Property property12 = mutableDateTime5.yearOfEra();
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime5.monthOfYear();
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) mutableDateTime5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "5:57:47 AM" + "'", str10.equals("5:57:47 AM"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        boolean boolean3 = mutableDateTime0.isEqual((long) ' ');
//        mutableDateTime0.addMonths((int) (short) 10);
//        int int6 = mutableDateTime0.getDayOfMonth();
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime0.yearOfEra();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
//        mutableDateTime0.setZoneRetainFields(dateTimeZone10);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis((int) (short) 1, (int) (byte) 0, 31, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(1L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology6.getZone();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime9);
        try {
            org.joda.time.DateTime dateTime12 = dateTime9.withMinuteOfHour((-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gJChronology10);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        java.util.Locale locale3 = null;
        int int4 = property2.getMaximumTextLength(locale3);
        try {
            org.joda.time.Instant instant5 = new org.joda.time.Instant((java.lang.Object) int4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
//        int int7 = mutableDateTime6.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
//        java.lang.String str14 = skipUndoDateTimeField13.toString();
//        boolean boolean16 = skipUndoDateTimeField13.isLeap((long) (short) -1);
//        org.joda.time.DateTimeField dateTimeField17 = skipUndoDateTimeField13.getWrappedField();
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
//        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology18.getZone();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology18.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (short) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology25.getZone();
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        long long30 = gregorianChronology25.add(readablePeriod27, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime31 = org.joda.time.MutableDateTime.now();
//        int int32 = mutableDateTime31.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.MutableDateTime mutableDateTime34 = mutableDateTime31.toMutableDateTime(dateTimeZone33);
//        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField36 = property35.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField38 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology25, dateTimeField36, 6);
//        int int40 = skipUndoDateTimeField38.getMinimumValue(28800032L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone42 = gregorianChronology41.getZone();
//        org.joda.time.DateTimeZone dateTimeZone43 = gregorianChronology41.getZone();
//        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology41.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology41.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField45, (int) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = offsetDateTimeField47.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField38, dateTimeFieldType48, (int) ' ');
//        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime52 = dateTime51.toLocalDateTime();
//        int int53 = offsetDateTimeField50.getMaximumValue((org.joda.time.ReadablePartial) localDateTime52);
//        long long55 = offsetDateTimeField50.roundHalfCeiling((long) (short) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology56.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone58 = gregorianChronology56.getZone();
//        org.joda.time.DateTime dateTime59 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime60 = dateTime59.toLocalDateTime();
//        long long62 = gregorianChronology56.set((org.joda.time.ReadablePartial) localDateTime60, 28800100L);
//        int int63 = offsetDateTimeField50.getMinimumValue((org.joda.time.ReadablePartial) localDateTime60);
//        java.util.Locale locale64 = null;
//        java.lang.String str65 = offsetDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDateTime60, locale64);
//        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone67 = gregorianChronology66.getZone();
//        org.joda.time.ReadablePeriod readablePeriod68 = null;
//        long long71 = gregorianChronology66.add(readablePeriod68, (long) 1, (int) (short) 100);
//        org.joda.time.DateTime dateTime72 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime73 = dateTime72.toLocalDateTime();
//        int[] intArray75 = gregorianChronology66.get((org.joda.time.ReadablePartial) localDateTime73, (long) ' ');
//        boolean boolean76 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime73);
//        java.util.Locale locale78 = null;
//        java.lang.String str79 = offsetDateTimeField24.getAsText((org.joda.time.ReadablePartial) localDateTime73, (int) (short) 1, locale78);
//        int[] intArray85 = new int[] { 9, 0, '#', (-28800000) };
//        java.util.Locale locale87 = null;
//        try {
//            int[] intArray88 = skipUndoDateTimeField13.set((org.joda.time.ReadablePartial) localDateTime73, (int) (byte) 10, intArray85, "1969-12-31T16:00:00.000-08:00", locale87);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-31T16:00:00.000-08:00\" for millisOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfDay]" + "'", str14.equals("DateTimeField[millisOfDay]"));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology41);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTimeField45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType48);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(localDateTime52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 86400031 + "'", int53 == 86400031);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 100L + "'", long55 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(dateTimeField57);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(localDateTime60);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560319068138L + "'", long62 == 1560319068138L);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 33 + "'", int63 == 33);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "21468" + "'", str65.equals("21468"));
//        org.junit.Assert.assertNotNull(gregorianChronology66);
//        org.junit.Assert.assertNotNull(dateTimeZone67);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1L + "'", long71 == 1L);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(localDateTime73);
//        org.junit.Assert.assertNotNull(intArray75);
//        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
//        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "1" + "'", str79.equals("1"));
//        org.junit.Assert.assertNotNull(intArray85);
//    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
//        long long6 = mutableDateTime2.getMillis();
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime9 = property8.getMutableDateTime();
//        mutableDateTime9.addMonths(31);
//        int int12 = mutableDateTime9.getDayOfMonth();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560344268169L + "'", long6 == 1560344268169L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime dateTime3 = property2.getDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.withHourOfDay((int) (short) 1);
        org.joda.time.DateMidnight dateMidnight6 = dateTime5.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateMidnight6);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(31010L, (-28800000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28768990L) + "'", long2 == (-28768990L));
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
//        long long4 = mutableDateTime0.getMillis();
//        java.lang.Class<?> wildcardClass5 = mutableDateTime0.getClass();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime0.secondOfMinute();
//        org.joda.time.MutableDateTime mutableDateTime7 = mutableDateTime0.toMutableDateTime();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime0.toMutableDateTime(dateTimeZone8);
//        mutableDateTime9.addMonths(9);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560344268271L + "'", long4 == 1560344268271L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) (short) 100);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime10.minus((long) (-1));
        org.joda.time.DateTime dateTime13 = dateTime12.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendTwoDigitYear((int) (short) 1);
        boolean boolean17 = dateTimeFormatterBuilder14.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendMonthOfYear(1);
        boolean boolean23 = dateTimeFormatterBuilder22.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendTwoDigitYear((int) (short) 1);
        boolean boolean27 = dateTimeFormatterBuilder24.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder24.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        long long34 = gregorianChronology29.add(readablePeriod31, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime35 = org.joda.time.MutableDateTime.now();
        int int36 = mutableDateTime35.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.MutableDateTime mutableDateTime38 = mutableDateTime35.toMutableDateTime(dateTimeZone37);
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime38.millisOfDay();
        org.joda.time.DateTimeField dateTimeField40 = property39.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology29, dateTimeField40, 6);
        int int44 = skipUndoDateTimeField42.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology45.getZone();
        org.joda.time.DateTimeZone dateTimeZone47 = gregorianChronology45.getZone();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology45.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology45.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = offsetDateTimeField51.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField42, dateTimeFieldType52, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder24.appendText(dateTimeFieldType52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType52, 86400031);
        org.joda.time.DateTime.Property property58 = dateTime13.property(dateTimeFieldType52);
        org.joda.time.DateTime dateTime60 = dateTime7.withField(dateTimeFieldType52, (int) (byte) 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder0.appendFixedSignedDecimal(dateTimeFieldType52, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(dateTime60);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
//        long long6 = mutableDateTime2.getMillis();
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime9 = property8.getMutableDateTime();
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) ' ');
//        int int12 = property8.compareTo((org.joda.time.ReadableInstant) mutableDateTime11);
//        mutableDateTime11.add(1560344238L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        long long20 = gregorianChronology15.add(readablePeriod17, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now();
//        int int22 = mutableDateTime21.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.MutableDateTime mutableDateTime24 = mutableDateTime21.toMutableDateTime(dateTimeZone23);
//        org.joda.time.MutableDateTime.Property property25 = mutableDateTime24.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField26 = property25.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology15, dateTimeField26, 6);
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        long long34 = gregorianChronology29.add(readablePeriod31, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime35 = org.joda.time.MutableDateTime.now();
//        int int36 = mutableDateTime35.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.MutableDateTime mutableDateTime38 = mutableDateTime35.toMutableDateTime(dateTimeZone37);
//        org.joda.time.MutableDateTime.Property property39 = mutableDateTime38.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField40 = property39.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology29, dateTimeField40, 6);
//        int int44 = skipUndoDateTimeField42.getMinimumValue(28800032L);
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime46 = dateTime45.toLocalDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone49 = gregorianChronology48.getZone();
//        org.joda.time.ReadablePeriod readablePeriod50 = null;
//        long long53 = gregorianChronology48.add(readablePeriod50, (long) 1, (int) (short) 100);
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime55 = dateTime54.toLocalDateTime();
//        int[] intArray57 = gregorianChronology48.get((org.joda.time.ReadablePartial) localDateTime55, (long) ' ');
//        int[] intArray59 = skipUndoDateTimeField42.add((org.joda.time.ReadablePartial) localDateTime46, 0, intArray57, 0);
//        int int60 = skipUndoDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) localDateTime46);
//        java.util.Locale locale62 = null;
//        java.lang.String str63 = skipUndoDateTimeField28.getAsShortText((int) (byte) 1, locale62);
//        long long65 = skipUndoDateTimeField28.roundCeiling((long) (-1));
//        mutableDateTime11.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField28);
//        java.lang.Class<?> wildcardClass67 = mutableDateTime11.getClass();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560344268351L + "'", long6 == 1560344268351L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(localDateTime46);
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1L + "'", long53 == 1L);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(localDateTime55);
//        org.junit.Assert.assertNotNull(intArray57);
//        org.junit.Assert.assertNotNull(intArray59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "1" + "'", str63.equals("1"));
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-1L) + "'", long65 == (-1L));
//        org.junit.Assert.assertNotNull(wildcardClass67);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(chronology0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.DateTime dateTime8 = dateTime5.withFieldAdded(durationFieldType6, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 33);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField6.getType();
        long long9 = offsetDateTimeField6.remainder((long) (-1));
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField6.getAsShortText((long) '4', locale11);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 999L + "'", long9 == 999L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "57599" + "'", str12.equals("57599"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        long long19 = gregorianChronology14.add(readablePeriod16, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime20 = org.joda.time.MutableDateTime.now();
        int int21 = mutableDateTime20.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.MutableDateTime mutableDateTime23 = mutableDateTime20.toMutableDateTime(dateTimeZone22);
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField25 = property24.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, dateTimeField25, 6);
        int int29 = skipUndoDateTimeField27.getMinimumValue(28800032L);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime31 = dateTime30.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology33.getZone();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        long long38 = gregorianChronology33.add(readablePeriod35, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        int[] intArray42 = gregorianChronology33.get((org.joda.time.ReadablePartial) localDateTime40, (long) ' ');
        int[] intArray44 = skipUndoDateTimeField27.add((org.joda.time.ReadablePartial) localDateTime31, 0, intArray42, 0);
        int int45 = skipUndoDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) localDateTime31);
        try {
            long long48 = skipUndoDateTimeField13.set(1560344266420L, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localDateTime31);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        java.lang.String str14 = skipUndoDateTimeField13.toString();
        long long17 = skipUndoDateTimeField13.addWrapField(28800100L, (-1));
        long long19 = skipUndoDateTimeField13.roundFloor(0L);
        java.lang.String str21 = skipUndoDateTimeField13.getAsShortText(0L);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology22.getZone();
        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology22.getZone();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (short) -1);
        long long31 = offsetDateTimeField28.add((long) (short) 10, 31);
        java.lang.String str33 = offsetDateTimeField28.getAsShortText((long) (-1));
        long long35 = offsetDateTimeField28.roundHalfCeiling(2440588L);
        int int38 = offsetDateTimeField28.getDifference(1L, (long) 19);
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) (short) 100);
        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime46 = dateTime44.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime48 = dateTime46.minus((long) (-1));
        org.joda.time.DateTime dateTime49 = dateTime48.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder50.appendTwoDigitYear((int) (short) 1);
        boolean boolean53 = dateTimeFormatterBuilder50.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder50.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder56.appendMonthOfYear(1);
        boolean boolean59 = dateTimeFormatterBuilder58.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder60 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder62 = dateTimeFormatterBuilder60.appendTwoDigitYear((int) (short) 1);
        boolean boolean63 = dateTimeFormatterBuilder60.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder64 = dateTimeFormatterBuilder60.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone66 = gregorianChronology65.getZone();
        org.joda.time.ReadablePeriod readablePeriod67 = null;
        long long70 = gregorianChronology65.add(readablePeriod67, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime71 = org.joda.time.MutableDateTime.now();
        int int72 = mutableDateTime71.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone73 = null;
        org.joda.time.MutableDateTime mutableDateTime74 = mutableDateTime71.toMutableDateTime(dateTimeZone73);
        org.joda.time.MutableDateTime.Property property75 = mutableDateTime74.millisOfDay();
        org.joda.time.DateTimeField dateTimeField76 = property75.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField78 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology65, dateTimeField76, 6);
        int int80 = skipUndoDateTimeField78.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology81 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone82 = gregorianChronology81.getZone();
        org.joda.time.DateTimeZone dateTimeZone83 = gregorianChronology81.getZone();
        org.joda.time.DateTimeField dateTimeField84 = gregorianChronology81.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField85 = gregorianChronology81.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField87 = new org.joda.time.field.OffsetDateTimeField(dateTimeField85, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType88 = offsetDateTimeField87.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField90 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField78, dateTimeFieldType88, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder91 = dateTimeFormatterBuilder60.appendText(dateTimeFieldType88);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder93 = dateTimeFormatterBuilder58.appendFixedDecimal(dateTimeFieldType88, 86400031);
        org.joda.time.DateTime.Property property94 = dateTime49.property(dateTimeFieldType88);
        org.joda.time.DateTime dateTime96 = dateTime43.withField(dateTimeFieldType88, (int) (byte) 10);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField97 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField28, dateTimeFieldType88);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField99 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, dateTimeFieldType88, 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfDay]" + "'", str14.equals("DateTimeField[millisOfDay]"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800099L + "'", long17 == 28800099L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "57600000" + "'", str21.equals("57600000"));
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31010L + "'", long31 == 31010L);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "57598" + "'", str33.equals("57598"));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2441000L + "'", long35 == 2441000L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder64);
        org.junit.Assert.assertNotNull(gregorianChronology65);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1L + "'", long70 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 6 + "'", int72 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime74);
        org.junit.Assert.assertNotNull(property75);
        org.junit.Assert.assertNotNull(dateTimeField76);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology81);
        org.junit.Assert.assertNotNull(dateTimeZone82);
        org.junit.Assert.assertNotNull(dateTimeZone83);
        org.junit.Assert.assertNotNull(dateTimeField84);
        org.junit.Assert.assertNotNull(dateTimeField85);
        org.junit.Assert.assertNotNull(dateTimeFieldType88);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder91);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder93);
        org.junit.Assert.assertNotNull(property94);
        org.junit.Assert.assertNotNull(dateTime96);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "secondOfDay");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 357, 22065, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 10, 1560344266172L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1560344266162L) + "'", long2 == (-1560344266162L));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 0, 0);
        int int4 = dateTimeZone2.getOffsetFromLocal((-57586990L));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology1.add(readablePeriod3, (long) 1, (int) (short) 100);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gregorianChronology1, locale7);
        dateTimeParserBucket8.setPivotYear((java.lang.Integer) (-1));
        long long11 = dateTimeParserBucket8.computeMillis();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology17.getZone();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone19);
        long long23 = dateTimeZone19.convertLocalToUTC((long) (byte) 100, true);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        dateTimeParserBucket8.setZone(dateTimeZone24);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone24);
        java.lang.String str28 = dateTimeZone24.getID();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800032L + "'", long11 == 28800032L);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 28800100L + "'", long23 == 28800100L);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "America/Los_Angeles" + "'", str28.equals("America/Los_Angeles"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("57598", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        java.io.Writer writer2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gregorianChronology3.add(readablePeriod5, (long) 1, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology3.year();
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology3);
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) mutableDateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
//        org.joda.time.DateTime.Property property3 = dateTime0.yearOfCentury();
//        boolean boolean4 = dateTime0.isEqualNow();
//        org.joda.time.DateTime.Property property5 = dateTime0.minuteOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter6.withChronology((org.joda.time.Chronology) gregorianChronology7);
//        org.joda.time.DurationField durationField9 = gregorianChronology7.minutes();
//        org.joda.time.DurationField durationField10 = gregorianChronology7.centuries();
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime0, (org.joda.time.Chronology) gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(localDateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTimeFormatter6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertNotNull(durationField10);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withMinuteOfHour(276);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 276 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
//        int int7 = mutableDateTime6.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
//        java.lang.String str14 = skipUndoDateTimeField13.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology17.getZone();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
//        long long23 = gregorianChronology17.set((org.joda.time.ReadablePartial) localDateTime21, 28800100L);
//        long long25 = gregorianChronology15.set((org.joda.time.ReadablePartial) localDateTime21, 0L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) '4', locale27);
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = skipUndoDateTimeField13.getAsText(0, locale30);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfDay]" + "'", str14.equals("DateTimeField[millisOfDay]"));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localDateTime21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560319070257L + "'", long23 == 1560319070257L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560344270257L + "'", long25 == 1560344270257L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "52" + "'", str28.equals("52"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "0" + "'", str31.equals("0"));
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
//        long long4 = mutableDateTime0.getMillis();
//        java.lang.Class<?> wildcardClass5 = mutableDateTime0.getClass();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime0.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime7 = property6.getMutableDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now(dateTimeZone9);
//        mutableDateTime7.setDate((org.joda.time.ReadableInstant) mutableDateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560344270330L + "'", long4 == 1560344270330L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        int int15 = skipUndoDateTimeField13.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology16.getZone();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology16.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology16.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField22.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, dateTimeFieldType23, (int) ' ');
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime27 = dateTime26.toLocalDateTime();
        int int28 = offsetDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) localDateTime27);
        long long30 = offsetDateTimeField25.roundHalfCeiling((long) 86399999);
        int int31 = offsetDateTimeField25.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 86400031 + "'", int28 == 86400031);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 86399999L + "'", long30 == 86399999L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 32 + "'", int31 == 32);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
//        int int7 = mutableDateTime6.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
//        java.lang.String str14 = skipUndoDateTimeField13.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology17.getZone();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
//        long long23 = gregorianChronology17.set((org.joda.time.ReadablePartial) localDateTime21, 28800100L);
//        long long25 = gregorianChronology15.set((org.joda.time.ReadablePartial) localDateTime21, 0L);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = skipUndoDateTimeField13.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, (int) '4', locale27);
//        long long31 = skipUndoDateTimeField13.getDifferenceAsLong((long) '4', (-4975515878413010L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfDay]" + "'", str14.equals("DateTimeField[millisOfDay]"));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localDateTime21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560319070692L + "'", long23 == 1560319070692L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560344270692L + "'", long25 == 1560344270692L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "52" + "'", str28.equals("52"));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 4975515878413062L + "'", long31 == 4975515878413062L);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfDay(0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfMinute((-1), 57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = gregorianChronology7.add(readablePeriod9, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now();
        int int14 = mutableDateTime13.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = mutableDateTime13.toMutableDateTime(dateTimeZone15);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.millisOfDay();
        org.joda.time.DateTimeField dateTimeField18 = property17.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField18, 6);
        int int22 = skipUndoDateTimeField20.getMinimumValue(28800032L);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime24 = dateTime23.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology26.getZone();
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        long long31 = gregorianChronology26.add(readablePeriod28, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime33 = dateTime32.toLocalDateTime();
        int[] intArray35 = gregorianChronology26.get((org.joda.time.ReadablePartial) localDateTime33, (long) ' ');
        int[] intArray37 = skipUndoDateTimeField20.add((org.joda.time.ReadablePartial) localDateTime24, 0, intArray35, 0);
        try {
            gregorianChronology0.validate(readablePartial6, intArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDateTime24);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray37);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        dateTimeFormatterBuilder0.clear();
        boolean boolean6 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.appendMonthOfYear(22065);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime dateTime3 = property2.getDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.plusMonths((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.Chronology chronology1 = mutableDateTime0.getChronology();
//        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.monthOfYear();
//        mutableDateTime0.setMillis((long) 9);
//        mutableDateTime0.addSeconds((int) (short) 10);
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
//        int int8 = mutableDateTime7.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.MutableDateTime mutableDateTime10 = mutableDateTime7.toMutableDateTime(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now();
//        int int12 = mutableDateTime11.getMonthOfYear();
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime10, (org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.DateTimeFormat.mediumTime();
//        java.lang.String str15 = mutableDateTime10.toString(dateTimeFormatter14);
//        org.joda.time.DateTime dateTime16 = mutableDateTime10.toDateTime();
//        org.joda.time.MutableDateTime.Property property17 = mutableDateTime10.yearOfEra();
//        mutableDateTime0.setDate((org.joda.time.ReadableInstant) mutableDateTime10);
//        mutableDateTime0.setMillisOfDay(5);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "5:57:51 AM" + "'", str15.equals("5:57:51 AM"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        java.util.Locale locale3 = null;
        int int4 = property2.getMaximumTextLength(locale3);
        java.util.Locale locale5 = null;
        int int6 = property2.getMaximumShortTextLength(locale5);
        java.util.Locale locale7 = null;
        int int8 = property2.getMaximumTextLength(locale7);
        java.util.Locale locale10 = null;
        try {
            org.joda.time.DateTime dateTime11 = property2.setCopy("57600", locale10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"57600\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 9 + "'", int8 == 9);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        java.lang.String str14 = skipUndoDateTimeField13.toString();
        long long17 = skipUndoDateTimeField13.addWrapField(28800100L, (-1));
        long long19 = skipUndoDateTimeField13.roundFloor(0L);
        java.lang.String str21 = skipUndoDateTimeField13.getAsShortText(0L);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        long long28 = gregorianChronology23.add(readablePeriod25, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime30 = dateTime29.toLocalDateTime();
        int[] intArray32 = gregorianChronology23.get((org.joda.time.ReadablePartial) localDateTime30, (long) ' ');
        boolean boolean33 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime30);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone35 = gregorianChronology34.getZone();
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        long long39 = gregorianChronology34.add(readablePeriod36, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime40 = org.joda.time.MutableDateTime.now();
        int int41 = mutableDateTime40.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.MutableDateTime mutableDateTime43 = mutableDateTime40.toMutableDateTime(dateTimeZone42);
        org.joda.time.MutableDateTime.Property property44 = mutableDateTime43.millisOfDay();
        org.joda.time.DateTimeField dateTimeField45 = property44.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField47 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology34, dateTimeField45, 6);
        int int49 = skipUndoDateTimeField47.getMinimumValue(28800032L);
        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime51 = dateTime50.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology53 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone54 = gregorianChronology53.getZone();
        org.joda.time.ReadablePeriod readablePeriod55 = null;
        long long58 = gregorianChronology53.add(readablePeriod55, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime59 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime60 = dateTime59.toLocalDateTime();
        int[] intArray62 = gregorianChronology53.get((org.joda.time.ReadablePartial) localDateTime60, (long) ' ');
        int[] intArray64 = skipUndoDateTimeField47.add((org.joda.time.ReadablePartial) localDateTime51, 0, intArray62, 0);
        iSOChronology22.validate((org.joda.time.ReadablePartial) localDateTime30, intArray64);
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone68 = gregorianChronology67.getZone();
        org.joda.time.ReadablePeriod readablePeriod69 = null;
        long long72 = gregorianChronology67.add(readablePeriod69, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime73 = org.joda.time.MutableDateTime.now();
        int int74 = mutableDateTime73.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone75 = null;
        org.joda.time.MutableDateTime mutableDateTime76 = mutableDateTime73.toMutableDateTime(dateTimeZone75);
        org.joda.time.MutableDateTime.Property property77 = mutableDateTime76.millisOfDay();
        org.joda.time.DateTimeField dateTimeField78 = property77.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField80 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology67, dateTimeField78, 6);
        int int82 = skipUndoDateTimeField80.getMinimumValue(28800032L);
        org.joda.time.DateTime dateTime83 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime84 = dateTime83.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology86 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone87 = gregorianChronology86.getZone();
        org.joda.time.ReadablePeriod readablePeriod88 = null;
        long long91 = gregorianChronology86.add(readablePeriod88, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime92 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime93 = dateTime92.toLocalDateTime();
        int[] intArray95 = gregorianChronology86.get((org.joda.time.ReadablePartial) localDateTime93, (long) ' ');
        int[] intArray97 = skipUndoDateTimeField80.add((org.joda.time.ReadablePartial) localDateTime84, 0, intArray95, 0);
        try {
            int[] intArray99 = skipUndoDateTimeField13.add((org.joda.time.ReadablePartial) localDateTime30, 57600000, intArray97, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 57600000");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfDay]" + "'", str14.equals("DateTimeField[millisOfDay]"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800099L + "'", long17 == 28800099L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "57600000" + "'", str21.equals("57600000"));
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localDateTime30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1L + "'", long39 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(localDateTime51);
        org.junit.Assert.assertNotNull(gregorianChronology53);
        org.junit.Assert.assertNotNull(dateTimeZone54);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1L + "'", long58 == 1L);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(localDateTime60);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1L + "'", long72 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 6 + "'", int74 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime76);
        org.junit.Assert.assertNotNull(property77);
        org.junit.Assert.assertNotNull(dateTimeField78);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(localDateTime84);
        org.junit.Assert.assertNotNull(gregorianChronology86);
        org.junit.Assert.assertNotNull(dateTimeZone87);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 1L + "'", long91 == 1L);
        org.junit.Assert.assertNotNull(dateTime92);
        org.junit.Assert.assertNotNull(localDateTime93);
        org.junit.Assert.assertNotNull(intArray95);
        org.junit.Assert.assertNotNull(intArray97);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology1.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        org.joda.time.ReadablePeriod readablePeriod10 = null;
//        long long13 = gregorianChronology8.add(readablePeriod10, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime14 = org.joda.time.MutableDateTime.now();
//        int int15 = mutableDateTime14.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.MutableDateTime mutableDateTime17 = mutableDateTime14.toMutableDateTime(dateTimeZone16);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField19 = property18.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology8, dateTimeField19, 6);
//        int int23 = skipUndoDateTimeField21.getMinimumValue(28800032L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology24.getZone();
//        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology24.getZone();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology24.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology24.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, (int) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField30.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField21, dateTimeFieldType31, (int) ' ');
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime35 = dateTime34.toLocalDateTime();
//        int int36 = offsetDateTimeField33.getMaximumValue((org.joda.time.ReadablePartial) localDateTime35);
//        long long38 = offsetDateTimeField33.roundHalfCeiling((long) (short) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology39.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone41 = gregorianChronology39.getZone();
//        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime43 = dateTime42.toLocalDateTime();
//        long long45 = gregorianChronology39.set((org.joda.time.ReadablePartial) localDateTime43, 28800100L);
//        int int46 = offsetDateTimeField33.getMinimumValue((org.joda.time.ReadablePartial) localDateTime43);
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = offsetDateTimeField7.getAsText((org.joda.time.ReadablePartial) localDateTime43, locale47);
//        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone50 = gregorianChronology49.getZone();
//        org.joda.time.ReadablePeriod readablePeriod51 = null;
//        long long54 = gregorianChronology49.add(readablePeriod51, (long) 1, (int) (short) 100);
//        org.joda.time.DateTime dateTime55 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
//        int[] intArray58 = gregorianChronology49.get((org.joda.time.ReadablePartial) localDateTime56, (long) ' ');
//        boolean boolean59 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime56);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = offsetDateTimeField7.getAsText((org.joda.time.ReadablePartial) localDateTime56, (int) (short) 1, locale61);
//        try {
//            java.lang.String str63 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime56);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(localDateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 86400031 + "'", int36 == 86400031);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 100L + "'", long38 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(localDateTime43);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560319071722L + "'", long45 == 1560319071722L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 33 + "'", int46 == 33);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "21471" + "'", str48.equals("21471"));
//        org.junit.Assert.assertNotNull(gregorianChronology49);
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1L + "'", long54 == 1L);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(localDateTime56);
//        org.junit.Assert.assertNotNull(intArray58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "1" + "'", str62.equals("1"));
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        mutableDateTime4.setZoneRetainFields(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime12 = dateTime10.minusHours((int) (short) 1);
        try {
            org.joda.time.DateTime dateTime17 = dateTime12.withTime(0, 10, 1969, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.append(dateTimeFormatter1);
        java.lang.StringBuffer stringBuffer3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        try {
            dateTimeFormatter1.printTo(stringBuffer3, (org.joda.time.ReadableInstant) dateTime4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("5:57:51 AM");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"5:57:51 AM/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        java.lang.String str14 = skipUndoDateTimeField13.toString();
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = gregorianChronology17.add(readablePeriod19, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime23 = org.joda.time.MutableDateTime.now();
        int int24 = mutableDateTime23.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.MutableDateTime mutableDateTime26 = mutableDateTime23.toMutableDateTime(dateTimeZone25);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime26.millisOfDay();
        org.joda.time.DateTimeField dateTimeField28 = property27.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology17, dateTimeField28, 6);
        int int32 = skipUndoDateTimeField30.getMinimumValue(28800032L);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime34 = dateTime33.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone37 = gregorianChronology36.getZone();
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        long long41 = gregorianChronology36.add(readablePeriod38, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime43 = dateTime42.toLocalDateTime();
        int[] intArray45 = gregorianChronology36.get((org.joda.time.ReadablePartial) localDateTime43, (long) ' ');
        int[] intArray47 = skipUndoDateTimeField30.add((org.joda.time.ReadablePartial) localDateTime34, 0, intArray45, 0);
        try {
            int[] intArray49 = skipUndoDateTimeField13.set(readablePartial15, (int) '4', intArray45, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfDay]" + "'", str14.equals("DateTimeField[millisOfDay]"));
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localDateTime34);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1L + "'", long41 == 1L);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localDateTime43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray47);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        java.lang.String str14 = skipUndoDateTimeField13.toString();
        boolean boolean16 = skipUndoDateTimeField13.isLeap((long) (short) -1);
        org.joda.time.DateTimeField dateTimeField17 = skipUndoDateTimeField13.getWrappedField();
        boolean boolean18 = skipUndoDateTimeField13.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfDay]" + "'", str14.equals("DateTimeField[millisOfDay]"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.monthOfYear();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = buddhistChronology2.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str3.equals("BuddhistChronology[America/Los_Angeles]"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimePrinter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", "DateTimeField[millisOfDay]", true, 10, 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology12.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField18.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder11.appendText(dateTimeFieldType19);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendDayOfYear((-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        boolean boolean7 = jodaTimePermission1.equals((java.lang.Object) dateTimeFormatterBuilder6);
        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
        int int9 = mutableDateTime8.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime8.toMutableDateTime(dateTimeZone10);
        boolean boolean12 = mutableDateTime8.isAfterNow();
        jodaTimePermission1.checkGuard((java.lang.Object) mutableDateTime8);
        org.joda.time.MutableDateTime mutableDateTime14 = mutableDateTime8.copy();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        try {
            mutableDateTime8.add(durationFieldType15, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(mutableDateTime14);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
//        long long6 = mutableDateTime2.getMillis();
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1L));
//        org.joda.time.MutableDateTime mutableDateTime11 = property8.roundFloor();
//        java.lang.String str12 = property8.toString();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560344272277L + "'", long6 == 1560344272277L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[dayOfYear]" + "'", str12.equals("Property[dayOfYear]"));
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(1L, (org.joda.time.Chronology) gregorianChronology2, locale4, (java.lang.Integer) 0);
        java.lang.Integer int7 = dateTimeParserBucket6.getPivotYear();
        dateTimeParserBucket6.setOffset(960);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7.equals(0));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("DateTimeField[secondOfDay]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: DateTimeField[secondOfDay]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("Property[dayOfYear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[dayOfYear]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        int int15 = skipUndoDateTimeField13.getMinimumValue(28800032L);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime17 = dateTime16.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        long long24 = gregorianChronology19.add(readablePeriod21, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime26 = dateTime25.toLocalDateTime();
        int[] intArray28 = gregorianChronology19.get((org.joda.time.ReadablePartial) localDateTime26, (long) ' ');
        int[] intArray30 = skipUndoDateTimeField13.add((org.joda.time.ReadablePartial) localDateTime17, 0, intArray28, 0);
        java.lang.String str32 = skipUndoDateTimeField13.getAsShortText((long) ' ');
        try {
            int int35 = skipUndoDateTimeField13.getDifference(1560344268271L, 2440588L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1560341827683");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDateTime17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "57600032" + "'", str32.equals("57600032"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(1L, (org.joda.time.Chronology) gregorianChronology2, locale4, (java.lang.Integer) 0);
        java.lang.Integer int7 = dateTimeParserBucket6.getPivotYear();
        long long10 = dateTimeParserBucket6.computeMillis(true, "1969-12-31T16:00:00.000-08:00");
        dateTimeParserBucket6.setOffset((java.lang.Integer) 18058);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7.equals(0));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28800001L + "'", long10 == 28800001L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_FLOOR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
        boolean boolean7 = mutableDateTime5.isEqual((long) 960);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime();
        org.joda.time.Chronology chronology9 = mutableDateTime8.getChronology();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime8.monthOfYear();
        mutableDateTime8.setDayOfYear((int) (byte) 10);
        mutableDateTime5.setTime((org.joda.time.ReadableInstant) mutableDateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(property10);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology8.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) (short) -1);
//        long long17 = offsetDateTimeField14.getDifferenceAsLong(1560344238929L, (long) 6);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField14.getRangeDurationField();
//        org.joda.time.DurationField durationField19 = offsetDateTimeField14.getLeapDurationField();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = offsetDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, locale22);
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology25.getZone();
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        long long30 = gregorianChronology25.add(readablePeriod27, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime31 = org.joda.time.MutableDateTime.now();
//        int int32 = mutableDateTime31.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone33 = null;
//        org.joda.time.MutableDateTime mutableDateTime34 = mutableDateTime31.toMutableDateTime(dateTimeZone33);
//        org.joda.time.MutableDateTime.Property property35 = mutableDateTime34.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField36 = property35.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField38 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology25, dateTimeField36, 6);
//        int int40 = skipUndoDateTimeField38.getMinimumValue(28800032L);
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime42 = dateTime41.toLocalDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone45 = gregorianChronology44.getZone();
//        org.joda.time.ReadablePeriod readablePeriod46 = null;
//        long long49 = gregorianChronology44.add(readablePeriod46, (long) 1, (int) (short) 100);
//        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime51 = dateTime50.toLocalDateTime();
//        int[] intArray53 = gregorianChronology44.get((org.joda.time.ReadablePartial) localDateTime51, (long) ' ');
//        int[] intArray55 = skipUndoDateTimeField38.add((org.joda.time.ReadablePartial) localDateTime42, 0, intArray53, 0);
//        try {
//            int[] intArray57 = delegatedDateTimeField7.set((org.joda.time.ReadablePartial) localDateTime21, 1969, intArray55, 52);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1969");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560344238L + "'", long17 == 1560344238L);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localDateTime21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "21473" + "'", str23.equals("21473"));
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(localDateTime42);
//        org.junit.Assert.assertNotNull(gregorianChronology44);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1L + "'", long49 == 1L);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(localDateTime51);
//        org.junit.Assert.assertNotNull(intArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime0.withYearOfEra((int) '4');
        boolean boolean7 = dateTime5.isEqual((long) (short) -1);
        org.joda.time.Instant instant8 = dateTime5.toInstant();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.DateTime dateTime11 = dateTime5.withFieldAdded(durationFieldType9, 57600063);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(instant8);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
//        org.joda.time.DateTime.Property property3 = dateTime0.yearOfCentury();
//        boolean boolean4 = dateTime0.isEqualNow();
//        org.joda.time.DateTime.Property property5 = dateTime0.minuteOfDay();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) 12);
//        java.lang.String str8 = property5.getAsText();
//        boolean boolean9 = property5.isLeap();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(localDateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "357" + "'", str8.equals("357"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField3 = gregorianChronology1.millis();
        org.joda.time.DurationField durationField4 = gregorianChronology1.years();
        long long7 = durationField4.subtract((-1L), (int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 31535999999L + "'", long7 == 31535999999L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone7);
        long long11 = dateTimeZone7.convertLocalToUTC((long) (byte) 100, true);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        long long15 = dateTimeZone12.convertLocalToUTC((-57599097L), true);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800100L + "'", long11 == 28800100L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-28799097L) + "'", long15 == (-28799097L));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 10, 357);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3570L + "'", long2 == 3570L);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
//        int int7 = mutableDateTime6.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
//        java.lang.String str14 = skipUndoDateTimeField13.toString();
//        long long17 = skipUndoDateTimeField13.addWrapField(28800100L, (-1));
//        long long19 = skipUndoDateTimeField13.roundFloor(0L);
//        java.lang.String str21 = skipUndoDateTimeField13.getAsShortText(0L);
//        long long24 = skipUndoDateTimeField13.set(1560319066749L, 7);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter26.withChronology((org.joda.time.Chronology) gregorianChronology27);
//        java.util.Locale locale29 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket(1L, (org.joda.time.Chronology) gregorianChronology27, locale29, (java.lang.Integer) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology32.getZone();
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime36 = dateTime35.toLocalDateTime();
//        long long38 = gregorianChronology32.set((org.joda.time.ReadablePartial) localDateTime36, 28800100L);
//        long long40 = gregorianChronology27.set((org.joda.time.ReadablePartial) localDateTime36, (long) 1969);
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone43 = gregorianChronology42.getZone();
//        org.joda.time.ReadablePeriod readablePeriod44 = null;
//        long long47 = gregorianChronology42.add(readablePeriod44, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime48 = org.joda.time.MutableDateTime.now();
//        int int49 = mutableDateTime48.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone50 = null;
//        org.joda.time.MutableDateTime mutableDateTime51 = mutableDateTime48.toMutableDateTime(dateTimeZone50);
//        org.joda.time.MutableDateTime.Property property52 = mutableDateTime51.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField53 = property52.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField55 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology42, dateTimeField53, 6);
//        int int57 = skipUndoDateTimeField55.getMinimumValue(28800032L);
//        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime59 = dateTime58.toLocalDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone62 = gregorianChronology61.getZone();
//        org.joda.time.ReadablePeriod readablePeriod63 = null;
//        long long66 = gregorianChronology61.add(readablePeriod63, (long) 1, (int) (short) 100);
//        org.joda.time.DateTime dateTime67 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime68 = dateTime67.toLocalDateTime();
//        int[] intArray70 = gregorianChronology61.get((org.joda.time.ReadablePartial) localDateTime68, (long) ' ');
//        int[] intArray72 = skipUndoDateTimeField55.add((org.joda.time.ReadablePartial) localDateTime59, 0, intArray70, 0);
//        try {
//            int[] intArray74 = skipUndoDateTimeField13.addWrapPartial((org.joda.time.ReadablePartial) localDateTime36, (int) (short) 100, intArray70, 22065);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfDay]" + "'", str14.equals("DateTimeField[millisOfDay]"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800099L + "'", long17 == 28800099L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "57600000" + "'", str21.equals("57600000"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236400007L + "'", long24 == 1560236400007L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(gregorianChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(localDateTime36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560319073858L + "'", long38 == 1560319073858L);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560344273858L + "'", long40 == 1560344273858L);
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1L + "'", long47 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(localDateTime59);
//        org.junit.Assert.assertNotNull(gregorianChronology61);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1L + "'", long66 == 1L);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(localDateTime68);
//        org.junit.Assert.assertNotNull(intArray70);
//        org.junit.Assert.assertNotNull(intArray72);
//    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        boolean boolean3 = mutableDateTime0.isEqual((long) ' ');
//        mutableDateTime0.addMonths((int) (short) 10);
//        int int6 = mutableDateTime0.getDayOfMonth();
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime0.yearOfEra();
//        org.joda.time.MutableDateTime mutableDateTime8 = org.joda.time.MutableDateTime.now();
//        int int9 = mutableDateTime8.getMonthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.now();
//        int int11 = mutableDateTime10.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.MutableDateTime mutableDateTime13 = mutableDateTime10.toMutableDateTime(dateTimeZone12);
//        long long14 = mutableDateTime10.getMillis();
//        mutableDateTime8.setMillis((org.joda.time.ReadableInstant) mutableDateTime10);
//        org.joda.time.MutableDateTime.Property property16 = mutableDateTime8.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime18 = property16.add((-1L));
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime20 = dateTime19.toLocalDateTime();
//        org.joda.time.DateTime.Property property21 = dateTime19.dayOfWeek();
//        org.joda.time.DateTime.Property property22 = dateTime19.dayOfMonth();
//        org.joda.time.ReadableDuration readableDuration23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime19.minus(readableDuration23);
//        boolean boolean25 = mutableDateTime18.isBefore((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology26.getZone();
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        long long31 = gregorianChronology26.add(readablePeriod28, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime32 = org.joda.time.MutableDateTime.now();
//        int int33 = mutableDateTime32.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone34 = null;
//        org.joda.time.MutableDateTime mutableDateTime35 = mutableDateTime32.toMutableDateTime(dateTimeZone34);
//        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField37 = property36.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology26, dateTimeField37, 6);
//        java.lang.String str40 = skipUndoDateTimeField39.toString();
//        boolean boolean42 = skipUndoDateTimeField39.isLeap((long) (short) -1);
//        int int44 = skipUndoDateTimeField39.getMaximumValue((long) 'a');
//        int int45 = skipUndoDateTimeField39.getMaximumValue();
//        java.lang.String str46 = skipUndoDateTimeField39.getName();
//        int int48 = skipUndoDateTimeField39.getLeapAmount((-1560344266162L));
//        int int49 = mutableDateTime18.get((org.joda.time.DateTimeField) skipUndoDateTimeField39);
//        int int50 = property7.getDifference((org.joda.time.ReadableInstant) mutableDateTime18);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560344273898L + "'", long14 == 1560344273898L);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "DateTimeField[millisOfDay]" + "'", str40.equals("DateTimeField[millisOfDay]"));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 86399999 + "'", int44 == 86399999);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 86399999 + "'", int45 == 86399999);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "millisOfDay" + "'", str46.equals("millisOfDay"));
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 21473898 + "'", int49 == 21473898);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withPivotYear(6);
        try {
            org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.parse("JulianChronology[America/Los_Angeles]", dateTimeFormatter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"JulianChronology[America/Los_Ang...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 960);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210783816000000L) + "'", long1 == (-210783816000000L));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) -1);
        org.joda.time.Chronology chronology5 = julianChronology0.withZone(dateTimeZone2);
        try {
            org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (-1560344266162L), (-97));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral(' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        long long14 = gregorianChronology9.add(readablePeriod11, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime15 = org.joda.time.MutableDateTime.now();
        int int16 = mutableDateTime15.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.MutableDateTime mutableDateTime18 = mutableDateTime15.toMutableDateTime(dateTimeZone17);
        org.joda.time.MutableDateTime.Property property19 = mutableDateTime18.millisOfDay();
        org.joda.time.DateTimeField dateTimeField20 = property19.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology9, dateTimeField20, 6);
        int int24 = skipUndoDateTimeField22.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone26 = gregorianChronology25.getZone();
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology25.getZone();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology25.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology25.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField29, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField31.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField22, dateTimeFieldType32, (int) ' ');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder8.appendDecimal(dateTimeFieldType32, (int) (short) -1, 21470);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.Chronology chronology1 = mutableDateTime0.getChronology();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.monthOfYear();
        mutableDateTime0.setDayOfYear((int) (byte) 10);
        mutableDateTime0.setMonthOfYear(10);
        try {
            mutableDateTime0.setDate(960, (int) (byte) -1, (-2));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
        int int3 = mutableDateTime2.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime5, (org.joda.time.ReadableInstant) mutableDateTime6);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        mutableDateTime6.setZoneRetainFields(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusHours((int) (short) 1);
        org.joda.time.DateTime dateTime16 = dateTime12.plusHours((int) (short) -1);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimePrinter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendSecondOfMinute((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder5.appendMonthOfYear(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, number1, (java.lang.Number) 22065, (java.lang.Number) 1560344270257L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology1.add(readablePeriod3, (long) 1, (int) (short) 100);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gregorianChronology1, locale7);
        dateTimeParserBucket8.setPivotYear((java.lang.Integer) (-1));
        long long11 = dateTimeParserBucket8.computeMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter15.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder12.append(dateTimePrinter16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendSecondOfMinute((int) 'a');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder17.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder17.appendMonthOfYear(86400031);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder17.appendFractionOfDay(21470, (-2));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder25.appendTimeZoneName();
        boolean boolean27 = dateTimeParserBucket8.restoreState((java.lang.Object) dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800032L + "'", long11 == 28800032L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimePrinter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
//        long long6 = mutableDateTime2.getMillis();
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime9 = property8.getMutableDateTime();
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) ' ');
//        int int12 = property8.compareTo((org.joda.time.ReadableInstant) mutableDateTime11);
//        java.util.Locale locale14 = null;
//        try {
//            org.joda.time.MutableDateTime mutableDateTime15 = property8.set("GJChronology[America/Los_Angeles,cutover=1970-01-01,mdfw=5]", locale14);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GJChronology[America/Los_Angeles,cutover=1970-01-01,mdfw=5]\" for dayOfYear is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560344274857L + "'", long6 == 1560344274857L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.Chronology chronology1 = mutableDateTime0.getChronology();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.monthOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology4.getZone();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        long long9 = gregorianChronology4.add(readablePeriod6, (long) 1, (int) (short) 100);
        java.util.Locale locale10 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gregorianChronology4, locale10);
        dateTimeParserBucket11.setPivotYear((java.lang.Integer) (-1));
        long long14 = dateTimeParserBucket11.computeMillis();
        long long17 = dateTimeParserBucket11.computeMillis(false, "4:00:00 PM");
        dateTimeParserBucket11.setOffset((java.lang.Integer) (-25200000));
        org.joda.time.DateTimeField dateTimeField20 = null;
        dateTimeParserBucket11.saveField(dateTimeField20, 57600000);
        boolean boolean23 = property2.equals((java.lang.Object) 57600000);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28800032L + "'", long14 == 28800032L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800032L + "'", long17 == 28800032L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560344274916L + "'", long0 == 1560344274916L);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gregorianChronology6.add(readablePeriod8, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now();
        int int13 = mutableDateTime12.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.toMutableDateTime(dateTimeZone14);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.millisOfDay();
        org.joda.time.DateTimeField dateTimeField17 = property16.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField17, 6);
        int int21 = skipUndoDateTimeField19.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology22.getZone();
        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology22.getZone();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField19, dateTimeFieldType29, (int) ' ');
        long long34 = skipUndoDateTimeField19.add((long) (short) 0, 2440588L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField19);
        long long37 = skipUndoDateTimeField19.roundCeiling(1560319070383L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2440588L + "'", long34 == 2440588L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560319070383L + "'", long37 == 1560319070383L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        org.joda.time.DateTime.Property property7 = dateTime5.dayOfWeek();
        org.joda.time.DateTime.Property property8 = dateTime5.dayOfMonth();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology14.getZone();
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone16);
        org.joda.time.DateTime dateTime18 = dateTime5.toDateTime(dateTimeZone16);
        java.lang.String str19 = dateTimeZone16.getID();
        try {
            org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(960, 31, 58200, 0, (-2), dateTimeZone16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "America/Los_Angeles" + "'", str19.equals("America/Los_Angeles"));
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
//        org.joda.time.DateTime.Property property3 = dateTime0.dayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime0.minus(readableDuration4);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime5.minus(readablePeriod6);
//        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.DateTimeFormat.shortDate();
//        java.lang.String str10 = dateTime7.toString(dateTimeFormatter9);
//        int int11 = dateTimeFormatter9.getDefaultYear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(localDateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6/12/19" + "'", str10.equals("6/12/19"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2000 + "'", int11 == 2000);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.Interval interval3 = property2.toInterval();
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval3);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(interval3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.DateTimeField dateTimeField1 = mutableDateTime0.getRoundingField();
        org.junit.Assert.assertNull(dateTimeField1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter3.getParser();
        java.lang.Appendable appendable5 = null;
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime7 = dateTime6.toLocalDateTime();
        org.joda.time.DateTime.Property property8 = dateTime6.dayOfWeek();
        org.joda.time.DateTime.Property property9 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime11 = dateTime6.withYearOfEra((int) '4');
        boolean boolean13 = dateTime11.isEqual((long) (short) -1);
        org.joda.time.Instant instant14 = dateTime11.toInstant();
        org.joda.time.Instant instant16 = instant14.minus((long) 58200);
        try {
            dateTimeFormatter3.printTo(appendable5, (org.joda.time.ReadableInstant) instant16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(instant14);
        org.junit.Assert.assertNotNull(instant16);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) ' ');
        boolean boolean3 = dateTimeFormatter2.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test317");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
//        long long6 = mutableDateTime2.getMillis();
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime9 = property8.getMutableDateTime();
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) ' ');
//        int int12 = property8.compareTo((org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.MutableDateTime mutableDateTime14 = property8.add((long) '4');
//        org.joda.time.MutableDateTime mutableDateTime15 = property8.roundHalfFloor();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560344275237L + "'", long6 == 1560344275237L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(mutableDateTime14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField6.getType();
        org.joda.time.DurationField durationField8 = offsetDateTimeField6.getLeapDurationField();
        long long10 = offsetDateTimeField6.roundHalfCeiling((long) (-25200000));
        long long12 = offsetDateTimeField6.roundHalfFloor((long) 7);
        int int14 = offsetDateTimeField6.getLeapAmount((long) (byte) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-25200000L) + "'", long10 == (-25200000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
//        org.joda.time.DateTime.Property property3 = dateTime0.dayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime0.minus(readableDuration4);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime5.minus(readablePeriod6);
//        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.DateTimeFormat.shortDate();
//        java.lang.String str10 = dateTime7.toString(dateTimeFormatter9);
//        java.io.Writer writer11 = null;
//        try {
//            dateTimeFormatter9.printTo(writer11, 1560319066749L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(localDateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6/12/19" + "'", str10.equals("6/12/19"));
//    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test320");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
//        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
//        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
//        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
//        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
//        int int28 = mutableDateTime27.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
//        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
//        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
//        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
//        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
//        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
//        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
//        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology51.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (short) -1);
//        long long60 = offsetDateTimeField57.getDifferenceAsLong(1560344238929L, (long) 6);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField57.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField61);
//        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone64 = gregorianChronology63.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology65.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone67 = gregorianChronology65.getZone();
//        org.joda.time.DateTime dateTime68 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime69 = dateTime68.toLocalDateTime();
//        long long71 = gregorianChronology65.set((org.joda.time.ReadablePartial) localDateTime69, 28800100L);
//        long long73 = gregorianChronology63.set((org.joda.time.ReadablePartial) localDateTime69, 0L);
//        try {
//            int int74 = unsupportedDateTimeField62.getMinimumValue((org.joda.time.ReadablePartial) localDateTime69);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(gregorianChronology51);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344238L + "'", long60 == 1560344238L);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
//        org.junit.Assert.assertNotNull(gregorianChronology63);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertNotNull(gregorianChronology65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertNotNull(dateTimeZone67);
//        org.junit.Assert.assertNotNull(dateTime68);
//        org.junit.Assert.assertNotNull(localDateTime69);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560319076139L + "'", long71 == 1560319076139L);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1560344276139L + "'", long73 == 1560344276139L);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
        int int28 = mutableDateTime27.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology51.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (short) -1);
        long long60 = offsetDateTimeField57.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField61 = offsetDateTimeField57.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField61);
        long long65 = unsupportedDateTimeField62.add((long) 22065, 2000);
        java.util.Locale locale67 = null;
        try {
            java.lang.String str68 = unsupportedDateTimeField62.getAsShortText((-28800000), locale67);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344238L + "'", long60 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 172796422065L + "'", long65 == 172796422065L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
        int int28 = mutableDateTime27.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology51.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (short) -1);
        long long60 = offsetDateTimeField57.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField61 = offsetDateTimeField57.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField61);
        try {
            java.lang.String str64 = unsupportedDateTimeField62.getAsText((long) 19);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344238L + "'", long60 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) (short) -1);
//        long long11 = offsetDateTimeField8.add((long) (short) 10, 31);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology12.getZone();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime16 = dateTime15.toLocalDateTime();
//        long long18 = gregorianChronology12.set((org.joda.time.ReadablePartial) localDateTime16, 28800100L);
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField8.getAsText((org.joda.time.ReadablePartial) localDateTime16, locale19);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDateTime16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 31010L + "'", long11 == 31010L);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(localDateTime16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560319076842L + "'", long18 == 1560319076842L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "21476" + "'", str20.equals("21476"));
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("-1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-1\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology1.getZone();
        org.joda.time.Chronology chronology4 = gJChronology0.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = gJChronology0.withUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
//        long long6 = mutableDateTime2.getMillis();
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = mutableDateTime2.toCalendar(locale8);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime2.dayOfWeek();
//        org.joda.time.MutableDateTime mutableDateTime11 = property10.getMutableDateTime();
//        java.util.Date date12 = mutableDateTime11.toDate();
//        org.joda.time.DurationFieldType durationFieldType13 = null;
//        try {
//            mutableDateTime11.add(durationFieldType13, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560344277106L + "'", long6 == 1560344277106L);
//        org.junit.Assert.assertNotNull(calendar9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertNotNull(date12);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
        int int28 = mutableDateTime27.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology51.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (short) -1);
        long long60 = offsetDateTimeField57.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField61 = offsetDateTimeField57.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField61);
        long long65 = unsupportedDateTimeField62.add((long) 22065, 2000);
        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone67 = gregorianChronology66.getZone();
        org.joda.time.ReadablePeriod readablePeriod68 = null;
        long long71 = gregorianChronology66.add(readablePeriod68, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime72 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime73 = dateTime72.toLocalDateTime();
        int[] intArray75 = gregorianChronology66.get((org.joda.time.ReadablePartial) localDateTime73, (long) ' ');
        java.util.Locale locale76 = null;
        try {
            java.lang.String str77 = unsupportedDateTimeField62.getAsShortText((org.joda.time.ReadablePartial) localDateTime73, locale76);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344238L + "'", long60 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 172796422065L + "'", long65 == 172796422065L);
        org.junit.Assert.assertNotNull(gregorianChronology66);
        org.junit.Assert.assertNotNull(dateTimeZone67);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1L + "'", long71 == 1L);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(localDateTime73);
        org.junit.Assert.assertNotNull(intArray75);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test330");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
//        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
//        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
//        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
//        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
//        int int28 = mutableDateTime27.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
//        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
//        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
//        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
//        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
//        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
//        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
//        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology51.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (short) -1);
//        long long60 = offsetDateTimeField57.getDifferenceAsLong(1560344238929L, (long) 6);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField57.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField61);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter64 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology65 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter66 = dateTimeFormatter64.withChronology((org.joda.time.Chronology) gregorianChronology65);
//        java.util.Locale locale67 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket69 = new org.joda.time.format.DateTimeParserBucket(1L, (org.joda.time.Chronology) gregorianChronology65, locale67, (java.lang.Integer) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField71 = gregorianChronology70.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone72 = gregorianChronology70.getZone();
//        org.joda.time.DateTime dateTime73 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime74 = dateTime73.toLocalDateTime();
//        long long76 = gregorianChronology70.set((org.joda.time.ReadablePartial) localDateTime74, 28800100L);
//        long long78 = gregorianChronology65.set((org.joda.time.ReadablePartial) localDateTime74, (long) 1969);
//        java.util.Locale locale79 = null;
//        try {
//            java.lang.String str80 = unsupportedDateTimeField62.getAsText((org.joda.time.ReadablePartial) localDateTime74, locale79);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(gregorianChronology51);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344238L + "'", long60 == 1560344238L);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
//        org.junit.Assert.assertNotNull(dateTimeFormatter64);
//        org.junit.Assert.assertNotNull(gregorianChronology65);
//        org.junit.Assert.assertNotNull(dateTimeFormatter66);
//        org.junit.Assert.assertNotNull(gregorianChronology70);
//        org.junit.Assert.assertNotNull(dateTimeField71);
//        org.junit.Assert.assertNotNull(dateTimeZone72);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(localDateTime74);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 1560319077669L + "'", long76 == 1560319077669L);
//        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1560344277669L + "'", long78 == 1560344277669L);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter1.getPrinter();
        try {
            org.joda.time.Instant instant3 = org.joda.time.Instant.parse("1", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        org.joda.time.DurationField durationField4 = property3.getDurationField();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(durationField4);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
//        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
//        org.joda.time.DateTime dateTime5 = dateTime0.withYearOfEra((int) '4');
//        org.joda.time.DateTime dateTime7 = dateTime5.minusDays(0);
//        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime();
//        boolean boolean9 = dateTime7.isBefore((org.joda.time.ReadableInstant) mutableDateTime8);
//        org.joda.time.MutableDateTime mutableDateTime10 = mutableDateTime8.copy();
//        mutableDateTime10.addMinutes(58200);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime17 = dateTime15.minus((long) (-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology18.getZone();
//        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology18.getZone();
//        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology18.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology18.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField24.getType();
//        int int26 = dateTime17.get(dateTimeFieldType25);
//        mutableDateTime10.set(dateTimeFieldType25, 22074);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(localDateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 22077 + "'", int26 == 22077);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.plus((long) 100);
        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime12);
        try {
            org.joda.time.DateTime dateTime15 = dateTime12.withDayOfWeek((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
//        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
//        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
//        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
//        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
//        int int28 = mutableDateTime27.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
//        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
//        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
//        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
//        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
//        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
//        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
//        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology51.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (short) -1);
//        long long60 = offsetDateTimeField57.getDifferenceAsLong(1560344238929L, (long) 6);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField57.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField61);
//        long long65 = unsupportedDateTimeField62.add((long) 22065, 2000);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter67 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology68 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter69 = dateTimeFormatter67.withChronology((org.joda.time.Chronology) gregorianChronology68);
//        java.util.Locale locale70 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket72 = new org.joda.time.format.DateTimeParserBucket(1L, (org.joda.time.Chronology) gregorianChronology68, locale70, (java.lang.Integer) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology73 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField74 = gregorianChronology73.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone75 = gregorianChronology73.getZone();
//        org.joda.time.DateTime dateTime76 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime77 = dateTime76.toLocalDateTime();
//        long long79 = gregorianChronology73.set((org.joda.time.ReadablePartial) localDateTime77, 28800100L);
//        long long81 = gregorianChronology68.set((org.joda.time.ReadablePartial) localDateTime77, (long) 1969);
//        java.util.Locale locale83 = null;
//        try {
//            java.lang.String str84 = unsupportedDateTimeField62.getAsText((org.joda.time.ReadablePartial) localDateTime77, 0, locale83);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(gregorianChronology51);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344238L + "'", long60 == 1560344238L);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 172796422065L + "'", long65 == 172796422065L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter67);
//        org.junit.Assert.assertNotNull(gregorianChronology68);
//        org.junit.Assert.assertNotNull(dateTimeFormatter69);
//        org.junit.Assert.assertNotNull(gregorianChronology73);
//        org.junit.Assert.assertNotNull(dateTimeField74);
//        org.junit.Assert.assertNotNull(dateTimeZone75);
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertNotNull(localDateTime77);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1560319078058L + "'", long79 == 1560319078058L);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 1560344278058L + "'", long81 == 1560344278058L);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundCeiling();
        org.joda.time.MutableDateTime mutableDateTime7 = property4.add((-1));
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField6.getType();
        org.joda.time.DurationField durationField8 = offsetDateTimeField6.getLeapDurationField();
        long long10 = offsetDateTimeField6.roundHalfCeiling((long) (-25200000));
        int int11 = offsetDateTimeField6.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-25200000L) + "'", long10 == (-25200000L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 86398 + "'", int11 == 86398);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime0.withYearOfEra((int) '4');
        boolean boolean7 = dateTime5.isEqual((long) (short) -1);
        org.joda.time.Instant instant8 = dateTime5.toInstant();
        org.joda.time.DateTime dateTime9 = instant8.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMonthOfYear(1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear(32);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendCenturyOfEra((int) (short) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        boolean boolean7 = jodaTimePermission1.equals((java.lang.Object) dateTimeFormatterBuilder6);
        org.joda.time.JodaTimePermission jodaTimePermission9 = new org.joda.time.JodaTimePermission("hi!");
        java.security.PermissionCollection permissionCollection10 = jodaTimePermission9.newPermissionCollection();
        boolean boolean11 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission9);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField14 = iSOChronology13.hours();
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket((long) 9, (org.joda.time.Chronology) iSOChronology13, locale15, (java.lang.Integer) 31, 1);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology13.yearOfEra();
        boolean boolean20 = jodaTimePermission1.equals((java.lang.Object) dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(permissionCollection10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter7.withChronology((org.joda.time.Chronology) gregorianChronology8);
        org.joda.time.DurationField durationField10 = gregorianChronology8.millis();
        org.joda.time.DurationField durationField11 = gregorianChronology8.seconds();
        org.joda.time.Chronology chronology12 = gregorianChronology8.withUTC();
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(86398, 0, 2000, (int) (short) 0, (int) (short) -1, 52, 19, (org.joda.time.Chronology) gregorianChronology8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology8.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) (short) -1);
//        long long17 = offsetDateTimeField14.add((long) (short) 10, 31);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology18.getZone();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime22 = dateTime21.toLocalDateTime();
//        long long24 = gregorianChronology18.set((org.joda.time.ReadablePartial) localDateTime22, 28800100L);
//        java.util.Locale locale25 = null;
//        java.lang.String str26 = offsetDateTimeField14.getAsText((org.joda.time.ReadablePartial) localDateTime22, locale25);
//        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology28.getZone();
//        org.joda.time.ReadablePeriod readablePeriod30 = null;
//        long long33 = gregorianChronology28.add(readablePeriod30, (long) 1, (int) (short) 100);
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime35 = dateTime34.toLocalDateTime();
//        int[] intArray37 = gregorianChronology28.get((org.joda.time.ReadablePartial) localDateTime35, (long) ' ');
//        java.util.Locale locale39 = null;
//        try {
//            int[] intArray40 = delegatedDateTimeField7.set((org.joda.time.ReadablePartial) localDateTime22, 9, intArray37, "1969-12-31T16:00:00.000", locale39);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-31T16:00:00.000\" for secondOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31010L + "'", long17 == 31010L);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(localDateTime22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560319078751L + "'", long24 == 1560319078751L);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "21478" + "'", str26.equals("21478"));
//        org.junit.Assert.assertNotNull(gregorianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1L + "'", long33 == 1L);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(localDateTime35);
//        org.junit.Assert.assertNotNull(intArray37);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
//        long long9 = offsetDateTimeField6.getDifferenceAsLong(1560344238929L, (long) 6);
//        org.joda.time.DurationField durationField10 = offsetDateTimeField6.getRangeDurationField();
//        org.joda.time.DurationField durationField11 = offsetDateTimeField6.getLeapDurationField();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime13 = dateTime12.toLocalDateTime();
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = offsetDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDateTime13, locale14);
//        int int16 = offsetDateTimeField6.getMaximumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344238L + "'", long9 == 1560344238L);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(localDateTime13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "21478" + "'", str15.equals("21478"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 86398 + "'", int16 == 86398);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.Chronology chronology1 = mutableDateTime0.getChronology();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.monthOfYear();
        mutableDateTime0.setDayOfYear((int) (byte) 10);
        mutableDateTime0.setMonthOfYear(10);
        mutableDateTime0.setYear((int) '#');
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1560344276762L, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 81137902391624L + "'", long2 == 81137902391624L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
        int int28 = mutableDateTime27.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology51.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (short) -1);
        long long60 = offsetDateTimeField57.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField61 = offsetDateTimeField57.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField61);
        try {
            long long64 = unsupportedDateTimeField62.roundFloor((long) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344238L + "'", long60 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimePrinter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", "DateTimeField[millisOfDay]", true, 10, 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder0.appendTimeZoneOffset("57600000", true, 0, 86398);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
//        long long6 = mutableDateTime2.getMillis();
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1L));
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime();
//        org.joda.time.Chronology chronology12 = mutableDateTime11.getChronology();
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime11.monthOfYear();
//        mutableDateTime11.setMillis((long) 9);
//        mutableDateTime11.addSeconds((int) (short) 10);
//        int int18 = mutableDateTime11.getMillisOfSecond();
//        org.joda.time.Instant instant19 = new org.joda.time.Instant((java.lang.Object) mutableDateTime11);
//        java.util.GregorianCalendar gregorianCalendar20 = mutableDateTime11.toGregorianCalendar();
//        int int21 = property8.getDifference((org.joda.time.ReadableInstant) mutableDateTime11);
//        int int22 = mutableDateTime11.getRoundingMode();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560344279198L + "'", long6 == 1560344279198L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
//        org.junit.Assert.assertNotNull(gregorianCalendar20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 18058 + "'", int21 == 18058);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter3.getParser();
        int int5 = dateTimeFormatter3.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2000 + "'", int5 == 2000);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology1.add(readablePeriod3, (long) 1, (int) (short) 100);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gregorianChronology1, locale7);
        dateTimeParserBucket8.setPivotYear((java.lang.Integer) (-1));
        long long11 = dateTimeParserBucket8.computeMillis();
        long long14 = dateTimeParserBucket8.computeMillis(false, "4:00:00 PM");
        dateTimeParserBucket8.setOffset((java.lang.Integer) (-25200000));
        java.lang.Object obj17 = dateTimeParserBucket8.saveState();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800032L + "'", long11 == 28800032L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28800032L + "'", long14 == 28800032L);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.Chronology chronology1 = mutableDateTime0.getChronology();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.monthOfYear();
        mutableDateTime0.setMillis((long) 9);
        mutableDateTime0.addSeconds((int) (short) 10);
        int int7 = mutableDateTime0.getMillisOfSecond();
        org.joda.time.Instant instant8 = new org.joda.time.Instant((java.lang.Object) mutableDateTime0);
        org.joda.time.Chronology chronology9 = null;
        mutableDateTime0.setChronology(chronology9);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
//        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
//        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology5.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology5.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = offsetDateTimeField11.getType();
//        int int13 = dateTime4.get(dateTimeFieldType12);
//        org.joda.time.DateTime.Property property14 = dateTime4.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = dateTime4.minusHours((int) (short) 0);
//        java.util.Date date17 = dateTime16.toDate();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 22079 + "'", int13 == 22079);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(date17);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology1.add(readablePeriod3, (long) 1, (int) (short) 100);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gregorianChronology1, locale7);
        dateTimeParserBucket8.setPivotYear((java.lang.Integer) (-1));
        long long11 = dateTimeParserBucket8.computeMillis();
        long long14 = dateTimeParserBucket8.computeMillis(false, "4:00:00 PM");
        dateTimeParserBucket8.setOffset((java.lang.Integer) (-25200000));
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime18 = dateTime17.toLocalDateTime();
        org.joda.time.DateTime.Property property19 = dateTime17.dayOfWeek();
        org.joda.time.DateTime.Property property20 = dateTime17.dayOfMonth();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime17.minus(readableDuration21);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology23.getZone();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.weekOfWeekyear();
        boolean boolean27 = dateTime17.equals((java.lang.Object) dateTimeField26);
        dateTimeParserBucket8.saveField(dateTimeField26, 5);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800032L + "'", long11 == 28800032L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 28800032L + "'", long14 == 28800032L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localDateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        boolean boolean3 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        dateTimeFormatterBuilder0.clear();
        boolean boolean6 = dateTimeFormatterBuilder0.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
        long long9 = offsetDateTimeField6.add((long) (short) 10, 31);
        long long12 = offsetDateTimeField6.add((-25200000L), 86399999);
        java.lang.String str14 = offsetDateTimeField6.getAsShortText(28800100L);
        long long16 = offsetDateTimeField6.roundHalfCeiling(28800032L);
        int int18 = offsetDateTimeField6.getLeapAmount(28800099L);
        try {
            long long21 = offsetDateTimeField6.set(0L, (-28800000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for secondOfDay must be in the range [-1,86398]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31010L + "'", long9 == 31010L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 86374799000L + "'", long12 == 86374799000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1" + "'", str14.equals("-1"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1560344268271L, 22079);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34450841099155409L + "'", long2 == 34450841099155409L);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime7 = property4.addWrapField(100);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        org.joda.time.DateTime.Property property4 = dateTime0.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime0.withYearOfEra((int) '4');
        java.util.Locale locale6 = null;
        java.util.Calendar calendar7 = dateTime5.toCalendar(locale6);
        boolean boolean9 = dateTime5.isAfter((-1L));
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(calendar7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.millisOfDay();
        org.joda.time.Interval interval5 = property4.toInterval();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval5);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField3 = gregorianChronology0.halfdays();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("GregorianChronology[UTC]", false);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder0.addRecurringSavings("357", 0, 1969, 57600000, '4', 9, 21472039, (int) (byte) -1, false, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        int int15 = skipUndoDateTimeField13.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology16.getZone();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology16.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology16.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField22.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, dateTimeFieldType23, (int) ' ');
        long long28 = skipUndoDateTimeField13.add((long) (short) 0, 2440588L);
        int int29 = skipUndoDateTimeField13.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 2440588L + "'", long28 == 2440588L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86399999 + "'", int29 == 86399999);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
        int int28 = mutableDateTime27.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology51.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (short) -1);
        long long60 = offsetDateTimeField57.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField61 = offsetDateTimeField57.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField61);
        long long65 = unsupportedDateTimeField62.add((long) 22065, 2000);
        long long68 = unsupportedDateTimeField62.add((long) '4', 52);
        org.joda.time.chrono.GregorianChronology gregorianChronology74 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone75 = gregorianChronology74.getZone();
        org.joda.time.DateTimeZone dateTimeZone76 = gregorianChronology74.getZone();
        org.joda.time.DateTime dateTime77 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone76);
        org.joda.time.DateTime dateTime79 = dateTime77.plus((long) 100);
        org.joda.time.LocalDateTime localDateTime80 = dateTime79.toLocalDateTime();
        java.util.Locale locale81 = null;
        try {
            java.lang.String str82 = unsupportedDateTimeField62.getAsShortText((org.joda.time.ReadablePartial) localDateTime80, locale81);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344238L + "'", long60 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 172796422065L + "'", long65 == 172796422065L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 4492800052L + "'", long68 == 4492800052L);
        org.junit.Assert.assertNotNull(gregorianChronology74);
        org.junit.Assert.assertNotNull(dateTimeZone75);
        org.junit.Assert.assertNotNull(dateTimeZone76);
        org.junit.Assert.assertNotNull(dateTime79);
        org.junit.Assert.assertNotNull(localDateTime80);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology1.add(readablePeriod3, (long) 1, (int) (short) 100);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gregorianChronology1, locale7);
        dateTimeParserBucket8.setPivotYear((java.lang.Integer) (-1));
        long long11 = dateTimeParserBucket8.computeMillis();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology17.getZone();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone19);
        long long23 = dateTimeZone19.convertLocalToUTC((long) (byte) 100, true);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        dateTimeParserBucket8.setZone(dateTimeZone24);
        long long27 = dateTimeParserBucket8.computeMillis(false);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800032L + "'", long11 == 28800032L);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 28800100L + "'", long23 == 28800100L);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28800032L + "'", long27 == 28800032L);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
//        long long6 = mutableDateTime2.getMillis();
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime9 = property8.getMutableDateTime();
//        try {
//            mutableDateTime9.setMinuteOfDay(18058);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 18058 for minuteOfDay must be in the range [0,1439]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560344280227L + "'", long6 == 1560344280227L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
        int int28 = mutableDateTime27.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology51.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (short) -1);
        long long60 = offsetDateTimeField57.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField61 = offsetDateTimeField57.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField61);
        java.util.Locale locale64 = null;
        try {
            java.lang.String str65 = unsupportedDateTimeField62.getAsText(0, locale64);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344238L + "'", long60 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        boolean boolean7 = jodaTimePermission1.equals((java.lang.Object) dateTimeFormatterBuilder6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder6.appendYear((int) (byte) 0, 57600000);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime16 = dateTime14.minus((long) (-1));
        org.joda.time.DateTime dateTime17 = dateTime16.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendTwoDigitYear((int) (short) 1);
        boolean boolean21 = dateTimeFormatterBuilder18.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder18.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMonthOfYear(1);
        boolean boolean27 = dateTimeFormatterBuilder26.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendTwoDigitYear((int) (short) 1);
        boolean boolean31 = dateTimeFormatterBuilder28.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder28.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology33.getZone();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        long long38 = gregorianChronology33.add(readablePeriod35, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        int int40 = mutableDateTime39.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.MutableDateTime mutableDateTime42 = mutableDateTime39.toMutableDateTime(dateTimeZone41);
        org.joda.time.MutableDateTime.Property property43 = mutableDateTime42.millisOfDay();
        org.joda.time.DateTimeField dateTimeField44 = property43.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology33, dateTimeField44, 6);
        int int48 = skipUndoDateTimeField46.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone50 = gregorianChronology49.getZone();
        org.joda.time.DateTimeZone dateTimeZone51 = gregorianChronology49.getZone();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology49.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology49.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType56 = offsetDateTimeField55.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField46, dateTimeFieldType56, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder28.appendText(dateTimeFieldType56);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder26.appendFixedDecimal(dateTimeFieldType56, 86400031);
        org.joda.time.DateTime.Property property62 = dateTime17.property(dateTimeFieldType56);
        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone64 = gregorianChronology63.getZone();
        org.joda.time.DateTimeZone dateTimeZone65 = gregorianChronology63.getZone();
        org.joda.time.DateTimeField dateTimeField66 = gregorianChronology63.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField67 = gregorianChronology63.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField69 = new org.joda.time.field.OffsetDateTimeField(dateTimeField67, (int) (short) -1);
        long long72 = offsetDateTimeField69.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField73 = offsetDateTimeField69.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField74 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType56, durationField73);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder75 = dateTimeFormatterBuilder11.appendShortText(dateTimeFieldType56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(dateTimeFieldType56);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(gregorianChronology63);
        org.junit.Assert.assertNotNull(dateTimeZone64);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertNotNull(dateTimeField67);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1560344238L + "'", long72 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField73);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField74);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder75);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime10.plus((long) 100);
        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        int int16 = dateTimeZone1.getOffsetFromLocal((long) (-28800000));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
        int int28 = mutableDateTime27.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology51.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (short) -1);
        long long60 = offsetDateTimeField57.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField61 = offsetDateTimeField57.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField61);
        long long65 = unsupportedDateTimeField62.add((long) 22065, 2000);
        long long68 = unsupportedDateTimeField62.add((long) '4', 52);
        try {
            boolean boolean70 = unsupportedDateTimeField62.isLeap((long) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344238L + "'", long60 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 172796422065L + "'", long65 == 172796422065L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 4492800052L + "'", long68 == 4492800052L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.yearOfEra();
        try {
            org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime((java.lang.Object) dateTimeZone1, (org.joda.time.Chronology) gregorianChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.tz.CachedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime3 = dateTime2.toLocalDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        org.joda.time.DateTime.Property property5 = dateTime2.secondOfDay();
        org.joda.time.DateTime dateTime7 = dateTime2.withYearOfEra((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.minusDays(0);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime();
        boolean boolean11 = dateTime9.isBefore((org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime10.copy();
        mutableDateTime12.addMinutes(58200);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) mutableDateTime12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(localDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(mutableDateTime12);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1560319065806L, (java.lang.Number) 2000, (java.lang.Number) (-25200000));
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2000 + "'", number5.equals(2000));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(dateTimeFieldType7);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        int int4 = dateTimeZone2.getOffsetFromLocal((long) (byte) -1);
        org.joda.time.Chronology chronology5 = julianChronology0.withZone(dateTimeZone2);
        java.lang.String str6 = julianChronology0.toString();
        try {
            long long14 = julianChronology0.getDateTimeMillis((int) (short) -1, 57600063, 57600, 960, 86398, 86398, 57600000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str6.equals("JulianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
        int int28 = mutableDateTime27.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology51.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (short) -1);
        long long60 = offsetDateTimeField57.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField61 = offsetDateTimeField57.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField61);
        long long65 = unsupportedDateTimeField62.add((long) 22065, 2000);
        org.joda.time.DurationField durationField66 = unsupportedDateTimeField62.getDurationField();
        try {
            java.lang.String str68 = unsupportedDateTimeField62.getAsText((long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344238L + "'", long60 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 172796422065L + "'", long65 == 172796422065L);
        org.junit.Assert.assertNotNull(durationField66);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime((java.lang.Object) chronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology0.yearOfEra();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
//        org.joda.time.DateTime dateTime3 = property2.getDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.minusMinutes((int) (short) 10);
//        int int6 = dateTime3.getMinuteOfHour();
//        org.joda.time.DateTime dateTime8 = dateTime3.plusDays(12);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(localDateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 58 + "'", int6 == 58);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.DataOutput dataOutput2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("America/Los_Angeles", dataOutput2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) mutableDateTime4);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        mutableDateTime4.setZoneRetainFields(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusHours((int) (short) 1);
//        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
//        int int14 = dateTime10.getMinuteOfDay();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 778 + "'", int14 == 778);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.plus((long) 100);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear(0);
        int int13 = dateTime12.getMinuteOfHour();
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime16 = dateTime12.withDurationAdded(readableDuration14, (int) (byte) 1);
        org.joda.time.MutableDateTime mutableDateTime17 = dateTime16.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
//        long long6 = mutableDateTime2.getMillis();
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1L));
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
//        org.joda.time.DateTime.Property property13 = dateTime11.dayOfWeek();
//        org.joda.time.DateTime.Property property14 = dateTime11.dayOfMonth();
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime11.minus(readableDuration15);
//        boolean boolean17 = mutableDateTime10.isBefore((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime10.millisOfDay();
//        org.joda.time.MutableDateTime.Property property19 = mutableDateTime10.weekOfWeekyear();
//        mutableDateTime10.setMillisOfDay(1);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560344282159L + "'", long6 == 1560344282159L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.Chronology chronology1 = mutableDateTime0.getChronology();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.monthOfYear();
        mutableDateTime0.setMillis((long) 9);
        mutableDateTime0.setYear(0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundFloor();
        java.util.GregorianCalendar gregorianCalendar7 = mutableDateTime6.toGregorianCalendar();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test390");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
//        org.joda.time.DateTime.Property property3 = dateTime0.dayOfMonth();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime0.minus(readableDuration4);
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime5.minus(readablePeriod6);
//        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.DateTimeFormat.shortDate();
//        java.lang.String str10 = dateTime7.toString(dateTimeFormatter9);
//        org.joda.time.DateTime dateTime12 = dateTime7.withWeekOfWeekyear(33);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(localDateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6/12/19" + "'", str10.equals("6/12/19"));
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone9);
        long long13 = dateTimeZone9.convertLocalToUTC((long) (byte) 100, true);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone9);
        org.joda.time.DateTime dateTime15 = dateTime0.withZone(dateTimeZone14);
        org.joda.time.DateTime.Property property16 = dateTime0.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800100L + "'", long13 == 28800100L);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField3 = gregorianChronology1.minutes();
        org.joda.time.DurationField durationField4 = gregorianChronology1.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology1.weekyears();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
//        org.joda.time.DateTime.Property property3 = dateTime0.yearOfCentury();
//        boolean boolean4 = dateTime0.isEqualNow();
//        org.joda.time.DateTime dateTime6 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekyear();
//        org.joda.time.DateTime.Property property8 = dateTime6.hourOfDay();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(localDateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime0.withYearOfEra((int) '4');
        org.joda.time.DateTime dateTime7 = dateTime5.minusDays(0);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime();
        boolean boolean9 = dateTime7.isBefore((org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.DateTime dateTime11 = dateTime7.minusWeeks(100);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        java.lang.Object obj4 = mutableDateTime3.clone();
        mutableDateTime3.setMinuteOfDay(1);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            mutableDateTime3.set(dateTimeFieldType7, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(obj4);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
//        long long6 = mutableDateTime2.getMillis();
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = mutableDateTime2.toCalendar(locale8);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime2.dayOfWeek();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsShortText(locale11);
//        org.joda.time.MutableDateTime mutableDateTime13 = property10.roundHalfEven();
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property10.getAsShortText(locale14);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560344282848L + "'", long6 == 1560344282848L);
//        org.junit.Assert.assertNotNull(calendar9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Wed" + "'", str12.equals("Wed"));
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Wed" + "'", str15.equals("Wed"));
//    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(28800099L, dateTimeZone2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone2.getShortName((long) 31, locale6);
//        org.junit.Assert.assertNotNull(gregorianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PST" + "'", str7.equals("PST"));
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 1560344268033L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
//        long long9 = offsetDateTimeField6.getDifferenceAsLong(1560344238929L, (long) 6);
//        org.joda.time.DurationField durationField10 = offsetDateTimeField6.getDurationField();
//        long long12 = offsetDateTimeField6.roundCeiling(10L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
//        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology13.getZone();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology13.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology13.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (short) -1);
//        long long22 = offsetDateTimeField19.getDifferenceAsLong(1560344238929L, (long) 6);
//        org.joda.time.DurationField durationField23 = offsetDateTimeField19.getRangeDurationField();
//        org.joda.time.DurationField durationField24 = offsetDateTimeField19.getLeapDurationField();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime26 = dateTime25.toLocalDateTime();
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = offsetDateTimeField19.getAsShortText((org.joda.time.ReadablePartial) localDateTime26, locale27);
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = offsetDateTimeField6.getAsShortText((org.joda.time.ReadablePartial) localDateTime26, 2000, locale30);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344238L + "'", long9 == 1560344238L);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1000L + "'", long12 == 1000L);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560344238L + "'", long22 == 1560344238L);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNull(durationField24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "21482" + "'", str28.equals("21482"));
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "2000" + "'", str31.equals("2000"));
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        java.lang.String str14 = skipUndoDateTimeField13.toString();
        long long17 = skipUndoDateTimeField13.addWrapField(28800100L, (-1));
        long long19 = skipUndoDateTimeField13.roundFloor(0L);
        java.lang.String str21 = skipUndoDateTimeField13.getAsShortText(0L);
        long long24 = skipUndoDateTimeField13.set(1560319066749L, 7);
        long long26 = skipUndoDateTimeField13.roundFloor(81137902391624L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfDay]" + "'", str14.equals("DateTimeField[millisOfDay]"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800099L + "'", long17 == 28800099L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "57600000" + "'", str21.equals("57600000"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236400007L + "'", long24 == 1560236400007L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 81137902391624L + "'", long26 == 81137902391624L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime0.withYearOfEra((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime8 = dateTime5.minusYears(0);
        org.joda.time.DateTime dateTime10 = dateTime5.withYearOfCentury((int) 'a');
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withEra((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = gregorianChronology6.add(readablePeriod8, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now();
        int int13 = mutableDateTime12.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = mutableDateTime12.toMutableDateTime(dateTimeZone14);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.millisOfDay();
        org.joda.time.DateTimeField dateTimeField17 = property16.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology6, dateTimeField17, 6);
        int int21 = skipUndoDateTimeField19.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology22.getZone();
        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology22.getZone();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology22.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology22.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField19, dateTimeFieldType29, (int) ' ');
        long long34 = skipUndoDateTimeField19.add((long) (short) 0, 2440588L);
        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField19);
        java.util.Locale locale38 = null;
        try {
            long long39 = skipDateTimeField35.set(0L, "-28800000", locale38);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 2440588L + "'", long34 == 2440588L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.roundFloor();
        org.joda.time.MutableDateTime mutableDateTime8 = property4.set(22077);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((int) (short) 100, (int) ' ', 21482710, 86400031, (int) ' ', 5994, 0, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86400031 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1560319065806L, (java.lang.Number) 2000, (java.lang.Number) (-25200000));
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        java.lang.Number number8 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2000 + "'", number5.equals(2000));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-25200000) + "'", number8.equals((-25200000)));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime dateTime3 = property2.getDateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfEra();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.plus(readableDuration5);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
        int int28 = mutableDateTime27.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology51.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (short) -1);
        long long60 = offsetDateTimeField57.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField61 = offsetDateTimeField57.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField61);
        java.util.Locale locale64 = null;
        try {
            java.lang.String str65 = unsupportedDateTimeField62.getAsText((int) (short) 1, locale64);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344238L + "'", long60 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        java.lang.String str14 = skipUndoDateTimeField13.getName();
        int int16 = skipUndoDateTimeField13.getMinimumValue((long) (byte) 100);
        int int18 = skipUndoDateTimeField13.get(0L);
        long long21 = skipUndoDateTimeField13.set(3570L, (int) ' ');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "millisOfDay" + "'", str14.equals("millisOfDay"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 57600000 + "'", int18 == 57600000);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-57599968L) + "'", long21 == (-57599968L));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(28800099L, dateTimeZone2);
        long long5 = dateTimeZone2.convertUTCToLocal(0L);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-28800000L) + "'", long5 == (-28800000L));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(0L, chronology2, locale3, (java.lang.Integer) (-25200000), 6);
        org.joda.time.Chronology chronology7 = dateTimeParserBucket6.getChronology();
        dateTimeParserBucket6.setPivotYear((java.lang.Integer) 21472039);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.monthOfYear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology1.yearOfEra();
        org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, dateTimeField4);
        java.lang.String str6 = gJChronology0.toString();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GJChronology[America/Los_Angeles]" + "'", str6.equals("GJChronology[America/Los_Angeles]"));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology1.add(readablePeriod3, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
        int[] intArray10 = gregorianChronology1.get((org.joda.time.ReadablePartial) localDateTime8, (long) ' ');
        boolean boolean11 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime8);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = gregorianChronology12.add(readablePeriod14, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime18 = org.joda.time.MutableDateTime.now();
        int int19 = mutableDateTime18.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.MutableDateTime mutableDateTime21 = mutableDateTime18.toMutableDateTime(dateTimeZone20);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime21.millisOfDay();
        org.joda.time.DateTimeField dateTimeField23 = property22.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology12, dateTimeField23, 6);
        int int27 = skipUndoDateTimeField25.getMinimumValue(28800032L);
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime29 = dateTime28.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone32 = gregorianChronology31.getZone();
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        long long36 = gregorianChronology31.add(readablePeriod33, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime38 = dateTime37.toLocalDateTime();
        int[] intArray40 = gregorianChronology31.get((org.joda.time.ReadablePartial) localDateTime38, (long) ' ');
        int[] intArray42 = skipUndoDateTimeField25.add((org.joda.time.ReadablePartial) localDateTime29, 0, intArray40, 0);
        iSOChronology0.validate((org.joda.time.ReadablePartial) localDateTime8, intArray42);
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDateTime29);
        org.junit.Assert.assertNotNull(gregorianChronology31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1L + "'", long36 == 1L);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(localDateTime38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(dateTimeField44);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
//        long long4 = mutableDateTime0.getMillis();
//        java.lang.Class<?> wildcardClass5 = mutableDateTime0.getClass();
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime0.dayOfWeek();
//        mutableDateTime0.setMillisOfSecond((int) (short) 1);
//        mutableDateTime0.setMillisOfSecond(0);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
//        org.joda.time.DateTime.Property property13 = dateTime11.dayOfWeek();
//        org.joda.time.DateTime.Property property14 = dateTime11.secondOfDay();
//        org.joda.time.DateTime dateTime16 = dateTime11.withYearOfEra((int) '4');
//        boolean boolean17 = mutableDateTime0.isAfter((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.Chronology chronology18 = dateTime11.getChronology();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone21 = gregorianChronology20.getZone();
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        long long25 = gregorianChronology20.add(readablePeriod22, (long) 1, (int) (short) 100);
//        java.util.Locale locale26 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gregorianChronology20, locale26);
//        dateTimeParserBucket27.setPivotYear((java.lang.Integer) (-1));
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone31 = gregorianChronology30.getZone();
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        long long35 = gregorianChronology30.add(readablePeriod32, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime36 = org.joda.time.MutableDateTime.now();
//        int int37 = mutableDateTime36.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.MutableDateTime mutableDateTime39 = mutableDateTime36.toMutableDateTime(dateTimeZone38);
//        org.joda.time.MutableDateTime.Property property40 = mutableDateTime39.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField41 = property40.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField43 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology30, dateTimeField41, 6);
//        java.lang.String str44 = skipUndoDateTimeField43.toString();
//        boolean boolean46 = skipUndoDateTimeField43.isLeap((long) (short) -1);
//        int int48 = skipUndoDateTimeField43.getMaximumValue((long) 'a');
//        dateTimeParserBucket27.saveField((org.joda.time.DateTimeField) skipUndoDateTimeField43, 3);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField52 = new org.joda.time.field.SkipDateTimeField(chronology18, (org.joda.time.DateTimeField) skipUndoDateTimeField43, (int) '#');
//        long long55 = skipDateTimeField52.set((-56638997L), "57600000");
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560344284402L + "'", long4 == 1560344284402L);
//        org.junit.Assert.assertNotNull(wildcardClass5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1L + "'", long25 == 1L);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1L + "'", long35 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "DateTimeField[millisOfDay]" + "'", str44.equals("DateTimeField[millisOfDay]"));
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 86399999 + "'", int48 == 86399999);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.minuteOfHour();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime3 = dateTime2.toLocalDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.dayOfWeek();
        org.joda.time.DateTime.Property property5 = dateTime2.secondOfDay();
        boolean boolean6 = iSOChronology0.equals((java.lang.Object) property5);
        org.joda.time.DateTime dateTime7 = property5.roundHalfCeilingCopy();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded(readableDuration8, 86400031);
        try {
            org.joda.time.DateTime dateTime12 = dateTime7.withHourOfDay((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(localDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        java.lang.String str14 = skipUndoDateTimeField13.toString();
        boolean boolean16 = skipUndoDateTimeField13.isLeap((long) (short) -1);
        org.joda.time.DateTimeField dateTimeField17 = skipUndoDateTimeField13.getWrappedField();
        boolean boolean19 = skipUndoDateTimeField13.isLeap(0L);
        java.util.Locale locale21 = null;
        java.lang.String str22 = skipUndoDateTimeField13.getAsShortText((long) ' ', locale21);
        int int23 = skipUndoDateTimeField13.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfDay]" + "'", str14.equals("DateTimeField[millisOfDay]"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "57600032" + "'", str22.equals("57600032"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.year();
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((org.joda.time.Chronology) gregorianChronology0);
        int int8 = mutableDateTime7.getCenturyOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 21 + "'", int8 == 21);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField6.getType();
        org.joda.time.DurationField durationField8 = offsetDateTimeField6.getLeapDurationField();
        long long10 = offsetDateTimeField6.roundHalfCeiling((long) (-25200000));
        boolean boolean11 = offsetDateTimeField6.isSupported();
        java.lang.String str13 = offsetDateTimeField6.getAsShortText(1560344274916L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-25200000L) + "'", long10 == (-25200000L));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "21473" + "'", str13.equals("21473"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T23:59:59.999 (4:00:00 PM)");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: org.joda.time.IllegalInstantException: Illegal instant due to time zone offset transition (daylight savings time 'gap'): 1969-12-31T23:59:59.999 (4:00:00 PM)");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimePrinter4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendTimeZoneOffset("", "DateTimeField[millisOfDay]", true, 10, 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendMonthOfYear((-97));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
        int int28 = mutableDateTime27.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology51.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (short) -1);
        long long60 = offsetDateTimeField57.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField61 = offsetDateTimeField57.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField61);
        long long65 = unsupportedDateTimeField62.add((long) 22065, 2000);
        long long68 = unsupportedDateTimeField62.add((long) '4', 52);
        org.joda.time.DurationField durationField69 = unsupportedDateTimeField62.getLeapDurationField();
        try {
            int int70 = unsupportedDateTimeField62.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344238L + "'", long60 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 172796422065L + "'", long65 == 172796422065L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 4492800052L + "'", long68 == 4492800052L);
        org.junit.Assert.assertNull(durationField69);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        int int3 = dateTimeZone1.getOffsetFromLocal((long) (byte) -1);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone1.getShortName(31010L, locale5);
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
//        int int8 = mutableDateTime7.getMonthOfYear();
//        int int9 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) mutableDateTime7);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime7.dayOfMonth();
//        java.lang.String str11 = property10.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UTC" + "'", str6.equals("UTC"));
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[dayOfMonth]" + "'", str11.equals("Property[dayOfMonth]"));
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter3.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.append(dateTimePrinter4);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendTwoDigitYear((int) (short) 1);
        boolean boolean15 = dateTimeFormatterBuilder12.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = gregorianChronology17.add(readablePeriod19, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime23 = org.joda.time.MutableDateTime.now();
        int int24 = mutableDateTime23.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.MutableDateTime mutableDateTime26 = mutableDateTime23.toMutableDateTime(dateTimeZone25);
        org.joda.time.MutableDateTime.Property property27 = mutableDateTime26.millisOfDay();
        org.joda.time.DateTimeField dateTimeField28 = property27.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology17, dateTimeField28, 6);
        int int32 = skipUndoDateTimeField30.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology33.getZone();
        org.joda.time.DateTimeZone dateTimeZone35 = gregorianChronology33.getZone();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology33.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology33.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = offsetDateTimeField39.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField42 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField30, dateTimeFieldType40, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder12.appendText(dateTimeFieldType40);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder11.appendFraction(dateTimeFieldType40, (int) '4', 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder5.appendFixedDecimal(dateTimeFieldType40, (-97));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: -97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        long long19 = gregorianChronology14.add(readablePeriod16, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime20 = org.joda.time.MutableDateTime.now();
        int int21 = mutableDateTime20.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.MutableDateTime mutableDateTime23 = mutableDateTime20.toMutableDateTime(dateTimeZone22);
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime23.millisOfDay();
        org.joda.time.DateTimeField dateTimeField25 = property24.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology14, dateTimeField25, 6);
        int int29 = skipUndoDateTimeField27.getMinimumValue(28800032L);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime31 = dateTime30.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology33.getZone();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        long long38 = gregorianChronology33.add(readablePeriod35, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        int[] intArray42 = gregorianChronology33.get((org.joda.time.ReadablePartial) localDateTime40, (long) ' ');
        int[] intArray44 = skipUndoDateTimeField27.add((org.joda.time.ReadablePartial) localDateTime31, 0, intArray42, 0);
        int int45 = skipUndoDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) localDateTime31);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone53);
        org.joda.time.DateTime dateTime56 = dateTime54.plus((long) 100);
        org.joda.time.LocalDateTime localDateTime57 = dateTime56.toLocalDateTime();
        int[] intArray59 = new int[] {};
        try {
            int[] intArray61 = skipUndoDateTimeField13.add((org.joda.time.ReadablePartial) localDateTime57, 960, intArray59, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 960");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localDateTime31);
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(localDateTime57);
        org.junit.Assert.assertNotNull(intArray59);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime2 = dateTime1.toLocalDateTime();
        org.joda.time.DateTime.Property property3 = dateTime1.dayOfWeek();
        org.joda.time.DateTime.Property property4 = dateTime1.dayOfMonth();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.minus(readableDuration5);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime6, 5);
        org.joda.time.DurationField durationField9 = gJChronology8.hours();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology17.getZone();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime20.plus((long) 100);
        int int23 = dateTimeZone11.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone11);
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.Chronology chronology26 = gJChronology8.withZone(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(localDateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        int int4 = dateTimeZone2.getOffset((org.joda.time.ReadableInstant) dateTime3);
        boolean boolean6 = dateTime3.isAfter((long) (byte) 10);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfWeek();
        org.joda.time.DateTime.Property property10 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime12 = dateTime7.withYearOfEra((int) '4');
        org.joda.time.DateTime dateTime14 = dateTime12.minusDays(0);
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime();
        boolean boolean16 = dateTime14.isBefore((org.joda.time.ReadableInstant) mutableDateTime15);
        org.joda.time.MutableDateTime mutableDateTime17 = mutableDateTime15.copy();
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, (org.joda.time.ReadableInstant) mutableDateTime15);
        int int19 = mutableDateTime15.getEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-25200000) + "'", int4 == (-25200000));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) mutableDateTime4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.mediumTime();
//        java.lang.String str8 = mutableDateTime3.toString(dateTimeFormatter7);
//        org.joda.time.DateTime dateTime9 = mutableDateTime3.toDateTime();
//        org.joda.time.DateTime dateTime10 = dateTime9.toDateTimeISO();
//        org.joda.time.DateTime.Property property11 = dateTime9.monthOfYear();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5:58:06 AM" + "'", str8.equals("5:58:06 AM"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//    }

//    @Test
//    public void test429() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test429");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
//        long long6 = mutableDateTime2.getMillis();
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime9 = property8.getMutableDateTime();
//        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((long) ' ');
//        int int12 = property8.compareTo((org.joda.time.ReadableInstant) mutableDateTime11);
//        mutableDateTime11.add(1560344238L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        long long20 = gregorianChronology15.add(readablePeriod17, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now();
//        int int22 = mutableDateTime21.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.MutableDateTime mutableDateTime24 = mutableDateTime21.toMutableDateTime(dateTimeZone23);
//        org.joda.time.MutableDateTime.Property property25 = mutableDateTime24.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField26 = property25.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology15, dateTimeField26, 6);
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
//        org.joda.time.ReadablePeriod readablePeriod31 = null;
//        long long34 = gregorianChronology29.add(readablePeriod31, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime35 = org.joda.time.MutableDateTime.now();
//        int int36 = mutableDateTime35.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone37 = null;
//        org.joda.time.MutableDateTime mutableDateTime38 = mutableDateTime35.toMutableDateTime(dateTimeZone37);
//        org.joda.time.MutableDateTime.Property property39 = mutableDateTime38.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField40 = property39.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology29, dateTimeField40, 6);
//        int int44 = skipUndoDateTimeField42.getMinimumValue(28800032L);
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime46 = dateTime45.toLocalDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone49 = gregorianChronology48.getZone();
//        org.joda.time.ReadablePeriod readablePeriod50 = null;
//        long long53 = gregorianChronology48.add(readablePeriod50, (long) 1, (int) (short) 100);
//        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime55 = dateTime54.toLocalDateTime();
//        int[] intArray57 = gregorianChronology48.get((org.joda.time.ReadablePartial) localDateTime55, (long) ' ');
//        int[] intArray59 = skipUndoDateTimeField42.add((org.joda.time.ReadablePartial) localDateTime46, 0, intArray57, 0);
//        int int60 = skipUndoDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) localDateTime46);
//        java.util.Locale locale62 = null;
//        java.lang.String str63 = skipUndoDateTimeField28.getAsShortText((int) (byte) 1, locale62);
//        long long65 = skipUndoDateTimeField28.roundCeiling((long) (-1));
//        mutableDateTime11.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField28);
//        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone68 = gregorianChronology67.getZone();
//        org.joda.time.ReadablePeriod readablePeriod69 = null;
//        long long72 = gregorianChronology67.add(readablePeriod69, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime73 = org.joda.time.MutableDateTime.now();
//        int int74 = mutableDateTime73.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone75 = null;
//        org.joda.time.MutableDateTime mutableDateTime76 = mutableDateTime73.toMutableDateTime(dateTimeZone75);
//        org.joda.time.MutableDateTime.Property property77 = mutableDateTime76.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField78 = property77.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField80 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology67, dateTimeField78, 6);
//        int int82 = skipUndoDateTimeField80.getMinimumValue(28800032L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology83 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone84 = gregorianChronology83.getZone();
//        org.joda.time.DateTimeZone dateTimeZone85 = gregorianChronology83.getZone();
//        org.joda.time.DateTimeField dateTimeField86 = gregorianChronology83.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField87 = gregorianChronology83.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField89 = new org.joda.time.field.OffsetDateTimeField(dateTimeField87, (int) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType90 = offsetDateTimeField89.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField92 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField80, dateTimeFieldType90, (int) ' ');
//        long long95 = skipUndoDateTimeField80.add((long) (short) 0, 2440588L);
//        mutableDateTime11.setRounding((org.joda.time.DateTimeField) skipUndoDateTimeField80);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560344286285L + "'", long6 == 1560344286285L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(localDateTime46);
//        org.junit.Assert.assertNotNull(gregorianChronology48);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1L + "'", long53 == 1L);
//        org.junit.Assert.assertNotNull(dateTime54);
//        org.junit.Assert.assertNotNull(localDateTime55);
//        org.junit.Assert.assertNotNull(intArray57);
//        org.junit.Assert.assertNotNull(intArray59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "1" + "'", str63.equals("1"));
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-1L) + "'", long65 == (-1L));
//        org.junit.Assert.assertNotNull(gregorianChronology67);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 1L + "'", long72 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime73);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 6 + "'", int74 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime76);
//        org.junit.Assert.assertNotNull(property77);
//        org.junit.Assert.assertNotNull(dateTimeField78);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology83);
//        org.junit.Assert.assertNotNull(dateTimeZone84);
//        org.junit.Assert.assertNotNull(dateTimeZone85);
//        org.junit.Assert.assertNotNull(dateTimeField86);
//        org.junit.Assert.assertNotNull(dateTimeField87);
//        org.junit.Assert.assertNotNull(dateTimeFieldType90);
//        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 2440588L + "'", long95 == 2440588L);
//    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime3 = dateTime1.plusMinutes((int) (byte) 10);
//        int int4 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime5 = dateTime1.withTimeAtStartOfDay();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
//        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendMonthOfYearShortText();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology11.getZone();
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        long long16 = gregorianChronology11.add(readablePeriod13, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now();
//        int int18 = mutableDateTime17.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone19 = null;
//        org.joda.time.MutableDateTime mutableDateTime20 = mutableDateTime17.toMutableDateTime(dateTimeZone19);
//        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField22 = property21.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology11, dateTimeField22, 6);
//        int int26 = skipUndoDateTimeField24.getMinimumValue(28800032L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology27.getZone();
//        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology27.getZone();
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology27.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology27.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = offsetDateTimeField33.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField24, dateTimeFieldType34, (int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder6.appendText(dateTimeFieldType34);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType34, (java.lang.Number) 3, "4:00:00 PM");
//        org.joda.time.DateTime.Property property41 = dateTime1.property(dateTimeFieldType34);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType34);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(property41);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime0.withYearOfEra((int) '4');
        org.joda.time.DateTime dateTime7 = dateTime5.minusDays(0);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime();
        boolean boolean9 = dateTime7.isBefore((org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            mutableDateTime8.add(durationFieldType10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.plus((long) 100);
        org.joda.time.DateTimeField dateTimeField11 = null;
        try {
            int int12 = dateTime8.get(dateTimeField11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeField must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        int int15 = skipUndoDateTimeField13.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology16.getZone();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology16.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology16.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField22.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField13, dateTimeFieldType23, (int) ' ');
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime27 = dateTime26.toLocalDateTime();
        int int28 = offsetDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) localDateTime27);
        long long30 = offsetDateTimeField25.roundHalfCeiling((long) (short) 100);
        java.lang.String str31 = offsetDateTimeField25.getName();
        long long33 = offsetDateTimeField25.roundCeiling((-1L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(localDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 86400031 + "'", int28 == 86400031);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 100L + "'", long30 == 100L);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "secondOfDay" + "'", str31.equals("secondOfDay"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1L) + "'", long33 == (-1L));
    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gregorianChronology2);
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(1L, (org.joda.time.Chronology) gregorianChronology2, locale4, (java.lang.Integer) 0);
//        org.joda.time.MutableDateTime mutableDateTime7 = org.joda.time.MutableDateTime.now();
//        int int8 = mutableDateTime7.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone9 = null;
//        org.joda.time.MutableDateTime mutableDateTime10 = mutableDateTime7.toMutableDateTime(dateTimeZone9);
//        org.joda.time.MutableDateTime mutableDateTime11 = org.joda.time.MutableDateTime.now();
//        int int12 = mutableDateTime11.getMonthOfYear();
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime10, (org.joda.time.ReadableInstant) mutableDateTime11);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        mutableDateTime11.setZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone15);
//        org.joda.time.DateTime dateTime19 = dateTime17.minusHours((int) (short) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.millisOfDay();
//        int int22 = dateTime17.get(dateTimeField21);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField24 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology2, dateTimeField21, (int) (byte) -1);
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology2.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(iSOChronology20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 21487125 + "'", int22 == 21487125);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
//        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
//        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
//        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
//        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
//        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
//        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
//        int int28 = mutableDateTime27.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
//        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
//        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
//        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
//        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
//        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
//        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
//        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology51.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (short) -1);
//        long long60 = offsetDateTimeField57.getDifferenceAsLong(1560344238929L, (long) 6);
//        org.joda.time.DurationField durationField61 = offsetDateTimeField57.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField61);
//        long long65 = unsupportedDateTimeField62.add((long) 22065, 2000);
//        int int68 = unsupportedDateTimeField62.getDifference(1560344268271L, (long) 'a');
//        org.joda.time.chrono.GregorianChronology gregorianChronology69 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone70 = gregorianChronology69.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology71 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField72 = gregorianChronology71.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone73 = gregorianChronology71.getZone();
//        org.joda.time.DateTime dateTime74 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime75 = dateTime74.toLocalDateTime();
//        long long77 = gregorianChronology71.set((org.joda.time.ReadablePartial) localDateTime75, 28800100L);
//        long long79 = gregorianChronology69.set((org.joda.time.ReadablePartial) localDateTime75, 0L);
//        int[] intArray80 = null;
//        try {
//            int int81 = unsupportedDateTimeField62.getMinimumValue((org.joda.time.ReadablePartial) localDateTime75, intArray80);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(gregorianChronology21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(gregorianChronology51);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344238L + "'", long60 == 1560344238L);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 172796422065L + "'", long65 == 172796422065L);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 18059 + "'", int68 == 18059);
//        org.junit.Assert.assertNotNull(gregorianChronology69);
//        org.junit.Assert.assertNotNull(dateTimeZone70);
//        org.junit.Assert.assertNotNull(gregorianChronology71);
//        org.junit.Assert.assertNotNull(dateTimeField72);
//        org.junit.Assert.assertNotNull(dateTimeZone73);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(localDateTime75);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 1560319087386L + "'", long77 == 1560319087386L);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1560344287386L + "'", long79 == 1560344287386L);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
        int int28 = mutableDateTime27.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology51.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (short) -1);
        long long60 = offsetDateTimeField57.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField61 = offsetDateTimeField57.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField61);
        long long65 = unsupportedDateTimeField62.add((long) 22065, 2000);
        long long68 = unsupportedDateTimeField62.add((long) '4', 52);
        try {
            long long71 = unsupportedDateTimeField62.set((long) 21473898, (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344238L + "'", long60 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 172796422065L + "'", long65 == 172796422065L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 4492800052L + "'", long68 == 4492800052L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(357, (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 357");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
        long long9 = offsetDateTimeField6.add((long) (short) 10, 31);
        java.lang.String str11 = offsetDateTimeField6.getAsShortText((long) (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder12.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendTwoDigitYear((int) (short) 1);
        boolean boolean20 = dateTimeFormatterBuilder17.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder17.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = gregorianChronology22.getZone();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        long long27 = gregorianChronology22.add(readablePeriod24, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime28 = org.joda.time.MutableDateTime.now();
        int int29 = mutableDateTime28.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.MutableDateTime mutableDateTime31 = mutableDateTime28.toMutableDateTime(dateTimeZone30);
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime31.millisOfDay();
        org.joda.time.DateTimeField dateTimeField33 = property32.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology22, dateTimeField33, 6);
        int int37 = skipUndoDateTimeField35.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology38.getZone();
        org.joda.time.DateTimeZone dateTimeZone40 = gregorianChronology38.getZone();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology38.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology38.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = offsetDateTimeField44.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField35, dateTimeFieldType45, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder17.appendText(dateTimeFieldType45);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder16.appendFraction(dateTimeFieldType45, (int) '4', 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField53 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType45, 5994);
        long long56 = dividedDateTimeField53.add((long) 57600063, 960);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31010L + "'", long9 == 31010L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "57598" + "'", str11.equals("57598"));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 5811840063L + "'", long56 == 5811840063L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMinuteOfHour(1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        int int15 = skipUndoDateTimeField13.getMinimumValue(28800032L);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime17 = dateTime16.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        long long24 = gregorianChronology19.add(readablePeriod21, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime26 = dateTime25.toLocalDateTime();
        int[] intArray28 = gregorianChronology19.get((org.joda.time.ReadablePartial) localDateTime26, (long) ' ');
        int[] intArray30 = skipUndoDateTimeField13.add((org.joda.time.ReadablePartial) localDateTime17, 0, intArray28, 0);
        java.lang.String str32 = skipUndoDateTimeField13.getAsShortText((long) ' ');
        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology33.getZone();
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        long long38 = gregorianChronology33.add(readablePeriod35, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
        int int40 = mutableDateTime39.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.MutableDateTime mutableDateTime42 = mutableDateTime39.toMutableDateTime(dateTimeZone41);
        org.joda.time.MutableDateTime.Property property43 = mutableDateTime42.millisOfDay();
        org.joda.time.DateTimeField dateTimeField44 = property43.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology33, dateTimeField44, 6);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone48 = gregorianChronology47.getZone();
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        long long52 = gregorianChronology47.add(readablePeriod49, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime53 = org.joda.time.MutableDateTime.now();
        int int54 = mutableDateTime53.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.MutableDateTime mutableDateTime56 = mutableDateTime53.toMutableDateTime(dateTimeZone55);
        org.joda.time.MutableDateTime.Property property57 = mutableDateTime56.millisOfDay();
        org.joda.time.DateTimeField dateTimeField58 = property57.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField60 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology47, dateTimeField58, 6);
        int int62 = skipUndoDateTimeField60.getMinimumValue(28800032L);
        org.joda.time.DateTime dateTime63 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime64 = dateTime63.toLocalDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone67 = gregorianChronology66.getZone();
        org.joda.time.ReadablePeriod readablePeriod68 = null;
        long long71 = gregorianChronology66.add(readablePeriod68, (long) 1, (int) (short) 100);
        org.joda.time.DateTime dateTime72 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime73 = dateTime72.toLocalDateTime();
        int[] intArray75 = gregorianChronology66.get((org.joda.time.ReadablePartial) localDateTime73, (long) ' ');
        int[] intArray77 = skipUndoDateTimeField60.add((org.joda.time.ReadablePartial) localDateTime64, 0, intArray75, 0);
        int int78 = skipUndoDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) localDateTime64);
        int int79 = skipUndoDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) localDateTime64);
        long long82 = skipUndoDateTimeField13.add((long) 9, (-2));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(localDateTime17);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(localDateTime26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "57600032" + "'", str32.equals("57600032"));
        org.junit.Assert.assertNotNull(gregorianChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1L + "'", long52 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(localDateTime64);
        org.junit.Assert.assertNotNull(gregorianChronology66);
        org.junit.Assert.assertNotNull(dateTimeZone67);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1L + "'", long71 == 1L);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(localDateTime73);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 7L + "'", long82 == 7L);
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
//        long long9 = offsetDateTimeField6.add((long) (short) 10, 31);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = dateTimeFormatter11.withChronology((org.joda.time.Chronology) gregorianChronology12);
//        java.util.Locale locale14 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket16 = new org.joda.time.format.DateTimeParserBucket(1L, (org.joda.time.Chronology) gregorianChronology12, locale14, (java.lang.Integer) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology17.getZone();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
//        long long23 = gregorianChronology17.set((org.joda.time.ReadablePartial) localDateTime21, 28800100L);
//        long long25 = gregorianChronology12.set((org.joda.time.ReadablePartial) localDateTime21, (long) 1969);
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = offsetDateTimeField6.getAsText((org.joda.time.ReadablePartial) localDateTime21, 276, locale27);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31010L + "'", long9 == 31010L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localDateTime21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560319088392L + "'", long23 == 1560319088392L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560344288392L + "'", long25 == 1560344288392L);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "276" + "'", str28.equals("276"));
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test446");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
//        long long9 = offsetDateTimeField6.add((long) (short) 10, 31);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology10.getZone();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
//        long long16 = gregorianChronology10.set((org.joda.time.ReadablePartial) localDateTime14, 28800100L);
//        java.util.Locale locale17 = null;
//        java.lang.String str18 = offsetDateTimeField6.getAsText((org.joda.time.ReadablePartial) localDateTime14, locale17);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, 57600);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31010L + "'", long9 == 31010L);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(localDateTime14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560319088588L + "'", long16 == 1560319088588L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "21488" + "'", str18.equals("21488"));
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField7 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6);
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology8.getZone();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology8.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology8.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) (short) -1);
//        long long17 = offsetDateTimeField14.getDifferenceAsLong(1560344238929L, (long) 6);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField14.getRangeDurationField();
//        org.joda.time.DurationField durationField19 = offsetDateTimeField14.getLeapDurationField();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
//        java.util.Locale locale22 = null;
//        java.lang.String str23 = offsetDateTimeField14.getAsShortText((org.joda.time.ReadablePartial) localDateTime21, locale22);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology26.getZone();
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        long long31 = gregorianChronology26.add(readablePeriod28, (long) 1, (int) (short) 100);
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime33 = dateTime32.toLocalDateTime();
//        int[] intArray35 = gregorianChronology26.get((org.joda.time.ReadablePartial) localDateTime33, (long) ' ');
//        boolean boolean36 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime33);
//        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
//        org.joda.time.ReadablePeriod readablePeriod39 = null;
//        long long42 = gregorianChronology37.add(readablePeriod39, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime43 = org.joda.time.MutableDateTime.now();
//        int int44 = mutableDateTime43.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.MutableDateTime mutableDateTime46 = mutableDateTime43.toMutableDateTime(dateTimeZone45);
//        org.joda.time.MutableDateTime.Property property47 = mutableDateTime46.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField48 = property47.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField50 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology37, dateTimeField48, 6);
//        int int52 = skipUndoDateTimeField50.getMinimumValue(28800032L);
//        org.joda.time.DateTime dateTime53 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime54 = dateTime53.toLocalDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone57 = gregorianChronology56.getZone();
//        org.joda.time.ReadablePeriod readablePeriod58 = null;
//        long long61 = gregorianChronology56.add(readablePeriod58, (long) 1, (int) (short) 100);
//        org.joda.time.DateTime dateTime62 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime63 = dateTime62.toLocalDateTime();
//        int[] intArray65 = gregorianChronology56.get((org.joda.time.ReadablePartial) localDateTime63, (long) ' ');
//        int[] intArray67 = skipUndoDateTimeField50.add((org.joda.time.ReadablePartial) localDateTime54, 0, intArray65, 0);
//        iSOChronology25.validate((org.joda.time.ReadablePartial) localDateTime33, intArray67);
//        try {
//            int[] intArray70 = delegatedDateTimeField7.add((org.joda.time.ReadablePartial) localDateTime21, (-2), intArray67, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -2");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560344238L + "'", long17 == 1560344238L);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localDateTime21);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "21488" + "'", str23.equals("21488"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(gregorianChronology26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1L + "'", long31 == 1L);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(localDateTime33);
//        org.junit.Assert.assertNotNull(intArray35);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1L + "'", long42 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
//        org.junit.Assert.assertNotNull(dateTime53);
//        org.junit.Assert.assertNotNull(localDateTime54);
//        org.junit.Assert.assertNotNull(gregorianChronology56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1L + "'", long61 == 1L);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(localDateTime63);
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertNotNull(intArray67);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("57598");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) mutableDateTime4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.DateTimeFormat.mediumTime();
//        java.lang.String str8 = mutableDateTime3.toString(dateTimeFormatter7);
//        org.joda.time.DateTime dateTime9 = mutableDateTime3.toDateTime();
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime3.yearOfEra();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime3.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime13 = property11.add(0);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5:58:09 AM" + "'", str8.equals("5:58:09 AM"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        java.util.Locale locale3 = null;
        int int4 = property2.getMaximumTextLength(locale3);
        org.joda.time.DurationField durationField5 = property2.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
        org.junit.Assert.assertNull(durationField5);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
        int int28 = mutableDateTime27.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology51.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (short) -1);
        long long60 = offsetDateTimeField57.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField61 = offsetDateTimeField57.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField61);
        long long65 = unsupportedDateTimeField62.add((long) 22065, 2000);
        long long68 = unsupportedDateTimeField62.add((long) '4', 52);
        try {
            long long70 = unsupportedDateTimeField62.roundHalfFloor(1560344238L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344238L + "'", long60 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 172796422065L + "'", long65 == 172796422065L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 4492800052L + "'", long68 == 4492800052L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfDay(100);
        dateTimeFormatterBuilder6.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField6.getType();
        org.joda.time.DurationField durationField8 = offsetDateTimeField6.getLeapDurationField();
        int int10 = offsetDateTimeField6.getLeapAmount((long) 1969);
        org.joda.time.DurationField durationField11 = offsetDateTimeField6.getDurationField();
        int int12 = offsetDateTimeField6.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.secondOfDay();
        org.joda.time.DateTime dateTime5 = dateTime0.withYearOfEra((int) '4');
        org.joda.time.DateTime dateTime7 = dateTime5.minusDays(0);
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime();
        boolean boolean9 = dateTime7.isBefore((org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.MutableDateTime mutableDateTime10 = mutableDateTime8.copy();
        mutableDateTime10.setDate(1560344277220L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.Chronology chronology1 = mutableDateTime0.getChronology();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.monthOfYear();
        mutableDateTime0.setMillis((long) 9);
        mutableDateTime0.addSeconds((int) (short) 10);
        int int7 = mutableDateTime0.getMillisOfSecond();
        int int8 = mutableDateTime0.getYearOfEra();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime3.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
        int int6 = property4.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 86399999 + "'", int6 == 86399999);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        int int7 = mutableDateTime6.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
        java.lang.String str14 = skipUndoDateTimeField13.getName();
        int int15 = skipUndoDateTimeField13.getMinimumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "millisOfDay" + "'", str14.equals("millisOfDay"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Instant instant2 = new org.joda.time.Instant((java.lang.Object) readableInterval0);
        org.joda.time.Instant instant4 = instant2.minus((-25200000L));
        org.joda.time.Instant instant6 = instant4.withMillis((-25200000L));
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
    }

//    @Test
//    public void test462() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test462");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
//        long long6 = mutableDateTime2.getMillis();
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime9 = property8.getMutableDateTime();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.roundCeiling();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560344290320L + "'", long6 == 1560344290320L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gregorianChronology3);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket(1L, (org.joda.time.Chronology) gregorianChronology3, locale5, (java.lang.Integer) 0);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology3.weekyearOfCentury();
        java.util.Locale locale9 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket12 = new org.joda.time.format.DateTimeParserBucket(1560344272298L, (org.joda.time.Chronology) gregorianChronology3, locale9, (java.lang.Integer) 22077, 960);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology3.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
//        org.joda.time.Chronology chronology1 = mutableDateTime0.getChronology();
//        mutableDateTime0.add((long) (short) 10);
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.dayOfYear();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsText(locale5);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "163" + "'", str6.equals("163"));
//    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
//        long long9 = offsetDateTimeField6.add((long) (short) 10, 31);
//        long long12 = offsetDateTimeField6.add((-25200000L), 86399999);
//        java.lang.String str14 = offsetDateTimeField6.getAsShortText(28800100L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone16 = gregorianChronology15.getZone();
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        long long20 = gregorianChronology15.add(readablePeriod17, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime21 = org.joda.time.MutableDateTime.now();
//        int int22 = mutableDateTime21.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone23 = null;
//        org.joda.time.MutableDateTime mutableDateTime24 = mutableDateTime21.toMutableDateTime(dateTimeZone23);
//        org.joda.time.MutableDateTime.Property property25 = mutableDateTime24.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField26 = property25.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField28 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology15, dateTimeField26, 6);
//        int int30 = skipUndoDateTimeField28.getMinimumValue(28800032L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone32 = gregorianChronology31.getZone();
//        org.joda.time.DateTimeZone dateTimeZone33 = gregorianChronology31.getZone();
//        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology31.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology31.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, (int) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField37.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField28, dateTimeFieldType38, (int) ' ');
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime42 = dateTime41.toLocalDateTime();
//        int int43 = offsetDateTimeField40.getMaximumValue((org.joda.time.ReadablePartial) localDateTime42);
//        long long45 = offsetDateTimeField40.roundHalfCeiling((long) (short) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField47 = gregorianChronology46.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone48 = gregorianChronology46.getZone();
//        org.joda.time.DateTime dateTime49 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime50 = dateTime49.toLocalDateTime();
//        long long52 = gregorianChronology46.set((org.joda.time.ReadablePartial) localDateTime50, 28800100L);
//        int int53 = offsetDateTimeField40.getMinimumValue((org.joda.time.ReadablePartial) localDateTime50);
//        org.joda.time.chrono.GregorianChronology gregorianChronology55 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone56 = gregorianChronology55.getZone();
//        org.joda.time.ReadablePeriod readablePeriod57 = null;
//        long long60 = gregorianChronology55.add(readablePeriod57, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime61 = org.joda.time.MutableDateTime.now();
//        int int62 = mutableDateTime61.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone63 = null;
//        org.joda.time.MutableDateTime mutableDateTime64 = mutableDateTime61.toMutableDateTime(dateTimeZone63);
//        org.joda.time.MutableDateTime.Property property65 = mutableDateTime64.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField66 = property65.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField68 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology55, dateTimeField66, 6);
//        int int70 = skipUndoDateTimeField68.getMinimumValue(28800032L);
//        org.joda.time.DateTime dateTime71 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime72 = dateTime71.toLocalDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology74 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone75 = gregorianChronology74.getZone();
//        org.joda.time.ReadablePeriod readablePeriod76 = null;
//        long long79 = gregorianChronology74.add(readablePeriod76, (long) 1, (int) (short) 100);
//        org.joda.time.DateTime dateTime80 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime81 = dateTime80.toLocalDateTime();
//        int[] intArray83 = gregorianChronology74.get((org.joda.time.ReadablePartial) localDateTime81, (long) ' ');
//        int[] intArray85 = skipUndoDateTimeField68.add((org.joda.time.ReadablePartial) localDateTime72, 0, intArray83, 0);
//        try {
//            int[] intArray87 = offsetDateTimeField6.set((org.joda.time.ReadablePartial) localDateTime50, 2000, intArray83, 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2000");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 31010L + "'", long9 == 31010L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 86374799000L + "'", long12 == 86374799000L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1" + "'", str14.equals("-1"));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(localDateTime42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 86400031 + "'", int43 == 86400031);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 100L + "'", long45 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(localDateTime50);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560319090498L + "'", long52 == 1560319090498L);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 33 + "'", int53 == 33);
//        org.junit.Assert.assertNotNull(gregorianChronology55);
//        org.junit.Assert.assertNotNull(dateTimeZone56);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1L + "'", long60 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 6 + "'", int62 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime64);
//        org.junit.Assert.assertNotNull(property65);
//        org.junit.Assert.assertNotNull(dateTimeField66);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDateTime72);
//        org.junit.Assert.assertNotNull(gregorianChronology74);
//        org.junit.Assert.assertNotNull(dateTimeZone75);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1L + "'", long79 == 1L);
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertNotNull(localDateTime81);
//        org.junit.Assert.assertNotNull(intArray83);
//        org.junit.Assert.assertNotNull(intArray85);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("GJChronology[America/Los_Angeles,cutover=1970-01-01,mdfw=5]", "357");
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        long long12 = gregorianChronology7.add(readablePeriod9, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now();
//        int int14 = mutableDateTime13.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.MutableDateTime mutableDateTime16 = mutableDateTime13.toMutableDateTime(dateTimeZone15);
//        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField18 = property17.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology7, dateTimeField18, 6);
//        int int22 = skipUndoDateTimeField20.getMinimumValue(28800032L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology23.getZone();
//        org.joda.time.DateTimeZone dateTimeZone25 = gregorianChronology23.getZone();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology23.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology23.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, (int) (short) -1);
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = offsetDateTimeField29.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField20, dateTimeFieldType30, (int) ' ');
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime34 = dateTime33.toLocalDateTime();
//        int int35 = offsetDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) localDateTime34);
//        long long37 = offsetDateTimeField32.roundHalfCeiling((long) (short) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology38 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology38.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone40 = gregorianChronology38.getZone();
//        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime42 = dateTime41.toLocalDateTime();
//        long long44 = gregorianChronology38.set((org.joda.time.ReadablePartial) localDateTime42, 28800100L);
//        int int45 = offsetDateTimeField32.getMinimumValue((org.joda.time.ReadablePartial) localDateTime42);
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = offsetDateTimeField6.getAsText((org.joda.time.ReadablePartial) localDateTime42, locale46);
//        long long49 = offsetDateTimeField6.roundCeiling((long) 2);
//        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone51 = gregorianChronology50.getZone();
//        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology50.getZone();
//        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology50.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology50.secondOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField(dateTimeField54, (int) (short) -1);
//        long long59 = offsetDateTimeField56.add((long) (short) 10, 31);
//        java.lang.String str61 = offsetDateTimeField56.getAsShortText((long) (-1));
//        long long63 = offsetDateTimeField56.roundHalfCeiling(2440588L);
//        long long65 = offsetDateTimeField56.remainder((long) 2000);
//        long long67 = offsetDateTimeField56.roundFloor((long) (byte) 10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology68 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone69 = gregorianChronology68.getZone();
//        org.joda.time.ReadablePeriod readablePeriod70 = null;
//        long long73 = gregorianChronology68.add(readablePeriod70, (long) 1, (int) (short) 100);
//        org.joda.time.DateTime dateTime74 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime75 = dateTime74.toLocalDateTime();
//        int[] intArray77 = gregorianChronology68.get((org.joda.time.ReadablePartial) localDateTime75, (long) ' ');
//        boolean boolean78 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime75);
//        java.util.Locale locale79 = null;
//        java.lang.String str80 = offsetDateTimeField56.getAsText((org.joda.time.ReadablePartial) localDateTime75, locale79);
//        java.util.Locale locale81 = null;
//        java.lang.String str82 = offsetDateTimeField6.getAsText((org.joda.time.ReadablePartial) localDateTime75, locale81);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(localDateTime34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 86400031 + "'", int35 == 86400031);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 100L + "'", long37 == 100L);
//        org.junit.Assert.assertNotNull(gregorianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(localDateTime42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560319090537L + "'", long44 == 1560319090537L);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 33 + "'", int45 == 33);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "21490" + "'", str47.equals("21490"));
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1000L + "'", long49 == 1000L);
//        org.junit.Assert.assertNotNull(gregorianChronology50);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(dateTimeField54);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 31010L + "'", long59 == 31010L);
//        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "57598" + "'", str61.equals("57598"));
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 2441000L + "'", long63 == 2441000L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 0L + "'", long65 == 0L);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology68);
//        org.junit.Assert.assertNotNull(dateTimeZone69);
//        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1L + "'", long73 == 1L);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(localDateTime75);
//        org.junit.Assert.assertNotNull(intArray77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "21490" + "'", str80.equals("21490"));
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "21490" + "'", str82.equals("21490"));
//    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
//        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
//        org.joda.time.DateTime.Property property3 = dateTime0.yearOfCentury();
//        boolean boolean4 = dateTime0.isEqualNow();
//        org.joda.time.DateTime dateTime6 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime.Property property7 = dateTime0.dayOfMonth();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(localDateTime1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) ' ');
        mutableDateTime1.setSecondOfMinute(0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.Chronology chronology1 = mutableDateTime0.getChronology();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.monthOfYear();
        mutableDateTime0.setDayOfYear((int) (byte) 10);
        mutableDateTime0.setMonthOfYear(10);
        int int7 = mutableDateTime0.getEra();
        mutableDateTime0.setSecondOfDay(50283);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
//        long long6 = mutableDateTime2.getMillis();
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1L));
//        org.joda.time.MutableDateTime mutableDateTime11 = property8.roundFloor();
//        try {
//            mutableDateTime11.setDate(0, 0, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560344291247L + "'", long6 == 1560344291247L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.plus((long) 100);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear(0);
        int int13 = dateTime12.getEra();
        org.joda.time.DateTime dateTime15 = dateTime12.withSecondOfMinute(10);
        int int16 = dateTime15.getMillisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 70100 + "'", int16 == 70100);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendClockhourOfDay(100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendTwoDigitYear(57600063, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder4.appendTwoDigitYear(57600);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.Chronology chronology1 = mutableDateTime0.getChronology();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.monthOfYear();
        mutableDateTime0.setMillis((long) 9);
        mutableDateTime0.addSeconds((int) (short) 10);
        mutableDateTime0.addMinutes(19);
        org.joda.time.DateTimeZone dateTimeZone9 = mutableDateTime0.getZone();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone2 = null;
//        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
//        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
//        int int5 = mutableDateTime4.getMonthOfYear();
//        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) mutableDateTime4);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        mutableDateTime4.setZoneRetainFields(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone8);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusHours((int) (short) 1);
//        org.joda.time.MutableDateTime mutableDateTime13 = org.joda.time.MutableDateTime.now();
//        int int14 = mutableDateTime13.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.MutableDateTime mutableDateTime16 = mutableDateTime13.toMutableDateTime(dateTimeZone15);
//        org.joda.time.MutableDateTime mutableDateTime17 = org.joda.time.MutableDateTime.now();
//        int int18 = mutableDateTime17.getMonthOfYear();
//        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime16, (org.joda.time.ReadableInstant) mutableDateTime17);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        mutableDateTime17.setZoneRetainFields(dateTimeZone21);
//        org.joda.time.MutableDateTime mutableDateTime23 = dateTime10.toMutableDateTime(dateTimeZone21);
//        org.joda.time.MutableDateTime mutableDateTime24 = org.joda.time.MutableDateTime.now();
//        int int25 = mutableDateTime24.getMonthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime26 = org.joda.time.MutableDateTime.now();
//        int int27 = mutableDateTime26.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.MutableDateTime mutableDateTime29 = mutableDateTime26.toMutableDateTime(dateTimeZone28);
//        long long30 = mutableDateTime26.getMillis();
//        mutableDateTime24.setMillis((org.joda.time.ReadableInstant) mutableDateTime26);
//        org.joda.time.MutableDateTime.Property property32 = mutableDateTime24.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime33 = property32.roundHalfEven();
//        boolean boolean34 = dateTime10.isAfter((org.joda.time.ReadableInstant) mutableDateTime33);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(mutableDateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime16);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertNotNull(mutableDateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime29);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560344291545L + "'", long30 == 1560344291545L);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(mutableDateTime33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.millisOfDay();
        try {
            org.joda.time.DateTime dateTime3 = dateTime0.withMinuteOfHour((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology5.getZone();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone7);
        org.joda.time.DateTime dateTime10 = dateTime8.plus((long) 100);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear(0);
        int int13 = dateTime12.getEra();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = gregorianChronology14.getZone();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.monthOfYear();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology14.yearOfEra();
        org.joda.time.DateTime dateTime18 = dateTime12.toDateTime((org.joda.time.Chronology) gregorianChronology14);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.LocalDateTime localDateTime1 = dateTime0.toLocalDateTime();
        org.joda.time.DateTime.Property property2 = dateTime0.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime0.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime0.minuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMonths(0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(localDateTime1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
//        int int7 = mutableDateTime6.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
//        java.lang.String str14 = skipUndoDateTimeField13.toString();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter16.withChronology((org.joda.time.Chronology) gregorianChronology17);
//        java.util.Locale locale19 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket21 = new org.joda.time.format.DateTimeParserBucket(1L, (org.joda.time.Chronology) gregorianChronology17, locale19, (java.lang.Integer) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone24 = gregorianChronology22.getZone();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime26 = dateTime25.toLocalDateTime();
//        long long28 = gregorianChronology22.set((org.joda.time.ReadablePartial) localDateTime26, 28800100L);
//        long long30 = gregorianChronology17.set((org.joda.time.ReadablePartial) localDateTime26, (long) 1969);
//        int int31 = skipUndoDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localDateTime26);
//        long long34 = skipUndoDateTimeField13.set(1560344269971L, 1);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[millisOfDay]" + "'", str14.equals("DateTimeField[millisOfDay]"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560319092143L + "'", long28 == 1560319092143L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1560344292143L + "'", long30 == 1560344292143L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 86399999 + "'", int31 == 86399999);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560322800000L + "'", long34 == 1560322800000L);
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = gregorianChronology0.add(readablePeriod2, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
//        int int7 = mutableDateTime6.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = mutableDateTime6.toMutableDateTime(dateTimeZone8);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = property10.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField11, 6);
//        int int15 = skipUndoDateTimeField13.getMinimumValue(28800032L);
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime17 = dateTime16.toLocalDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone20 = gregorianChronology19.getZone();
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        long long24 = gregorianChronology19.add(readablePeriod21, (long) 1, (int) (short) 100);
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime26 = dateTime25.toLocalDateTime();
//        int[] intArray28 = gregorianChronology19.get((org.joda.time.ReadablePartial) localDateTime26, (long) ' ');
//        int[] intArray30 = skipUndoDateTimeField13.add((org.joda.time.ReadablePartial) localDateTime17, 0, intArray28, 0);
//        java.lang.String str32 = skipUndoDateTimeField13.getAsShortText((long) ' ');
//        org.joda.time.chrono.GregorianChronology gregorianChronology33 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone34 = gregorianChronology33.getZone();
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        long long38 = gregorianChronology33.add(readablePeriod35, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime39 = org.joda.time.MutableDateTime.now();
//        int int40 = mutableDateTime39.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone41 = null;
//        org.joda.time.MutableDateTime mutableDateTime42 = mutableDateTime39.toMutableDateTime(dateTimeZone41);
//        org.joda.time.MutableDateTime.Property property43 = mutableDateTime42.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField44 = property43.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField46 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology33, dateTimeField44, 6);
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone48 = gregorianChronology47.getZone();
//        org.joda.time.ReadablePeriod readablePeriod49 = null;
//        long long52 = gregorianChronology47.add(readablePeriod49, (long) 1, (int) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime53 = org.joda.time.MutableDateTime.now();
//        int int54 = mutableDateTime53.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone55 = null;
//        org.joda.time.MutableDateTime mutableDateTime56 = mutableDateTime53.toMutableDateTime(dateTimeZone55);
//        org.joda.time.MutableDateTime.Property property57 = mutableDateTime56.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField58 = property57.getField();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField60 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology47, dateTimeField58, 6);
//        int int62 = skipUndoDateTimeField60.getMinimumValue(28800032L);
//        org.joda.time.DateTime dateTime63 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime64 = dateTime63.toLocalDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology66 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone67 = gregorianChronology66.getZone();
//        org.joda.time.ReadablePeriod readablePeriod68 = null;
//        long long71 = gregorianChronology66.add(readablePeriod68, (long) 1, (int) (short) 100);
//        org.joda.time.DateTime dateTime72 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime73 = dateTime72.toLocalDateTime();
//        int[] intArray75 = gregorianChronology66.get((org.joda.time.ReadablePartial) localDateTime73, (long) ' ');
//        int[] intArray77 = skipUndoDateTimeField60.add((org.joda.time.ReadablePartial) localDateTime64, 0, intArray75, 0);
//        int int78 = skipUndoDateTimeField46.getMinimumValue((org.joda.time.ReadablePartial) localDateTime64);
//        int int79 = skipUndoDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) localDateTime64);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter81 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology82 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter83 = dateTimeFormatter81.withChronology((org.joda.time.Chronology) gregorianChronology82);
//        java.util.Locale locale84 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket86 = new org.joda.time.format.DateTimeParserBucket(1L, (org.joda.time.Chronology) gregorianChronology82, locale84, (java.lang.Integer) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology87 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField88 = gregorianChronology87.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone89 = gregorianChronology87.getZone();
//        org.joda.time.DateTime dateTime90 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime91 = dateTime90.toLocalDateTime();
//        long long93 = gregorianChronology87.set((org.joda.time.ReadablePartial) localDateTime91, 28800100L);
//        long long95 = gregorianChronology82.set((org.joda.time.ReadablePartial) localDateTime91, (long) 1969);
//        int int96 = skipUndoDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) localDateTime91);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(localDateTime17);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertNotNull(intArray28);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "57600032" + "'", str32.equals("57600032"));
//        org.junit.Assert.assertNotNull(gregorianChronology33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1L + "'", long38 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1L + "'", long52 == 1L);
//        org.junit.Assert.assertNotNull(mutableDateTime53);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime56);
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(dateTimeField58);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(localDateTime64);
//        org.junit.Assert.assertNotNull(gregorianChronology66);
//        org.junit.Assert.assertNotNull(dateTimeZone67);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1L + "'", long71 == 1L);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(localDateTime73);
//        org.junit.Assert.assertNotNull(intArray75);
//        org.junit.Assert.assertNotNull(intArray77);
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter81);
//        org.junit.Assert.assertNotNull(gregorianChronology82);
//        org.junit.Assert.assertNotNull(dateTimeFormatter83);
//        org.junit.Assert.assertNotNull(gregorianChronology87);
//        org.junit.Assert.assertNotNull(dateTimeField88);
//        org.junit.Assert.assertNotNull(dateTimeZone89);
//        org.junit.Assert.assertNotNull(dateTime90);
//        org.junit.Assert.assertNotNull(localDateTime91);
//        org.junit.Assert.assertTrue("'" + long93 + "' != '" + 1560319092265L + "'", long93 == 1560319092265L);
//        org.junit.Assert.assertTrue("'" + long95 + "' != '" + 1560344292265L + "'", long95 == 1560344292265L);
//        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 86399999 + "'", int96 == 86399999);
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 5);
        java.lang.String str4 = dateTimeFormatter0.print((long) 1);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withZone(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "12/31/69 4:00 PM" + "'", str4.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        java.lang.Object obj4 = mutableDateTime3.clone();
        try {
            mutableDateTime3.setDayOfYear(960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(778, 0, (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology1.getZone();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology1.add(readablePeriod3, (long) 1, (int) (short) 100);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) ' ', (org.joda.time.Chronology) gregorianChronology1, locale7);
        dateTimeParserBucket8.setPivotYear((java.lang.Integer) (-1));
        long long11 = dateTimeParserBucket8.computeMillis();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology17.getZone();
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology17.getZone();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone19);
        long long23 = dateTimeZone19.convertLocalToUTC((long) (byte) 100, true);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeUtils.getZone(dateTimeZone19);
        dateTimeParserBucket8.setZone(dateTimeZone24);
        try {
            org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone24, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 12");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28800032L + "'", long11 == 28800032L);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 28800100L + "'", long23 == 28800100L);
        org.junit.Assert.assertNotNull(dateTimeZone24);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket6 = new org.joda.time.format.DateTimeParserBucket(0L, chronology2, locale3, (java.lang.Integer) (-25200000), 6);
        org.joda.time.Chronology chronology7 = dateTimeParserBucket6.getChronology();
        dateTimeParserBucket6.setPivotYear((java.lang.Integer) (-2));
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear((int) (short) 1);
        boolean boolean3 = dateTimeFormatter2.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply((-4975515878413010L), (-57599968L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -4975515878413010 * -57599968");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("GJChronology[America/Los_Angeles,cutover=1970-01-01,mdfw=5]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GJChronology[America/Los_Angeles...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField6.getType();
        org.joda.time.DurationField durationField8 = offsetDateTimeField6.getLeapDurationField();
        int int10 = offsetDateTimeField6.getLeapAmount((long) 1969);
        long long13 = offsetDateTimeField6.set((long) 3, "960");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendTwoDigitYear((int) (short) 1);
        boolean boolean17 = dateTimeFormatterBuilder14.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder14.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder20.appendMonthOfYear(1);
        boolean boolean23 = dateTimeFormatterBuilder22.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendTwoDigitYear((int) (short) 1);
        boolean boolean27 = dateTimeFormatterBuilder24.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder24.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone30 = gregorianChronology29.getZone();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        long long34 = gregorianChronology29.add(readablePeriod31, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime35 = org.joda.time.MutableDateTime.now();
        int int36 = mutableDateTime35.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone37 = null;
        org.joda.time.MutableDateTime mutableDateTime38 = mutableDateTime35.toMutableDateTime(dateTimeZone37);
        org.joda.time.MutableDateTime.Property property39 = mutableDateTime38.millisOfDay();
        org.joda.time.DateTimeField dateTimeField40 = property39.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField42 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology29, dateTimeField40, 6);
        int int44 = skipUndoDateTimeField42.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology45 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone46 = gregorianChronology45.getZone();
        org.joda.time.DateTimeZone dateTimeZone47 = gregorianChronology45.getZone();
        org.joda.time.DateTimeField dateTimeField48 = gregorianChronology45.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology45.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType52 = offsetDateTimeField51.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField42, dateTimeFieldType52, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder55 = dateTimeFormatterBuilder24.appendText(dateTimeFieldType52);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder57 = dateTimeFormatterBuilder22.appendFixedDecimal(dateTimeFieldType52, 86400031);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType52, (int) (short) 100);
        java.lang.String str61 = offsetDateTimeField59.getAsShortText(28800032L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
        org.junit.Assert.assertNull(durationField8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-56638997L) + "'", long13 == (-56638997L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1L + "'", long34 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeFieldType52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder55);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder57);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "99" + "'", str61.equals("99"));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        org.joda.time.Chronology chronology1 = mutableDateTime0.getChronology();
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime0.monthOfYear();
        mutableDateTime0.setMillis((long) 9);
        mutableDateTime0.addSeconds((int) (short) 10);
        int int7 = mutableDateTime0.getMillisOfSecond();
        org.joda.time.Instant instant8 = new org.joda.time.Instant((java.lang.Object) mutableDateTime0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime0.minuteOfDay();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 9 + "'", int7 == 9);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology7.getZone();
//        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology7.getZone();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (byte) 1, 10, (int) (short) 1, 0, (int) (byte) 1, dateTimeZone9);
//        org.joda.time.DateTime dateTime12 = dateTime10.plus((long) 100);
//        int int13 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
//        boolean boolean16 = dateTimeZone14.isStandardOffset((long) 'a');
//        java.lang.String str18 = dateTimeZone14.getShortName(0L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        int int1 = mutableDateTime0.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = mutableDateTime0.toMutableDateTime(dateTimeZone2);
        org.joda.time.MutableDateTime mutableDateTime4 = org.joda.time.MutableDateTime.now();
        int int5 = mutableDateTime4.getMonthOfYear();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) mutableDateTime3, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 0);
        mutableDateTime4.setZoneRetainFields(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.DateTime dateTime12 = dateTime10.minusHours((int) (short) 1);
        org.joda.time.DateTime dateTime14 = dateTime10.plusHours((int) (short) -1);
        org.joda.time.DateTime dateTime16 = dateTime10.plusDays(86399999);
        try {
            org.joda.time.DateTime dateTime20 = dateTime10.withDate(9, (int) '#', (-97));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitYear((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneName();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendWeekOfWeekyear(57600000);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap6 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendTimeZoneName(strMap6);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendMinuteOfHour(0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) (short) -1);
        long long9 = offsetDateTimeField6.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField10 = offsetDateTimeField6.getRangeDurationField();
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField6.getAsShortText(0, locale12);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560344238L + "'", long9 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
//        long long6 = mutableDateTime2.getMillis();
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = mutableDateTime2.toCalendar(locale8);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime2.dayOfWeek();
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime2.yearOfCentury();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560344293951L + "'", long6 == 1560344293951L);
//        org.junit.Assert.assertNotNull(calendar9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusMinutes((int) (byte) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minus((long) (-1));
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendTwoDigitYear((int) (short) 1);
        boolean boolean9 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder6.appendTwoDigitWeekyear((int) '4', true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendMonthOfYear(1);
        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTwoDigitYear((int) (short) 1);
        boolean boolean19 = dateTimeFormatterBuilder16.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendMonthOfYearShortText();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone22 = gregorianChronology21.getZone();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        long long26 = gregorianChronology21.add(readablePeriod23, (long) 1, (int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime27 = org.joda.time.MutableDateTime.now();
        int int28 = mutableDateTime27.getMonthOfYear();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.MutableDateTime mutableDateTime30 = mutableDateTime27.toMutableDateTime(dateTimeZone29);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime30.millisOfDay();
        org.joda.time.DateTimeField dateTimeField32 = property31.getField();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField34 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gregorianChronology21, dateTimeField32, 6);
        int int36 = skipUndoDateTimeField34.getMinimumValue(28800032L);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology37.getZone();
        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology37.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField43 = new org.joda.time.field.OffsetDateTimeField(dateTimeField41, (int) (short) -1);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = offsetDateTimeField43.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField34, dateTimeFieldType44, (int) ' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder16.appendText(dateTimeFieldType44);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType44, 86400031);
        org.joda.time.DateTime.Property property50 = dateTime5.property(dateTimeFieldType44);
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone52 = gregorianChronology51.getZone();
        org.joda.time.DateTimeZone dateTimeZone53 = gregorianChronology51.getZone();
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology51.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField55 = gregorianChronology51.secondOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField57 = new org.joda.time.field.OffsetDateTimeField(dateTimeField55, (int) (short) -1);
        long long60 = offsetDateTimeField57.getDifferenceAsLong(1560344238929L, (long) 6);
        org.joda.time.DurationField durationField61 = offsetDateTimeField57.getRangeDurationField();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField62 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType44, durationField61);
        long long65 = unsupportedDateTimeField62.add((long) 22065, 2000);
        org.joda.time.DurationField durationField66 = unsupportedDateTimeField62.getDurationField();
        org.joda.time.ReadablePartial readablePartial67 = null;
        try {
            int int68 = unsupportedDateTimeField62.getMaximumValue(readablePartial67);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: secondOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560344238L + "'", long60 == 1560344238L);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField62);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 172796422065L + "'", long65 == 172796422065L);
        org.junit.Assert.assertNotNull(durationField66);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        int int1 = mutableDateTime0.getMonthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now();
//        int int3 = mutableDateTime2.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = mutableDateTime2.toMutableDateTime(dateTimeZone4);
//        long long6 = mutableDateTime2.getMillis();
//        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) mutableDateTime2);
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.dayOfYear();
//        org.joda.time.MutableDateTime mutableDateTime10 = property8.add((-1L));
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
//        org.joda.time.DateTime.Property property13 = dateTime11.dayOfWeek();
//        org.joda.time.DateTime.Property property14 = dateTime11.dayOfMonth();
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime11.minus(readableDuration15);
//        boolean boolean17 = mutableDateTime10.isBefore((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
//        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
//        org.joda.time.DateTime.Property property20 = dateTime18.dayOfWeek();
//        org.joda.time.DateTime.Property property21 = dateTime18.yearOfCentury();
//        boolean boolean22 = dateTime18.isEqualNow();
//        org.joda.time.DateTime dateTime24 = dateTime18.plusMinutes(1);
//        org.joda.time.DateTime.Property property25 = dateTime24.weekyear();
//        mutableDateTime10.setMillis((org.joda.time.ReadableInstant) dateTime24);
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560344294012L + "'", long6 == 1560344294012L);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//    }
//}

