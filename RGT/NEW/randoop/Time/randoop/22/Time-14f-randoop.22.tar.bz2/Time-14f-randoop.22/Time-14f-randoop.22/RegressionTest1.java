import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
        java.lang.String str15 = property13.getAsString();
        org.joda.time.DurationField durationField16 = property13.getDurationField();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), chronology18);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.withDurationAdded(readableDuration20, 0);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), chronology24);
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime25.getZone();
        java.util.TimeZone timeZone28 = dateTimeZone27.toTimeZone();
        org.joda.time.DateTime dateTime29 = dateTime22.toDateTime(dateTimeZone27);
        org.joda.time.DateTime.Property property30 = dateTime22.yearOfEra();
        org.joda.time.DurationField durationField31 = property30.getRangeDurationField();
        java.lang.String str32 = property30.getAsString();
        org.joda.time.DurationField durationField33 = property30.getDurationField();
        boolean boolean34 = property13.equals((java.lang.Object) durationField33);
        int int35 = property13.getMaximumValueOverall();
        java.lang.String str36 = property13.toString();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNull(durationField31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1969" + "'", str32.equals("1969"));
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 292278993 + "'", int35 == 292278993);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Property[yearOfEra]" + "'", str36.equals("Property[yearOfEra]"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.halfdays();
        boolean boolean3 = gregorianChronology0.equals((java.lang.Object) durationField2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        try {
            long long30 = unsupportedDateTimeField28.roundFloor((long) 89);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        try {
            int int29 = unsupportedDateTimeField28.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        boolean boolean8 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay6.plus(readablePeriod9);
        int[] intArray12 = new int[] { 0 };
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay10, intArray12);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, (int) (byte) 100);
        long long17 = delegatedDateTimeField2.roundCeiling(52L);
        org.joda.time.DateTimeField dateTimeField18 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long27 = fixedDateTimeZone23.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone23, readableInstant28);
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone23);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone35 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int37 = fixedDateTimeZone35.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay38 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone35);
        int int39 = monthDay30.compareTo((org.joda.time.ReadablePartial) monthDay38);
        int int40 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay38);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-9L) + "'", long27 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 999 + "'", int40 == 999);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getChronology(chronology31);
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((int) (byte) 1, 9, chronology32);
        try {
            int int34 = unsupportedDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) monthDay33);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(chronology32);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = copticChronology29.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30);
        long long34 = delegatedDateTimeField31.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay35 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now();
        boolean boolean37 = monthDay35.isEqual((org.joda.time.ReadablePartial) monthDay36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.MonthDay monthDay39 = monthDay35.plus(readablePeriod38);
        int[] intArray41 = new int[] { 0 };
        int int42 = delegatedDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) monthDay39, intArray41);
        org.joda.time.MonthDay monthDay44 = monthDay39.minusDays(0);
        try {
            int int45 = unsupportedDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) monthDay44);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 292278122L + "'", long34 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 999 + "'", int42 == 999);
        org.junit.Assert.assertNotNull(monthDay44);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        boolean boolean17 = offsetDateTimeField13.isLeap((-31556476800000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumTextLength(locale8);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, (org.joda.time.Chronology) copticChronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = copticChronology3.getZone();
        org.joda.time.DurationField durationField6 = copticChronology3.millis();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int11 = fixedDateTimeZone4.getOffset((long) 359);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertNotNull(monthDay12);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(86399);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendSecondOfDay(365);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(5, 89, (-25200000), (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-25199906) + "'", int4 == (-25199906));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.halfdays();
        boolean boolean3 = gregorianChronology0.equals((java.lang.Object) durationField2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology0.centuries();
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8);
        long long12 = delegatedDateTimeField9.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now();
        boolean boolean15 = monthDay13.isEqual((org.joda.time.ReadablePartial) monthDay14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay17 = monthDay13.plus(readablePeriod16);
        int[] intArray19 = new int[] { 0 };
        int int20 = delegatedDateTimeField9.getMaximumValue((org.joda.time.ReadablePartial) monthDay17, intArray19);
        try {
            gregorianChronology0.validate(readablePartial6, intArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 292278122L + "'", long12 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 999 + "'", int20 == 999);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        java.lang.String str26 = property25.toString();
        java.lang.String str27 = property25.getAsText();
        int int28 = property25.getMinimumValueOverall();
        org.joda.time.DateTime dateTime29 = property25.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[dayOfMonth]" + "'", str26.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "24" + "'", str27.equals("24"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean14 = fixedDateTimeZone5.isFixed();
        org.joda.time.Chronology chronology15 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str16 = julianChronology0.toString();
        long long21 = julianChronology0.getDateTimeMillis(1099, 6, 9, 31);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forID("-01:00");
        long long25 = dateTimeZone23.convertUTCToLocal((-28800000L));
        org.joda.time.Chronology chronology26 = julianChronology0.withZone(dateTimeZone23);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (-1), chronology28);
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTimeZone dateTimeZone31 = dateTime29.getZone();
        boolean boolean33 = dateTime29.isEqual((long) 999);
        boolean boolean34 = julianChronology0.equals((java.lang.Object) boolean33);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone39 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long43 = fixedDateTimeZone39.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.DateTimeFormat.mediumTime();
        boolean boolean45 = fixedDateTimeZone39.equals((java.lang.Object) dateTimeFormatter44);
        org.joda.time.Chronology chronology46 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone39);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str16.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-27471802021969L) + "'", long21 == (-27471802021969L));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-32400000L) + "'", long25 == (-32400000L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-9L) + "'", long43 == (-9L));
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(chronology46);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
        java.lang.String str15 = property13.getAsString();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property13.getAsShortText(locale16);
        java.util.Locale locale18 = null;
        java.lang.String str19 = property13.getAsText(locale18);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969" + "'", str17.equals("1969"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "1969" + "'", str19.equals("1969"));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfCentury();
        boolean boolean28 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.YearMonthDay yearMonthDay29 = dateTime24.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(yearMonthDay29);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long10 = fixedDateTimeZone6.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6, readableInstant11);
        org.joda.time.Chronology chronology13 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = gregorianChronology1.add(readablePeriod14, (long) (byte) 10, 53);
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology1.getZone();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology1.millisOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-9L) + "'", long10 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfCentury();
        boolean boolean28 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime24);
        java.util.GregorianCalendar gregorianCalendar29 = dateTime24.toGregorianCalendar();
        org.joda.time.DateTime dateTime31 = dateTime24.withMillisOfSecond(0);
        int int32 = dateTime31.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 59 + "'", int32 == 59);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (short) 10);
        org.joda.time.MonthDay.Property property2 = monthDay1.dayOfMonth();
        java.lang.String str3 = property2.toString();
        java.lang.String str4 = property2.toString();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Property[dayOfMonth]" + "'", str3.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[dayOfMonth]" + "'", str4.equals("Property[dayOfMonth]"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        int int12 = dateTime8.getSecondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime8.withYear(2116);
        org.joda.time.DateTime dateTime16 = dateTime14.withMillisOfSecond((int) '#');
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = gJChronology10.monthOfYear();
        org.joda.time.Instant instant34 = gJChronology10.getGregorianCutover();
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36);
        java.lang.String str39 = delegatedDateTimeField37.getAsText((long) (byte) 10);
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField37.getAsText(0L, locale41);
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) delegatedDateTimeField37, 358);
        int int45 = skipDateTimeField44.getMinimumValue();
        int int47 = skipDateTimeField44.get(13632725433589019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10" + "'", str39.equals("10"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0" + "'", str42.equals("0"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 18 + "'", int47 == 18);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
        java.lang.String str15 = property13.getAsString();
        org.joda.time.DurationField durationField16 = property13.getDurationField();
        org.joda.time.DateTime dateTime17 = property13.withMinimumValue();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (-1), chronology19);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime20.getZone();
        org.joda.time.LocalTime localTime23 = dateTime20.toLocalTime();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (-1), chronology25);
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTimeZone dateTimeZone28 = dateTime26.getZone();
        org.joda.time.LocalTime localTime29 = dateTime26.toLocalTime();
        boolean boolean30 = localTime23.isEqual((org.joda.time.ReadablePartial) localTime29);
        boolean boolean31 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime29);
        org.joda.time.DateTime dateTime32 = dateTime17.withFields((org.joda.time.ReadablePartial) localTime29);
        org.joda.time.DateTime dateTime34 = dateTime32.withDayOfYear(9);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(localTime23);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(localTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
        org.joda.time.DateTime dateTime15 = property13.roundFloorCopy();
        org.joda.time.DateTime.Property property16 = dateTime15.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendMinuteOfDay(359);
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (-1), chronology10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded(readableDuration12, 0);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (-1), chronology16);
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
        java.util.TimeZone timeZone20 = dateTimeZone19.toTimeZone();
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone19);
        org.joda.time.DateTime.Property property22 = dateTime14.yearOfEra();
        org.joda.time.DateTime dateTime24 = dateTime14.minusDays(0);
        org.joda.time.DateTime dateTime26 = dateTime24.minusHours((int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = copticChronology27.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
        long long32 = delegatedDateTimeField29.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField29.getType();
        org.joda.time.DateTime.Property property34 = dateTime24.property(dateTimeFieldType33);
        int int35 = monthDay8.indexOf(dateTimeFieldType33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType33, 57599999, 1099);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder39 = dateTimeFormatterBuilder7.appendHalfdayOfDayText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder39.appendTimeZoneOffset("DateTimeField[yearOfEra]", "2019-06-15T21:05:06.830Z", false, 401135, 34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(copticChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 292278122L + "'", long32 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder39);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.monthOfYear();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology10.weekyearOfCentury();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (-1), chronology16);
        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property20 = dateTime19.year();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (-1), chronology22);
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime23);
        int int25 = dateTime19.compareTo((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime.Property property26 = dateTime23.yearOfCentury();
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (-1), chronology28);
        org.joda.time.DateTime dateTime31 = dateTime29.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property32 = dateTime31.year();
        int int33 = property32.getMaximumValue();
        java.util.Locale locale34 = null;
        java.lang.String str35 = property32.getAsText(locale34);
        org.joda.time.DateTime dateTime37 = property32.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay38 = dateTime37.toTimeOfDay();
        boolean boolean39 = dateTime23.isBefore((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTime.Property property40 = dateTime37.dayOfMonth();
        int int41 = dateTime37.getYearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.DateTime dateTime43 = dateTime37.plus(readablePeriod42);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.DateTime dateTime45 = dateTime43.toDateTime(dateTimeZone44);
        boolean boolean46 = gJChronology10.equals((java.lang.Object) dateTime45);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 292278993 + "'", int33 == 292278993);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1969" + "'", str35.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(timeOfDay38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology4.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        long long9 = delegatedDateTimeField6.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField6.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 86399);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology13.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        long long18 = delegatedDateTimeField15.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = delegatedDateTimeField15.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField12, dateTimeFieldType19);
        try {
            long long23 = dividedDateTimeField12.set(57599999L, (-54));
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 292278122L + "'", long9 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 292278122L + "'", long18 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        java.lang.Object obj22 = null;
        boolean boolean23 = fixedDateTimeZone15.equals(obj22);
        long long25 = fixedDateTimeZone15.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology26 = gJChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long35 = fixedDateTimeZone31.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone31, readableInstant36);
        org.joda.time.DurationField durationField38 = gJChronology37.millis();
        org.joda.time.DurationField durationField39 = gJChronology37.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone44 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long48 = fixedDateTimeZone44.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone44, readableInstant49);
        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) 'a');
        long long55 = offsetDateTimeField53.roundCeiling(10L);
        long long57 = offsetDateTimeField53.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField59 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology37, (org.joda.time.DateTimeField) offsetDateTimeField53, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField60 = gJChronology37.monthOfYear();
        boolean boolean61 = fixedDateTimeZone15.equals((java.lang.Object) gJChronology37);
        org.joda.time.DateTimeZone dateTimeZone62 = gJChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField63 = gJChronology37.year();
        org.joda.time.DateTimeField dateTimeField64 = gJChronology37.year();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31556476799900L) + "'", long25 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-9L) + "'", long35 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-9L) + "'", long48 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 31535999990L + "'", long55 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 31535999990L + "'", long57 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        java.util.Locale locale30 = null;
        try {
            java.lang.String str31 = unsupportedDateTimeField28.getAsText((long) 292278993, locale30);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = gJChronology10.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 53);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField33, dateTimeFieldType36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), chronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property16 = dateTime15.year();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), chronology18);
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime19);
        int int21 = dateTime15.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime.Property property22 = dateTime19.yearOfCentury();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), chronology24);
        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property28 = dateTime27.year();
        int int29 = property28.getMaximumValue();
        java.util.Locale locale30 = null;
        java.lang.String str31 = property28.getAsText(locale30);
        org.joda.time.DateTime dateTime33 = property28.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay34 = dateTime33.toTimeOfDay();
        boolean boolean35 = dateTime19.isBefore((org.joda.time.ReadableInstant) dateTime33);
        int int36 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean38 = cachedDateTimeZone37.isFixed();
        org.joda.time.Chronology chronology40 = null;
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (-1), chronology40);
        org.joda.time.ReadableDuration readableDuration42 = null;
        org.joda.time.DateTime dateTime44 = dateTime41.withDurationAdded(readableDuration42, 0);
        org.joda.time.Chronology chronology46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (-1), chronology46);
        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime47);
        org.joda.time.DateTimeZone dateTimeZone49 = dateTime47.getZone();
        java.util.TimeZone timeZone50 = dateTimeZone49.toTimeZone();
        org.joda.time.DateTime dateTime51 = dateTime44.toDateTime(dateTimeZone49);
        org.joda.time.DateTime.Property property52 = dateTime44.yearOfEra();
        org.joda.time.DateTime dateTime54 = dateTime44.minusMillis(10);
        org.joda.time.Chronology chronology55 = null;
        org.joda.time.Chronology chronology56 = org.joda.time.DateTimeUtils.getChronology(chronology55);
        org.joda.time.DateTime dateTime57 = dateTime44.withChronology(chronology55);
        org.joda.time.Chronology chronology58 = dateTime57.getChronology();
        org.joda.time.Chronology chronology59 = dateTime57.getChronology();
        boolean boolean60 = cachedDateTimeZone37.equals((java.lang.Object) dateTime57);
        java.util.GregorianCalendar gregorianCalendar61 = dateTime57.toGregorianCalendar();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 292278993 + "'", int29 == 292278993);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969" + "'", str31.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(timeOfDay34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(chronology56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(chronology58);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(gregorianCalendar61);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        try {
            java.lang.String str30 = unsupportedDateTimeField28.getAsText(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (-98));
        org.joda.time.DurationField durationField22 = offsetDateTimeField13.getDurationField();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = gJChronology10.monthOfYear();
        org.joda.time.Instant instant34 = gJChronology10.getGregorianCutover();
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36);
        java.lang.String str39 = delegatedDateTimeField37.getAsText((long) (byte) 10);
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField37.getAsText(0L, locale41);
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) delegatedDateTimeField37, 358);
        long long47 = skipDateTimeField44.set(1560632687348L, 999);
        java.util.Locale locale49 = null;
        java.lang.String str50 = skipDateTimeField44.getAsShortText(359, locale49);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10" + "'", str39.equals("10"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0" + "'", str42.equals("0"));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560632687999L + "'", long47 == 1560632687999L);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "359" + "'", str50.equals("359"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        java.lang.Object obj22 = null;
        boolean boolean23 = fixedDateTimeZone15.equals(obj22);
        long long25 = fixedDateTimeZone15.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology26 = gJChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long35 = fixedDateTimeZone31.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone31, readableInstant36);
        org.joda.time.DurationField durationField38 = gJChronology37.millis();
        org.joda.time.DurationField durationField39 = gJChronology37.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone44 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long48 = fixedDateTimeZone44.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone44, readableInstant49);
        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) 'a');
        long long55 = offsetDateTimeField53.roundCeiling(10L);
        long long57 = offsetDateTimeField53.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField59 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology37, (org.joda.time.DateTimeField) offsetDateTimeField53, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField60 = gJChronology37.monthOfYear();
        boolean boolean61 = fixedDateTimeZone15.equals((java.lang.Object) gJChronology37);
        org.joda.time.DateTimeZone dateTimeZone62 = gJChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField63 = gJChronology37.year();
        org.joda.time.Chronology chronology64 = gJChronology37.withUTC();
        org.joda.time.DateTimeField dateTimeField65 = gJChronology37.minuteOfDay();
        try {
            long long70 = gJChronology37.getDateTimeMillis(89, 31, 1, 58);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31556476799900L) + "'", long25 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-9L) + "'", long35 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-9L) + "'", long48 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 31535999990L + "'", long55 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 31535999990L + "'", long57 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(chronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds((int) (short) 1);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (-1), chronology16);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded(readableDuration18, 0);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (-1), chronology22);
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTimeZone dateTimeZone25 = dateTime23.getZone();
        java.util.TimeZone timeZone26 = dateTimeZone25.toTimeZone();
        org.joda.time.DateTime dateTime27 = dateTime20.toDateTime(dateTimeZone25);
        org.joda.time.DateTime.Property property28 = dateTime20.yearOfEra();
        org.joda.time.DateTime dateTime30 = dateTime20.minusDays(0);
        org.joda.time.DateTime dateTime32 = dateTime30.minusHours((int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = copticChronology33.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34);
        long long38 = delegatedDateTimeField35.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = delegatedDateTimeField35.getType();
        org.joda.time.DateTime.Property property40 = dateTime30.property(dateTimeFieldType39);
        org.joda.time.DateTime.Property property41 = dateTime12.property(dateTimeFieldType39);
        org.joda.time.DateTime.Property property42 = dateTime12.yearOfEra();
        org.joda.time.DateTime dateTime44 = dateTime12.plusDays(5);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 292278122L + "'", long38 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime44);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15T21:04:52.040Z");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long11 = fixedDateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7, readableInstant12);
        org.joda.time.DurationField durationField14 = gJChronology13.millis();
        org.joda.time.DurationField durationField15 = gJChronology13.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DateTimeField dateTimeField27 = gJChronology26.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, (int) 'a');
        long long31 = offsetDateTimeField29.roundCeiling(10L);
        long long33 = offsetDateTimeField29.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField35 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology13, (org.joda.time.DateTimeField) offsetDateTimeField29, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField36 = gJChronology13.yearOfCentury();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField36, 53);
        boolean boolean39 = jodaTimePermission1.equals((java.lang.Object) 53);
        java.lang.String str40 = jodaTimePermission1.getName();
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) (-1), chronology42);
        org.joda.time.DateTime dateTime45 = dateTime43.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property46 = dateTime45.year();
        org.joda.time.Instant instant47 = dateTime45.toInstant();
        jodaTimePermission1.checkGuard((java.lang.Object) instant47);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9L) + "'", long11 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 31535999990L + "'", long31 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 31535999990L + "'", long33 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019-06-15T21:04:52.040Z" + "'", str40.equals("2019-06-15T21:04:52.040Z"));
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(instant47);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        try {
            long long30 = unsupportedDateTimeField28.roundHalfEven((-365L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = copticChronology9.era();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime12 = dateTime8.minusHours(10);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) '#');
        org.joda.time.DateTime dateTime16 = dateTime14.plus((long) 366);
        int int17 = dateTime14.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 34 + "'", int17 == 34);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        try {
            int int29 = unsupportedDateTimeField28.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969", (java.lang.Number) 10.0f, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertNull(dateTimeFieldType5);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969", (java.lang.Number) 10.0f, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("1969", (java.lang.Number) 10.0f, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 1);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        java.lang.String str11 = illegalFieldValueException9.getIllegalStringValue();
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        try {
            java.lang.String str30 = unsupportedDateTimeField28.getAsText((long) 86399);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property18 = dateTime17.year();
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (-1), chronology20);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime21);
        int int23 = dateTime17.compareTo((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property24 = dateTime21.yearOfCentury();
        int int25 = dateTime21.getSecondOfMinute();
        org.joda.time.DateTime dateTime27 = dateTime21.minusSeconds((-1));
        boolean boolean28 = gregorianChronology12.equals((java.lang.Object) dateTime21);
        org.joda.time.DateTimeZone dateTimeZone29 = gregorianChronology12.getZone();
        org.joda.time.DateTime dateTime30 = dateTime8.toDateTime(dateTimeZone29);
        org.joda.time.Chronology chronology31 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime30);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 59 + "'", int25 == 59);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(chronology31);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.lang.Object obj0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.yearOfEra();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.weekyear();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gJChronology11);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded(readableDuration15, 292279090);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = gJChronology10.monthOfYear();
        org.joda.time.DateTimeField dateTimeField34 = gJChronology10.millisOfSecond();
        try {
            long long39 = gJChronology10.getDateTimeMillis(57599999, (int) 'a', 89, 359);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.halfdays();
        boolean boolean3 = gregorianChronology0.equals((java.lang.Object) durationField2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        long long7 = gregorianChronology0.add(readablePeriod4, 3155760000100L, 86399);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3155760000100L + "'", long7 == 3155760000100L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        java.util.Locale locale31 = null;
        try {
            long long32 = unsupportedDateTimeField28.set(31L, "4", locale31);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(86399);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap3);
        dateTimeFormatterBuilder2.clear();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendMillisOfDay((-100));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), chronology2);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime3.toMutableDateTime();
        int int7 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime4, "2067", 53);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withDefaultYear((int) (short) 1);
        java.lang.StringBuffer stringBuffer10 = null;
        try {
            dateTimeFormatter9.printTo(stringBuffer10, (long) 292278993);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-54) + "'", int7 == (-54));
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long10 = fixedDateTimeZone6.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6, readableInstant11);
        org.joda.time.Chronology chronology13 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = gregorianChronology1.add(readablePeriod14, (long) (byte) 10, 53);
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology1.getZone();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology1.weekyearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-9L) + "'", long10 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeField20);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = gJChronology10.monthOfYear();
        org.joda.time.Instant instant34 = gJChronology10.getGregorianCutover();
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36);
        java.lang.String str39 = delegatedDateTimeField37.getAsText((long) (byte) 10);
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField37.getAsText(0L, locale41);
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) delegatedDateTimeField37, 358);
        int int45 = skipDateTimeField44.getMinimumValue();
        boolean boolean46 = skipDateTimeField44.isSupported();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10" + "'", str39.equals("10"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0" + "'", str42.equals("0"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.monthOfYear();
        org.joda.time.DateTime dateTime3 = property1.addWrapFieldToCopy(34);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        int int3 = dateTime2.getDayOfWeek();
        try {
            java.lang.String str5 = dateTime2.toString("T��:��:��");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (-1), chronology8);
//        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.DateTimeZone dateTimeZone11 = dateTime9.getZone();
//        java.util.TimeZone timeZone12 = dateTimeZone11.toTimeZone();
//        org.joda.time.Instant instant13 = new org.joda.time.Instant();
//        org.joda.time.Chronology chronology14 = instant13.getChronology();
//        java.lang.String str15 = instant13.toString();
//        int int16 = dateTimeZone11.getOffset((org.joda.time.ReadableInstant) instant13);
//        try {
//            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(0, 4, (int) '#', 2, 6, (int) (byte) -1, 59, dateTimeZone11);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2019-06-15T21:05:50.830Z" + "'", str15.equals("2019-06-15T21:05:50.830Z"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-25200000) + "'", int16 == (-25200000));
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer2, readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        java.lang.String str26 = property25.toString();
        boolean boolean27 = property25.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
        long long29 = property25.remainder();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[dayOfMonth]" + "'", str26.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 57599999L + "'", long29 == 57599999L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType24);
        long long28 = offsetDateTimeField13.getDifferenceAsLong((long) (short) 1, (long) 292278993);
        long long31 = offsetDateTimeField13.add((long) 86399, 0);
        int int33 = offsetDateTimeField13.getMinimumValue(292278122L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 86399L + "'", long31 == 86399L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 98 + "'", int33 == 98);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("24");
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (-1), chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.plusWeeks((int) (short) -1);
        int int7 = dateTime6.getDayOfMonth();
        org.joda.time.DateTime dateTime9 = dateTime6.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = copticChronology10.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField12 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField11);
        long long15 = delegatedDateTimeField12.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = delegatedDateTimeField12.getType();
        int int17 = dateTime6.get(dateTimeFieldType16);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long26 = fixedDateTimeZone22.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone22, readableInstant27);
        org.joda.time.DurationField durationField29 = gJChronology28.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType16, durationField29);
        try {
            int int31 = monthDay1.get(dateTimeFieldType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 24 + "'", int7 == 24);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 292278122L + "'", long15 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 999 + "'", int17 == 999);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-9L) + "'", long26 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField30);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusMillis(10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology(chronology16);
        org.joda.time.DateTime dateTime18 = dateTime5.withChronology(chronology16);
        org.joda.time.DateTime dateTime19 = dateTime5.withLaterOffsetAtOverlap();
        int int20 = dateTime19.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("millisOfSecond");
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField3 = copticChronology2.seconds();
        org.joda.time.DateTimeZone dateTimeZone4 = copticChronology2.getZone();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTimeZone4);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime5.withEra((int) (byte) 1);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (-1), chronology16);
        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks((int) (short) -1);
        org.joda.time.DateTime dateTime21 = dateTime17.plusWeeks(0);
        boolean boolean22 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime5.minusYears(0);
        org.joda.time.DateTime.Property property25 = dateTime24.millisOfDay();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), chronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property16 = dateTime15.year();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), chronology18);
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime19);
        int int21 = dateTime15.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime.Property property22 = dateTime19.yearOfCentury();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), chronology24);
        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property28 = dateTime27.year();
        int int29 = property28.getMaximumValue();
        java.util.Locale locale30 = null;
        java.lang.String str31 = property28.getAsText(locale30);
        org.joda.time.DateTime dateTime33 = property28.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay34 = dateTime33.toTimeOfDay();
        boolean boolean35 = dateTime19.isBefore((org.joda.time.ReadableInstant) dateTime33);
        int int36 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean38 = cachedDateTimeZone37.isFixed();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone39 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone37);
        long long41 = cachedDateTimeZone37.previousTransition((long) 1099);
        boolean boolean42 = cachedDateTimeZone37.isFixed();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 292278993 + "'", int29 == 292278993);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969" + "'", str31.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(timeOfDay34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1099L + "'", long41 == 1099L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), chronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property16 = dateTime15.year();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), chronology18);
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime19);
        int int21 = dateTime15.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime.Property property22 = dateTime19.yearOfCentury();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), chronology24);
        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property28 = dateTime27.year();
        int int29 = property28.getMaximumValue();
        java.util.Locale locale30 = null;
        java.lang.String str31 = property28.getAsText(locale30);
        org.joda.time.DateTime dateTime33 = property28.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay34 = dateTime33.toTimeOfDay();
        boolean boolean35 = dateTime19.isBefore((org.joda.time.ReadableInstant) dateTime33);
        int int36 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean38 = cachedDateTimeZone37.isFixed();
        boolean boolean39 = cachedDateTimeZone37.isFixed();
        org.joda.time.chrono.JulianChronology julianChronology40 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone37);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone37);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 292278993 + "'", int29 == 292278993);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969" + "'", str31.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(timeOfDay34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(julianChronology40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("millisOfSecond");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.DateTimeFormat.shortDate();
        java.lang.Integer int3 = dateTimeFormatter2.getPivotYear();
        boolean boolean4 = jodaTimePermission1.equals((java.lang.Object) dateTimeFormatter2);
        java.lang.String str5 = jodaTimePermission1.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"millisOfSecond\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"millisOfSecond\")"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        java.lang.String str3 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str3.equals("GregorianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean14 = fixedDateTimeZone5.isFixed();
        org.joda.time.Chronology chronology15 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DurationField durationField16 = julianChronology0.months();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology0.getZone();
        org.joda.time.Chronology chronology18 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        boolean boolean8 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay6.plus(readablePeriod9);
        int[] intArray12 = new int[] { 0 };
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay10, intArray12);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, (int) (byte) 100);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now();
        boolean boolean18 = monthDay16.isEqual((org.joda.time.ReadablePartial) monthDay17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay20 = monthDay16.plus(readablePeriod19);
        int int21 = offsetDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) monthDay16);
        long long23 = offsetDateTimeField15.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1099 + "'", int21 == 1099);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValue();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        int int9 = property5.getMinimumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property5.getFieldType();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-292275054) + "'", int9 == (-292275054));
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.DurationField durationField2 = copticChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.weekyear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
        java.lang.String str15 = property13.getAsString();
        org.joda.time.DurationField durationField16 = property13.getDurationField();
        org.joda.time.DateTime dateTime17 = property13.withMinimumValue();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (-1), chronology19);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime20.getZone();
        org.joda.time.LocalTime localTime23 = dateTime20.toLocalTime();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (-1), chronology25);
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTimeZone dateTimeZone28 = dateTime26.getZone();
        org.joda.time.LocalTime localTime29 = dateTime26.toLocalTime();
        boolean boolean30 = localTime23.isEqual((org.joda.time.ReadablePartial) localTime29);
        boolean boolean31 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime29);
        org.joda.time.DateTime dateTime32 = dateTime17.withFields((org.joda.time.ReadablePartial) localTime29);
        int int33 = dateTime32.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(localTime23);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(localTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 999 + "'", int33 == 999);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.year();
        try {
            long long10 = copticChronology0.getDateTimeMillis((int) (short) 10, 0, 18, (-25200000), (int) (byte) -1, 12, (-25199906));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology4.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        long long9 = delegatedDateTimeField6.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField6.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 86399);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology13.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        long long18 = delegatedDateTimeField15.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = delegatedDateTimeField15.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField12, dateTimeFieldType19);
        java.lang.String str22 = dividedDateTimeField12.getAsText(63696143087348L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 292278122L + "'", long9 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 292278122L + "'", long18 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
//        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), chronology12);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks((int) (short) -1);
//        org.joda.time.DateTime.Property property16 = dateTime15.year();
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), chronology18);
//        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime19);
//        int int21 = dateTime15.compareTo((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.DateTime.Property property22 = dateTime19.yearOfCentury();
//        org.joda.time.Chronology chronology24 = null;
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), chronology24);
//        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) (short) -1);
//        org.joda.time.DateTime.Property property28 = dateTime27.year();
//        int int29 = property28.getMaximumValue();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = property28.getAsText(locale30);
//        org.joda.time.DateTime dateTime33 = property28.setCopy(0);
//        org.joda.time.TimeOfDay timeOfDay34 = dateTime33.toTimeOfDay();
//        boolean boolean35 = dateTime19.isBefore((org.joda.time.ReadableInstant) dateTime33);
//        int int36 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
//        boolean boolean38 = cachedDateTimeZone37.isFixed();
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) cachedDateTimeZone37);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.hourMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = dateTimeFormatter40.withPivotYear(1);
//        org.joda.time.format.DateTimePrinter dateTimePrinter43 = dateTimeFormatter40.getPrinter();
//        org.joda.time.format.DateTimePrinter dateTimePrinter44 = dateTimeFormatter40.getPrinter();
//        java.lang.String str45 = dateTime39.toString(dateTimeFormatter40);
//        org.joda.time.DateTime dateTime47 = dateTime39.plusDays((-25200000));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 292278993 + "'", int29 == 292278993);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969" + "'", str31.equals("1969"));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(timeOfDay34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertNotNull(dateTimePrinter43);
//        org.junit.Assert.assertNotNull(dateTimePrinter44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "21:05" + "'", str45.equals("21:05"));
//        org.junit.Assert.assertNotNull(dateTime47);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(292278993);
        int int3 = dateTimeZone1.getOffsetFromLocal((long) 59);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 292278993 + "'", int3 == 292278993);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (-1), chronology19);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime20);
        int int22 = dateTime16.compareTo((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime.Property property23 = dateTime20.yearOfCentury();
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (-1), chronology25);
        org.joda.time.DateTime dateTime28 = dateTime26.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property29 = dateTime28.year();
        int int30 = property29.getMaximumValue();
        java.util.Locale locale31 = null;
        java.lang.String str32 = property29.getAsText(locale31);
        org.joda.time.DateTime dateTime34 = property29.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay35 = dateTime34.toTimeOfDay();
        boolean boolean36 = dateTime20.isBefore((org.joda.time.ReadableInstant) dateTime34);
        int int37 = fixedDateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone38 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean39 = cachedDateTimeZone38.isFixed();
        long long41 = cachedDateTimeZone38.previousTransition((long) 31);
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) 57599999, (org.joda.time.DateTimeZone) cachedDateTimeZone38);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 292278993 + "'", int30 == 292278993);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1969" + "'", str32.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(timeOfDay35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 10 + "'", int37 == 10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 31L + "'", long41 == 31L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        java.lang.String str26 = property25.toString();
        java.lang.String str27 = property25.getAsText();
        int int28 = property25.getMinimumValueOverall();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) (-1), chronology30);
        org.joda.time.ReadableDuration readableDuration32 = null;
        org.joda.time.DateTime dateTime34 = dateTime31.withDurationAdded(readableDuration32, 0);
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (-1), chronology36);
        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTimeZone dateTimeZone39 = dateTime37.getZone();
        java.util.TimeZone timeZone40 = dateTimeZone39.toTimeZone();
        org.joda.time.DateTime dateTime41 = dateTime34.toDateTime(dateTimeZone39);
        org.joda.time.DateTime dateTime43 = dateTime34.withEra((int) (byte) 1);
        int int44 = property25.compareTo((org.joda.time.ReadableInstant) dateTime43);
        org.joda.time.DateTime.Property property45 = dateTime43.dayOfMonth();
        int int46 = property45.get();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[dayOfMonth]" + "'", str26.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "24" + "'", str27.equals("24"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(timeZone40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 31 + "'", int46 == 31);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType24);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone30 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long34 = fixedDateTimeZone30.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone30, readableInstant35);
        org.joda.time.MonthDay monthDay37 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone30);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone42 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int44 = fixedDateTimeZone42.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone42);
        int int46 = monthDay37.compareTo((org.joda.time.ReadablePartial) monthDay45);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone51 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long55 = fixedDateTimeZone51.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone51, readableInstant56);
        org.joda.time.MonthDay monthDay58 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone51);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone63 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int65 = fixedDateTimeZone63.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay66 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone63);
        int int67 = monthDay58.compareTo((org.joda.time.ReadablePartial) monthDay66);
        org.joda.time.MonthDay monthDay69 = monthDay58.minusMonths(0);
        org.joda.time.MonthDay monthDay71 = monthDay69.plusMonths((int) (short) 0);
        int int72 = monthDay69.size();
        boolean boolean73 = monthDay37.isBefore((org.joda.time.ReadablePartial) monthDay69);
        int int74 = delegatedDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) monthDay69);
        org.joda.time.DateTimeField dateTimeField75 = delegatedDateTimeField25.getWrappedField();
        long long78 = delegatedDateTimeField25.add(1L, (long) '#');
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-9L) + "'", long34 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 10 + "'", int44 == 10);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-9L) + "'", long55 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(monthDay58);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 10 + "'", int65 == 10);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(monthDay69);
        org.junit.Assert.assertNotNull(monthDay71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 292279090 + "'", int74 == 292279090);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 1104537600001L + "'", long78 == 1104537600001L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime12 = dateTime8.minusHours(10);
        org.joda.time.DateTime.Property property13 = dateTime8.millisOfSecond();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (-1), chronology15);
        org.joda.time.DateTime dateTime18 = dateTime16.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property19 = dateTime18.year();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (-1), chronology21);
        org.joda.time.Chronology chronology23 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime22);
        int int24 = dateTime18.compareTo((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime26 = dateTime22.minusHours(10);
        org.joda.time.DateTime dateTime28 = dateTime26.plusMillis((int) '#');
        org.joda.time.DateTime.Property property29 = dateTime28.era();
        boolean boolean30 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime28);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValue();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        org.joda.time.DateTime dateTime10 = property5.setCopy(0);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear(0);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), chronology14);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
        org.joda.time.LocalTime localTime18 = dateTime15.toLocalTime();
        org.joda.time.MutableDateTime mutableDateTime19 = dateTime15.toMutableDateTime();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime10, (org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime10.minus(readableDuration21);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(localTime18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
        org.joda.time.DateTime dateTime15 = property13.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusMillis(10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology(chronology16);
        org.joda.time.DateTime dateTime18 = dateTime5.withChronology(chronology16);
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.Chronology chronology20 = dateTime18.getChronology();
        org.joda.time.DateTime dateTime21 = dateTime18.toDateTimeISO();
        boolean boolean23 = dateTime21.isAfter((long) (short) 0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int11 = fixedDateTimeZone9.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str13 = fixedDateTimeZone9.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        long long17 = fixedDateTimeZone9.adjustOffset((long) 401135, false);
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(999, 1, 292278993, (int) (short) 0, (-98), (org.joda.time.DateTimeZone) fixedDateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -98 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 401135L + "'", long17 == 401135L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime4.dayOfYear();
        int int12 = property11.get();
        org.joda.time.DurationField durationField13 = property11.getLeapDurationField();
        org.joda.time.DateTime dateTime14 = property11.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 358 + "'", int12 == 358);
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime2.getZone();
        org.joda.time.DateTime dateTime6 = dateTime2.minusYears(0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant0.plus(readableDuration2);
        org.joda.time.DateTime dateTime4 = instant0.toDateTime();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant0.plus(readableDuration2);
        org.joda.time.Chronology chronology4 = instant3.getChronology();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType24);
        int int27 = offsetDateTimeField13.get(1560632677806L);
        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay((long) (short) 10);
        org.joda.time.MonthDay.Property property30 = monthDay29.dayOfMonth();
        int int31 = offsetDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) monthDay29);
        long long34 = offsetDateTimeField13.add((long) (byte) 10, (long) 18);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2116 + "'", int27 == 2116);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 292279090 + "'", int31 == 292279090);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 567993600010L + "'", long34 == 567993600010L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimePrinter1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValueOverall();
        org.joda.time.DateTime dateTime7 = property5.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        org.joda.time.DateTime dateTime11 = dateTime7.minusDays(98);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DurationField durationField24 = gJChronology23.millis();
        org.joda.time.DurationField durationField25 = gJChronology23.centuries();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology23.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField26, (-1));
        long long31 = skipDateTimeField28.addWrapField(10990L, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone36 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long40 = fixedDateTimeZone36.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant41 = null;
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone36, readableInstant41);
        org.joda.time.Chronology chronology44 = null;
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) (-1), chronology44);
        org.joda.time.DateTime dateTime47 = dateTime45.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property48 = dateTime47.year();
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (-1), chronology50);
        org.joda.time.Chronology chronology52 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime51);
        int int53 = dateTime47.compareTo((org.joda.time.ReadableInstant) dateTime51);
        org.joda.time.DateTime.Property property54 = dateTime51.yearOfCentury();
        org.joda.time.Chronology chronology56 = null;
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) (-1), chronology56);
        org.joda.time.DateTime dateTime59 = dateTime57.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property60 = dateTime59.year();
        int int61 = property60.getMaximumValue();
        java.util.Locale locale62 = null;
        java.lang.String str63 = property60.getAsText(locale62);
        org.joda.time.DateTime dateTime65 = property60.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay66 = dateTime65.toTimeOfDay();
        boolean boolean67 = dateTime51.isBefore((org.joda.time.ReadableInstant) dateTime65);
        int int68 = fixedDateTimeZone36.getOffset((org.joda.time.ReadableInstant) dateTime65);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone69 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone36);
        boolean boolean70 = cachedDateTimeZone69.isFixed();
        org.joda.time.DateTime dateTime71 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) cachedDateTimeZone69);
        org.joda.time.Chronology chronology73 = null;
        org.joda.time.DateTime dateTime74 = new org.joda.time.DateTime((long) (-1), chronology73);
        org.joda.time.DateTime dateTime76 = dateTime74.plusWeeks((int) (short) -1);
        int int77 = dateTime76.getDayOfMonth();
        org.joda.time.DateTime dateTime79 = dateTime76.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology80 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField81 = copticChronology80.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField82 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField81);
        long long85 = delegatedDateTimeField82.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType86 = delegatedDateTimeField82.getType();
        int int87 = dateTime76.get(dateTimeFieldType86);
        boolean boolean88 = dateTime71.equals((java.lang.Object) dateTimeFieldType86);
        java.lang.Number number89 = null;
        java.lang.Number number90 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException92 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType86, number89, number90, (java.lang.Number) 10.0d);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField93 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipDateTimeField28, dateTimeFieldType86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10990L + "'", long31 == 10990L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-9L) + "'", long40 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 292278993 + "'", int61 == 292278993);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "1969" + "'", str63.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(timeOfDay66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 10 + "'", int68 == 10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNotNull(dateTime76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 24 + "'", int77 == 24);
        org.junit.Assert.assertNotNull(dateTime79);
        org.junit.Assert.assertNotNull(copticChronology80);
        org.junit.Assert.assertNotNull(dateTimeField81);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 292278122L + "'", long85 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 999 + "'", int87 == 999);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        int int12 = dateTime8.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime8.minusWeeks(0);
        org.joda.time.DateTime dateTime16 = dateTime14.plus(1560632677806L);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), chronology18);
        org.joda.time.DateTime dateTime21 = dateTime19.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property22 = dateTime21.year();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), chronology24);
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime25);
        int int27 = dateTime21.compareTo((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime.Property property28 = dateTime25.yearOfCentury();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) (-1), chronology30);
        org.joda.time.DateTime dateTime33 = dateTime31.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property34 = dateTime33.year();
        int int35 = property34.getMaximumValue();
        java.util.Locale locale36 = null;
        java.lang.String str37 = property34.getAsText(locale36);
        org.joda.time.DateTime dateTime39 = property34.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay40 = dateTime39.toTimeOfDay();
        boolean boolean41 = dateTime25.isBefore((org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.DateTime.Property property42 = dateTime39.dayOfMonth();
        int int43 = dateTime39.getYearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.DateTime dateTime45 = dateTime39.plus(readablePeriod44);
        boolean boolean46 = dateTime16.isAfter((org.joda.time.ReadableInstant) dateTime45);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 292278993 + "'", int35 == 292278993);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1969" + "'", str37.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(timeOfDay40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfCentury();
        boolean boolean28 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long37 = fixedDateTimeZone33.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone33, readableInstant38);
        org.joda.time.MonthDay monthDay40 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.DateTime dateTime41 = dateTime5.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.DateTime.Property property42 = dateTime41.millisOfSecond();
        try {
            org.joda.time.DateTime dateTime44 = dateTime41.withSecondOfMinute((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-9L) + "'", long37 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        java.lang.String str29 = unsupportedDateTimeField28.toString();
        try {
            int int31 = unsupportedDateTimeField28.getMaximumValue((long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDateTimeField" + "'", str29.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        java.lang.String str29 = unsupportedDateTimeField28.toString();
        try {
            int int31 = unsupportedDateTimeField28.getLeapAmount((-27471802020167L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDateTimeField" + "'", str29.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        java.lang.Object obj22 = null;
        boolean boolean23 = fixedDateTimeZone15.equals(obj22);
        long long25 = fixedDateTimeZone15.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology26 = gJChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long35 = fixedDateTimeZone31.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone31, readableInstant36);
        org.joda.time.DurationField durationField38 = gJChronology37.millis();
        org.joda.time.DurationField durationField39 = gJChronology37.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone44 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long48 = fixedDateTimeZone44.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone44, readableInstant49);
        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) 'a');
        long long55 = offsetDateTimeField53.roundCeiling(10L);
        long long57 = offsetDateTimeField53.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField59 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology37, (org.joda.time.DateTimeField) offsetDateTimeField53, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField60 = gJChronology37.monthOfYear();
        boolean boolean61 = fixedDateTimeZone15.equals((java.lang.Object) gJChronology37);
        org.joda.time.DateTimeZone dateTimeZone62 = gJChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField63 = gJChronology37.year();
        org.joda.time.Chronology chronology64 = gJChronology37.withUTC();
        org.joda.time.DateTimeField dateTimeField65 = gJChronology37.minuteOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone70 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long74 = fixedDateTimeZone70.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant75 = null;
        org.joda.time.chrono.GJChronology gJChronology76 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone70, readableInstant75);
        org.joda.time.MonthDay monthDay77 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone70);
        org.joda.time.MonthDay monthDay78 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone70);
        org.joda.time.chrono.ZonedChronology zonedChronology79 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology37, (org.joda.time.DateTimeZone) fixedDateTimeZone70);
        try {
            long long84 = zonedChronology79.getDateTimeMillis(0, 166, (int) (byte) 100, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31556476799900L) + "'", long25 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-9L) + "'", long35 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-9L) + "'", long48 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 31535999990L + "'", long55 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 31535999990L + "'", long57 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(chronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-9L) + "'", long74 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology76);
        org.junit.Assert.assertNotNull(monthDay77);
        org.junit.Assert.assertNotNull(zonedChronology79);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int18 = fixedDateTimeZone16.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        int int20 = monthDay11.compareTo((org.joda.time.ReadablePartial) monthDay19);
        org.joda.time.MonthDay monthDay22 = monthDay11.minusMonths(0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long31 = fixedDateTimeZone27.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone27, readableInstant32);
        org.joda.time.DurationField durationField34 = gJChronology33.millis();
        org.joda.time.DurationField durationField35 = gJChronology33.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone40 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long44 = fixedDateTimeZone40.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone40, readableInstant45);
        org.joda.time.DateTimeField dateTimeField47 = gJChronology46.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField47, (int) 'a');
        long long51 = offsetDateTimeField49.roundCeiling(10L);
        long long53 = offsetDateTimeField49.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField55 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology33, (org.joda.time.DateTimeField) offsetDateTimeField49, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField56 = skipUndoDateTimeField55.getWrappedField();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone61 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long65 = fixedDateTimeZone61.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant66 = null;
        org.joda.time.chrono.GJChronology gJChronology67 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone61, readableInstant66);
        org.joda.time.MonthDay monthDay68 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone61);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone73 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int75 = fixedDateTimeZone73.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay76 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone73);
        int int77 = monthDay68.compareTo((org.joda.time.ReadablePartial) monthDay76);
        java.util.Locale locale79 = null;
        java.lang.String str80 = skipUndoDateTimeField55.getAsShortText((org.joda.time.ReadablePartial) monthDay68, 0, locale79);
        org.joda.time.MonthDay monthDay82 = monthDay68.minusDays(359);
        org.joda.time.ReadablePeriod readablePeriod83 = null;
        org.joda.time.MonthDay monthDay84 = monthDay68.minus(readablePeriod83);
        org.joda.time.MonthDay monthDay86 = monthDay84.minusDays(2);
        boolean boolean87 = monthDay22.isAfter((org.joda.time.ReadablePartial) monthDay84);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-9L) + "'", long31 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(durationField34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-9L) + "'", long44 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 31535999990L + "'", long51 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 31535999990L + "'", long53 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-9L) + "'", long65 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology67);
        org.junit.Assert.assertNotNull(monthDay68);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 10 + "'", int75 == 10);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "0" + "'", str80.equals("0"));
        org.junit.Assert.assertNotNull(monthDay82);
        org.junit.Assert.assertNotNull(monthDay84);
        org.junit.Assert.assertNotNull(monthDay86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (-1), chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property15 = dateTime14.year();
        int int16 = property15.getMaximumValueOverall();
        org.joda.time.DateTime dateTime17 = property15.roundCeilingCopy();
        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfDay((int) ' ');
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTimeZone dateTimeZone21 = gJChronology20.getZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 292278993 + "'", int16 == 292278993);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        long long31 = unsupportedDateTimeField28.add((long) 0, 0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = unsupportedDateTimeField28.getType();
        java.util.Locale locale34 = null;
        try {
            java.lang.String str35 = unsupportedDateTimeField28.getAsShortText(530L, locale34);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfCentury();
        boolean boolean28 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.TimeOfDay timeOfDay29 = dateTime24.toTimeOfDay();
        org.joda.time.DateTime dateTime31 = dateTime24.withWeekyear(0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(timeOfDay29);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
        java.lang.String str15 = property13.getAsString();
        org.joda.time.DurationField durationField16 = property13.getDurationField();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), chronology18);
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime22 = dateTime19.withDurationAdded(readableDuration20, 0);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), chronology24);
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime25.getZone();
        java.util.TimeZone timeZone28 = dateTimeZone27.toTimeZone();
        org.joda.time.DateTime dateTime29 = dateTime22.toDateTime(dateTimeZone27);
        org.joda.time.DateTime.Property property30 = dateTime22.yearOfEra();
        org.joda.time.DurationField durationField31 = property30.getRangeDurationField();
        java.lang.String str32 = property30.getAsString();
        org.joda.time.DurationField durationField33 = property30.getDurationField();
        boolean boolean34 = property13.equals((java.lang.Object) durationField33);
        org.joda.time.DateTime dateTime35 = property13.roundHalfFloorCopy();
        int int36 = property13.getMinimumValueOverall();
        org.joda.time.DateTime dateTime37 = property13.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNull(durationField31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1969" + "'", str32.equals("1969"));
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(dateTime37);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        java.lang.Object obj11 = null;
        boolean boolean12 = fixedDateTimeZone4.equals(obj11);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), chronology14);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, 0);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (-1), chronology20);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime21.getZone();
        java.util.TimeZone timeZone24 = dateTimeZone23.toTimeZone();
        org.joda.time.DateTime dateTime25 = dateTime18.toDateTime(dateTimeZone23);
        org.joda.time.DateTime.Property property26 = dateTime18.yearOfEra();
        org.joda.time.DateTime dateTime28 = dateTime18.minusMillis(10);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) dateTime18);
        long long31 = fixedDateTimeZone4.previousTransition((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.getMinimumValue((long) (byte) 10);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField2.getAsShortText((int) (byte) 0, locale6);
        long long9 = delegatedDateTimeField2.roundHalfFloor((long) 6);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 6L + "'", long9 == 6L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime26 = dateTime8.withMinuteOfHour(0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        java.lang.String str29 = unsupportedDateTimeField28.toString();
        try {
            long long32 = unsupportedDateTimeField28.set(3068L, "1969-12-31T15:59:59.999-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDateTimeField" + "'", str29.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundCeiling(52L);
        try {
            long long24 = offsetDateTimeField13.set((long) 366, "4");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for yearOfEra must be in the range [98,292279090]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 31535999990L + "'", long21 == 31535999990L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        boolean boolean8 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay6.plus(readablePeriod9);
        int[] intArray12 = new int[] { 0 };
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay10, intArray12);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, (int) (byte) 100);
        long long17 = delegatedDateTimeField2.roundCeiling(52L);
        java.lang.String str18 = delegatedDateTimeField2.getName();
        int int19 = delegatedDateTimeField2.getMinimumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "millisOfSecond" + "'", str18.equals("millisOfSecond"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now();
        boolean boolean2 = monthDay0.isEqual((org.joda.time.ReadablePartial) monthDay1);
        org.joda.time.MonthDay.Property property3 = monthDay1.dayOfMonth();
        try {
            org.joda.time.MonthDay monthDay5 = monthDay1.withMonthOfYear(58);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds((int) (short) 1);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (-1), chronology16);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded(readableDuration18, 0);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (-1), chronology22);
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTimeZone dateTimeZone25 = dateTime23.getZone();
        java.util.TimeZone timeZone26 = dateTimeZone25.toTimeZone();
        org.joda.time.DateTime dateTime27 = dateTime20.toDateTime(dateTimeZone25);
        org.joda.time.DateTime.Property property28 = dateTime20.yearOfEra();
        org.joda.time.DateTime dateTime30 = dateTime20.minusDays(0);
        org.joda.time.DateTime dateTime32 = dateTime30.minusHours((int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = copticChronology33.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34);
        long long38 = delegatedDateTimeField35.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = delegatedDateTimeField35.getType();
        org.joda.time.DateTime.Property property40 = dateTime30.property(dateTimeFieldType39);
        org.joda.time.DateTime.Property property41 = dateTime12.property(dateTimeFieldType39);
        java.lang.String str42 = property41.getName();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 292278122L + "'", long38 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "millisOfSecond" + "'", str42.equals("millisOfSecond"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.append(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        org.joda.time.DurationField durationField16 = property15.getRangeDurationField();
        int int17 = property15.getMinimumValueOverall();
        org.joda.time.DateTimeField dateTimeField18 = property15.getField();
        int int19 = property15.get();
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay21 = org.joda.time.MonthDay.now();
        boolean boolean22 = monthDay20.isEqual((org.joda.time.ReadablePartial) monthDay21);
        org.joda.time.MonthDay monthDay24 = monthDay20.minusDays((int) (byte) 0);
        org.joda.time.DateTimeField[] dateTimeFieldArray25 = monthDay20.getFields();
        int int26 = monthDay20.getMonthOfYear();
        int int27 = property15.compareTo((org.joda.time.ReadablePartial) monthDay20);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(dateTimeFieldArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValue();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        org.joda.time.DateTime dateTime10 = property5.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay11 = dateTime10.toTimeOfDay();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime14.getZone();
        org.joda.time.LocalTime localTime17 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        org.joda.time.DateTime.Property property19 = dateTime18.hourOfDay();
        java.lang.String str20 = property19.getName();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(timeOfDay11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hourOfDay" + "'", str20.equals("hourOfDay"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "UTC");
        java.lang.String str18 = illegalFieldValueException17.toString();
        java.lang.Number number19 = illegalFieldValueException17.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"UTC\" for millisOfSecond is not supported" + "'", str18.equals("org.joda.time.IllegalFieldValueException: Value \"UTC\" for millisOfSecond is not supported"));
        org.junit.Assert.assertNull(number19);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = gJChronology10.monthOfYear();
        org.joda.time.Instant instant34 = gJChronology10.getGregorianCutover();
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36);
        java.lang.String str39 = delegatedDateTimeField37.getAsText((long) (byte) 10);
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField37.getAsText(0L, locale41);
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) delegatedDateTimeField37, 358);
        long long47 = skipDateTimeField44.set(1560632687348L, 999);
        long long50 = skipDateTimeField44.set((long) 3, 0);
        org.joda.time.DateTimeField dateTimeField51 = skipDateTimeField44.getWrappedField();
        org.joda.time.DurationField durationField52 = skipDateTimeField44.getLeapDurationField();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10" + "'", str39.equals("10"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0" + "'", str42.equals("0"));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560632687999L + "'", long47 == 1560632687999L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1L + "'", long50 == 1L);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNull(durationField52);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        java.lang.String str12 = gJChronology10.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int19 = fixedDateTimeZone17.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        int[] intArray22 = gJChronology10.get((org.joda.time.ReadablePartial) monthDay20, 100L);
        org.joda.time.DateTimeField dateTimeField23 = gJChronology10.monthOfYear();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology10.minuteOfHour();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology10, dateTimeZone25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GJChronology[]" + "'", str12.equals("GJChronology[]"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
//        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
//        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
//        boolean boolean8 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay7);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.MonthDay monthDay10 = monthDay6.plus(readablePeriod9);
//        int[] intArray12 = new int[] { 0 };
//        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay10, intArray12);
//        java.lang.String str14 = monthDay10.toString();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
//        org.junit.Assert.assertNotNull(monthDay6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//        org.junit.Assert.assertNotNull(monthDay10);
//        org.junit.Assert.assertNotNull(intArray12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "--06-15" + "'", str14.equals("--06-15"));
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), chronology2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (-1), chronology8);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        int int11 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfCentury();
        org.joda.time.DateTime dateTime14 = dateTime9.plusMillis((int) (byte) 1);
        java.lang.String str15 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.withDurationAdded(readableDuration19, 0);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime24.getZone();
        java.util.TimeZone timeZone27 = dateTimeZone26.toTimeZone();
        org.joda.time.DateTime dateTime28 = dateTime21.toDateTime(dateTimeZone26);
        org.joda.time.DateTime.Property property29 = dateTime21.yearOfEra();
        org.joda.time.DateTime dateTime31 = dateTime21.minusDays(0);
        org.joda.time.DateTime dateTime33 = dateTime31.minusHours((int) (byte) 100);
        int int34 = dateTime14.compareTo((org.joda.time.ReadableInstant) dateTime33);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970W013" + "'", str15.equals("1970W013"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.DurationField durationField2 = copticChronology0.halfdays();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = copticChronology0.add(readablePeriod3, (long) (-25199906), 9);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology0.clockhourOfDay();
        int int8 = copticChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-25199906L) + "'", long6 == (-25199906L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfCentury();
        boolean boolean28 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime24);
        java.util.GregorianCalendar gregorianCalendar29 = dateTime24.toGregorianCalendar();
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar29);
        org.joda.time.MonthDay monthDay31 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar29);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        boolean boolean34 = monthDay32.isEqual((org.joda.time.ReadablePartial) monthDay33);
        org.joda.time.MonthDay monthDay36 = monthDay32.minusDays((int) (byte) 0);
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.MonthDay monthDay38 = monthDay32.plus(readablePeriod37);
        boolean boolean39 = monthDay31.isBefore((org.joda.time.ReadablePartial) monthDay32);
        int[] intArray40 = monthDay32.getValues();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar29);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(intArray40);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMonthOfYear(359);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMillisOfSecond(1099);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendTimeZoneOffset("GregorianChronology[UTC]", "hi!", true, (int) (byte) 10, 98);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendMonthOfYearText();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.year();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int29 = fixedDateTimeZone27.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone27);
        int int31 = monthDay22.compareTo((org.joda.time.ReadablePartial) monthDay30);
        org.joda.time.MonthDay monthDay33 = monthDay22.minusMonths(0);
        int[] intArray35 = buddhistChronology9.get((org.joda.time.ReadablePartial) monthDay33, (long) 89);
        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology9.halfdayOfDay();
        org.joda.time.Chronology chronology37 = buddhistChronology9.withUTC();
        org.joda.time.chrono.CopticChronology copticChronology38 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = copticChronology38.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField39);
        java.lang.String str42 = delegatedDateTimeField40.getAsText((long) (byte) 10);
        org.joda.time.DateTimeField dateTimeField43 = delegatedDateTimeField40.getWrappedField();
        long long45 = delegatedDateTimeField40.roundFloor((long) (byte) 10);
        boolean boolean46 = buddhistChronology9.equals((java.lang.Object) (byte) 10);
        java.lang.Object obj47 = null;
        boolean boolean48 = buddhistChronology9.equals(obj47);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(copticChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "10" + "'", str42.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("2019-06-15T21:05:06.830Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        org.joda.time.DurationField durationField16 = property15.getRangeDurationField();
        int int17 = property15.getMinimumValueOverall();
        org.joda.time.DateTimeField dateTimeField18 = property15.getField();
        int int19 = property15.get();
        org.joda.time.DurationField durationField20 = property15.getDurationField();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        int int16 = offsetDateTimeField13.getMinimumValue();
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField13.getAsText((-8L), locale18);
        boolean boolean21 = offsetDateTimeField13.isLeap((-84243599995L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 98 + "'", int16 == 98);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2067" + "'", str19.equals("2067"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (-1), chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.year();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), chronology9);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        int int12 = dateTime6.compareTo((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        int int14 = dateTime10.getSecondOfMinute();
        org.joda.time.DateTime dateTime16 = dateTime10.minusSeconds((-1));
        boolean boolean17 = gregorianChronology1.equals((java.lang.Object) dateTime10);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 10, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology1.getZone();
        try {
            org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone19, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeZone19);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DurationField durationField24 = gJChronology23.millis();
        org.joda.time.DurationField durationField25 = gJChronology23.centuries();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology23.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField26, (-1));
        boolean boolean30 = skipDateTimeField28.isLeap((long) 2067);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        java.lang.String str29 = unsupportedDateTimeField28.toString();
        try {
            int int31 = unsupportedDateTimeField28.getLeapAmount(52L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDateTimeField" + "'", str29.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime2.getZone();
        org.joda.time.LocalTime localTime5 = dateTime2.toLocalTime();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        org.joda.time.LocalTime localTime11 = dateTime8.toLocalTime();
        boolean boolean12 = localTime5.isEqual((org.joda.time.ReadablePartial) localTime11);
        boolean boolean13 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime11);
        boolean boolean14 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime11);
        boolean boolean15 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime11);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        java.lang.Object obj22 = null;
        boolean boolean23 = fixedDateTimeZone15.equals(obj22);
        long long25 = fixedDateTimeZone15.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology26 = gJChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        java.lang.String str27 = fixedDateTimeZone15.getID();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31556476799900L) + "'", long25 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
        org.joda.time.Interval interval15 = property13.toInterval();
        int int16 = property13.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(interval15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (-1), chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property15 = dateTime14.year();
        int int16 = property15.getMaximumValueOverall();
        org.joda.time.DateTime dateTime17 = property15.roundCeilingCopy();
        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfDay((int) ' ');
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTimeField dateTimeField21 = gJChronology20.halfdayOfDay();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 292278993 + "'", int16 == 292278993);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DurationField durationField24 = gJChronology23.millis();
        org.joda.time.DurationField durationField25 = gJChronology23.centuries();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology23.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField26, (-1));
        int int30 = skipDateTimeField28.get((long) 100);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long22 = fixedDateTimeZone18.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant23 = null;
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone18, readableInstant23);
        org.joda.time.MonthDay monthDay25 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone30 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int32 = fixedDateTimeZone30.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone30);
        int int34 = monthDay25.compareTo((org.joda.time.ReadablePartial) monthDay33);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone39 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long43 = fixedDateTimeZone39.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant44 = null;
        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone39, readableInstant44);
        org.joda.time.MonthDay monthDay46 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone39);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone51 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int53 = fixedDateTimeZone51.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay54 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone51);
        int int55 = monthDay46.compareTo((org.joda.time.ReadablePartial) monthDay54);
        org.joda.time.MonthDay monthDay57 = monthDay46.minusMonths(0);
        org.joda.time.MonthDay monthDay59 = monthDay57.plusMonths((int) (short) 0);
        int int60 = monthDay57.size();
        boolean boolean61 = monthDay25.isBefore((org.joda.time.ReadablePartial) monthDay57);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone67 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long71 = fixedDateTimeZone67.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant72 = null;
        org.joda.time.chrono.GJChronology gJChronology73 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone67, readableInstant72);
        org.joda.time.DateTimeField dateTimeField74 = gJChronology73.yearOfEra();
        java.lang.String str75 = gJChronology73.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone80 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int82 = fixedDateTimeZone80.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay83 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone80);
        int[] intArray85 = gJChronology73.get((org.joda.time.ReadablePartial) monthDay83, 100L);
        try {
            int[] intArray87 = offsetDateTimeField13.add((org.joda.time.ReadablePartial) monthDay57, 97, intArray85, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-9L) + "'", long22 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-9L) + "'", long43 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology45);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 10 + "'", int53 == 10);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertNotNull(monthDay59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2 + "'", int60 == 2);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + (-9L) + "'", long71 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology73);
        org.junit.Assert.assertNotNull(dateTimeField74);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "GJChronology[]" + "'", str75.equals("GJChronology[]"));
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 10 + "'", int82 == 10);
        org.junit.Assert.assertNotNull(intArray85);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime5.withEra((int) (byte) 1);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (-1), chronology16);
        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks((int) (short) -1);
        org.joda.time.DateTime dateTime21 = dateTime17.plusWeeks(0);
        boolean boolean22 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology23.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
        java.lang.String str27 = delegatedDateTimeField25.getAsText((long) (byte) 10);
        java.util.Locale locale29 = null;
        java.lang.String str30 = delegatedDateTimeField25.getAsText(0L, locale29);
        long long33 = delegatedDateTimeField25.add((long) 1, (-9L));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long42 = fixedDateTimeZone38.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone38, readableInstant43);
        org.joda.time.MonthDay monthDay45 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone38);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone50 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int52 = fixedDateTimeZone50.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay53 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone50);
        int int54 = monthDay45.compareTo((org.joda.time.ReadablePartial) monthDay53);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone59 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int61 = fixedDateTimeZone59.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str63 = fixedDateTimeZone59.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology64 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone59);
        org.joda.time.DateTimeField dateTimeField65 = buddhistChronology64.year();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone70 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long74 = fixedDateTimeZone70.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant75 = null;
        org.joda.time.chrono.GJChronology gJChronology76 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone70, readableInstant75);
        org.joda.time.MonthDay monthDay77 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone70);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone82 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int84 = fixedDateTimeZone82.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay85 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone82);
        int int86 = monthDay77.compareTo((org.joda.time.ReadablePartial) monthDay85);
        org.joda.time.MonthDay monthDay88 = monthDay77.minusMonths(0);
        int[] intArray90 = buddhistChronology64.get((org.joda.time.ReadablePartial) monthDay88, (long) 89);
        int int91 = delegatedDateTimeField25.getMinimumValue((org.joda.time.ReadablePartial) monthDay45, intArray90);
        int int92 = dateTime5.get((org.joda.time.DateTimeField) delegatedDateTimeField25);
        java.util.Locale locale94 = null;
        java.lang.String str95 = delegatedDateTimeField25.getAsShortText(59, locale94);
        long long98 = delegatedDateTimeField25.add((-3599999L), 1099);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "10" + "'", str27.equals("10"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0" + "'", str30.equals("0"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-8L) + "'", long33 == (-8L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-9L) + "'", long42 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-9L) + "'", long74 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology76);
        org.junit.Assert.assertNotNull(monthDay77);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 10 + "'", int84 == 10);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertNotNull(monthDay88);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 999 + "'", int92 == 999);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "59" + "'", str95.equals("59"));
        org.junit.Assert.assertTrue("'" + long98 + "' != '" + (-3598900L) + "'", long98 == (-3598900L));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (short) 10);
        org.joda.time.MonthDay.Property property2 = monthDay1.dayOfMonth();
        java.lang.String str3 = property2.getName();
        int int4 = property2.getMinimumValue();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfMonth" + "'", str3.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        int int16 = offsetDateTimeField13.getMinimumValue();
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField13.getAsText((-8L), locale18);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (-1), chronology21);
        org.joda.time.DateTime dateTime24 = dateTime22.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property25 = dateTime24.year();
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (-1), chronology27);
        org.joda.time.Chronology chronology29 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime28);
        int int30 = dateTime24.compareTo((org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.DateTime.Property property31 = dateTime28.yearOfCentury();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (-1), chronology33);
        org.joda.time.DateTime dateTime36 = dateTime34.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property37 = dateTime36.year();
        int int38 = property37.getMaximumValue();
        java.util.Locale locale39 = null;
        java.lang.String str40 = property37.getAsText(locale39);
        org.joda.time.DateTime dateTime42 = property37.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay43 = dateTime42.toTimeOfDay();
        boolean boolean44 = dateTime28.isBefore((org.joda.time.ReadableInstant) dateTime42);
        org.joda.time.DateTime.Property property45 = dateTime42.dayOfMonth();
        java.lang.String str46 = property45.toString();
        boolean boolean47 = property45.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = property45.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField49 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType48);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType48, (int) (byte) 0, (int) '4', 57599999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [52,57599999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 98 + "'", int16 == 98);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2067" + "'", str19.equals("2067"));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 292278993 + "'", int38 == 292278993);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1969" + "'", str40.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(timeOfDay43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Property[dayOfMonth]" + "'", str46.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        java.lang.Object obj11 = null;
        boolean boolean12 = fixedDateTimeZone4.equals(obj11);
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int15 = fixedDateTimeZone4.getStandardOffset((long) 5);
        java.lang.String str16 = fixedDateTimeZone4.getID();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfHour((int) (short) 100, 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMinuteOfDay(12);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long18 = fixedDateTimeZone14.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone14, readableInstant19);
        org.joda.time.DateTimeField dateTimeField21 = gJChronology20.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField23 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, (int) 'a');
        long long25 = offsetDateTimeField23.roundCeiling(10L);
        int int26 = offsetDateTimeField23.getMinimumValue();
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField23.getAsText((-8L), locale28);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (-1), chronology31);
        org.joda.time.DateTime dateTime34 = dateTime32.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property35 = dateTime34.year();
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (-1), chronology37);
        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime38);
        int int40 = dateTime34.compareTo((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTime.Property property41 = dateTime38.yearOfCentury();
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (-1), chronology43);
        org.joda.time.DateTime dateTime46 = dateTime44.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property47 = dateTime46.year();
        int int48 = property47.getMaximumValue();
        java.util.Locale locale49 = null;
        java.lang.String str50 = property47.getAsText(locale49);
        org.joda.time.DateTime dateTime52 = property47.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay53 = dateTime52.toTimeOfDay();
        boolean boolean54 = dateTime38.isBefore((org.joda.time.ReadableInstant) dateTime52);
        org.joda.time.DateTime.Property property55 = dateTime52.dayOfMonth();
        java.lang.String str56 = property55.toString();
        boolean boolean57 = property55.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = property55.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField59 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField23, dateTimeFieldType58);
        org.joda.time.DateTimeFieldType dateTimeFieldType60 = offsetDateTimeField23.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException63 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType60, (java.lang.Number) (-98), "2066");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder7.appendFixedDecimal(dateTimeFieldType60, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal number of digits: -100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-9L) + "'", long18 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 31535999990L + "'", long25 == 31535999990L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 98 + "'", int26 == 98);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2067" + "'", str29.equals("2067"));
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 292278993 + "'", int48 == 292278993);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "1969" + "'", str50.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(timeOfDay53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(property55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Property[dayOfMonth]" + "'", str56.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertNotNull(dateTimeFieldType60);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), chronology2);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10, chronology4);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.DateTime dateTime9 = dateTime5.withFieldAdded(durationFieldType7, 365);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(localTime6);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        int int12 = dateTime8.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime8.minusWeeks(0);
        org.joda.time.DateTime dateTime16 = dateTime14.plus(1560632677806L);
        org.joda.time.DateMidnight dateMidnight17 = dateTime14.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateMidnight17);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        boolean boolean8 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay6.plus(readablePeriod9);
        int[] intArray12 = new int[] { 0 };
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay10, intArray12);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, (int) (byte) 100);
        long long17 = delegatedDateTimeField2.roundCeiling(52L);
        java.util.Locale locale18 = null;
        int int19 = delegatedDateTimeField2.getMaximumShortTextLength(locale18);
        java.util.Locale locale20 = null;
        int int21 = delegatedDateTimeField2.getMaximumTextLength(locale20);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusMillis(10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology(chronology16);
        org.joda.time.DateTime dateTime18 = dateTime5.withChronology(chronology16);
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        boolean boolean20 = dateTime18.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.Interval interval14 = property13.toInterval();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean16 = property13.equals((java.lang.Object) dateTimeFormatter15);
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now();
        boolean boolean19 = monthDay17.isEqual((org.joda.time.ReadablePartial) monthDay18);
        org.joda.time.MonthDay monthDay21 = monthDay17.minusDays((int) (byte) 0);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.MonthDay monthDay23 = monthDay17.plus(readablePeriod22);
        java.lang.String str24 = dateTimeFormatter15.print((org.joda.time.ReadablePartial) monthDay17);
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay((long) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.MonthDay monthDay29 = monthDay26.withPeriodAdded(readablePeriod27, 718790);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.MonthDay monthDay31 = monthDay29.plus(readablePeriod30);
        int int32 = monthDay17.compareTo((org.joda.time.ReadablePartial) monthDay29);
        java.lang.String str34 = monthDay29.toString("2066");
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(interval14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "T��:��:��" + "'", str24.equals("T��:��:��"));
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2066" + "'", str34.equals("2066"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        long long35 = skipUndoDateTimeField32.getDifferenceAsLong(0L, (long) (byte) 1);
        long long38 = skipUndoDateTimeField32.getDifferenceAsLong((-3598900L), (long) '4');
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean13 = fixedDateTimeZone4.isFixed();
        java.lang.String str15 = fixedDateTimeZone4.getShortName((long) 6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.010" + "'", str15.equals("+00:00:00.010"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long10 = fixedDateTimeZone6.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6, readableInstant11);
        org.joda.time.Chronology chronology13 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = gregorianChronology1.add(readablePeriod14, (long) (byte) 10, 53);
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology1.getZone();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField20 = gregorianChronology1.hours();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-9L) + "'", long10 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), chronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property16 = dateTime15.year();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), chronology18);
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime19);
        int int21 = dateTime15.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime.Property property22 = dateTime19.yearOfCentury();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), chronology24);
        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property28 = dateTime27.year();
        int int29 = property28.getMaximumValue();
        java.util.Locale locale30 = null;
        java.lang.String str31 = property28.getAsText(locale30);
        org.joda.time.DateTime dateTime33 = property28.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay34 = dateTime33.toTimeOfDay();
        boolean boolean35 = dateTime19.isBefore((org.joda.time.ReadableInstant) dateTime33);
        int int36 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean38 = cachedDateTimeZone37.isFixed();
        org.joda.time.DateTimeZone dateTimeZone39 = cachedDateTimeZone37.getUncachedZone();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 292278993 + "'", int29 == 292278993);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969" + "'", str31.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(timeOfDay34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTimeZone39);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(6, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        java.lang.Object obj11 = null;
        boolean boolean12 = fixedDateTimeZone4.equals(obj11);
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType15 = monthDay13.getFieldType(34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(monthDay13);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType14, "UTC");
        java.lang.String str18 = illegalFieldValueException17.toString();
        java.lang.String str19 = illegalFieldValueException17.getFieldName();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"UTC\" for millisOfSecond is not supported" + "'", str18.equals("org.joda.time.IllegalFieldValueException: Value \"UTC\" for millisOfSecond is not supported"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "millisOfSecond" + "'", str19.equals("millisOfSecond"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfHour();
        int int3 = copticChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        int int3 = dateTime2.getWeekOfWeekyear();
        boolean boolean4 = dateTime2.isEqualNow();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "31");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfDay(12, 3);
        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatterBuilder7.toPrinter();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimePrinter8);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (short) 10);
        org.joda.time.Instant instant3 = instant1.withMillis((long) 24);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType24);
        java.lang.String str27 = offsetDateTimeField13.getAsText(0L);
        long long29 = offsetDateTimeField13.roundHalfEven((long) '#');
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "2067" + "'", str27.equals("2067"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-10L) + "'", long29 == (-10L));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 0);
        long long10 = fixedDateTimeZone4.previousTransition((-3599999L));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.MonthDay monthDay25 = monthDay23.minusDays((int) (byte) -1);
        boolean boolean26 = fixedDateTimeZone4.equals((java.lang.Object) monthDay23);
        org.joda.time.MonthDay monthDay28 = monthDay23.plusMonths((int) 'a');
        try {
            int int30 = monthDay28.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-3599999L) + "'", long10 == (-3599999L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(monthDay28);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean14 = fixedDateTimeZone5.isFixed();
        org.joda.time.Chronology chronology15 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        int int16 = julianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.Chronology chronology18 = julianChronology0.withZone(dateTimeZone17);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(86399);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap3);
        dateTimeFormatterBuilder2.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendEraText();
        boolean boolean7 = dateTimeFormatterBuilder6.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        int int12 = dateTime8.getSecondOfMinute();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int19 = fixedDateTimeZone17.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str21 = fixedDateTimeZone17.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        long long25 = fixedDateTimeZone17.adjustOffset((long) 401135, false);
        org.joda.time.DateTime dateTime26 = dateTime8.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 401135L + "'", long25 == 401135L);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(86399);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendSecondOfDay(365);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.year();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int29 = fixedDateTimeZone27.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone27);
        int int31 = monthDay22.compareTo((org.joda.time.ReadablePartial) monthDay30);
        org.joda.time.MonthDay monthDay33 = monthDay22.minusMonths(0);
        int[] intArray35 = buddhistChronology9.get((org.joda.time.ReadablePartial) monthDay33, (long) 89);
        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology9.halfdayOfDay();
        org.joda.time.Chronology chronology37 = buddhistChronology9.withUTC();
        org.joda.time.chrono.CopticChronology copticChronology38 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField39 = copticChronology38.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField39);
        java.lang.String str42 = delegatedDateTimeField40.getAsText((long) (byte) 10);
        org.joda.time.DateTimeField dateTimeField43 = delegatedDateTimeField40.getWrappedField();
        long long45 = delegatedDateTimeField40.roundFloor((long) (byte) 10);
        boolean boolean46 = buddhistChronology9.equals((java.lang.Object) (byte) 10);
        org.joda.time.DateTimeField dateTimeField47 = buddhistChronology9.halfdayOfDay();
        org.joda.time.MonthDay monthDay48 = org.joda.time.MonthDay.now();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter49 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.String str50 = monthDay48.toString(dateTimeFormatter49);
        int[] intArray52 = buddhistChronology9.get((org.joda.time.ReadablePartial) monthDay48, 567993600010L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(copticChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "10" + "'", str42.equals("10"));
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 10L + "'", long45 == 10L);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(monthDay48);
        org.junit.Assert.assertNotNull(dateTimeFormatter49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "����-06" + "'", str50.equals("����-06"));
        org.junit.Assert.assertNotNull(intArray52);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(86399, 401135);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendMinuteOfHour(3382);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendFractionOfSecond(2000, (-100));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.DurationField durationField2 = copticChronology0.halfdays();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = copticChronology0.add(readablePeriod3, (long) (-25199906), 9);
        java.lang.String str7 = copticChronology0.toString();
        org.joda.time.Chronology chronology8 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-25199906L) + "'", long6 == (-25199906L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str7.equals("CopticChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), chronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property16 = dateTime15.year();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), chronology18);
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime19);
        int int21 = dateTime15.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime.Property property22 = dateTime19.yearOfCentury();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), chronology24);
        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property28 = dateTime27.year();
        int int29 = property28.getMaximumValue();
        java.util.Locale locale30 = null;
        java.lang.String str31 = property28.getAsText(locale30);
        org.joda.time.DateTime dateTime33 = property28.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay34 = dateTime33.toTimeOfDay();
        boolean boolean35 = dateTime19.isBefore((org.joda.time.ReadableInstant) dateTime33);
        int int36 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone38 = cachedDateTimeZone37.getUncachedZone();
        try {
            org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (long) 999, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 12");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 292278993 + "'", int29 == 292278993);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969" + "'", str31.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(timeOfDay34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean14 = fixedDateTimeZone5.isFixed();
        org.joda.time.Chronology chronology15 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DurationField durationField16 = julianChronology0.months();
        long long19 = durationField16.subtract((long) 5, (int) ' ');
        try {
            org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((java.lang.Object) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Character");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-84243599995L) + "'", long19 == (-84243599995L));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property15.getAsText(locale16);
        int int18 = property15.getMinimumValueOverall();
        java.util.Locale locale19 = null;
        int int20 = property15.getMaximumShortTextLength(locale19);
        org.joda.time.MonthDay monthDay21 = property15.getMonthDay();
        org.joda.time.MonthDay monthDay23 = property15.addToCopy(292279090);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property15.getFieldType();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June" + "'", str17.equals("June"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        long long26 = offsetDateTimeField13.set((long) '#', "2067");
        long long29 = offsetDateTimeField13.getDifferenceAsLong((long) 2, 0L);
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField13.getAsShortText(4, locale31);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone37 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long41 = fixedDateTimeZone37.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant42 = null;
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone37, readableInstant42);
        org.joda.time.MonthDay monthDay44 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone37);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone49 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int51 = fixedDateTimeZone49.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay52 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone49);
        int int53 = monthDay44.compareTo((org.joda.time.ReadablePartial) monthDay52);
        org.joda.time.MonthDay monthDay55 = monthDay44.minusMonths(0);
        org.joda.time.MonthDay monthDay57 = monthDay55.plusMonths((int) (short) 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone62 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int64 = fixedDateTimeZone62.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str66 = fixedDateTimeZone62.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology67 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone62);
        org.joda.time.DateTimeField dateTimeField68 = buddhistChronology67.year();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone73 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long77 = fixedDateTimeZone73.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant78 = null;
        org.joda.time.chrono.GJChronology gJChronology79 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone73, readableInstant78);
        org.joda.time.MonthDay monthDay80 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone73);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone85 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int87 = fixedDateTimeZone85.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay88 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone85);
        int int89 = monthDay80.compareTo((org.joda.time.ReadablePartial) monthDay88);
        org.joda.time.MonthDay monthDay91 = monthDay80.minusMonths(0);
        int[] intArray93 = buddhistChronology67.get((org.joda.time.ReadablePartial) monthDay91, (long) 89);
        int int94 = offsetDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) monthDay57, intArray93);
        java.lang.String str95 = offsetDateTimeField13.toString();
        int int97 = offsetDateTimeField13.getMaximumValue(52L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "4" + "'", str32.equals("4"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-9L) + "'", long41 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(monthDay55);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 10 + "'", int64 == 10);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "" + "'", str66.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-9L) + "'", long77 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology79);
        org.junit.Assert.assertNotNull(monthDay80);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 10 + "'", int87 == 10);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertNotNull(monthDay91);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 292279090 + "'", int94 == 292279090);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "DateTimeField[yearOfEra]" + "'", str95.equals("DateTimeField[yearOfEra]"));
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 292279090 + "'", int97 == 292279090);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology4.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        long long9 = delegatedDateTimeField6.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField6.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 86399);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology13.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        long long18 = delegatedDateTimeField15.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = delegatedDateTimeField15.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField12, dateTimeFieldType19);
        int int22 = dividedDateTimeField12.get(52L);
        long long25 = dividedDateTimeField12.add((long) '4', 59);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 292278122L + "'", long9 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 292278122L + "'", long18 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 160866159836400052L + "'", long25 == 160866159836400052L);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        java.lang.Object obj22 = null;
        boolean boolean23 = fixedDateTimeZone15.equals(obj22);
        long long25 = fixedDateTimeZone15.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology26 = gJChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long35 = fixedDateTimeZone31.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone31, readableInstant36);
        org.joda.time.DurationField durationField38 = gJChronology37.millis();
        org.joda.time.DurationField durationField39 = gJChronology37.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone44 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long48 = fixedDateTimeZone44.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone44, readableInstant49);
        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) 'a');
        long long55 = offsetDateTimeField53.roundCeiling(10L);
        long long57 = offsetDateTimeField53.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField59 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology37, (org.joda.time.DateTimeField) offsetDateTimeField53, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField60 = gJChronology37.monthOfYear();
        boolean boolean61 = fixedDateTimeZone15.equals((java.lang.Object) gJChronology37);
        org.joda.time.DateTimeZone dateTimeZone62 = gJChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField63 = gJChronology37.year();
        java.lang.String str64 = gJChronology37.toString();
        try {
            long long69 = gJChronology37.getDateTimeMillis(0, 0, 999, (-25199906));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25199906 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31556476799900L) + "'", long25 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-9L) + "'", long35 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-9L) + "'", long48 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 31535999990L + "'", long55 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 31535999990L + "'", long57 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "GJChronology[]" + "'", str64.equals("GJChronology[]"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("UnsupportedDateTimeField");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UnsupportedDateTimeField\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        int int4 = dateTime2.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime2.plusSeconds((-25199906));
        org.joda.time.DateTime dateTime9 = dateTime2.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("24", "1970W013");
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendMinuteOfDay(359);
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendHourOfHalfday(53);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
//        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
//        org.joda.time.ReadableInstant readableInstant9 = null;
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
//        org.joda.time.DurationField durationField11 = gJChronology10.millis();
//        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
//        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
//        org.joda.time.ReadableInstant readableInstant22 = null;
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
//        long long28 = offsetDateTimeField26.roundCeiling(10L);
//        long long30 = offsetDateTimeField26.roundCeiling(0L);
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField33 = skipUndoDateTimeField32.getWrappedField();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
//        long long42 = fixedDateTimeZone38.convertLocalToUTC((long) (short) 1, true, (long) 1);
//        org.joda.time.ReadableInstant readableInstant43 = null;
//        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone38, readableInstant43);
//        org.joda.time.MonthDay monthDay45 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone38);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone50 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
//        int int52 = fixedDateTimeZone50.getOffsetFromLocal((long) (byte) 100);
//        org.joda.time.MonthDay monthDay53 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone50);
//        int int54 = monthDay45.compareTo((org.joda.time.ReadablePartial) monthDay53);
//        java.util.Locale locale56 = null;
//        java.lang.String str57 = skipUndoDateTimeField32.getAsShortText((org.joda.time.ReadablePartial) monthDay45, 0, locale56);
//        org.joda.time.MonthDay monthDay59 = monthDay45.minusDays(359);
//        org.joda.time.ReadablePeriod readablePeriod60 = null;
//        org.joda.time.MonthDay monthDay61 = monthDay45.minus(readablePeriod60);
//        java.lang.String str62 = monthDay61.toString();
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-9L) + "'", long42 == (-9L));
//        org.junit.Assert.assertNotNull(gJChronology44);
//        org.junit.Assert.assertNotNull(monthDay45);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "0" + "'", str57.equals("0"));
//        org.junit.Assert.assertNotNull(monthDay59);
//        org.junit.Assert.assertNotNull(monthDay61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "--06-15" + "'", str62.equals("--06-15"));
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        java.lang.String str29 = unsupportedDateTimeField28.toString();
        org.joda.time.DurationField durationField30 = unsupportedDateTimeField28.getRangeDurationField();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone35 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long39 = fixedDateTimeZone35.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant40 = null;
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone35, readableInstant40);
        org.joda.time.MonthDay monthDay42 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone35);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone47 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int49 = fixedDateTimeZone47.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay50 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone47);
        int int51 = monthDay42.compareTo((org.joda.time.ReadablePartial) monthDay50);
        int int52 = monthDay42.getMonthOfYear();
        org.joda.time.chrono.CopticChronology copticChronology54 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField55 = copticChronology54.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField56 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField55);
        long long59 = delegatedDateTimeField56.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay60 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay61 = org.joda.time.MonthDay.now();
        boolean boolean62 = monthDay60.isEqual((org.joda.time.ReadablePartial) monthDay61);
        org.joda.time.ReadablePeriod readablePeriod63 = null;
        org.joda.time.MonthDay monthDay64 = monthDay60.plus(readablePeriod63);
        int[] intArray66 = new int[] { 0 };
        int int67 = delegatedDateTimeField56.getMaximumValue((org.joda.time.ReadablePartial) monthDay64, intArray66);
        try {
            int[] intArray69 = unsupportedDateTimeField28.add((org.joda.time.ReadablePartial) monthDay42, (int) '#', intArray66, (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDateTimeField" + "'", str29.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNull(durationField30);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-9L) + "'", long39 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(monthDay42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 10 + "'", int49 == 10);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 6 + "'", int52 == 6);
        org.junit.Assert.assertNotNull(copticChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 292278122L + "'", long59 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay60);
        org.junit.Assert.assertNotNull(monthDay61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(monthDay64);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 999 + "'", int67 == 999);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        int int12 = dateTime8.getSecondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime8.minusSeconds((-1));
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime16 = dateTime8.minus(readableDuration15);
        org.joda.time.DateTime dateTime18 = dateTime16.minus((-25199906L));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
        java.util.Locale locale3 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNull(locale3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        org.joda.time.DurationField durationField26 = property25.getRangeDurationField();
        org.joda.time.DateTimeField dateTimeField27 = property25.getField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfCentury();
        boolean boolean28 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime24);
        java.util.GregorianCalendar gregorianCalendar29 = dateTime24.toGregorianCalendar();
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar29);
        org.joda.time.MonthDay monthDay31 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar29);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        boolean boolean34 = monthDay32.isEqual((org.joda.time.ReadablePartial) monthDay33);
        org.joda.time.MonthDay monthDay36 = monthDay32.minusDays((int) (byte) 0);
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.MonthDay monthDay38 = monthDay32.plus(readablePeriod37);
        boolean boolean39 = monthDay31.isBefore((org.joda.time.ReadablePartial) monthDay32);
        org.joda.time.Chronology chronology40 = monthDay32.getChronology();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar29);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(chronology40);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
        java.lang.String str15 = property13.getAsString();
        org.joda.time.DurationField durationField16 = property13.getDurationField();
        org.joda.time.DateTime dateTime17 = property13.withMinimumValue();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long26 = fixedDateTimeZone22.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone22, readableInstant27);
        org.joda.time.DurationField durationField29 = gJChronology28.millis();
        org.joda.time.DurationField durationField30 = gJChronology28.centuries();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology28.monthOfYear();
        boolean boolean32 = property13.equals((java.lang.Object) gJChronology28);
        java.util.Locale locale33 = null;
        int int34 = property13.getMaximumTextLength(locale33);
        int int35 = property13.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-9L) + "'", long26 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 9 + "'", int34 == 9);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int22 = offsetDateTimeField13.getMaximumValue();
        int int24 = offsetDateTimeField13.getMinimumValue((-9L));
        long long27 = offsetDateTimeField13.add(86409L, 58147);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292279090 + "'", int22 == 292279090);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 98 + "'", int24 == 98);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1834942118486409L + "'", long27 == 1834942118486409L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), chronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property16 = dateTime15.year();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), chronology18);
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime19);
        int int21 = dateTime15.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime.Property property22 = dateTime19.yearOfCentury();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), chronology24);
        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property28 = dateTime27.year();
        int int29 = property28.getMaximumValue();
        java.util.Locale locale30 = null;
        java.lang.String str31 = property28.getAsText(locale30);
        org.joda.time.DateTime dateTime33 = property28.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay34 = dateTime33.toTimeOfDay();
        boolean boolean35 = dateTime19.isBefore((org.joda.time.ReadableInstant) dateTime33);
        int int36 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean38 = cachedDateTimeZone37.isFixed();
        int int40 = cachedDateTimeZone37.getOffset(0L);
        long long42 = cachedDateTimeZone37.nextTransition((long) 718790);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 292278993 + "'", int29 == 292278993);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969" + "'", str31.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(timeOfDay34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 718790L + "'", long42 == 718790L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        boolean boolean8 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay6.plus(readablePeriod9);
        int[] intArray12 = new int[] { 0 };
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay10, intArray12);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, (int) (byte) 100);
        long long17 = delegatedDateTimeField2.roundCeiling(52L);
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField19 = copticChronology18.seconds();
        org.joda.time.DateTimeZone dateTimeZone20 = copticChronology18.getZone();
        org.joda.time.DateTimeField dateTimeField21 = copticChronology18.year();
        org.joda.time.chrono.CopticChronology copticChronology22 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField23 = copticChronology22.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField24 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField23);
        long long27 = delegatedDateTimeField24.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = delegatedDateTimeField24.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField30 = new org.joda.time.field.DividedDateTimeField(dateTimeField21, dateTimeFieldType28, 86399);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, dateTimeFieldType28, 292279090);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(copticChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 292278122L + "'", long27 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime5.withEra((int) (byte) 1);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (-1), chronology16);
        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks((int) (short) -1);
        org.joda.time.DateTime dateTime21 = dateTime17.plusWeeks(0);
        boolean boolean22 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime24 = dateTime5.minusYears(0);
        org.joda.time.DateTime dateTime25 = dateTime5.toDateTime();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean14 = fixedDateTimeZone5.isFixed();
        org.joda.time.Chronology chronology15 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str16 = julianChronology0.toString();
        long long21 = julianChronology0.getDateTimeMillis(1099, 6, 9, 31);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forID("-01:00");
        long long25 = dateTimeZone23.convertUTCToLocal((-28800000L));
        org.joda.time.Chronology chronology26 = julianChronology0.withZone(dateTimeZone23);
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str16.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-27471802021969L) + "'", long21 == (-27471802021969L));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-32400000L) + "'", long25 == (-32400000L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(chronology27);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (-25199906));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("GregorianChronology[UTC]");
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType24);
        long long28 = offsetDateTimeField13.add((long) (byte) 10, 3);
        try {
            long long31 = offsetDateTimeField13.set((long) (short) 1, "2019-06-15T21:04:49.999Z");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-15T21:04:49.999Z\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 94694400010L + "'", long28 == 94694400010L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        boolean boolean8 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay6.plus(readablePeriod9);
        int[] intArray12 = new int[] { 0 };
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay10, intArray12);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, (int) (byte) 100);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now();
        boolean boolean18 = monthDay16.isEqual((org.joda.time.ReadablePartial) monthDay17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay20 = monthDay16.plus(readablePeriod19);
        int int21 = offsetDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) monthDay16);
        org.joda.time.MonthDay monthDay23 = monthDay16.minusMonths(401135);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long32 = fixedDateTimeZone28.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone28, readableInstant33);
        org.joda.time.DurationField durationField35 = gJChronology34.millis();
        org.joda.time.DurationField durationField36 = gJChronology34.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone41 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long45 = fixedDateTimeZone41.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone41, readableInstant46);
        org.joda.time.DateTimeField dateTimeField48 = gJChronology47.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField48, (int) 'a');
        long long52 = offsetDateTimeField50.roundCeiling(10L);
        long long54 = offsetDateTimeField50.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField56 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology34, (org.joda.time.DateTimeField) offsetDateTimeField50, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField57 = gJChronology34.monthOfYear();
        org.joda.time.DateTimeField dateTimeField58 = gJChronology34.millisOfSecond();
        org.joda.time.MonthDay monthDay59 = monthDay16.withChronologyRetainFields((org.joda.time.Chronology) gJChronology34);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1099 + "'", int21 == 1099);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-9L) + "'", long32 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-9L) + "'", long45 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 31535999990L + "'", long52 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 31535999990L + "'", long54 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(monthDay59);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime5.withEra((int) (byte) 1);
        int int15 = dateTime5.getDayOfYear();
        org.joda.time.DateTime dateTime17 = dateTime5.plusSeconds((int) (byte) -1);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (-1), chronology19);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, 0);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (-1), chronology25);
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTimeZone dateTimeZone28 = dateTime26.getZone();
        java.util.TimeZone timeZone29 = dateTimeZone28.toTimeZone();
        org.joda.time.DateTime dateTime30 = dateTime23.toDateTime(dateTimeZone28);
        org.joda.time.DateTime dateTime32 = dateTime30.minusSeconds((int) (short) 1);
        boolean boolean33 = dateTime17.isBefore((org.joda.time.ReadableInstant) dateTime32);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 365 + "'", int15 == 365);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime4.dayOfYear();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds((int) (short) -1);
        org.joda.time.Chronology chronology15 = dateTime14.getChronology();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.yearOfCentury();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime2.getZone();
        java.util.TimeZone timeZone5 = dateTimeZone4.toTimeZone();
        java.util.TimeZone timeZone6 = dateTimeZone4.toTimeZone();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone6);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.DurationField durationField2 = copticChronology0.halfdays();
        java.lang.Class<?> wildcardClass3 = durationField2.getClass();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType4, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property11 = dateTime10.year();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime14);
        int int16 = dateTime10.compareTo((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property17 = dateTime14.yearOfCentury();
        int int18 = dateTime14.getSecondOfMinute();
        org.joda.time.DateTime dateTime20 = dateTime14.minusSeconds((-1));
        boolean boolean21 = gregorianChronology5.equals((java.lang.Object) dateTime14);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = dateTimeFormatter4.withChronology((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.format.DateTimeParser dateTimeParser23 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser23);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 59 + "'", int18 == 59);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTimeParser23);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property15.getAsText(locale16);
        int int18 = property15.getMinimumValueOverall();
        int int19 = property15.get();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (-1), chronology21);
        int int23 = property15.compareTo((org.joda.time.ReadableInstant) dateTime22);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June" + "'", str17.equals("June"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfCentury();
        boolean boolean28 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime24);
        java.util.GregorianCalendar gregorianCalendar29 = dateTime24.toGregorianCalendar();
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar29);
        org.joda.time.MonthDay monthDay31 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar29);
        org.joda.time.Instant instant32 = new org.joda.time.Instant((java.lang.Object) gregorianCalendar29);
        org.joda.time.Instant instant35 = instant32.withDurationAdded((long) 9, 100);
        org.joda.time.DateTime dateTime36 = instant32.toDateTimeISO();
        org.joda.time.DateTime dateTime37 = instant32.toDateTime();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar29);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(instant35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime37);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime2.getZone();
//        java.util.TimeZone timeZone5 = dateTimeZone4.toTimeZone();
//        org.joda.time.Instant instant6 = new org.joda.time.Instant();
//        org.joda.time.Chronology chronology7 = instant6.getChronology();
//        java.lang.String str8 = instant6.toString();
//        int int9 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) instant6);
//        org.joda.time.Instant instant12 = instant6.withDurationAdded((-8L), 166);
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.Instant instant15 = instant12.withDurationAdded(readableDuration13, (-1));
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(timeZone5);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019-06-15T21:06:06.037Z" + "'", str8.equals("2019-06-15T21:06:06.037Z"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-25200000) + "'", int9 == (-25200000));
//        org.junit.Assert.assertNotNull(instant12);
//        org.junit.Assert.assertNotNull(instant15);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime5.withEra((int) (byte) 1);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (-1), chronology16);
        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks((int) (short) -1);
        org.joda.time.DateTime dateTime21 = dateTime17.plusWeeks(0);
        boolean boolean22 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.DateTimeFormat.forPattern("1969");
        java.util.Locale locale25 = dateTimeFormatter24.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter24.withZoneUTC();
        boolean boolean27 = dateTime21.equals((java.lang.Object) dateTimeFormatter26);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone32 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long36 = fixedDateTimeZone32.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone32, readableInstant37);
        org.joda.time.Chronology chronology40 = null;
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (-1), chronology40);
        org.joda.time.DateTime dateTime43 = dateTime41.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property44 = dateTime43.year();
        org.joda.time.Chronology chronology46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (-1), chronology46);
        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime47);
        int int49 = dateTime43.compareTo((org.joda.time.ReadableInstant) dateTime47);
        org.joda.time.DateTime.Property property50 = dateTime47.yearOfCentury();
        org.joda.time.Chronology chronology52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime((long) (-1), chronology52);
        org.joda.time.DateTime dateTime55 = dateTime53.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property56 = dateTime55.year();
        int int57 = property56.getMaximumValue();
        java.util.Locale locale58 = null;
        java.lang.String str59 = property56.getAsText(locale58);
        org.joda.time.DateTime dateTime61 = property56.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay62 = dateTime61.toTimeOfDay();
        boolean boolean63 = dateTime47.isBefore((org.joda.time.ReadableInstant) dateTime61);
        int int64 = fixedDateTimeZone32.getOffset((org.joda.time.ReadableInstant) dateTime61);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone65 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone32);
        boolean boolean66 = cachedDateTimeZone65.isFixed();
        long long68 = cachedDateTimeZone65.previousTransition((long) 31);
        org.joda.time.DateTime dateTime69 = dateTime21.toDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone65);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNull(locale25);
        org.junit.Assert.assertNotNull(dateTimeFormatter26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-9L) + "'", long36 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 292278993 + "'", int57 == 292278993);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "1969" + "'", str59.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(timeOfDay62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 10 + "'", int64 == 10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 31L + "'", long68 == 31L);
        org.junit.Assert.assertNotNull(dateTime69);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology0);
        org.joda.time.DurationField durationField3 = copticChronology0.seconds();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        int int12 = dateTime8.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime8.minusWeeks(0);
        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.halfdays();
        boolean boolean3 = gregorianChronology0.equals((java.lang.Object) durationField2);
        org.joda.time.DurationField durationField4 = gregorianChronology0.hours();
        long long8 = gregorianChronology0.add(31L, (long) 718790, 5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3593981L + "'", long8 == 3593981L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime2.getZone();
        org.joda.time.LocalTime localTime5 = dateTime2.toLocalTime();
        org.joda.time.DateTime dateTime7 = dateTime2.plusMinutes(0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(86399);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendPattern("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendLiteral('#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        java.lang.String str26 = property25.toString();
        boolean boolean27 = property25.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
        java.lang.String str29 = property25.getAsText();
        org.joda.time.DateTime dateTime30 = property25.roundCeilingCopy();
        java.util.GregorianCalendar gregorianCalendar31 = dateTime30.toGregorianCalendar();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[dayOfMonth]" + "'", str26.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "24" + "'", str29.equals("24"));
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(gregorianCalendar31);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean14 = fixedDateTimeZone5.isFixed();
        org.joda.time.Chronology chronology15 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DurationField durationField16 = julianChronology0.minutes();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property13.getFieldType();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime12 = dateTime8.minusHours(10);
        boolean boolean13 = dateTime8.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
        java.lang.String str15 = property13.getAsString();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder4.appendYearOfCentury(2000, 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendMonthOfYearShortText();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (-1), chronology11);
        org.joda.time.DateTime dateTime14 = dateTime12.plusWeeks((int) (short) -1);
        int int15 = dateTime14.getDayOfMonth();
        org.joda.time.DateTime dateTime17 = dateTime14.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19);
        long long23 = delegatedDateTimeField20.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField20.getType();
        int int25 = dateTime14.get(dateTimeFieldType24);
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, "UTC");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder9.appendDecimal(dateTimeFieldType24, (int) (short) 1, 12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 24 + "'", int15 == 24);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 292278122L + "'", long23 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 999 + "'", int25 == 999);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        long long31 = unsupportedDateTimeField28.add((long) 0, 0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = unsupportedDateTimeField28.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType32, 0, (int) (short) 10, 15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for millisOfSecond must be in the range [10,15]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.DateTimeFormat.mediumTime();
        boolean boolean10 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withZoneUTC();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundHalfEven((long) (short) 0);
        int int22 = offsetDateTimeField13.getDifference((long) 9, (long) 98);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.DateTime dateTime9 = dateTime7.minus((long) (byte) 1);
        try {
            org.joda.time.DateTime dateTime11 = dateTime7.withDayOfMonth(53);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now();
        boolean boolean2 = monthDay0.isEqual((org.joda.time.ReadablePartial) monthDay1);
        try {
            org.joda.time.MonthDay monthDay4 = monthDay0.withDayOfMonth((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        long long31 = unsupportedDateTimeField28.add((long) 0, 0L);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = unsupportedDateTimeField28.getType();
        int int35 = unsupportedDateTimeField28.getDifference(58247L, (long) (short) 100);
        org.joda.time.DurationField durationField36 = unsupportedDateTimeField28.getDurationField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 58147 + "'", int35 == 58147);
        org.junit.Assert.assertNotNull(durationField36);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant0.plus(readableDuration2);
        org.joda.time.MutableDateTime mutableDateTime4 = instant0.toMutableDateTimeISO();
        org.joda.time.DateTimeZone dateTimeZone5 = mutableDateTime4.getZone();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime5.withEra((int) (byte) 1);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (-1), chronology16);
        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks((int) (short) -1);
        org.joda.time.DateTime dateTime21 = dateTime17.plusWeeks(0);
        boolean boolean22 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology23.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
        java.lang.String str27 = delegatedDateTimeField25.getAsText((long) (byte) 10);
        java.util.Locale locale29 = null;
        java.lang.String str30 = delegatedDateTimeField25.getAsText(0L, locale29);
        long long33 = delegatedDateTimeField25.add((long) 1, (-9L));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long42 = fixedDateTimeZone38.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone38, readableInstant43);
        org.joda.time.MonthDay monthDay45 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone38);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone50 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int52 = fixedDateTimeZone50.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay53 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone50);
        int int54 = monthDay45.compareTo((org.joda.time.ReadablePartial) monthDay53);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone59 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int61 = fixedDateTimeZone59.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str63 = fixedDateTimeZone59.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology64 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone59);
        org.joda.time.DateTimeField dateTimeField65 = buddhistChronology64.year();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone70 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long74 = fixedDateTimeZone70.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant75 = null;
        org.joda.time.chrono.GJChronology gJChronology76 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone70, readableInstant75);
        org.joda.time.MonthDay monthDay77 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone70);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone82 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int84 = fixedDateTimeZone82.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay85 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone82);
        int int86 = monthDay77.compareTo((org.joda.time.ReadablePartial) monthDay85);
        org.joda.time.MonthDay monthDay88 = monthDay77.minusMonths(0);
        int[] intArray90 = buddhistChronology64.get((org.joda.time.ReadablePartial) monthDay88, (long) 89);
        int int91 = delegatedDateTimeField25.getMinimumValue((org.joda.time.ReadablePartial) monthDay45, intArray90);
        int int92 = dateTime5.get((org.joda.time.DateTimeField) delegatedDateTimeField25);
        java.util.Locale locale93 = null;
        int int94 = delegatedDateTimeField25.getMaximumTextLength(locale93);
        java.util.Locale locale97 = null;
        try {
            long long98 = delegatedDateTimeField25.set(0L, "2067", locale97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2067 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "10" + "'", str27.equals("10"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0" + "'", str30.equals("0"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-8L) + "'", long33 == (-8L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-9L) + "'", long42 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-9L) + "'", long74 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology76);
        org.junit.Assert.assertNotNull(monthDay77);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 10 + "'", int84 == 10);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertNotNull(monthDay88);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 999 + "'", int92 == 999);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 3 + "'", int94 == 3);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
        java.lang.String str15 = property13.getAsShortText();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(86399);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendDayOfMonth(359);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime4.dayOfYear();
        org.joda.time.DateTime dateTime12 = property11.roundHalfCeilingCopy();
        org.joda.time.DateTime.Property property13 = dateTime12.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (-1), chronology19);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime20);
        int int22 = dateTime16.compareTo((org.joda.time.ReadableInstant) dateTime20);
        java.util.Locale locale24 = null;
        java.lang.String str25 = dateTime20.toString("-01:00", locale24);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone30 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int32 = fixedDateTimeZone30.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str34 = fixedDateTimeZone30.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology35 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone30);
        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology35.year();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone41 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long45 = fixedDateTimeZone41.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone41, readableInstant46);
        org.joda.time.MonthDay monthDay48 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone41);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone53 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int55 = fixedDateTimeZone53.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay56 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone53);
        int int57 = monthDay48.compareTo((org.joda.time.ReadablePartial) monthDay56);
        org.joda.time.MonthDay monthDay59 = monthDay48.minusMonths(0);
        int[] intArray61 = buddhistChronology35.get((org.joda.time.ReadablePartial) monthDay59, (long) 89);
        org.joda.time.DateTimeField dateTimeField62 = buddhistChronology35.halfdayOfDay();
        org.joda.time.Chronology chronology63 = buddhistChronology35.withUTC();
        org.joda.time.MutableDateTime mutableDateTime64 = dateTime20.toMutableDateTime(chronology63);
        int int65 = property11.getDifference((org.joda.time.ReadableInstant) mutableDateTime64);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "-01:00" + "'", str25.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 10 + "'", int32 == 10);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-9L) + "'", long45 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology47);
        org.junit.Assert.assertNotNull(monthDay48);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 10 + "'", int55 == 10);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(monthDay59);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(chronology63);
        org.junit.Assert.assertNotNull(mutableDateTime64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        int int12 = dateTime8.getSecondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime8.withYear(2116);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfEra();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "Property[dayOfMonth]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        long long14 = durationField11.subtract(0L, 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (-98));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long30 = fixedDateTimeZone26.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26, readableInstant31);
        org.joda.time.DateTimeField dateTimeField33 = gJChronology32.yearOfEra();
        java.lang.String str34 = gJChronology32.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone39 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int41 = fixedDateTimeZone39.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay42 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone39);
        int[] intArray44 = gJChronology32.get((org.joda.time.ReadablePartial) monthDay42, 100L);
        org.joda.time.DateTimeField dateTimeField45 = gJChronology32.monthOfYear();
        org.joda.time.MonthDay monthDay46 = org.joda.time.MonthDay.now((org.joda.time.Chronology) gJChronology32);
        java.lang.String str48 = monthDay46.toString("21:05");
        org.joda.time.chrono.CopticChronology copticChronology50 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField51 = copticChronology50.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField52 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField51);
        long long55 = delegatedDateTimeField52.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay56 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay57 = org.joda.time.MonthDay.now();
        boolean boolean58 = monthDay56.isEqual((org.joda.time.ReadablePartial) monthDay57);
        org.joda.time.ReadablePeriod readablePeriod59 = null;
        org.joda.time.MonthDay monthDay60 = monthDay56.plus(readablePeriod59);
        int[] intArray62 = new int[] { 0 };
        int int63 = delegatedDateTimeField52.getMaximumValue((org.joda.time.ReadablePartial) monthDay60, intArray62);
        try {
            int[] intArray65 = offsetDateTimeField13.set((org.joda.time.ReadablePartial) monthDay46, 98, intArray62, 86399);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 98");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-9L) + "'", long30 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "GJChronology[]" + "'", str34.equals("GJChronology[]"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "21:05" + "'", str48.equals("21:05"));
        org.junit.Assert.assertNotNull(copticChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 292278122L + "'", long55 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay56);
        org.junit.Assert.assertNotNull(monthDay57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(monthDay60);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 999 + "'", int63 == 999);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        java.lang.String str26 = property25.toString();
        boolean boolean27 = property25.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
        java.lang.String str29 = property25.getAsText();
        org.joda.time.DateTime dateTime30 = property25.roundCeilingCopy();
        org.joda.time.DateTime dateTime31 = property25.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[dayOfMonth]" + "'", str26.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "24" + "'", str29.equals("24"));
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(3593981L, 292278122L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1050442017183682L + "'", long2 == 1050442017183682L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime12 = dateTime8.plusMinutes((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        boolean boolean8 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay6.plus(readablePeriod9);
        int[] intArray12 = new int[] { 0 };
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay10, intArray12);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, (int) (byte) 100);
        long long17 = delegatedDateTimeField2.roundCeiling(52L);
        org.joda.time.DateTimeField dateTimeField18 = delegatedDateTimeField2.getWrappedField();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long27 = fixedDateTimeZone23.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant28 = null;
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone23, readableInstant28);
        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, (int) 'a');
        long long34 = offsetDateTimeField32.roundCeiling(10L);
        long long36 = offsetDateTimeField32.roundCeiling(0L);
        long long38 = offsetDateTimeField32.roundFloor((long) 'a');
        long long40 = offsetDateTimeField32.roundHalfCeiling((-1L));
        int int42 = offsetDateTimeField32.getMinimumValue((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField44 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField32, dateTimeFieldType43);
        int int47 = offsetDateTimeField32.getDifference(0L, (long) 1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone52 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long56 = fixedDateTimeZone52.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant57 = null;
        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone52, readableInstant57);
        java.lang.Object obj59 = null;
        boolean boolean60 = fixedDateTimeZone52.equals(obj59);
        org.joda.time.MonthDay monthDay61 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone52);
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField32.getAsShortText((org.joda.time.ReadablePartial) monthDay61, (-98), locale63);
        int int65 = delegatedDateTimeField2.getMinimumValue((org.joda.time.ReadablePartial) monthDay61);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-9L) + "'", long27 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 31535999990L + "'", long34 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 31535999990L + "'", long36 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-10L) + "'", long38 == (-10L));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-10L) + "'", long40 == (-10L));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 98 + "'", int42 == 98);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-9L) + "'", long56 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(monthDay61);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "-98" + "'", str64.equals("-98"));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean14 = fixedDateTimeZone5.isFixed();
        org.joda.time.Chronology chronology15 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str16 = julianChronology0.toString();
        long long21 = julianChronology0.getDateTimeMillis(1099, 6, 9, 31);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forID("-01:00");
        long long25 = dateTimeZone23.convertUTCToLocal((-28800000L));
        org.joda.time.Chronology chronology26 = julianChronology0.withZone(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField27 = julianChronology0.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone32 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long36 = fixedDateTimeZone32.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant37 = null;
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone32, readableInstant37);
        org.joda.time.DurationField durationField39 = gJChronology38.millis();
        org.joda.time.DurationField durationField40 = gJChronology38.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone45 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long49 = fixedDateTimeZone45.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant50 = null;
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone45, readableInstant50);
        org.joda.time.DateTimeField dateTimeField52 = gJChronology51.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, (int) 'a');
        long long56 = offsetDateTimeField54.roundCeiling(10L);
        long long58 = offsetDateTimeField54.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField60 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology38, (org.joda.time.DateTimeField) offsetDateTimeField54, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField61 = gJChronology38.monthOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField62 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField61);
        java.lang.String str63 = delegatedDateTimeField62.getName();
        org.joda.time.field.SkipDateTimeField skipDateTimeField64 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField62);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str16.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-27471802021969L) + "'", long21 == (-27471802021969L));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-32400000L) + "'", long25 == (-32400000L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-9L) + "'", long36 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-9L) + "'", long49 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 31535999990L + "'", long56 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 31535999990L + "'", long58 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "monthOfYear" + "'", str63.equals("monthOfYear"));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        boolean boolean8 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay6.plus(readablePeriod9);
        int[] intArray12 = new int[] { 0 };
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay10, intArray12);
        int int14 = delegatedDateTimeField2.getMaximumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 999 + "'", int14 == 999);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "GregorianChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("JulianChronology[America/Los_Angeles]", "2019-06-15T21:05:06.830Z");
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean14 = fixedDateTimeZone5.isFixed();
        org.joda.time.Chronology chronology15 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DurationField durationField16 = julianChronology0.months();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology0.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long26 = fixedDateTimeZone22.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone22, readableInstant27);
        org.joda.time.MonthDay monthDay29 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.Chronology chronology30 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-9L) + "'", long26 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(chronology30);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("monthOfYear");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: monthOfYear");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology4.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        long long9 = delegatedDateTimeField6.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField6.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 86399);
        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = copticChronology13.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField15 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14);
        long long18 = delegatedDateTimeField15.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = delegatedDateTimeField15.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField20 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField12, dateTimeFieldType19);
        long long22 = remainderDateTimeField20.remainder((long) 86399);
        long long25 = remainderDateTimeField20.addWrapField(0L, (int) (short) 10);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 292278122L + "'", long9 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(copticChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 292278122L + "'", long18 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9648086399L + "'", long22 == 9648086399L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 315619200000L + "'", long25 == 315619200000L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValue();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        java.util.Locale locale9 = null;
        java.lang.String str10 = property5.getAsShortText(locale9);
        org.joda.time.DateTime dateTime11 = property5.getDateTime();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long20 = fixedDateTimeZone16.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone16, readableInstant21);
        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) 'a');
        long long27 = offsetDateTimeField25.roundCeiling(10L);
        long long29 = offsetDateTimeField25.roundCeiling(0L);
        long long31 = offsetDateTimeField25.roundHalfEven((long) (short) 0);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        boolean boolean34 = monthDay32.isEqual((org.joda.time.ReadablePartial) monthDay33);
        org.joda.time.MonthDay monthDay36 = monthDay32.minusDays((int) (byte) 0);
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.MonthDay monthDay38 = monthDay32.plus(readablePeriod37);
        int int39 = offsetDateTimeField25.getMinimumValue((org.joda.time.ReadablePartial) monthDay32);
        org.joda.time.DateTime dateTime40 = dateTime11.withFields((org.joda.time.ReadablePartial) monthDay32);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969" + "'", str10.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-9L) + "'", long20 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 31535999990L + "'", long27 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 31535999990L + "'", long29 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-10L) + "'", long31 == (-10L));
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(monthDay38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 98 + "'", int39 == 98);
        org.junit.Assert.assertNotNull(dateTime40);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        java.lang.String str26 = property25.toString();
        boolean boolean27 = property25.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
        java.lang.String str29 = property25.getAsText();
        org.joda.time.DateTime dateTime30 = property25.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[dayOfMonth]" + "'", str26.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "24" + "'", str29.equals("24"));
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.MonthDay monthDay4 = monthDay1.withPeriodAdded(readablePeriod2, 718790);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay6 = monthDay4.plus(readablePeriod5);
        org.joda.time.MonthDay.Property property7 = monthDay6.monthOfYear();
        org.junit.Assert.assertNotNull(monthDay4);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        java.lang.Object obj11 = null;
        boolean boolean12 = fixedDateTimeZone4.equals(obj11);
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.TimeZone timeZone14 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(monthDay15);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.monthOfYear();
        org.joda.time.DurationField durationField14 = gJChronology10.years();
        try {
            long long19 = gJChronology10.getDateTimeMillis(58, 0, 1, (-25199906));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25199906 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), chronology9);
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property13 = dateTime12.year();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (-1), chronology15);
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
        int int18 = dateTime12.compareTo((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime.Property property19 = dateTime16.yearOfCentury();
        int int20 = dateTime16.getSecondOfMinute();
        org.joda.time.DateTime dateTime22 = dateTime16.minusSeconds((-1));
        boolean boolean23 = gregorianChronology7.equals((java.lang.Object) dateTime16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter6.withChronology((org.joda.time.Chronology) gregorianChronology7);
        try {
            org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((-292275054), (int) 'a', 999, (-1), (-100), 3, (org.joda.time.Chronology) gregorianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 59 + "'", int20 == 59);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, (-98));
        org.joda.time.DurationField durationField22 = offsetDateTimeField13.getLeapDurationField();
        long long25 = offsetDateTimeField13.getDifferenceAsLong(401135L, 13632725433589019L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-432003L) + "'", long25 == (-432003L));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMonthOfYear(359);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendMillisOfSecond(1099);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder9.appendTimeZoneOffset("GregorianChronology[UTC]", "hi!", true, (int) (byte) 10, 98);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder15.appendDayOfWeekShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder15.appendWeekyear((-54), 3382);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(86399, 2067, 2067, 9, 0, 59, 89);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2067 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds((int) (short) 1);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (-1), chronology16);
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withDurationAdded(readableDuration18, 0);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (-1), chronology22);
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTimeZone dateTimeZone25 = dateTime23.getZone();
        java.util.TimeZone timeZone26 = dateTimeZone25.toTimeZone();
        org.joda.time.DateTime dateTime27 = dateTime20.toDateTime(dateTimeZone25);
        org.joda.time.DateTime.Property property28 = dateTime20.yearOfEra();
        org.joda.time.DateTime dateTime30 = dateTime20.minusDays(0);
        org.joda.time.DateTime dateTime32 = dateTime30.minusHours((int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField34 = copticChronology33.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField35 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField34);
        long long38 = delegatedDateTimeField35.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = delegatedDateTimeField35.getType();
        org.joda.time.DateTime.Property property40 = dateTime30.property(dateTimeFieldType39);
        org.joda.time.DateTime.Property property41 = dateTime12.property(dateTimeFieldType39);
        org.joda.time.DateTime.Property property42 = dateTime12.yearOfEra();
        org.joda.time.DateTime dateTime44 = property42.addWrapFieldToCopy(2000);
        org.joda.time.ReadableInstant readableInstant45 = null;
        try {
            int int46 = property42.compareTo(readableInstant45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 292278122L + "'", long38 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime44);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean14 = fixedDateTimeZone5.isFixed();
        org.joda.time.Chronology chronology15 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.Chronology chronology17 = julianChronology0.withZone(dateTimeZone16);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Instant instant3 = instant0.withDurationAdded((long) 18, (int) 'a');
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = skipUndoDateTimeField32.getWrappedField();
        long long35 = skipUndoDateTimeField32.roundFloor((long) (byte) 100);
        long long37 = skipUndoDateTimeField32.roundHalfEven((long) 100);
        java.lang.String str38 = skipUndoDateTimeField32.getName();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-10L) + "'", long35 == (-10L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-10L) + "'", long37 == (-10L));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "yearOfEra" + "'", str38.equals("yearOfEra"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(86399);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMonthOfYear((int) (short) 100);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendYearOfEra((-54), 292279090);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendMinuteOfDay(359);
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildFormatter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendMillisOfSecond((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology4.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        long long9 = delegatedDateTimeField6.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField6.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 86399);
        org.joda.time.DurationField durationField13 = dividedDateTimeField12.getDurationField();
        int int16 = dividedDateTimeField12.getDifference((long) 6, (-25200000L));
        int int17 = dividedDateTimeField12.getMaximumValue();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField18 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField12);
        try {
            long long20 = dividedDateTimeField12.roundFloor((long) 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 292278122L + "'", long9 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3382 + "'", int17 == 3382);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone33 = gJChronology10.getZone();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeZone33);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        int int16 = property15.getMaximumValue();
        java.lang.Object obj17 = null;
        boolean boolean18 = property15.equals(obj17);
        org.joda.time.DurationField durationField19 = property15.getRangeDurationField();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        java.lang.String str2 = monthDay0.toString(dateTimeFormatter1);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((long) (byte) 1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.MonthDay monthDay7 = monthDay4.withPeriodAdded(readablePeriod5, 718790);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.MonthDay monthDay9 = monthDay7.plus(readablePeriod8);
        boolean boolean10 = monthDay0.isAfter((org.joda.time.ReadablePartial) monthDay9);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "����-06" + "'", str2.equals("����-06"));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) (byte) 10);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds((int) (short) 1);
        org.joda.time.DateTime.Property property15 = dateTime12.hourOfDay();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.DateTime dateTime17 = dateTime5.withMonthOfYear(3);
        org.joda.time.DateTime.Property property18 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime19 = property18.getDateTime();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType24);
        long long28 = offsetDateTimeField13.getDifferenceAsLong((long) (short) 1, (long) 292278993);
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) (-1), chronology30);
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTimeZone dateTimeZone33 = dateTime31.getZone();
        org.joda.time.LocalTime localTime34 = dateTime31.toLocalTime();
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (-1), chronology36);
        org.joda.time.Chronology chronology38 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTimeZone dateTimeZone39 = dateTime37.getZone();
        org.joda.time.LocalTime localTime40 = dateTime37.toLocalTime();
        boolean boolean41 = localTime34.isEqual((org.joda.time.ReadablePartial) localTime40);
        boolean boolean42 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime40);
        boolean boolean43 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime40);
        org.joda.time.Chronology chronology45 = null;
        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) (-1), chronology45);
        org.joda.time.Chronology chronology47 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime46);
        org.joda.time.DateTimeZone dateTimeZone48 = dateTime46.getZone();
        org.joda.time.LocalTime localTime49 = dateTime46.toLocalTime();
        int int50 = localTime40.compareTo((org.joda.time.ReadablePartial) localTime49);
        java.util.Locale locale52 = null;
        java.lang.String str53 = offsetDateTimeField13.getAsText((org.joda.time.ReadablePartial) localTime49, 9, locale52);
        java.util.Locale locale55 = null;
        java.lang.String str56 = offsetDateTimeField13.getAsShortText((long) (byte) 0, locale55);
        java.util.Locale locale58 = null;
        java.lang.String str59 = offsetDateTimeField13.getAsShortText((long) 3382, locale58);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(localTime34);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(localTime40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(localTime49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "9" + "'", str53.equals("9"));
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "2067" + "'", str56.equals("2067"));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "2067" + "'", str59.equals("2067"));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        java.lang.Object obj22 = null;
        boolean boolean23 = fixedDateTimeZone15.equals(obj22);
        long long25 = fixedDateTimeZone15.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology26 = gJChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long35 = fixedDateTimeZone31.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone31, readableInstant36);
        org.joda.time.DurationField durationField38 = gJChronology37.millis();
        org.joda.time.DurationField durationField39 = gJChronology37.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone44 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long48 = fixedDateTimeZone44.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone44, readableInstant49);
        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) 'a');
        long long55 = offsetDateTimeField53.roundCeiling(10L);
        long long57 = offsetDateTimeField53.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField59 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology37, (org.joda.time.DateTimeField) offsetDateTimeField53, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField60 = gJChronology37.monthOfYear();
        boolean boolean61 = fixedDateTimeZone15.equals((java.lang.Object) gJChronology37);
        org.joda.time.DateTimeZone dateTimeZone62 = gJChronology37.getZone();
        org.joda.time.DateTimeField dateTimeField63 = gJChronology37.year();
        org.joda.time.Chronology chronology64 = gJChronology37.withUTC();
        org.joda.time.DateTimeField dateTimeField65 = gJChronology37.minuteOfDay();
        java.lang.String str66 = gJChronology37.toString();
        org.joda.time.DateTimeZone dateTimeZone67 = gJChronology37.getZone();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31556476799900L) + "'", long25 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-9L) + "'", long35 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-9L) + "'", long48 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 31535999990L + "'", long55 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 31535999990L + "'", long57 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(dateTimeZone62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(chronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "GJChronology[]" + "'", str66.equals("GJChronology[]"));
        org.junit.Assert.assertNotNull(dateTimeZone67);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(86399, 401135);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendFractionOfHour(58, (int) (short) 10);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendTimeZoneShortName(strMap11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.getMinimumValue((long) (byte) 10);
        java.lang.String str5 = delegatedDateTimeField2.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[millisOfSecond]" + "'", str5.equals("DateTimeField[millisOfSecond]"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter0.getPrinter();
        java.lang.Integer int4 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNull(int4);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology0);
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            long long5 = copticChronology0.set(readablePartial3, (-25199906L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundHalfEven(292278122L);
        long long21 = offsetDateTimeField13.roundCeiling(0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 31535999990L + "'", long21 == 31535999990L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property15.getAsText(locale16);
        int int18 = property15.getMinimumValueOverall();
        java.util.Locale locale19 = null;
        int int20 = property15.getMaximumShortTextLength(locale19);
        org.joda.time.MonthDay monthDay21 = property15.getMonthDay();
        int int22 = property15.get();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), chronology24);
        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property28 = dateTime27.year();
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) (-1), chronology30);
        org.joda.time.Chronology chronology32 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime31);
        int int33 = dateTime27.compareTo((org.joda.time.ReadableInstant) dateTime31);
        org.joda.time.DateTime.Property property34 = dateTime31.yearOfCentury();
        int int35 = dateTime31.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime37 = dateTime31.minusWeeks(0);
        org.joda.time.Instant instant38 = dateTime37.toInstant();
        int int39 = property15.compareTo((org.joda.time.ReadableInstant) instant38);
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.Instant instant42 = instant38.withDurationAdded(readableDuration40, 97);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June" + "'", str17.equals("June"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(chronology32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(instant38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(instant42);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfCentury();
        boolean boolean28 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime24);
        java.util.GregorianCalendar gregorianCalendar29 = dateTime24.toGregorianCalendar();
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar29);
        org.joda.time.MonthDay monthDay31 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean33 = dateTimeFormatterBuilder32.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder32.appendYear(0, (int) '#');
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (-1), chronology38);
        org.joda.time.DateTime dateTime41 = dateTime39.plusWeeks((int) (short) -1);
        int int42 = dateTime41.getDayOfMonth();
        org.joda.time.DateTime dateTime44 = dateTime41.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology45 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField46 = copticChronology45.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField47 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField46);
        long long50 = delegatedDateTimeField47.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType51 = delegatedDateTimeField47.getType();
        int int52 = dateTime41.get(dateTimeFieldType51);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone57 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long61 = fixedDateTimeZone57.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant62 = null;
        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone57, readableInstant62);
        org.joda.time.DurationField durationField64 = gJChronology63.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField65 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType51, durationField64);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder32.appendFraction(dateTimeFieldType51, (int) ' ', 166);
        try {
            org.joda.time.MonthDay monthDay70 = monthDay31.withField(dateTimeFieldType51, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar29);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 24 + "'", int42 == 24);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(copticChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 292278122L + "'", long50 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 999 + "'", int52 == 999);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-9L) + "'", long61 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology63);
        org.junit.Assert.assertNotNull(durationField64);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendYear(86399, 401135);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfWeek((int) (short) 1);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap10 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendTimeZoneShortName(strMap10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendEraText();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("1969");
        java.lang.Class<?> wildcardClass2 = dateTimeFormatter1.getClass();
        try {
            org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        int int33 = skipUndoDateTimeField32.getMaximumValue();
        java.util.Locale locale34 = null;
        int int35 = skipUndoDateTimeField32.getMaximumShortTextLength(locale34);
        long long37 = skipUndoDateTimeField32.roundHalfFloor((-28800000L));
        long long39 = skipUndoDateTimeField32.roundFloor((long) (byte) 10);
        org.joda.time.DurationField durationField40 = skipUndoDateTimeField32.getDurationField();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 292279090 + "'", int33 == 292279090);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-10L) + "'", long37 == (-10L));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-10L) + "'", long39 == (-10L));
        org.junit.Assert.assertNotNull(durationField40);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        java.lang.String str29 = unsupportedDateTimeField28.toString();
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (-1), chronology31);
        org.joda.time.Chronology chronology33 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.DateTimeZone dateTimeZone34 = dateTime32.getZone();
        org.joda.time.LocalTime localTime35 = dateTime32.toLocalTime();
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (-1), chronology37);
        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTimeZone dateTimeZone40 = dateTime38.getZone();
        org.joda.time.LocalTime localTime41 = dateTime38.toLocalTime();
        boolean boolean42 = localTime35.isEqual((org.joda.time.ReadablePartial) localTime41);
        boolean boolean43 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime41);
        boolean boolean44 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localTime41);
        org.joda.time.Chronology chronology46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (-1), chronology46);
        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime47);
        org.joda.time.DateTimeZone dateTimeZone49 = dateTime47.getZone();
        org.joda.time.LocalTime localTime50 = dateTime47.toLocalTime();
        int int51 = localTime41.compareTo((org.joda.time.ReadablePartial) localTime50);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone57 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long61 = fixedDateTimeZone57.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant62 = null;
        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone57, readableInstant62);
        org.joda.time.DateTimeField dateTimeField64 = gJChronology63.yearOfEra();
        java.lang.String str65 = gJChronology63.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone70 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int72 = fixedDateTimeZone70.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay73 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone70);
        int[] intArray75 = gJChronology63.get((org.joda.time.ReadablePartial) monthDay73, 100L);
        try {
            int[] intArray77 = unsupportedDateTimeField28.set((org.joda.time.ReadablePartial) localTime41, (int) (short) 10, intArray75, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDateTimeField" + "'", str29.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(localTime35);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(localTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(localTime50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-9L) + "'", long61 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "GJChronology[]" + "'", str65.equals("GJChronology[]"));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 10 + "'", int72 == 10);
        org.junit.Assert.assertNotNull(intArray75);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValue();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        java.util.Locale locale9 = null;
        java.lang.String str10 = property5.getAsShortText(locale9);
        org.joda.time.DateTime dateTime11 = property5.getDateTime();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (-1), chronology19);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime20);
        int int22 = dateTime16.compareTo((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime.Property property23 = dateTime20.yearOfCentury();
        int int24 = dateTime20.getSecondOfMinute();
        org.joda.time.DateTime dateTime26 = dateTime20.minusSeconds((-1));
        org.joda.time.DateTime dateTime28 = dateTime20.minusHours(89);
        int int29 = property5.compareTo((org.joda.time.ReadableInstant) dateTime20);
        int int30 = dateTime20.getYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969" + "'", str10.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 59 + "'", int24 == 59);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1969 + "'", int30 == 1969);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 53);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendMinuteOfDay(359);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendDayOfMonth(718790);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        org.joda.time.DateTime dateTime27 = dateTime22.withWeekOfWeekyear(9);
        org.joda.time.DateTime dateTime29 = dateTime22.plusWeeks((-100));
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.MutableDateTime mutableDateTime31 = dateTime22.toMutableDateTime(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(mutableDateTime31);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property15.getAsText(locale16);
        int int18 = property15.getMinimumValueOverall();
        java.util.Locale locale19 = null;
        int int20 = property15.getMaximumShortTextLength(locale19);
        java.lang.String str21 = property15.getName();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June" + "'", str17.equals("June"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "monthOfYear" + "'", str21.equals("monthOfYear"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (-1), chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.year();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), chronology9);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        int int12 = dateTime6.compareTo((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        int int14 = dateTime10.getSecondOfMinute();
        org.joda.time.DateTime dateTime16 = dateTime10.minusSeconds((-1));
        boolean boolean17 = gregorianChronology1.equals((java.lang.Object) dateTime10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        try {
            long long23 = gregorianChronology1.getDateTimeMillis((int) (short) 100, 358, 97, 24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 358 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long16 = fixedDateTimeZone12.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone12, readableInstant17);
        java.lang.Object obj19 = null;
        boolean boolean20 = fixedDateTimeZone12.equals(obj19);
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) 401135, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
        try {
            org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(12, 58147, (-54), 97, 0, 58147, 0, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-9L) + "'", long16 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        java.lang.String str34 = offsetDateTimeField26.getAsText((long) (-54));
        org.joda.time.DurationField durationField35 = offsetDateTimeField26.getDurationField();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2066" + "'", str34.equals("2066"));
        org.junit.Assert.assertNotNull(durationField35);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        java.lang.String str34 = offsetDateTimeField26.getAsText((long) (-54));
        long long36 = offsetDateTimeField26.roundFloor(3593981L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "2066" + "'", str34.equals("2066"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-10L) + "'", long36 == (-10L));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        boolean boolean5 = dateTimeFormatterBuilder4.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendMinuteOfDay(359);
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (-1), chronology10);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withDurationAdded(readableDuration12, 0);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (-1), chronology16);
        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
        java.util.TimeZone timeZone20 = dateTimeZone19.toTimeZone();
        org.joda.time.DateTime dateTime21 = dateTime14.toDateTime(dateTimeZone19);
        org.joda.time.DateTime.Property property22 = dateTime14.yearOfEra();
        org.joda.time.DateTime dateTime24 = dateTime14.minusDays(0);
        org.joda.time.DateTime dateTime26 = dateTime24.minusHours((int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology27 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = copticChronology27.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28);
        long long32 = delegatedDateTimeField29.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = delegatedDateTimeField29.getType();
        org.joda.time.DateTime.Property property34 = dateTime24.property(dateTimeFieldType33);
        int int35 = monthDay8.indexOf(dateTimeFieldType33);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder7.appendSignedDecimal(dateTimeFieldType33, 57599999, 1099);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType33, 18, 292279090, 292278993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 18 for millisOfSecond must be in the range [292279090,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(copticChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 292278122L + "'", long32 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling((-365L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-10L) + "'", long17 == (-10L));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(dateTimeZone3);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(6, 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTimeISO();
//        long long2 = instant0.getMillis();
//        org.joda.time.Instant instant3 = instant0.toInstant();
//        org.junit.Assert.assertNotNull(mutableDateTime1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560632772497L + "'", long2 == 1560632772497L);
//        org.junit.Assert.assertNotNull(instant3);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long20 = fixedDateTimeZone16.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone16, readableInstant21);
        java.lang.Object obj23 = null;
        boolean boolean24 = fixedDateTimeZone16.equals(obj23);
        long long26 = fixedDateTimeZone16.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology27 = gJChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DateTimeField dateTimeField28 = gJChronology11.secondOfDay();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 0, (org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTimeZone dateTimeZone31 = gJChronology11.getZone();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-9L) + "'", long20 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-31556476799900L) + "'", long26 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeZone31);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.halfdays();
        boolean boolean3 = gregorianChronology0.equals((java.lang.Object) durationField2);
        org.joda.time.DurationField durationField4 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField5 = gregorianChronology0.minutes();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField8 = new org.joda.time.field.ScaledDurationField(durationField5, durationFieldType6, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), chronology2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withDurationAdded(readableDuration4, 0);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (-1), chronology8);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime9.getZone();
        java.util.TimeZone timeZone12 = dateTimeZone11.toTimeZone();
        org.joda.time.DateTime dateTime13 = dateTime6.toDateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property14 = dateTime6.yearOfEra();
        org.joda.time.DateTime dateTime16 = dateTime6.minusDays(0);
        org.joda.time.DateTime dateTime18 = dateTime16.minusHours((int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField20 = copticChronology19.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        long long24 = delegatedDateTimeField21.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = delegatedDateTimeField21.getType();
        org.joda.time.DateTime.Property property26 = dateTime16.property(dateTimeFieldType25);
        int int27 = monthDay0.indexOf(dateTimeFieldType25);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType25, 718790, 15, 359);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 718790 for millisOfSecond must be in the range [15,359]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 292278122L + "'", long24 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(86399);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap3);
        dateTimeFormatterBuilder2.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendTimeZoneShortName();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.minus(readablePeriod3);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(86399);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(34, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMillisOfSecond(401135);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = gJChronology10.monthOfYear();
        org.joda.time.Instant instant34 = gJChronology10.getGregorianCutover();
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36);
        java.lang.String str39 = delegatedDateTimeField37.getAsText((long) (byte) 10);
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField37.getAsText(0L, locale41);
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) delegatedDateTimeField37, 358);
        long long47 = skipDateTimeField44.set(1560632687348L, 999);
        int int49 = skipDateTimeField44.getMaximumValue((-32400000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10" + "'", str39.equals("10"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0" + "'", str42.equals("0"));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560632687999L + "'", long47 == 1560632687999L);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 999 + "'", int49 == 999);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.LocalDateTime localDateTime4 = dateTime2.toLocalDateTime();
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            boolean boolean6 = localDateTime4.isAfter(readablePartial5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfHour((int) (short) 100, 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear((int) (byte) 100, false);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.DateTimeFormat.forPattern("24");
        org.joda.time.format.DateTimePrinter dateTimePrinter13 = dateTimeFormatter12.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean15 = dateTimeFormatterBuilder14.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder14.appendYear(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder18.appendFractionOfHour((int) (short) 100, 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendMinuteOfDay(12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (-1), chronology27);
        org.joda.time.DateTime dateTime30 = dateTime28.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property31 = dateTime30.year();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (-1), chronology33);
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime34);
        int int36 = dateTime30.compareTo((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime.Property property37 = dateTime34.yearOfCentury();
        int int38 = dateTime34.getSecondOfMinute();
        org.joda.time.DateTime dateTime40 = dateTime34.minusSeconds((-1));
        boolean boolean41 = gregorianChronology25.equals((java.lang.Object) dateTime34);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = dateTimeFormatter24.withChronology((org.joda.time.Chronology) gregorianChronology25);
        org.joda.time.format.DateTimeParser dateTimeParser43 = dateTimeFormatter24.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder23.appendOptional(dateTimeParser43);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter45 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology48 = null;
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime((long) (-1), chronology48);
        org.joda.time.DateTime dateTime51 = dateTime49.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property52 = dateTime51.year();
        org.joda.time.Chronology chronology54 = null;
        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((long) (-1), chronology54);
        org.joda.time.Chronology chronology56 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime55);
        int int57 = dateTime51.compareTo((org.joda.time.ReadableInstant) dateTime55);
        org.joda.time.DateTime.Property property58 = dateTime55.yearOfCentury();
        int int59 = dateTime55.getSecondOfMinute();
        org.joda.time.DateTime dateTime61 = dateTime55.minusSeconds((-1));
        boolean boolean62 = gregorianChronology46.equals((java.lang.Object) dateTime55);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter63 = dateTimeFormatter45.withChronology((org.joda.time.Chronology) gregorianChronology46);
        org.joda.time.format.DateTimeParser dateTimeParser64 = dateTimeFormatter45.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray65 = new org.joda.time.format.DateTimeParser[] { dateTimeParser43, dateTimeParser64 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder66 = dateTimeFormatterBuilder7.append(dateTimePrinter13, dateTimeParserArray65);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimePrinter13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 59 + "'", int38 == 59);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(dateTimeParser43);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatter45);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(chronology56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 59 + "'", int59 == 59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter63);
        org.junit.Assert.assertNotNull(dateTimeParser64);
        org.junit.Assert.assertNotNull(dateTimeParserArray65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder66);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        boolean boolean33 = offsetDateTimeField26.isLenient();
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField26.getAsShortText((long) 89, locale35);
        int int38 = offsetDateTimeField26.getMaximumValue((long) 2067);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "2067" + "'", str36.equals("2067"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 292279090 + "'", int38 == 292279090);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType24);
        int int27 = offsetDateTimeField13.get(1560632677806L);
        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay((long) (short) 10);
        org.joda.time.MonthDay.Property property30 = monthDay29.dayOfMonth();
        int int31 = offsetDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) monthDay29);
        int int32 = offsetDateTimeField13.getOffset();
        long long34 = offsetDateTimeField13.roundCeiling((-1L));
        java.util.Locale locale36 = null;
        java.lang.String str37 = offsetDateTimeField13.getAsShortText(0L, locale36);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2116 + "'", int27 == 2116);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 292279090 + "'", int31 == 292279090);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 97 + "'", int32 == 97);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 31535999990L + "'", long34 == 31535999990L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "2067" + "'", str37.equals("2067"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("Property[yearOfEra]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[yearOfEra]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        java.lang.String str29 = unsupportedDateTimeField28.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long38 = fixedDateTimeZone34.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant39 = null;
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone34, readableInstant39);
        org.joda.time.MonthDay monthDay41 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        org.joda.time.MonthDay monthDay43 = monthDay41.minusMonths(100);
        try {
            int int44 = unsupportedDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) monthDay41);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "UnsupportedDateTimeField" + "'", str29.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-9L) + "'", long38 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(monthDay43);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property15.getAsText(locale16);
        int int18 = property15.getMinimumValueOverall();
        java.util.Locale locale19 = null;
        int int20 = property15.getMaximumShortTextLength(locale19);
        org.joda.time.MonthDay monthDay21 = property15.getMonthDay();
        int int22 = property15.get();
        java.util.Locale locale23 = null;
        int int24 = property15.getMaximumShortTextLength(locale23);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June" + "'", str17.equals("June"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1969", (java.lang.Number) 10.0f, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 1);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException4.getSuppressed();
        java.lang.String str8 = illegalFieldValueException4.getFieldName();
        illegalFieldValueException4.prependMessage("June");
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
        java.lang.String str15 = property13.getAsString();
        org.joda.time.DurationField durationField16 = property13.getDurationField();
        org.joda.time.DateTime dateTime17 = property13.withMinimumValue();
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone19 = copticChronology18.getZone();
        org.joda.time.DurationField durationField20 = copticChronology18.centuries();
        org.joda.time.MutableDateTime mutableDateTime21 = dateTime17.toMutableDateTime((org.joda.time.Chronology) copticChronology18);
        java.util.Date date22 = dateTime17.toDate();
        org.joda.time.DateTime dateTime23 = dateTime17.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), chronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property16 = dateTime15.year();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), chronology18);
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime19);
        int int21 = dateTime15.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime.Property property22 = dateTime19.yearOfCentury();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), chronology24);
        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property28 = dateTime27.year();
        int int29 = property28.getMaximumValue();
        java.util.Locale locale30 = null;
        java.lang.String str31 = property28.getAsText(locale30);
        org.joda.time.DateTime dateTime33 = property28.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay34 = dateTime33.toTimeOfDay();
        boolean boolean35 = dateTime19.isBefore((org.joda.time.ReadableInstant) dateTime33);
        int int36 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean38 = cachedDateTimeZone37.isFixed();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) cachedDateTimeZone37);
        org.joda.time.Chronology chronology41 = null;
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) (-1), chronology41);
        org.joda.time.ReadableDuration readableDuration43 = null;
        org.joda.time.DateTime dateTime45 = dateTime42.withDurationAdded(readableDuration43, 0);
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (-1), chronology47);
        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime48);
        org.joda.time.DateTimeZone dateTimeZone50 = dateTime48.getZone();
        java.util.TimeZone timeZone51 = dateTimeZone50.toTimeZone();
        org.joda.time.DateTime dateTime52 = dateTime45.toDateTime(dateTimeZone50);
        org.joda.time.DateTime.Property property53 = dateTime45.yearOfEra();
        org.joda.time.DateTime dateTime55 = dateTime45.plusYears((int) (byte) 100);
        boolean boolean56 = cachedDateTimeZone37.equals((java.lang.Object) (byte) 100);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 292278993 + "'", int29 == 292278993);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969" + "'", str31.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(timeOfDay34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusMillis(10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology(chronology16);
        org.joda.time.DateTime dateTime18 = dateTime5.withChronology(chronology16);
        org.joda.time.Chronology chronology19 = dateTime18.getChronology();
        org.joda.time.Chronology chronology20 = dateTime18.getChronology();
        org.joda.time.DateTime dateTime21 = dateTime18.toDateTimeISO();
        org.joda.time.DateTime.Property property22 = dateTime18.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone19 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long23 = fixedDateTimeZone19.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone19, readableInstant24);
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (-1), chronology27);
        org.joda.time.DateTime dateTime30 = dateTime28.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property31 = dateTime30.year();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (-1), chronology33);
        org.joda.time.Chronology chronology35 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime34);
        int int36 = dateTime30.compareTo((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.DateTime.Property property37 = dateTime34.yearOfCentury();
        org.joda.time.Chronology chronology39 = null;
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) (-1), chronology39);
        org.joda.time.DateTime dateTime42 = dateTime40.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property43 = dateTime42.year();
        int int44 = property43.getMaximumValue();
        java.util.Locale locale45 = null;
        java.lang.String str46 = property43.getAsText(locale45);
        org.joda.time.DateTime dateTime48 = property43.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay49 = dateTime48.toTimeOfDay();
        boolean boolean50 = dateTime34.isBefore((org.joda.time.ReadableInstant) dateTime48);
        int int51 = fixedDateTimeZone19.getOffset((org.joda.time.ReadableInstant) dateTime48);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone52 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone19);
        boolean boolean53 = cachedDateTimeZone52.isFixed();
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) cachedDateTimeZone52);
        org.joda.time.Chronology chronology56 = null;
        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) (-1), chronology56);
        org.joda.time.DateTime dateTime59 = dateTime57.plusWeeks((int) (short) -1);
        int int60 = dateTime59.getDayOfMonth();
        org.joda.time.DateTime dateTime62 = dateTime59.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology63 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField64 = copticChronology63.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField64);
        long long68 = delegatedDateTimeField65.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType69 = delegatedDateTimeField65.getType();
        int int70 = dateTime59.get(dateTimeFieldType69);
        boolean boolean71 = dateTime54.equals((java.lang.Object) dateTimeFieldType69);
        try {
            org.joda.time.MonthDay monthDay73 = monthDay12.withField(dateTimeFieldType69, 3382);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-9L) + "'", long23 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 292278993 + "'", int44 == 292278993);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "1969" + "'", str46.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(timeOfDay49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 10 + "'", int51 == 10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 24 + "'", int60 == 24);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(copticChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 292278122L + "'", long68 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 999 + "'", int70 == 999);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(9, 358, (int) (short) -1, 15, 6, (int) '#', 718790);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 718790 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfHour();
        org.joda.time.DurationField durationField3 = copticChronology0.hours();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long12 = fixedDateTimeZone8.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone8, readableInstant13);
        org.joda.time.DateTimeField dateTimeField15 = gJChronology14.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) 'a');
        long long19 = offsetDateTimeField17.roundCeiling(10L);
        long long21 = offsetDateTimeField17.roundCeiling(0L);
        long long23 = offsetDateTimeField17.roundFloor((long) 'a');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long32 = fixedDateTimeZone28.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone28, readableInstant33);
        org.joda.time.MonthDay monthDay35 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        org.joda.time.MonthDay monthDay37 = monthDay35.withDayOfMonth((int) (short) 1);
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) monthDay35, (int) '4', locale39);
        boolean boolean41 = copticChronology0.equals((java.lang.Object) str40);
        int int42 = copticChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-9L) + "'", long12 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 31535999990L + "'", long19 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 31535999990L + "'", long21 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-10L) + "'", long23 == (-10L));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-9L) + "'", long32 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "52" + "'", str40.equals("52"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        java.lang.String str8 = fixedDateTimeZone6.getNameKey((long) (short) 10);
        long long10 = fixedDateTimeZone6.previousTransition((long) (short) 1);
        org.joda.time.Chronology chronology11 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        java.lang.String str12 = fixedDateTimeZone6.getID();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property15.getAsText(locale16);
        int int18 = property15.getMinimumValueOverall();
        java.util.Locale locale19 = null;
        int int20 = property15.getMaximumShortTextLength(locale19);
        java.lang.String str21 = property15.getAsString();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June" + "'", str17.equals("June"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "6" + "'", str21.equals("6"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendFractionOfDay(12, 3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendHourOfDay(9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder7.appendFractionOfDay(999, (-1));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean14 = dateTimeFormatterBuilder13.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendYear(0, (int) '#');
        org.joda.time.format.DateTimePrinter dateTimePrinter18 = dateTimeFormatterBuilder13.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean20 = dateTimeFormatterBuilder19.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder19.appendYear(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder23.appendFractionOfHour((int) (short) 100, 24);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendMinuteOfDay(12);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (-1), chronology32);
        org.joda.time.DateTime dateTime35 = dateTime33.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property36 = dateTime35.year();
        org.joda.time.Chronology chronology38 = null;
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (-1), chronology38);
        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime39);
        int int41 = dateTime35.compareTo((org.joda.time.ReadableInstant) dateTime39);
        org.joda.time.DateTime.Property property42 = dateTime39.yearOfCentury();
        int int43 = dateTime39.getSecondOfMinute();
        org.joda.time.DateTime dateTime45 = dateTime39.minusSeconds((-1));
        boolean boolean46 = gregorianChronology30.equals((java.lang.Object) dateTime39);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = dateTimeFormatter29.withChronology((org.joda.time.Chronology) gregorianChronology30);
        org.joda.time.format.DateTimeParser dateTimeParser48 = dateTimeFormatter29.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder28.appendOptional(dateTimeParser48);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder12.append(dateTimePrinter18, dateTimeParser48);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder50.appendHourOfDay(9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimePrinter18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 59 + "'", int43 == 59);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter47);
        org.junit.Assert.assertNotNull(dateTimeParser48);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property15.getAsText(locale16);
        int int18 = property15.getMaximumValue();
        java.lang.String str19 = property15.toString();
        java.lang.String str20 = property15.getAsShortText();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June" + "'", str17.equals("June"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 12 + "'", int18 == 12);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Property[monthOfYear]" + "'", str19.equals("Property[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Jun" + "'", str20.equals("Jun"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology10.monthOfYear();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology10.weekyearOfCentury();
        try {
            long long22 = gJChronology10.getDateTimeMillis((int) 'a', 6, (int) (short) 0, 358, 2000, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 358 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(24, (int) (short) 1, (-98), 58, (-98), (int) (byte) -1, 166);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        int int26 = dateTime22.getYearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime28 = dateTime22.plus(readablePeriod27);
        org.joda.time.DateTime dateTime29 = dateTime28.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (short) 10);
        try {
            java.lang.String str3 = monthDay1.toString("UnsupportedDateTimeField");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: U");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(86399);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(34, true);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay13 = monthDay11.minusMonths(100);
        org.joda.time.MonthDay monthDay15 = monthDay11.plusDays(1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(monthDay15);
    }
}

