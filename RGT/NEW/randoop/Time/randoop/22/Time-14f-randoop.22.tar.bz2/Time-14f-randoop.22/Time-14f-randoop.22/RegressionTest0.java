import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test005");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.Chronology chronology1 = null;
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((java.lang.Object) (short) 1, chronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test007");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
//        java.lang.String str2 = dateTimeFormatter0.print((-1L));
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "3:59:59 PM PST" + "'", str2.equals("3:59:59 PM PST"));
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTimeField dateTimeField4 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField(chronology3, dateTimeField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValue();
        try {
            org.joda.time.DateTime dateTime8 = property5.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("3:59:59 PM PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"3:59:59 PM PST\" is malformed at \":59:59 PM PST\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        try {
            long long2 = dateTimeFormatter0.parseMillis("1969");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-1), (int) (short) 10, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime2.getZone();
        org.joda.time.LocalTime localTime5 = dateTime2.toLocalTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        try {
            java.lang.String str7 = localTime5.toString(dateTimeFormatter6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime2.getZone();
        try {
            org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), chronology2);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10, chronology4);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            int int7 = dateTime5.get(dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) '4', (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 53L + "'", long2 == 53L);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test023");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560632677806L + "'", long0 == 1560632677806L);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        int int0 = org.joda.time.MonthDay.DAY_OF_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        try {
            org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), chronology2);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTime3.getZone();
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 10, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(53L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 53 + "'", int1 == 53);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), chronology2);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10, chronology4);
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withDayOfWeek((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.DateTime dateTime6 = dateTime2.withFieldAdded(durationFieldType4, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        try {
            org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (long) (short) 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 97");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Locale locale13 = null;
        try {
            java.lang.String str14 = monthDay11.toString("", locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((int) (byte) 1, (int) (byte) -1, (int) (short) -1, (int) '4', (int) ' ', (int) (byte) 100, chronology9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (long) 3, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        long long15 = durationField12.subtract(100L, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-31556476799900L) + "'", long15 == (-31556476799900L));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), chronology2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withDurationAdded(readableDuration4, 0);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (-1), chronology8);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime9.getZone();
        java.util.TimeZone timeZone12 = dateTimeZone11.toTimeZone();
        org.joda.time.DateTime dateTime13 = dateTime6.toDateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property14 = dateTime6.yearOfEra();
        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
        java.lang.String str16 = property14.getAsString();
        org.joda.time.DurationField durationField17 = property14.getDurationField();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (-1), chronology19);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, 0);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (-1), chronology25);
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTimeZone dateTimeZone28 = dateTime26.getZone();
        java.util.TimeZone timeZone29 = dateTimeZone28.toTimeZone();
        org.joda.time.DateTime dateTime30 = dateTime23.toDateTime(dateTimeZone28);
        org.joda.time.DateTime.Property property31 = dateTime23.yearOfEra();
        org.joda.time.DurationField durationField32 = property31.getRangeDurationField();
        java.lang.String str33 = property31.getAsString();
        org.joda.time.DurationField durationField34 = property31.getDurationField();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField35 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField17, durationField34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNull(durationField32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1969" + "'", str33.equals("1969"));
        org.junit.Assert.assertNotNull(durationField34);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        long long3 = dateTimeZone1.convertUTCToLocal((long) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-3599999L) + "'", long3 == (-3599999L));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.Chronology chronology19 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTimeZone dateTimeZone20 = dateTime18.getZone();
        org.joda.time.LocalTime localTime21 = dateTime18.toLocalTime();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime24.getZone();
        org.joda.time.LocalTime localTime27 = dateTime24.toLocalTime();
        boolean boolean28 = localTime21.isEqual((org.joda.time.ReadablePartial) localTime27);
        int[] intArray35 = new int[] { 'a', (byte) -1, 292278993, '#', (short) 100 };
        try {
            int[] intArray37 = offsetDateTimeField13.addWrapPartial((org.joda.time.ReadablePartial) localTime27, (int) ' ', intArray35, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(localTime21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(localTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(intArray35);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("1969", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        try {
            org.joda.time.DateTime dateTime18 = dateTime5.withTime((int) (short) -1, (int) (byte) -1, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
//        java.lang.String str2 = dateTimeFormatter0.print((long) (short) 10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Wednesday, December 31, 1969 4:00:00 PM PST" + "'", str2.equals("Wednesday, December 31, 1969 4:00:00 PM PST"));
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.LocalDateTime localDateTime2 = null;
        try {
            boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.junit.Assert.assertNotNull(mutableDateTime1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("1969");
        try {
            org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        try {
            long long6 = copticChronology0.getDateTimeMillis(0, 3, (int) (short) -1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now();
        int[] intArray22 = new int[] { (short) 10, (byte) 100, (short) 100, 98 };
        try {
            int[] intArray24 = offsetDateTimeField13.add((org.joda.time.ReadablePartial) monthDay16, 98, intArray22, 24);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 98");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now();
        boolean boolean2 = monthDay0.isEqual((org.joda.time.ReadablePartial) monthDay1);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType4 = monthDay1.getFieldType(3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded(readableDuration15, 0);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (-1), chronology19);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime20.getZone();
        java.util.TimeZone timeZone23 = dateTimeZone22.toTimeZone();
        org.joda.time.DateTime dateTime24 = dateTime17.toDateTime(dateTimeZone22);
        org.joda.time.DateTime.Property property25 = dateTime17.yearOfEra();
        org.joda.time.DateTime dateTime27 = dateTime17.minusDays(0);
        org.joda.time.Chronology chronology29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (-1), chronology29);
        org.joda.time.DateTime dateTime32 = dateTime30.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property33 = dateTime32.year();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) (-1), chronology35);
        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime36);
        int int38 = dateTime32.compareTo((org.joda.time.ReadableInstant) dateTime36);
        org.joda.time.DateTime.Property property39 = dateTime36.yearOfCentury();
        boolean boolean40 = dateTime17.isEqual((org.joda.time.ReadableInstant) dateTime36);
        try {
            org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) dateTime17, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        try {
            long long35 = skipUndoDateTimeField32.set((long) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [98,292279090]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int18 = fixedDateTimeZone16.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        int int20 = monthDay11.compareTo((org.joda.time.ReadablePartial) monthDay19);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        try {
            org.joda.time.MonthDay monthDay23 = monthDay11.withFieldAdded(durationFieldType21, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime2.getZone();
        org.joda.time.LocalTime localTime5 = dateTime2.toLocalTime();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        org.joda.time.LocalTime localTime11 = dateTime8.toLocalTime();
        boolean boolean12 = localTime5.isEqual((org.joda.time.ReadablePartial) localTime11);
        try {
            org.joda.time.DateTimeField dateTimeField14 = localTime5.getField((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 100");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(localTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(localTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(98, 0, 10, 24, (int) 'a', (int) 'a', dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        try {
            long long22 = offsetDateTimeField13.set((long) 59, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [98,292279090]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
        java.lang.String str15 = property13.getAsString();
        org.joda.time.DurationField durationField16 = property13.getDurationField();
        org.joda.time.DateTime dateTime17 = property13.withMinimumValue();
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone19 = copticChronology18.getZone();
        org.joda.time.DurationField durationField20 = copticChronology18.centuries();
        org.joda.time.MutableDateTime mutableDateTime21 = dateTime17.toMutableDateTime((org.joda.time.Chronology) copticChronology18);
        try {
            long long29 = copticChronology18.getDateTimeMillis(53, (int) (byte) 0, (int) (byte) -1, 59, 292279090, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        int int33 = skipUndoDateTimeField32.getMaximumValue();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long42 = fixedDateTimeZone38.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone38, readableInstant43);
        org.joda.time.MonthDay monthDay45 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone38);
        java.util.Locale locale46 = null;
        try {
            java.lang.String str47 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) monthDay45, locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 292279090 + "'", int33 == 292279090);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-9L) + "'", long42 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(monthDay45);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.Interval interval14 = property13.toInterval();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean16 = property13.equals((java.lang.Object) dateTimeFormatter15);
        java.io.Writer writer17 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long26 = fixedDateTimeZone22.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone22, readableInstant27);
        org.joda.time.MonthDay monthDay29 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        try {
            dateTimeFormatter15.printTo(writer17, (org.joda.time.ReadablePartial) monthDay29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(interval14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-9L) + "'", long26 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(monthDay29);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime dateTime6 = dateTime2.plusWeeks(0);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.DateTime dateTime9 = dateTime2.withField(dateTimeFieldType7, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        int int7 = property5.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            int int12 = dateTime4.get(dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.years();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("2019-06-15T21:04:46.111Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        boolean boolean12 = property11.isLeap();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        int int3 = dateTime2.getDayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime2.toMutableDateTime();
        try {
            java.lang.String str6 = dateTime2.toString("Wednesday, December 31, 1969 4:00:00 PM PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: W");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime2.getZone();
        java.util.TimeZone timeZone5 = dateTimeZone4.toTimeZone();
        long long7 = dateTimeZone4.convertUTCToLocal((long) 0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-28800000L) + "'", long7 == (-28800000L));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (-1), chronology6);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded(readableDuration8, 0);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), chronology12);
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTimeZone dateTimeZone15 = dateTime13.getZone();
        java.util.TimeZone timeZone16 = dateTimeZone15.toTimeZone();
        org.joda.time.DateTime dateTime17 = dateTime10.toDateTime(dateTimeZone15);
        org.joda.time.DateTime.Property property18 = dateTime10.yearOfEra();
        org.joda.time.DateTime dateTime20 = dateTime10.minusDays(0);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (-1), chronology22);
        org.joda.time.DateTime dateTime25 = dateTime23.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property26 = dateTime25.year();
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (-1), chronology28);
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime29);
        int int31 = dateTime25.compareTo((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime.Property property32 = dateTime29.yearOfCentury();
        boolean boolean33 = dateTime10.isEqual((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long42 = fixedDateTimeZone38.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone38, readableInstant43);
        org.joda.time.MonthDay monthDay45 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone38);
        org.joda.time.DateTime dateTime46 = dateTime10.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone38);
        try {
            org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(9, (-1), (int) 'a', 59, (int) '4', (org.joda.time.DateTimeZone) fixedDateTimeZone38);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-9L) + "'", long42 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertNotNull(dateTime46);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now();
        boolean boolean2 = monthDay0.isEqual((org.joda.time.ReadablePartial) monthDay1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay4 = monthDay0.plus(readablePeriod3);
        java.util.Locale locale6 = null;
        try {
            java.lang.String str7 = monthDay4.toString("3:59:59 PM PST", locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(monthDay4);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Chronology chronology1 = instant0.getChronology();
//        java.lang.String str2 = instant0.toString();
//        long long3 = instant0.getMillis();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15T21:04:47.348Z" + "'", str2.equals("2019-06-15T21:04:47.348Z"));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560632687348L + "'", long3 == 1560632687348L);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
        java.lang.String str15 = property13.getAsString();
        org.joda.time.DurationField durationField16 = property13.getDurationField();
        org.joda.time.DateTime dateTime17 = property13.withMinimumValue();
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone19 = copticChronology18.getZone();
        org.joda.time.DurationField durationField20 = copticChronology18.centuries();
        org.joda.time.MutableDateTime mutableDateTime21 = dateTime17.toMutableDateTime((org.joda.time.Chronology) copticChronology18);
        try {
            int int22 = mutableDateTime21.getYearOfEra();
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 59, (int) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3068L + "'", long2 == 3068L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfCentury();
        boolean boolean28 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime24);
        java.util.GregorianCalendar gregorianCalendar29 = dateTime24.toGregorianCalendar();
        org.joda.time.MonthDay monthDay30 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar29);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        try {
            org.joda.time.MonthDay monthDay33 = monthDay30.withField(dateTimeFieldType31, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar29);
        org.junit.Assert.assertNotNull(monthDay30);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, (long) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        java.lang.Object obj22 = null;
        boolean boolean23 = fixedDateTimeZone15.equals(obj22);
        long long25 = fixedDateTimeZone15.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology26 = gJChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        try {
            long long34 = gJChronology10.getDateTimeMillis((int) (byte) -1, 3, 59, 292279090, (int) (byte) 1, 3, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279090 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31556476799900L) + "'", long25 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfCentury();
        boolean boolean28 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime24);
        int int29 = dateTime24.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        try {
            long long2 = dateTimeFormatter0.parseMillis("-01:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-01:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        int int3 = dateTime2.getDayOfYear();
//        try {
//            org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime2, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 166 + "'", int3 == 166);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((-1), (int) (byte) -1, (int) (byte) 10, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 89 + "'", int4 == 89);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = skipUndoDateTimeField32.getWrappedField();
        long long35 = skipUndoDateTimeField32.roundFloor((long) (byte) 100);
        long long37 = skipUndoDateTimeField32.roundHalfEven((long) 100);
        int int38 = skipUndoDateTimeField32.getMinimumValue();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-10L) + "'", long35 == (-10L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-10L) + "'", long37 == (-10L));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 98 + "'", int38 == 98);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay15 = org.joda.time.MonthDay.now();
        boolean boolean16 = monthDay14.isEqual((org.joda.time.ReadablePartial) monthDay15);
        int[] intArray18 = null;
        java.util.Locale locale20 = null;
        try {
            int[] intArray21 = offsetDateTimeField13.set((org.joda.time.ReadablePartial) monthDay14, (int) (short) -1, intArray18, "+00:00:00.010", locale20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00:00.010\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 53, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 530L + "'", long2 == 530L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        java.util.Locale locale16 = null;
        try {
            long long17 = offsetDateTimeField13.set((long) (-1), "+00:00:00.010", locale16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00:00.010\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.lang.String str2 = dateTimeFormatter0.print((long) ' ');
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "160000-0800" + "'", str2.equals("160000-0800"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DurationField durationField14 = property13.getRangeDurationField();
        java.lang.String str15 = property13.getAsString();
        org.joda.time.DurationField durationField16 = property13.getDurationField();
        org.joda.time.DateTime dateTime17 = property13.withMinimumValue();
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone19 = copticChronology18.getZone();
        org.joda.time.DurationField durationField20 = copticChronology18.centuries();
        org.joda.time.MutableDateTime mutableDateTime21 = dateTime17.toMutableDateTime((org.joda.time.Chronology) copticChronology18);
        boolean boolean22 = dateTime17.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(mutableDateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.longTime();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("0", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"0\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int18 = fixedDateTimeZone16.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        int int20 = monthDay11.compareTo((org.joda.time.ReadablePartial) monthDay19);
        org.joda.time.MonthDay monthDay22 = monthDay11.minusMonths(0);
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology23.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
        long long28 = delegatedDateTimeField25.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = delegatedDateTimeField25.getType();
        try {
            int int30 = monthDay22.get(dateTimeFieldType29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 292278122L + "'", long28 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        try {
            org.joda.time.DateTime dateTime17 = dateTime5.withDate((int) (short) 10, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now();
        boolean boolean2 = monthDay0.isEqual((org.joda.time.ReadablePartial) monthDay1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField4 = copticChronology3.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField5 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField4);
        long long8 = delegatedDateTimeField5.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = delegatedDateTimeField5.getType();
        try {
            int int10 = monthDay0.get(dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(copticChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 292278122L + "'", long8 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test108");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Chronology chronology1 = instant0.getChronology();
//        java.lang.String str2 = instant0.toString();
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), chronology5);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusWeeks((int) (short) -1);
//        org.joda.time.DateTime.Property property9 = dateTime8.year();
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (-1), chronology11);
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime12);
//        int int14 = dateTime8.compareTo((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime.Property property15 = dateTime12.yearOfCentury();
//        int int16 = dateTime12.getSecondOfMinute();
//        org.joda.time.DateTime dateTime18 = dateTime12.minusSeconds((-1));
//        boolean boolean19 = gregorianChronology3.equals((java.lang.Object) dateTime12);
//        org.joda.time.MutableDateTime mutableDateTime20 = instant0.toMutableDateTime((org.joda.time.Chronology) gregorianChronology3);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019-06-15T21:04:52.040Z" + "'", str2.equals("2019-06-15T21:04:52.040Z"));
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 59 + "'", int16 == 59);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(mutableDateTime20);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant0.minus(readableDuration2);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(4, (int) (byte) 10, (int) (byte) -1, (int) (short) 10, 3, 24);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.Interval interval14 = property13.toInterval();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean16 = property13.equals((java.lang.Object) dateTimeFormatter15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        try {
            int int18 = property13.compareTo(readableInstant17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(interval14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(1);
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.getMinimumValue((long) (byte) 10);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField2.getAsShortText((int) (byte) 0, locale6);
        int int8 = delegatedDateTimeField2.getMinimumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.year();
        try {
            long long7 = copticChronology0.getDateTimeMillis(57599999, 100, (int) (short) -1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DurationField durationField33 = skipUndoDateTimeField32.getRangeDurationField();
        java.util.Locale locale36 = null;
        try {
            long long37 = skipUndoDateTimeField32.set(0L, "hi!", locale36);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"hi!\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNull(durationField33);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("+00:00:00.010", 31, 999, 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for +00:00:00.010 must be in the range [999,9]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int22 = offsetDateTimeField13.getMaximumValue();
        int int24 = offsetDateTimeField13.getMinimumValue((-9L));
        long long26 = offsetDateTimeField13.roundHalfEven((long) 3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292279090 + "'", int22 == 292279090);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 98 + "'", int24 == 98);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-10L) + "'", long26 == (-10L));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int22 = offsetDateTimeField13.getMaximumValue();
        int int23 = offsetDateTimeField13.getMinimumValue();
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now();
        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField27 = copticChronology26.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27);
        long long31 = delegatedDateTimeField28.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now();
        boolean boolean34 = monthDay32.isEqual((org.joda.time.ReadablePartial) monthDay33);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.MonthDay monthDay36 = monthDay32.plus(readablePeriod35);
        int[] intArray38 = new int[] { 0 };
        int int39 = delegatedDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) monthDay36, intArray38);
        try {
            int[] intArray41 = offsetDateTimeField13.set((org.joda.time.ReadablePartial) monthDay24, 100, intArray38, 31);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for yearOfEra must be in the range [98,292279090]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292279090 + "'", int22 == 292279090);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(copticChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 292278122L + "'", long31 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 999 + "'", int39 == 999);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long4 = delegatedDateTimeField2.roundHalfFloor(3068L);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long13 = fixedDateTimeZone9.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone9, readableInstant14);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int23 = fixedDateTimeZone21.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        int int25 = monthDay16.compareTo((org.joda.time.ReadablePartial) monthDay24);
        org.joda.time.MonthDay monthDay27 = monthDay16.minusMonths(0);
        org.joda.time.MonthDay monthDay29 = monthDay27.plusMonths((int) (short) 0);
        java.util.Locale locale30 = null;
        try {
            java.lang.String str31 = delegatedDateTimeField2.getAsText((org.joda.time.ReadablePartial) monthDay29, locale30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3068L + "'", long4 == 3068L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-9L) + "'", long13 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(monthDay29);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.DateTime dateTime17 = dateTime15.minusHours((int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19);
        long long23 = delegatedDateTimeField20.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField20.getType();
        org.joda.time.DateTime.Property property25 = dateTime15.property(dateTimeFieldType24);
        org.joda.time.chrono.CopticChronology copticChronology26 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone27 = copticChronology26.getZone();
        org.joda.time.DurationField durationField28 = copticChronology26.halfdays();
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone30 = copticChronology29.getZone();
        org.joda.time.DurationField durationField31 = copticChronology29.centuries();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField32 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType24, durationField28, durationField31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 292278122L + "'", long23 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(copticChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(durationField31);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), chronology2);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10, chronology4);
        try {
            org.joda.time.DateTime dateTime7 = dateTime5.withEra(999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = gJChronology10.monthOfYear();
        try {
            long long41 = gJChronology10.getDateTimeMillis(59, 0, (int) '#', (int) (byte) 10, 2, (int) (short) 0, (-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property18 = dateTime17.year();
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (-1), chronology20);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime21);
        int int23 = dateTime17.compareTo((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property24 = dateTime21.yearOfCentury();
        int int25 = dateTime21.getSecondOfMinute();
        org.joda.time.DateTime dateTime27 = dateTime21.minusSeconds((-1));
        org.joda.time.DateTime dateTime29 = dateTime21.withYearOfCentury(24);
        int int30 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime29);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 59 + "'", int25 == 59);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField2 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField13.getAsShortText(52L, locale15);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2067" + "'", str16.equals("2067"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.DateTime dateTime17 = dateTime15.minusHours((int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19);
        long long23 = delegatedDateTimeField20.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField20.getType();
        org.joda.time.DateTime.Property property25 = dateTime15.property(dateTimeFieldType24);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone30 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long34 = fixedDateTimeZone30.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone30, readableInstant35);
        org.joda.time.MonthDay monthDay37 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone30);
        try {
            int int38 = property25.compareTo((org.joda.time.ReadablePartial) monthDay37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 292278122L + "'", long23 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-9L) + "'", long34 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(monthDay37);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime4.dayOfYear();
        int int12 = property11.get();
        try {
            org.joda.time.DateTime dateTime14 = property11.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 358 + "'", int12 == 358);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int22 = offsetDateTimeField13.getMaximumValue();
        int int24 = offsetDateTimeField13.getMinimumValue((-9L));
        java.util.Locale locale25 = null;
        int int26 = offsetDateTimeField13.getMaximumShortTextLength(locale25);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292279090 + "'", int22 == 292279090);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 98 + "'", int24 == 98);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 9 + "'", int26 == 9);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) copticChronology0);
        try {
            long long9 = copticChronology0.getDateTimeMillis(0L, (int) ' ', (int) (short) 10, 366, (-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology1.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField3 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2);
        long long6 = delegatedDateTimeField3.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = delegatedDateTimeField3.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField8 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 292278122L + "'", long6 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = delegatedDateTimeField2.getType();
        try {
            long long9 = delegatedDateTimeField2.set((long) (byte) 0, 1099);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1099 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        int int33 = skipUndoDateTimeField32.getMaximumValue();
        org.joda.time.DurationField durationField34 = skipUndoDateTimeField32.getLeapDurationField();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 292279090 + "'", int33 == 292279090);
        org.junit.Assert.assertNull(durationField34);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType24);
        int int27 = offsetDateTimeField13.get(1560632677806L);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone32 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int34 = fixedDateTimeZone32.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone32);
        int[] intArray41 = new int[] { 53, 57599999, (-54), '4' };
        java.util.Locale locale43 = null;
        try {
            int[] intArray44 = offsetDateTimeField13.set((org.joda.time.ReadablePartial) monthDay35, (int) (byte) 0, intArray41, "Wednesday, December 31, 1969 4:00:00 PM PST", locale43);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Wednesday, December 31, 1969 4:00:00 PM PST\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2116 + "'", int27 == 2116);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertNotNull(intArray41);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology(chronology2);
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((int) (byte) 1, 9, chronology3);
        try {
            org.joda.time.MonthDay monthDay6 = monthDay4.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("2019-06-15T21:04:47.348Z", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 2019-06-15T21:04:47.348Z");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        java.lang.String str13 = fixedDateTimeZone5.getName((long) 'a');
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance(chronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00:00.010" + "'", str13.equals("+00:00:00.010"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        org.joda.time.MonthDay monthDay17 = monthDay14.plusMonths((-292275054));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(monthDay17);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfCentury();
        boolean boolean28 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime24);
        try {
            org.joda.time.DateTime dateTime30 = dateTime5.withMonthOfYear(53);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 53 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.DateTime dateTime17 = dateTime15.minusHours((int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19);
        long long23 = delegatedDateTimeField20.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField20.getType();
        org.joda.time.DateTime.Property property25 = dateTime15.property(dateTimeFieldType24);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) (-25200000), (java.lang.Number) (-32400000L), (java.lang.Number) 100.0f);
        org.joda.time.DurationFieldType durationFieldType30 = illegalFieldValueException29.getDurationFieldType();
        java.lang.String str31 = illegalFieldValueException29.getIllegalStringValue();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 292278122L + "'", long23 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNull(durationFieldType30);
        org.junit.Assert.assertNull(str31);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValue();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        org.joda.time.DateTime dateTime10 = property5.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay11 = dateTime10.toTimeOfDay();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime14.getZone();
        org.joda.time.LocalTime localTime17 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        int int19 = dateTime10.getMillisOfDay();
        try {
            org.joda.time.DateTime dateTime21 = dateTime10.withDayOfYear(292279090);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279090 for dayOfYear must be in the range [1,366]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(timeOfDay11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57599999 + "'", int19 == 57599999);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusMillis(10);
        org.joda.time.DateTime.Property property16 = dateTime5.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.DateTime dateTime17 = dateTime15.minusHours((int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19);
        long long23 = delegatedDateTimeField20.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField20.getType();
        org.joda.time.DateTime.Property property25 = dateTime15.property(dateTimeFieldType24);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType24, 292278993, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for millisOfSecond must be in the range [0,97]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 292278122L + "'", long23 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(property25);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.DateTime dateTime17 = dateTime15.minusHours((int) (byte) 100);
        org.joda.time.DateTime dateTime19 = dateTime15.plusMillis(98);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int0 = org.joda.time.MonthDay.MONTH_OF_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (-1), chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.year();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), chronology9);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        int int12 = dateTime6.compareTo((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        int int14 = dateTime10.getSecondOfMinute();
        org.joda.time.DateTime dateTime16 = dateTime10.minusSeconds((-1));
        boolean boolean17 = gregorianChronology1.equals((java.lang.Object) dateTime10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology1);
        try {
            long long26 = gregorianChronology1.getDateTimeMillis((int) (short) -1, 53, 0, 0, (int) (byte) 100, 366, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter18);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        java.lang.Object obj22 = null;
        boolean boolean23 = fixedDateTimeZone15.equals(obj22);
        long long25 = fixedDateTimeZone15.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology26 = gJChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long35 = fixedDateTimeZone31.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant36 = null;
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone31, readableInstant36);
        org.joda.time.DurationField durationField38 = gJChronology37.millis();
        org.joda.time.DurationField durationField39 = gJChronology37.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone44 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long48 = fixedDateTimeZone44.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant49 = null;
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone44, readableInstant49);
        org.joda.time.DateTimeField dateTimeField51 = gJChronology50.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) 'a');
        long long55 = offsetDateTimeField53.roundCeiling(10L);
        long long57 = offsetDateTimeField53.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField59 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology37, (org.joda.time.DateTimeField) offsetDateTimeField53, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField60 = gJChronology37.monthOfYear();
        boolean boolean61 = fixedDateTimeZone15.equals((java.lang.Object) gJChronology37);
        org.joda.time.Chronology chronology62 = gJChronology37.withUTC();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31556476799900L) + "'", long25 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-9L) + "'", long35 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-9L) + "'", long48 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 31535999990L + "'", long55 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 31535999990L + "'", long57 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(chronology62);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(100, 1099, 0, 2, 0, (int) (short) 0, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1099 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long14 = fixedDateTimeZone10.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10, readableInstant15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long25 = fixedDateTimeZone21.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone21, readableInstant26);
        java.lang.Object obj28 = null;
        boolean boolean29 = fixedDateTimeZone21.equals(obj28);
        long long31 = fixedDateTimeZone21.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology32 = gJChronology16.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        try {
            org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((int) (byte) 10, 999, (int) ' ', 4, (int) 'a', 98, chronology32);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-9L) + "'", long14 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-9L) + "'", long25 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-31556476799900L) + "'", long31 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology32);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long20 = fixedDateTimeZone16.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone16, readableInstant21);
        java.lang.Object obj23 = null;
        boolean boolean24 = fixedDateTimeZone16.equals(obj23);
        long long26 = fixedDateTimeZone16.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology27 = gJChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DateTimeField dateTimeField28 = gJChronology11.secondOfDay();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 0, (org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTimeField dateTimeField30 = gJChronology11.hourOfHalfday();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-9L) + "'", long20 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-31556476799900L) + "'", long26 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField30);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.plusYears((int) (byte) 100);
        boolean boolean16 = dateTime5.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) (short) 10);
        try {
            org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int18 = fixedDateTimeZone16.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        int int20 = monthDay11.compareTo((org.joda.time.ReadablePartial) monthDay19);
        try {
            java.lang.String str22 = monthDay19.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        java.lang.Object obj12 = null;
        boolean boolean13 = fixedDateTimeZone5.equals(obj12);
        long long15 = fixedDateTimeZone5.nextTransition((-31556476799900L));
        int int17 = fixedDateTimeZone5.getOffsetFromLocal((long) 2);
        org.joda.time.Chronology chronology18 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        try {
            long long26 = gregorianChronology0.getDateTimeMillis((-1), 10, (int) (short) 100, (int) '4', 1, 0, 2116);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-31556476799900L) + "'", long15 == (-31556476799900L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 1, 292278993, 53, (int) (short) 1, 9, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.plusYears((int) (byte) 100);
        try {
            org.joda.time.DateTime dateTime17 = dateTime15.withWeekOfWeekyear((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.util.Date date0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime8.minus(readablePeriod11);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone32 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int34 = fixedDateTimeZone32.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone32);
        int int36 = monthDay27.compareTo((org.joda.time.ReadablePartial) monthDay35);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone41 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long45 = fixedDateTimeZone41.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant46 = null;
        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone41, readableInstant46);
        org.joda.time.MonthDay monthDay48 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone41);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone53 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int55 = fixedDateTimeZone53.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay56 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone53);
        int int57 = monthDay48.compareTo((org.joda.time.ReadablePartial) monthDay56);
        org.joda.time.MonthDay monthDay59 = monthDay48.minusMonths(0);
        org.joda.time.MonthDay monthDay61 = monthDay59.plusMonths((int) (short) 0);
        int int62 = monthDay59.size();
        boolean boolean63 = monthDay27.isBefore((org.joda.time.ReadablePartial) monthDay59);
        int[] intArray69 = new int[] { 292278993, 166, 0, 365 };
        try {
            int[] intArray71 = offsetDateTimeField13.set((org.joda.time.ReadablePartial) monthDay27, 365, intArray69, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 365");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 10 + "'", int34 == 10);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-9L) + "'", long45 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology47);
        org.junit.Assert.assertNotNull(monthDay48);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 10 + "'", int55 == 10);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(monthDay59);
        org.junit.Assert.assertNotNull(monthDay61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2 + "'", int62 == 2);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(intArray69);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int11 = fixedDateTimeZone9.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str13 = fixedDateTimeZone9.getNameKey((long) 0);
        long long15 = fixedDateTimeZone9.previousTransition((-3599999L));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.MonthDay monthDay27 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.MonthDay monthDay30 = monthDay28.minusDays((int) (byte) -1);
        boolean boolean31 = fixedDateTimeZone9.equals((java.lang.Object) monthDay28);
        try {
            org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(366, (-25200000), (int) 'a', (int) '#', 9, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-3599999L) + "'", long15 == (-3599999L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long20 = fixedDateTimeZone16.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone16, readableInstant21);
        java.lang.Object obj23 = null;
        boolean boolean24 = fixedDateTimeZone16.equals(obj23);
        long long26 = fixedDateTimeZone16.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology27 = gJChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DateTimeField dateTimeField28 = gJChronology11.secondOfDay();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 0, (org.joda.time.Chronology) gJChronology11);
        try {
            long long37 = gJChronology11.getDateTimeMillis(358, (-25200000), 0, 100, 1, (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-9L) + "'", long20 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-31556476799900L) + "'", long26 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        try {
            long long18 = offsetDateTimeField13.add((long) 292279090, (long) 292279090);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292281060 for year must be in the range [-292275054,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(1);
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withLocale(locale3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int18 = fixedDateTimeZone16.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        int int20 = monthDay11.compareTo((org.joda.time.ReadablePartial) monthDay19);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone25 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long29 = fixedDateTimeZone25.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone25, readableInstant30);
        org.joda.time.MonthDay monthDay32 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone25);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone37 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int39 = fixedDateTimeZone37.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone37);
        int int41 = monthDay32.compareTo((org.joda.time.ReadablePartial) monthDay40);
        org.joda.time.MonthDay monthDay43 = monthDay32.minusMonths(0);
        org.joda.time.MonthDay monthDay45 = monthDay43.plusMonths((int) (short) 0);
        int int46 = monthDay43.size();
        boolean boolean47 = monthDay11.isBefore((org.joda.time.ReadablePartial) monthDay43);
        org.joda.time.MonthDay monthDay49 = monthDay43.plusMonths(98);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-9L) + "'", long29 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(monthDay49);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean13 = fixedDateTimeZone4.isFixed();
        org.joda.time.Instant instant14 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology15 = instant14.getChronology();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int22 = fixedDateTimeZone20.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTime dateTime24 = instant14.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone20);
        org.joda.time.DateTime dateTime26 = dateTime24.minusYears(9);
        org.joda.time.DateTimeZone dateTimeZone27 = dateTime24.getZone();
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) dateTime24);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(gJChronology28);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        try {
            long long8 = julianChronology0.getDateTimeMillis(0, 53, 59, 3, 166, 292278993, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("160000-0800");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"160000-0800\" is malformed at \"00-0800\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter0.getPrinter();
        java.io.Writer writer4 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (-1), chronology6);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), chronology12);
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime13);
        int int15 = dateTime9.compareTo((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property16 = dateTime13.yearOfCentury();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), chronology18);
        org.joda.time.DateTime dateTime21 = dateTime19.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property22 = dateTime21.year();
        int int23 = property22.getMaximumValue();
        java.util.Locale locale24 = null;
        java.lang.String str25 = property22.getAsText(locale24);
        org.joda.time.DateTime dateTime27 = property22.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay28 = dateTime27.toTimeOfDay();
        boolean boolean29 = dateTime13.isBefore((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime.Property property30 = dateTime27.dayOfMonth();
        int int31 = dateTime27.getYearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime27.plus(readablePeriod32);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = dateTime33.toDateTime(dateTimeZone34);
        try {
            dateTimeFormatter0.printTo(writer4, (org.joda.time.ReadableInstant) dateTime35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 292278993 + "'", int23 == 292278993);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1969" + "'", str25.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(timeOfDay28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("1969");
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZoneUTC();
        try {
            org.joda.time.DateTime dateTime5 = dateTimeFormatter1.parseDateTime("Wednesday, December 31, 1969 4:00:00 PM PST");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Wednesday, December 31, 1969 4:0...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("-01:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-01:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.plusYears((int) (byte) 100);
        org.joda.time.DateTime.Property property16 = dateTime5.dayOfYear();
        try {
            org.joda.time.DateTime dateTime18 = dateTime5.withEra((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfCentury();
        boolean boolean28 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long37 = fixedDateTimeZone33.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone33, readableInstant38);
        org.joda.time.MonthDay monthDay40 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.DateTime dateTime41 = dateTime5.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.DateTime.Property property42 = dateTime41.secondOfMinute();
        int int43 = dateTime41.getSecondOfDay();
        try {
            org.joda.time.DateTime dateTime45 = dateTime41.withSecondOfMinute(358);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 358 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-9L) + "'", long37 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValue();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        org.joda.time.DateTime dateTime10 = property5.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay11 = dateTime10.toTimeOfDay();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime14.getZone();
        org.joda.time.LocalTime localTime17 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        try {
            org.joda.time.DateTime dateTime20 = dateTime18.withYearOfCentury((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(timeOfDay11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 365, (long) 1099);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 401135 + "'", int2 == 401135);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.DurationField durationField2 = copticChronology0.centuries();
        try {
            long long7 = copticChronology0.getDateTimeMillis((int) (short) 0, 1, (int) (byte) 10, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The resulting instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime dateTime6 = dateTime2.plusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.lang.String str10 = dateTimeZone8.getName((long) '#');
        org.joda.time.DateTime dateTime11 = dateTime2.withZone(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-01:00" + "'", str10.equals("-01:00"));
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(31, (int) ' ', 98, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.year();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int29 = fixedDateTimeZone27.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone27);
        int int31 = monthDay22.compareTo((org.joda.time.ReadablePartial) monthDay30);
        org.joda.time.MonthDay monthDay33 = monthDay22.minusMonths(0);
        int[] intArray35 = buddhistChronology9.get((org.joda.time.ReadablePartial) monthDay33, (long) 89);
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (-1), chronology37);
        org.joda.time.MutableDateTime mutableDateTime39 = dateTime38.toMutableDateTime();
        org.joda.time.Chronology chronology41 = null;
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) (-1), chronology41);
        org.joda.time.ReadableDuration readableDuration43 = null;
        org.joda.time.DateTime dateTime45 = dateTime42.withDurationAdded(readableDuration43, 0);
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((long) (-1), chronology47);
        org.joda.time.Chronology chronology49 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime48);
        org.joda.time.DateTimeZone dateTimeZone50 = dateTime48.getZone();
        java.util.TimeZone timeZone51 = dateTimeZone50.toTimeZone();
        org.joda.time.DateTime dateTime52 = dateTime45.toDateTime(dateTimeZone50);
        org.joda.time.DateTime dateTime54 = dateTime52.minusSeconds((int) (short) 1);
        try {
            org.joda.time.chrono.LimitChronology limitChronology55 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) buddhistChronology9, (org.joda.time.ReadableDateTime) mutableDateTime39, (org.joda.time.ReadableDateTime) dateTime52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(timeZone51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTime54);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusMillis(10);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getChronology(chronology16);
        org.joda.time.DateTime dateTime18 = dateTime5.withChronology(chronology16);
        org.joda.time.DateMidnight dateMidnight19 = dateTime5.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateMidnight19);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        org.joda.time.DateTime dateTime27 = dateTime22.withWeekOfWeekyear(9);
        boolean boolean28 = dateTime27.isEqualNow();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("2019-06-15T21:04:46.111Z", "100");
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), chronology2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (-1), chronology8);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        int int11 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfCentury();
        int int13 = dateTime9.getSecondOfMinute();
        org.joda.time.DateTime dateTime15 = dateTime9.minusSeconds((-1));
        boolean boolean16 = gregorianChronology0.equals((java.lang.Object) dateTime9);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology0.getZone();
        try {
            long long25 = gregorianChronology0.getDateTimeMillis(1099, 0, 999, 100, 999, 358, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeZone17);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        long long35 = skipUndoDateTimeField32.getDifferenceAsLong(0L, (long) (byte) 1);
        java.lang.String str36 = skipUndoDateTimeField32.toString();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "DateTimeField[yearOfEra]" + "'", str36.equals("DateTimeField[yearOfEra]"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime12 = dateTime8.minusHours(10);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) '#');
        org.joda.time.DateTime.Property property15 = dateTime14.era();
        java.lang.String str16 = property15.getAsText();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "AD" + "'", str16.equals("AD"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean14 = fixedDateTimeZone5.isFixed();
        org.joda.time.Chronology chronology15 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str16 = julianChronology0.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long25 = fixedDateTimeZone21.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone21, readableInstant26);
        org.joda.time.DateTimeField dateTimeField28 = gJChronology27.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField(dateTimeField28, (int) 'a');
        long long32 = offsetDateTimeField30.roundCeiling(10L);
        long long34 = offsetDateTimeField30.roundCeiling(0L);
        boolean boolean35 = julianChronology0.equals((java.lang.Object) offsetDateTimeField30);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str16.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-9L) + "'", long25 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 31535999990L + "'", long32 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 31535999990L + "'", long34 == 31535999990L);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        java.lang.Object obj11 = null;
        boolean boolean12 = fixedDateTimeZone4.equals(obj11);
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int15 = fixedDateTimeZone4.getOffset((long) 1099);
        java.lang.String str17 = fixedDateTimeZone4.getNameKey((-1L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), chronology2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (-1), chronology8);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        int int11 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfCentury();
        int int13 = dateTime9.getSecondOfMinute();
        org.joda.time.DateTime dateTime15 = dateTime9.minusSeconds((-1));
        boolean boolean16 = gregorianChronology0.equals((java.lang.Object) dateTime9);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology0.getZone();
        org.joda.time.DurationField durationField18 = gregorianChronology0.days();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(durationField18);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15T21:04:52.040Z");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.getActions();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = gJChronology10.monthOfYear();
        boolean boolean35 = gJChronology10.equals((java.lang.Object) (short) 100);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone40 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long44 = fixedDateTimeZone40.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone40, readableInstant45);
        org.joda.time.DurationField durationField47 = gJChronology46.millis();
        org.joda.time.DurationField durationField48 = gJChronology46.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone53 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long57 = fixedDateTimeZone53.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant58 = null;
        org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone53, readableInstant58);
        org.joda.time.DateTimeField dateTimeField60 = gJChronology59.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, (int) 'a');
        long long64 = offsetDateTimeField62.roundCeiling(10L);
        long long66 = offsetDateTimeField62.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField68 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology46, (org.joda.time.DateTimeField) offsetDateTimeField62, (int) (short) 1);
        int int69 = skipUndoDateTimeField68.getMaximumValue();
        java.util.Locale locale70 = null;
        int int71 = skipUndoDateTimeField68.getMaximumShortTextLength(locale70);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField73 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) skipUndoDateTimeField68, 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-9L) + "'", long44 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + (-9L) + "'", long57 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 31535999990L + "'", long64 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 31535999990L + "'", long66 == 31535999990L);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 292279090 + "'", int69 == 292279090);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 9 + "'", int71 == 9);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfCentury();
        boolean boolean28 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime24);
        long long29 = dateTime5.getMillis();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-1L) + "'", long29 == (-1L));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), chronology2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (-1), chronology8);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        int int11 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfCentury();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property18 = dateTime17.year();
        int int19 = property18.getMaximumValue();
        java.util.Locale locale20 = null;
        java.lang.String str21 = property18.getAsText(locale20);
        org.joda.time.DateTime dateTime23 = property18.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay24 = dateTime23.toTimeOfDay();
        boolean boolean25 = dateTime9.isBefore((org.joda.time.ReadableInstant) dateTime23);
        org.joda.time.DateTime.Property property26 = dateTime23.dayOfMonth();
        java.lang.String str27 = property26.toString();
        boolean boolean28 = property26.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property26.getFieldType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 292278993 + "'", int19 == 292278993);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "1969" + "'", str21.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(timeOfDay24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Property[dayOfMonth]" + "'", str27.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.getMinimumValue((long) (byte) 10);
        java.util.Locale locale6 = null;
        java.lang.String str7 = delegatedDateTimeField2.getAsShortText((int) (byte) 0, locale6);
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay9 = org.joda.time.MonthDay.now();
        boolean boolean10 = monthDay8.isEqual((org.joda.time.ReadablePartial) monthDay9);
        org.joda.time.MonthDay monthDay12 = monthDay8.minusDays((int) (byte) 0);
        org.joda.time.DateTimeField[] dateTimeFieldArray13 = monthDay8.getFields();
        int int14 = monthDay8.getMonthOfYear();
        java.util.Locale locale15 = null;
        try {
            java.lang.String str16 = delegatedDateTimeField2.getAsShortText((org.joda.time.ReadablePartial) monthDay8, locale15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(dateTimeFieldArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
//        org.joda.time.DateTime dateTime6 = dateTime2.plusWeeks(0);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        int int8 = dateTime7.getDayOfYear();
//        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 0, (java.lang.Object) dateTime7);
//        org.joda.time.DateTime dateTime11 = dateTime7.withYear((-292275054));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 166 + "'", int8 == 166);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("DateTimeField[yearOfEra]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[yearOfEra]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(166, (-25200000), 89, 10, 292279090);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279090 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15T21:04:52.040Z", (java.lang.Number) 89, (java.lang.Number) 100L, (java.lang.Number) (byte) 1);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
//        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
//        org.joda.time.DateTime.Property property5 = dateTime2.secondOfMinute();
//        org.joda.time.ReadableInstant readableInstant6 = null;
//        long long7 = property5.getDifferenceAsLong(readableInstant6);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1560632710L) + "'", long7 == (-1560632710L));
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 10, 1099);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10990L + "'", long2 == 10990L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(98);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-98) + "'", int1 == (-98));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValue();
        boolean boolean7 = property5.isLeap();
        java.lang.String str8 = property5.getName();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "year" + "'", str8.equals("year"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.withMillis((long) '#');
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime2.getZone();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(1099);
        org.joda.time.DateTime dateTime8 = dateTime6.minusHours((int) (short) 1);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        java.lang.String str12 = gJChronology10.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int19 = fixedDateTimeZone17.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        int[] intArray22 = gJChronology10.get((org.joda.time.ReadablePartial) monthDay20, 100L);
        org.joda.time.DateTimeField dateTimeField23 = gJChronology10.secondOfMinute();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GJChronology[]" + "'", str12.equals("GJChronology[]"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', 53, 166, (int) (byte) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        org.joda.time.LocalDateTime localDateTime4 = dateTime2.toLocalDateTime();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (-1), chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime7.getZone();
        java.util.TimeZone timeZone10 = dateTimeZone9.toTimeZone();
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((java.lang.Object) localDateTime4, dateTimeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.LocalDateTime");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = gJChronology10.monthOfYear();
        org.joda.time.Instant instant34 = gJChronology10.getGregorianCutover();
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36);
        java.lang.String str39 = delegatedDateTimeField37.getAsText((long) (byte) 10);
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField37.getAsText(0L, locale41);
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) delegatedDateTimeField37, 358);
        long long47 = skipDateTimeField44.set(1560632687348L, 999);
        try {
            long long50 = skipDateTimeField44.set((long) 3, 57599999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57599999 for millisOfSecond must be in the range [-1,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10" + "'", str39.equals("10"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0" + "'", str42.equals("0"));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560632687999L + "'", long47 == 1560632687999L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (short) 10);
        org.joda.time.MonthDay.Property property2 = monthDay1.dayOfMonth();
        int int3 = property2.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (short) 10);
        org.joda.time.MonthDay.Property property2 = monthDay1.dayOfMonth();
        java.lang.String str3 = property2.toString();
        int int4 = property2.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Property[dayOfMonth]" + "'", str3.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = copticChronology0.get(readablePeriod2, (long) (short) 1, (long) 53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now();
        boolean boolean2 = monthDay0.isEqual((org.joda.time.ReadablePartial) monthDay1);
        org.joda.time.MonthDay monthDay4 = monthDay0.minusDays((int) (byte) 0);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.MonthDay monthDay7 = monthDay0.withFieldAdded(durationFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(monthDay4);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        int int12 = dateTime8.getSecondOfMinute();
        org.joda.time.DateTime dateTime14 = dateTime8.minusSeconds((-1));
        org.joda.time.DateTime dateTime16 = dateTime8.withYearOfCentury(24);
        int int17 = dateTime8.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 59 + "'", int17 == 59);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), chronology2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (-1), chronology8);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        int int11 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfCentury();
        int int13 = dateTime9.getSecondOfMinute();
        org.joda.time.DateTime dateTime15 = dateTime9.minusSeconds((-1));
        boolean boolean16 = gregorianChronology0.equals((java.lang.Object) dateTime9);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology0.getZone();
        try {
            long long22 = gregorianChronology0.getDateTimeMillis(358, 4, 999, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeZone17);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.Instant instant6 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology7 = instant6.getChronology();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int14 = fixedDateTimeZone12.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTime dateTime16 = instant6.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(366, 366, (int) (byte) 1, 292279090, (int) (short) 1, (int) (byte) 1, (org.joda.time.DateTimeZone) fixedDateTimeZone12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279090 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 53, (long) 1099);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 58247L + "'", long2 == 58247L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("2019-06-15T21:04:47.348Z", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-06-15T21:04:47.348Z\" is malformed at \"-06-15T21:04:47.348Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (-1), chronology6);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime7.getZone();
        org.joda.time.LocalTime localTime10 = dateTime7.toLocalTime();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), chronology12);
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTimeZone dateTimeZone15 = dateTime13.getZone();
        org.joda.time.LocalTime localTime16 = dateTime13.toLocalTime();
        boolean boolean17 = localTime10.isEqual((org.joda.time.ReadablePartial) localTime16);
        org.joda.time.DateTime dateTime18 = dateTime4.withFields((org.joda.time.ReadablePartial) localTime10);
        org.joda.time.DateTime dateTime20 = dateTime4.withYearOfCentury(0);
        java.util.Locale locale21 = null;
        java.util.Calendar calendar22 = dateTime20.toCalendar(locale21);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(localTime10);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(localTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(calendar22);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        java.lang.Object obj22 = null;
        boolean boolean23 = fixedDateTimeZone15.equals(obj22);
        long long25 = fixedDateTimeZone15.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology26 = gJChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTimeField dateTimeField27 = gJChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology10.millisOfSecond();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31556476799900L) + "'", long25 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        java.util.Locale locale3 = null;
        java.lang.String str4 = dateTimeZone1.getShortName(292278122L, locale3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-01:00" + "'", str4.equals("-01:00"));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        long long26 = offsetDateTimeField13.set((long) '#', "2067");
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField13.getAsShortText((long) 24, locale28);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "2067" + "'", str29.equals("2067"));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        int int25 = dateTime22.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 359 + "'", int25 == 359);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (-1), chronology3);
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime4);
        try {
            org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(31, (int) (short) 10, chronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 0);
        long long10 = fixedDateTimeZone4.previousTransition((-3599999L));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.MonthDay monthDay25 = monthDay23.minusDays((int) (byte) -1);
        boolean boolean26 = fixedDateTimeZone4.equals((java.lang.Object) monthDay23);
        try {
            int int28 = monthDay23.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-3599999L) + "'", long10 == (-3599999L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = skipUndoDateTimeField32.getWrappedField();
        long long35 = skipUndoDateTimeField32.roundFloor((long) (byte) 100);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipUndoDateTimeField32.getAsText(100, locale37);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-10L) + "'", long35 == (-10L));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "100" + "'", str38.equals("100"));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean13 = buddhistChronology0.equals((java.lang.Object) fixedDateTimeZone5);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTime();
        int int4 = dateTime2.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime6 = dateTime2.withYearOfEra(9);
        org.joda.time.LocalTime localTime7 = dateTime6.toLocalTime();
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localTime7);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        org.joda.time.DurationField durationField16 = property15.getRangeDurationField();
        int int17 = property15.getMinimumValueOverall();
        java.lang.String str18 = property15.getName();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "monthOfYear" + "'", str18.equals("monthOfYear"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        boolean boolean8 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay6.plus(readablePeriod9);
        int[] intArray12 = new int[] { 0 };
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay10, intArray12);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, (int) (byte) 100);
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now();
        boolean boolean18 = monthDay16.isEqual((org.joda.time.ReadablePartial) monthDay17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay20 = monthDay16.plus(readablePeriod19);
        int int21 = offsetDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) monthDay16);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType23 = monthDay16.getFieldType((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1099 + "'", int21 == 1099);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (short) -1, (long) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-100) + "'", int2 == (-100));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long15 = fixedDateTimeZone11.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11, readableInstant16);
        java.lang.Object obj18 = null;
        boolean boolean19 = fixedDateTimeZone11.equals(obj18);
        org.joda.time.MonthDay monthDay20 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        int int22 = fixedDateTimeZone11.getOffset((long) 1099);
        try {
            org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(0, 9, (int) (short) 10, 358, 100, 0, (int) (byte) 100, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 358 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-9L) + "'", long15 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValueOverall();
        org.joda.time.DateTime dateTime7 = property5.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfDay((int) ' ');
        try {
            org.joda.time.DateTime dateTime11 = dateTime9.withEra(292279090);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279090 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now();
        boolean boolean2 = monthDay0.isEqual((org.joda.time.ReadablePartial) monthDay1);
        org.joda.time.MonthDay monthDay4 = monthDay0.minusDays((int) (byte) 0);
        try {
            java.lang.String str6 = monthDay0.toString("June");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(monthDay4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        int int25 = offsetDateTimeField13.get((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2067 + "'", int25 == 2067);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.DurationField durationField2 = copticChronology0.halfdays();
        java.lang.Class<?> wildcardClass3 = durationField2.getClass();
        long long6 = durationField2.subtract((long) '4', 0L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        int int16 = offsetDateTimeField13.getMinimumValue();
        int int18 = offsetDateTimeField13.getLeapAmount((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 98 + "'", int16 == 98);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1L, number2, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("DateTimeField[yearOfEra]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        long long32 = offsetDateTimeField26.roundFloor((long) 'a');
        long long34 = offsetDateTimeField26.roundHalfCeiling((-1L));
        int int36 = offsetDateTimeField26.getMinimumValue((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField38 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField26, dateTimeFieldType37);
        org.joda.time.Chronology chronology40 = null;
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (-1), chronology40);
        org.joda.time.ReadableDuration readableDuration42 = null;
        org.joda.time.DateTime dateTime44 = dateTime41.withDurationAdded(readableDuration42, 0);
        org.joda.time.Chronology chronology46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime((long) (-1), chronology46);
        org.joda.time.Chronology chronology48 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime47);
        org.joda.time.DateTimeZone dateTimeZone49 = dateTime47.getZone();
        java.util.TimeZone timeZone50 = dateTimeZone49.toTimeZone();
        org.joda.time.DateTime dateTime51 = dateTime44.toDateTime(dateTimeZone49);
        org.joda.time.DateTime.Property property52 = dateTime44.yearOfEra();
        org.joda.time.DateTime dateTime54 = dateTime44.minusDays(0);
        org.joda.time.DateTime dateTime56 = dateTime54.minusHours((int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology57 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField58 = copticChronology57.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField59 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField58);
        long long62 = delegatedDateTimeField59.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType63 = delegatedDateTimeField59.getType();
        org.joda.time.DateTime.Property property64 = dateTime54.property(dateTimeFieldType63);
        org.joda.time.IllegalFieldValueException illegalFieldValueException68 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType63, (java.lang.Number) (-25200000), (java.lang.Number) (-32400000L), (java.lang.Number) 100.0f);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField70 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField26, dateTimeFieldType63, 2116);
        try {
            org.joda.time.MonthDay.Property property71 = monthDay12.property(dateTimeFieldType63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-10L) + "'", long32 == (-10L));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-10L) + "'", long34 == (-10L));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 98 + "'", int36 == 98);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(timeZone50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(copticChronology57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 292278122L + "'", long62 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType63);
        org.junit.Assert.assertNotNull(property64);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
//        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now();
//        boolean boolean2 = monthDay0.isEqual((org.joda.time.ReadablePartial) monthDay1);
//        org.joda.time.MonthDay.Property property3 = monthDay1.dayOfMonth();
//        org.joda.time.MonthDay monthDay5 = property3.addWrapFieldToCopy((int) ' ');
//        java.lang.String str6 = property3.getAsString();
//        org.junit.Assert.assertNotNull(monthDay0);
//        org.junit.Assert.assertNotNull(monthDay1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(monthDay5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "15" + "'", str6.equals("15"));
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) 1099);
        org.joda.time.DateTime dateTime3 = dateTime1.withMillisOfDay((int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property15.getAsText(locale16);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (-1), chronology19);
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTime();
        int int22 = property15.compareTo((org.joda.time.ReadableInstant) dateTime21);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June" + "'", str17.equals("June"));
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), chronology2);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property6 = dateTime5.year();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (-1), chronology8);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        int int11 = dateTime5.compareTo((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime.Property property12 = dateTime9.yearOfCentury();
        int int13 = dateTime9.getSecondOfMinute();
        org.joda.time.DateTime dateTime15 = dateTime9.minusSeconds((-1));
        boolean boolean16 = gregorianChronology0.equals((java.lang.Object) dateTime9);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology0.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long26 = fixedDateTimeZone22.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone22, readableInstant27);
        java.lang.Object obj29 = null;
        boolean boolean30 = fixedDateTimeZone22.equals(obj29);
        org.joda.time.MonthDay monthDay31 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.Chronology chronology32 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 59 + "'", int13 == 59);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-9L) + "'", long26 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertNotNull(chronology32);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("JulianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: JulianChronology[America/Los_Angeles]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        int int12 = dateTime8.getSecondOfMinute();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks((int) (short) -1);
        int int18 = dateTime17.getDayOfMonth();
        org.joda.time.DateTime dateTime20 = dateTime17.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = copticChronology21.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField22);
        long long26 = delegatedDateTimeField23.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = delegatedDateTimeField23.getType();
        int int28 = dateTime17.get(dateTimeFieldType27);
        try {
            org.joda.time.DateTime dateTime30 = dateTime8.withField(dateTimeFieldType27, (-54));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -54 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 59 + "'", int12 == 59);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 24 + "'", int18 == 24);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(copticChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 292278122L + "'", long26 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 999 + "'", int28 == 999);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.DateTimeFormat.mediumTime();
        boolean boolean10 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeFormatter9);
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        long long16 = gregorianChronology0.add(readablePeriod13, (long) (byte) 10, 53);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology0.getZone();
        java.lang.String str18 = dateTimeZone17.getID();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UTC" + "'", str18.equals("UTC"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        boolean boolean8 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay6.plus(readablePeriod9);
        int[] intArray12 = new int[] { 0 };
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay10, intArray12);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField2, (int) (byte) 100);
        long long17 = delegatedDateTimeField2.roundCeiling(52L);
        org.joda.time.DateTimeField dateTimeField18 = delegatedDateTimeField2.getWrappedField();
        long long21 = delegatedDateTimeField2.add((long) 31, (int) ' ');
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 63L + "'", long21 == 63L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("9");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.Object obj12 = null;
        boolean boolean13 = monthDay11.equals(obj12);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((-98), 0, 365, 10, 100, 0, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long11 = fixedDateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7, readableInstant12);
        org.joda.time.Chronology chronology14 = gregorianChronology2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        long long18 = gregorianChronology2.add(readablePeriod15, (long) (byte) 10, 53);
        org.joda.time.DateTimeZone dateTimeZone19 = gregorianChronology2.getZone();
        try {
            org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(24, (int) ' ', (org.joda.time.Chronology) gregorianChronology2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9L) + "'", long11 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 10L + "'", long18 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone19);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("+00:00:00.010");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00:00.010\" is malformed at \":00:00.010\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.plusYears((int) (byte) 100);
        org.joda.time.DateTime.Property property16 = dateTime5.dayOfYear();
        org.joda.time.DateTime dateTime17 = property16.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), chronology9);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded(readableDuration11, 0);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (-1), chronology15);
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime16.getZone();
        java.util.TimeZone timeZone19 = dateTimeZone18.toTimeZone();
        org.joda.time.DateTime dateTime20 = dateTime13.toDateTime(dateTimeZone18);
        org.joda.time.DateTime.Property property21 = dateTime13.yearOfEra();
        org.joda.time.Interval interval22 = property21.toInterval();
        boolean boolean23 = fixedDateTimeZone4.equals((java.lang.Object) interval22);
        org.joda.time.Chronology chronology24 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval22);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(interval22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, (long) 365);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-365L) + "'", long2 == (-365L));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 9, 10990L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10981L) + "'", long2 == (-10981L));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        int int33 = skipUndoDateTimeField32.getMaximumValue();
        java.util.Locale locale34 = null;
        int int35 = skipUndoDateTimeField32.getMaximumShortTextLength(locale34);
        java.util.Locale locale38 = null;
        try {
            long long39 = skipUndoDateTimeField32.set((long) 292278993, "Property[dayOfMonth]", locale38);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[dayOfMonth]\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 292279090 + "'", int33 == 292279090);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 9 + "'", int35 == 9);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        org.joda.time.DurationField durationField3 = delegatedDateTimeField2.getLeapDurationField();
        long long5 = delegatedDateTimeField2.roundHalfFloor((long) (-25200000));
        long long8 = delegatedDateTimeField2.set((long) (byte) 0, 9);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNull(durationField3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-25200000L) + "'", long5 == (-25200000L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9L + "'", long8 == 9L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        long long26 = offsetDateTimeField13.set((long) '#', "2067");
        long long29 = offsetDateTimeField13.getDifferenceAsLong((long) 2, 0L);
        long long31 = offsetDateTimeField13.roundHalfCeiling(58247L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-10L) + "'", long31 == (-10L));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long32 = fixedDateTimeZone28.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone28, readableInstant33);
        java.lang.Object obj35 = null;
        boolean boolean36 = fixedDateTimeZone28.equals(obj35);
        long long38 = fixedDateTimeZone28.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology39 = gJChronology23.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        org.joda.time.Chronology chronology40 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-9L) + "'", long32 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-31556476799900L) + "'", long38 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(chronology40);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        int int10 = property7.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 86399 + "'", int10 == 86399);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.getMinimumValue((long) (byte) 10);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = delegatedDateTimeField2.getMinimumValue(readablePartial5);
        long long9 = delegatedDateTimeField2.getDifferenceAsLong(94694400010L, (long) 59);
        java.lang.String str11 = delegatedDateTimeField2.getAsShortText(1L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 94694399951L + "'", long9 == 94694399951L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1" + "'", str11.equals("1"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long30 = fixedDateTimeZone26.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26, readableInstant31);
        java.lang.Object obj33 = null;
        boolean boolean34 = fixedDateTimeZone26.equals(obj33);
        long long36 = fixedDateTimeZone26.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology37 = gJChronology21.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone42 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long46 = fixedDateTimeZone42.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant47 = null;
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone42, readableInstant47);
        org.joda.time.DurationField durationField49 = gJChronology48.millis();
        org.joda.time.DurationField durationField50 = gJChronology48.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone55 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long59 = fixedDateTimeZone55.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant60 = null;
        org.joda.time.chrono.GJChronology gJChronology61 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone55, readableInstant60);
        org.joda.time.DateTimeField dateTimeField62 = gJChronology61.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField64 = new org.joda.time.field.OffsetDateTimeField(dateTimeField62, (int) 'a');
        long long66 = offsetDateTimeField64.roundCeiling(10L);
        long long68 = offsetDateTimeField64.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField70 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology48, (org.joda.time.DateTimeField) offsetDateTimeField64, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField71 = gJChronology48.monthOfYear();
        boolean boolean72 = fixedDateTimeZone26.equals((java.lang.Object) gJChronology48);
        org.joda.time.DateTimeZone dateTimeZone73 = gJChronology48.getZone();
        org.joda.time.MutableDateTime mutableDateTime74 = dateTime8.toMutableDateTime(dateTimeZone73);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-9L) + "'", long30 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-31556476799900L) + "'", long36 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-9L) + "'", long46 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-9L) + "'", long59 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 31535999990L + "'", long66 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 31535999990L + "'", long68 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(dateTimeZone73);
        org.junit.Assert.assertNotNull(mutableDateTime74);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.Object obj1 = null;
        boolean boolean2 = julianChronology0.equals(obj1);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean14 = fixedDateTimeZone5.isFixed();
        org.joda.time.Chronology chronology15 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str16 = julianChronology0.toString();
        long long21 = julianChronology0.getDateTimeMillis(1099, 6, 9, 31);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forID("-01:00");
        long long25 = dateTimeZone23.convertUTCToLocal((-28800000L));
        org.joda.time.Chronology chronology26 = julianChronology0.withZone(dateTimeZone23);
        try {
            long long34 = julianChronology0.getDateTimeMillis(59, 0, (-98), 366, 366, (-98), 9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 366 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str16.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-27471802021969L) + "'", long21 == (-27471802021969L));
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-32400000L) + "'", long25 == (-32400000L));
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        java.lang.String str12 = gJChronology10.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int19 = fixedDateTimeZone17.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        int[] intArray22 = gJChronology10.get((org.joda.time.ReadablePartial) monthDay20, 100L);
        org.joda.time.DateTimeField dateTimeField23 = gJChronology10.monthOfYear();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology10);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GJChronology[]" + "'", str12.equals("GJChronology[]"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime4.dayOfYear();
        int int12 = property11.getMaximumValueOverall();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), chronology14);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, 0);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (-1), chronology20);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime21.getZone();
        java.util.TimeZone timeZone24 = dateTimeZone23.toTimeZone();
        org.joda.time.DateTime dateTime25 = dateTime18.toDateTime(dateTimeZone23);
        org.joda.time.DateTime.Property property26 = dateTime18.yearOfEra();
        org.joda.time.DurationField durationField27 = property26.getRangeDurationField();
        java.lang.String str28 = property26.getAsString();
        org.joda.time.DurationField durationField29 = property26.getDurationField();
        org.joda.time.DateTime dateTime30 = property26.withMinimumValue();
        org.joda.time.DateTime dateTime32 = dateTime30.minusMillis(98);
        int int33 = property11.getDifference((org.joda.time.ReadableInstant) dateTime32);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 366 + "'", int12 == 366);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNull(durationField27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "1969" + "'", str28.equals("1969"));
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 718790 + "'", int33 == 718790);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        int int26 = dateTime22.getYearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime28 = dateTime22.plus(readablePeriod27);
        java.util.GregorianCalendar gregorianCalendar29 = dateTime28.toGregorianCalendar();
        try {
            org.joda.time.DateTime dateTime31 = dateTime28.withDayOfYear(2116);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2116 for dayOfYear must be in the range [1,366]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gregorianCalendar29);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("2067");
        org.junit.Assert.assertNotNull(monthDay1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), chronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property16 = dateTime15.year();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), chronology18);
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime19);
        int int21 = dateTime15.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime.Property property22 = dateTime19.yearOfCentury();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), chronology24);
        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property28 = dateTime27.year();
        int int29 = property28.getMaximumValue();
        java.util.Locale locale30 = null;
        java.lang.String str31 = property28.getAsText(locale30);
        org.joda.time.DateTime dateTime33 = property28.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay34 = dateTime33.toTimeOfDay();
        boolean boolean35 = dateTime19.isBefore((org.joda.time.ReadableInstant) dateTime33);
        int int36 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime33);
        java.util.GregorianCalendar gregorianCalendar37 = dateTime33.toGregorianCalendar();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 292278993 + "'", int29 == 292278993);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969" + "'", str31.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(timeOfDay34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertNotNull(gregorianCalendar37);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.halfdays();
        boolean boolean3 = gregorianChronology0.equals((java.lang.Object) durationField2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField2, durationFieldType4, 999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Instant instant6 = dateTime4.toInstant();
        org.joda.time.DateTime dateTime8 = dateTime4.minusMinutes(24);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (-1), chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.year();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), chronology9);
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        int int12 = dateTime6.compareTo((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime.Property property13 = dateTime10.yearOfCentury();
        int int14 = dateTime10.getSecondOfMinute();
        org.joda.time.DateTime dateTime16 = dateTime10.minusSeconds((-1));
        boolean boolean17 = gregorianChronology1.equals((java.lang.Object) dateTime10);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) 10, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getChronology(chronology21);
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay((int) (byte) 1, 9, chronology22);
        boolean boolean24 = gregorianChronology1.equals((java.lang.Object) (byte) 1);
        try {
            long long32 = gregorianChronology1.getDateTimeMillis(10, 718790, 3, 2000, 59, 6, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 59 + "'", int14 == 59);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (-1), chronology3);
        org.joda.time.DateTime dateTime6 = dateTime4.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property7 = dateTime6.year();
        int int8 = property7.getMaximumValueOverall();
        org.joda.time.DateTime dateTime9 = property7.roundCeilingCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfDay((int) ' ');
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 292278993 + "'", int8 == 292278993);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime dateTime5 = dateTime2.withTimeAtStartOfDay();
        org.joda.time.DateTime.Property property6 = dateTime5.era();
        long long7 = property6.remainder();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 62135510400000L + "'", long7 == 62135510400000L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
        boolean boolean6 = delegatedDateTimeField2.isSupported();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("-01:00", 100, 89, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for -01:00 must be in the range [89,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) (byte) 1);
        try {
            org.joda.time.MonthDay monthDay3 = monthDay1.withDayOfMonth((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int22 = offsetDateTimeField13.getMaximumValue();
        int int23 = offsetDateTimeField13.getMinimumValue();
        long long25 = offsetDateTimeField13.roundHalfCeiling((long) 2);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292279090 + "'", int22 == 292279090);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-10L) + "'", long25 == (-10L));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone6 = dateTime4.getZone();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("10", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"10/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.DateTime dateTime17 = dateTime15.minusHours((int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19);
        long long23 = delegatedDateTimeField20.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField20.getType();
        org.joda.time.DateTime.Property property25 = dateTime15.property(dateTimeFieldType24);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) (-25200000), (java.lang.Number) (-32400000L), (java.lang.Number) 100.0f);
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray30 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType24 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList31 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean32 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList31, dateTimeFieldTypeArray30);
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList31, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No valid ISO8601 format for fields: []");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 292278122L + "'", long23 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (-1), chronology5);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(readableDuration7, 0);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (-1), chronology11);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime12.getZone();
        java.util.TimeZone timeZone15 = dateTimeZone14.toTimeZone();
        org.joda.time.DateTime dateTime16 = dateTime9.toDateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime18 = dateTime9.withEra((int) (byte) 1);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (-1), chronology20);
        org.joda.time.DateTime dateTime23 = dateTime21.plusWeeks((int) (short) -1);
        org.joda.time.DateTime dateTime25 = dateTime21.plusWeeks(0);
        boolean boolean26 = dateTime9.isAfter((org.joda.time.ReadableInstant) dateTime25);
        boolean boolean27 = gregorianChronology0.equals((java.lang.Object) dateTime25);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        int int12 = dateTime8.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime8.minusWeeks(0);
        org.joda.time.DateTime dateTime16 = dateTime8.withDayOfYear((int) ' ');
        int int17 = dateTime16.getHourOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay(9, 4);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int22 = offsetDateTimeField13.getMaximumValue();
        int int24 = offsetDateTimeField13.getMinimumValue((-9L));
        org.joda.time.DurationField durationField25 = offsetDateTimeField13.getLeapDurationField();
        long long27 = offsetDateTimeField13.roundHalfCeiling((long) 401135);
        long long29 = offsetDateTimeField13.roundHalfEven(0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292279090 + "'", int22 == 292279090);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 98 + "'", int24 == 98);
        org.junit.Assert.assertNull(durationField25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-10L) + "'", long27 == (-10L));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-10L) + "'", long29 == (-10L));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray4 = buddhistChronology0.get(readablePeriod1, (-3599999L), (-28800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.MonthDay monthDay0 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.now();
        boolean boolean2 = monthDay0.isEqual((org.joda.time.ReadablePartial) monthDay1);
        org.joda.time.MonthDay.Property property3 = monthDay1.dayOfMonth();
        org.joda.time.MonthDay monthDay5 = property3.addWrapFieldToCopy((int) ' ');
        boolean boolean6 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay5);
        org.junit.Assert.assertNotNull(monthDay0);
        org.junit.Assert.assertNotNull(monthDay1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology4.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        long long9 = delegatedDateTimeField6.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField6.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 86399);
        try {
            long long14 = dividedDateTimeField12.roundFloor(1L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 292278122L + "'", long9 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        long long35 = skipUndoDateTimeField32.getDifferenceAsLong(0L, (long) (byte) 1);
        org.joda.time.ReadableInterval readableInterval36 = null;
        org.joda.time.Chronology chronology37 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval36);
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime(chronology37);
        org.joda.time.chrono.CopticChronology copticChronology39 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay((java.lang.Object) dateTime38, (org.joda.time.Chronology) copticChronology39);
        int int41 = skipUndoDateTimeField32.getMinimumValue((org.joda.time.ReadablePartial) monthDay40);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(copticChronology39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 98 + "'", int41 == 98);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.DateTime dateTime9 = dateTime7.minus((long) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMinutes(4);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DurationField durationField13 = gJChronology11.centuries();
        org.joda.time.DateTimeField dateTimeField14 = gJChronology11.monthOfYear();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) 718790, (org.joda.time.Chronology) gJChronology11);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime2.getZone();
        boolean boolean6 = dateTime2.isEqual((long) 999);
        org.joda.time.DateTime dateTime7 = dateTime2.toDateTimeISO();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) 'a');
        long long16 = offsetDateTimeField14.roundCeiling(10L);
        int int17 = offsetDateTimeField14.getMinimumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField14.getAsText((-8L), locale19);
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (-1), chronology22);
        org.joda.time.DateTime dateTime25 = dateTime23.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property26 = dateTime25.year();
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (-1), chronology28);
        org.joda.time.Chronology chronology30 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime29);
        int int31 = dateTime25.compareTo((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime.Property property32 = dateTime29.yearOfCentury();
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (-1), chronology34);
        org.joda.time.DateTime dateTime37 = dateTime35.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property38 = dateTime37.year();
        int int39 = property38.getMaximumValue();
        java.util.Locale locale40 = null;
        java.lang.String str41 = property38.getAsText(locale40);
        org.joda.time.DateTime dateTime43 = property38.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay44 = dateTime43.toTimeOfDay();
        boolean boolean45 = dateTime29.isBefore((org.joda.time.ReadableInstant) dateTime43);
        org.joda.time.DateTime.Property property46 = dateTime43.dayOfMonth();
        java.lang.String str47 = property46.toString();
        boolean boolean48 = property46.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property46.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField14, dateTimeFieldType49);
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType49, 0, (-292275054), 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 31535999990L + "'", long16 == 31535999990L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 98 + "'", int17 == 98);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2067" + "'", str20.equals("2067"));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 292278993 + "'", int39 == 292278993);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1969" + "'", str41.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(timeOfDay44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Property[dayOfMonth]" + "'", str47.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 1, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean14 = fixedDateTimeZone5.isFixed();
        org.joda.time.Chronology chronology15 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        java.lang.String str16 = julianChronology0.toString();
        org.joda.time.Chronology chronology17 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str16.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.halfdays();
        boolean boolean3 = gregorianChronology0.equals((java.lang.Object) durationField2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.minuteOfHour();
        org.joda.time.DurationField durationField5 = gregorianChronology0.centuries();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DurationField durationField33 = skipUndoDateTimeField32.getRangeDurationField();
        org.joda.time.DurationField durationField34 = skipUndoDateTimeField32.getDurationField();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNull(durationField33);
        org.junit.Assert.assertNotNull(durationField34);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), chronology14);
        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property18 = dateTime17.year();
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (-1), chronology20);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime21);
        int int23 = dateTime17.compareTo((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime.Property property24 = dateTime21.yearOfCentury();
        org.joda.time.Chronology chronology26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (-1), chronology26);
        org.joda.time.DateTime dateTime29 = dateTime27.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property30 = dateTime29.year();
        int int31 = property30.getMaximumValue();
        java.util.Locale locale32 = null;
        java.lang.String str33 = property30.getAsText(locale32);
        org.joda.time.DateTime dateTime35 = property30.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay36 = dateTime35.toTimeOfDay();
        boolean boolean37 = dateTime21.isBefore((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.DateTime.Property property38 = dateTime35.dayOfMonth();
        int int39 = dateTime35.getYearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.DateTime dateTime41 = dateTime35.plus(readablePeriod40);
        boolean boolean42 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime35);
        try {
            org.joda.time.DateTime dateTime44 = dateTime5.withHourOfDay(718790);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 718790 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 292278993 + "'", int31 == 292278993);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1969" + "'", str33.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(timeOfDay36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        int int12 = dateTime8.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime8.minusWeeks(0);
        org.joda.time.Instant instant15 = dateTime14.toInstant();
        org.joda.time.Instant instant18 = instant15.withDurationAdded((long) 2000, (int) (short) 10);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertNotNull(instant18);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime2.getZone();
        org.joda.time.DateTime dateTime6 = dateTime2.withCenturyOfEra(1099);
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withMillisOfSecond(86399);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        java.lang.Object obj22 = null;
        boolean boolean23 = fixedDateTimeZone15.equals(obj22);
        long long25 = fixedDateTimeZone15.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology26 = gJChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTimeField dateTimeField27 = gJChronology10.secondOfDay();
        int int28 = gJChronology10.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31556476799900L) + "'", long25 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(chronology1);
        org.joda.time.chrono.CopticChronology copticChronology3 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.MonthDay monthDay4 = new org.joda.time.MonthDay((java.lang.Object) dateTime2, (org.joda.time.Chronology) copticChronology3);
        try {
            int int6 = monthDay4.getValue(292279090);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 292279090");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(copticChronology3);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology9);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfCentury();
        boolean boolean28 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime dateTime29 = dateTime5.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 1, (int) '#', 166, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        int int34 = offsetDateTimeField26.getLeapAmount((long) 'a');
        long long36 = offsetDateTimeField26.roundHalfCeiling((long) 98);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-10L) + "'", long36 == (-10L));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValue();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        java.util.Locale locale9 = null;
        java.lang.String str10 = property5.getAsShortText(locale9);
        java.lang.String str11 = property5.getAsString();
        org.joda.time.DurationField durationField12 = property5.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1969" + "'", str10.equals("1969"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1969" + "'", str11.equals("1969"));
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType24);
        long long28 = offsetDateTimeField13.getDifferenceAsLong((long) (short) 1, (long) 292278993);
        try {
            long long31 = offsetDateTimeField13.set((-8L), "-01:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"-01:00\" for yearOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime5.withEra((int) (byte) 1);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (-1), chronology16);
        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks((int) (short) -1);
        org.joda.time.DateTime dateTime21 = dateTime17.plusWeeks(0);
        boolean boolean22 = dateTime5.isAfter((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.chrono.CopticChronology copticChronology23 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField24 = copticChronology23.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField24);
        java.lang.String str27 = delegatedDateTimeField25.getAsText((long) (byte) 10);
        java.util.Locale locale29 = null;
        java.lang.String str30 = delegatedDateTimeField25.getAsText(0L, locale29);
        long long33 = delegatedDateTimeField25.add((long) 1, (-9L));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long42 = fixedDateTimeZone38.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone38, readableInstant43);
        org.joda.time.MonthDay monthDay45 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone38);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone50 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int52 = fixedDateTimeZone50.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay53 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone50);
        int int54 = monthDay45.compareTo((org.joda.time.ReadablePartial) monthDay53);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone59 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int61 = fixedDateTimeZone59.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str63 = fixedDateTimeZone59.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology64 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone59);
        org.joda.time.DateTimeField dateTimeField65 = buddhistChronology64.year();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone70 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long74 = fixedDateTimeZone70.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant75 = null;
        org.joda.time.chrono.GJChronology gJChronology76 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone70, readableInstant75);
        org.joda.time.MonthDay monthDay77 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone70);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone82 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int84 = fixedDateTimeZone82.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay85 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone82);
        int int86 = monthDay77.compareTo((org.joda.time.ReadablePartial) monthDay85);
        org.joda.time.MonthDay monthDay88 = monthDay77.minusMonths(0);
        int[] intArray90 = buddhistChronology64.get((org.joda.time.ReadablePartial) monthDay88, (long) 89);
        int int91 = delegatedDateTimeField25.getMinimumValue((org.joda.time.ReadablePartial) monthDay45, intArray90);
        int int92 = dateTime5.get((org.joda.time.DateTimeField) delegatedDateTimeField25);
        java.util.Locale locale95 = null;
        long long96 = delegatedDateTimeField25.set((-31556476799900L), "0", locale95);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(copticChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "10" + "'", str27.equals("10"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "0" + "'", str30.equals("0"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-8L) + "'", long33 == (-8L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-9L) + "'", long42 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 10 + "'", int61 == 10);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-9L) + "'", long74 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology76);
        org.junit.Assert.assertNotNull(monthDay77);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 10 + "'", int84 == 10);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertNotNull(monthDay88);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 999 + "'", int92 == 999);
        org.junit.Assert.assertTrue("'" + long96 + "' != '" + (-31556476800000L) + "'", long96 == (-31556476800000L));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology2 = instant1.getChronology();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int9 = fixedDateTimeZone7.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTime dateTime11 = instant1.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withDurationAdded(readableDuration15, 0);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (-1), chronology19);
        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTimeZone dateTimeZone22 = dateTime20.getZone();
        java.util.TimeZone timeZone23 = dateTimeZone22.toTimeZone();
        org.joda.time.DateTime dateTime24 = dateTime17.toDateTime(dateTimeZone22);
        org.joda.time.DateTime.Property property25 = dateTime17.yearOfEra();
        org.joda.time.DateTime dateTime27 = dateTime17.plusYears((int) (byte) 100);
        try {
            org.joda.time.chrono.LimitChronology limitChronology28 = org.joda.time.chrono.LimitChronology.getInstance(chronology0, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        boolean boolean8 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay6.plus(readablePeriod9);
        int[] intArray12 = new int[] { 0 };
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay10, intArray12);
        java.lang.String str15 = delegatedDateTimeField2.getAsShortText(31L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "31" + "'", str15.equals("31"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        int int20 = offsetDateTimeField13.getMaximumValue();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 292279090 + "'", int20 == 292279090);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = skipUndoDateTimeField32.getWrappedField();
        long long35 = skipUndoDateTimeField32.roundFloor((long) (byte) 100);
        long long37 = skipUndoDateTimeField32.roundHalfEven((long) 100);
        int int39 = skipUndoDateTimeField32.getMaximumValue((long) (byte) 1);
        int int41 = skipUndoDateTimeField32.get((long) 86399);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-10L) + "'", long35 == (-10L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-10L) + "'", long37 == (-10L));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 292279090 + "'", int39 == 292279090);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2067 + "'", int41 == 2067);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = skipUndoDateTimeField32.getWrappedField();
        long long35 = skipUndoDateTimeField32.roundFloor((long) (byte) 100);
        long long37 = skipUndoDateTimeField32.roundHalfEven((long) 100);
        boolean boolean38 = skipUndoDateTimeField32.isSupported();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-10L) + "'", long35 == (-10L));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-10L) + "'", long37 == (-10L));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        long long26 = offsetDateTimeField13.set((long) '#', "2067");
        long long29 = offsetDateTimeField13.getDifferenceAsLong((long) 2, 0L);
        long long31 = offsetDateTimeField13.roundHalfCeiling((-10981L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-10L) + "'", long31 == (-10L));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = skipUndoDateTimeField32.getWrappedField();
        long long35 = skipUndoDateTimeField32.roundFloor((long) (byte) 100);
        long long38 = skipUndoDateTimeField32.getDifferenceAsLong((long) (-54), (-8L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-10L) + "'", long35 == (-10L));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        org.joda.time.DateTime dateTime8 = dateTime6.withMonthOfYear(5);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValue();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        org.joda.time.DateTime dateTime10 = property5.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay11 = dateTime10.toTimeOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.minus(readablePeriod12);
        org.joda.time.DateTime.Property property14 = dateTime13.hourOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(timeOfDay11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime12 = dateTime8.minusHours(10);
        org.joda.time.DateTime.Property property13 = dateTime8.millisOfSecond();
        org.joda.time.DateTime dateTime15 = dateTime8.plusHours(2116);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        int int12 = dateTime8.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime8.minusWeeks(0);
        org.joda.time.DateTime dateTime16 = dateTime8.withDayOfYear((int) ' ');
        org.joda.time.DateTime.Property property17 = dateTime16.era();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        long long4 = dateTimeZone1.convertLocalToUTC(1560632677806L, false);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560657877806L + "'", long4 == 1560657877806L);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.DateTime dateTime17 = dateTime15.minusHours((int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology18 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = copticChronology18.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField20 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19);
        long long23 = delegatedDateTimeField20.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = delegatedDateTimeField20.getType();
        org.joda.time.DateTime.Property property25 = dateTime15.property(dateTimeFieldType24);
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, (java.lang.Number) (-25200000), (java.lang.Number) (-32400000L), (java.lang.Number) 100.0f);
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException("1969", (java.lang.Number) 10.0f, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException("1969", (java.lang.Number) 10.0f, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 1);
        illegalFieldValueException34.addSuppressed((java.lang.Throwable) illegalFieldValueException39);
        illegalFieldValueException29.addSuppressed((java.lang.Throwable) illegalFieldValueException39);
        java.lang.Throwable[] throwableArray42 = illegalFieldValueException39.getSuppressed();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(copticChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 292278122L + "'", long23 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(throwableArray42);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        java.lang.String str12 = gJChronology10.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int19 = fixedDateTimeZone17.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone17);
        int[] intArray22 = gJChronology10.get((org.joda.time.ReadablePartial) monthDay20, 100L);
        org.joda.time.DateTimeField dateTimeField23 = gJChronology10.monthOfYear();
        org.joda.time.Instant instant24 = gJChronology10.getGregorianCutover();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GJChronology[]" + "'", str12.equals("GJChronology[]"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(instant24);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        int int33 = skipUndoDateTimeField32.getMaximumValue();
        boolean boolean34 = skipUndoDateTimeField32.isSupported();
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale36 = null;
        try {
            java.lang.String str37 = skipUndoDateTimeField32.getAsText(readablePartial35, locale36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 292279090 + "'", int33 == 292279090);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        java.lang.String str26 = property25.toString();
        java.lang.String str27 = property25.getAsText();
        int int28 = property25.getMinimumValueOverall();
        long long29 = property25.remainder();
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (-1), chronology31);
        org.joda.time.DateTime dateTime33 = dateTime32.toDateTime();
        int int34 = dateTime32.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.DateTime dateTime36 = dateTime32.toDateTime(dateTimeZone35);
        boolean boolean37 = property25.equals((java.lang.Object) dateTime36);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[dayOfMonth]" + "'", str26.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "24" + "'", str27.equals("24"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 57599999L + "'", long29 == 57599999L);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 365 + "'", int34 == 365);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = skipUndoDateTimeField32.getWrappedField();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long42 = fixedDateTimeZone38.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone38, readableInstant43);
        org.joda.time.MonthDay monthDay45 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone38);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone50 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int52 = fixedDateTimeZone50.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay53 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone50);
        int int54 = monthDay45.compareTo((org.joda.time.ReadablePartial) monthDay53);
        java.util.Locale locale56 = null;
        java.lang.String str57 = skipUndoDateTimeField32.getAsShortText((org.joda.time.ReadablePartial) monthDay45, 0, locale56);
        java.util.Locale locale59 = null;
        java.lang.String str60 = skipUndoDateTimeField32.getAsText(9, locale59);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-9L) + "'", long42 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "0" + "'", str57.equals("0"));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "9" + "'", str60.equals("9"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 0);
        long long4 = dateTimeZone1.adjustOffset((long) (short) 1, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), chronology2);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withDurationAdded(readableDuration4, 0);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (-1), chronology8);
        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime9.getZone();
        java.util.TimeZone timeZone12 = dateTimeZone11.toTimeZone();
        org.joda.time.DateTime dateTime13 = dateTime6.toDateTime(dateTimeZone11);
        org.joda.time.DateTime.Property property14 = dateTime6.yearOfEra();
        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
        java.lang.String str16 = property14.getAsString();
        org.joda.time.DurationField durationField17 = property14.getDurationField();
        org.joda.time.DateTime dateTime18 = property14.withMinimumValue();
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = copticChronology19.getZone();
        org.joda.time.DurationField durationField21 = copticChronology19.centuries();
        org.joda.time.MutableDateTime mutableDateTime22 = dateTime18.toMutableDateTime((org.joda.time.Chronology) copticChronology19);
        try {
            int int25 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime22, "4", (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 0001-01-01T00:00:00.000Z (CopticChronology[UTC])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1969" + "'", str16.equals("1969"));
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(mutableDateTime22);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(86399);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendPattern("");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfHour();
        org.joda.time.DurationField durationField3 = copticChronology0.hours();
        try {
            long long11 = copticChronology0.getDateTimeMillis(292278993, 57599999, 9, 100, 365, 2, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTime dateTime9 = dateTime6.plusWeeks(24);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = dateTime6.toMutableDateTime(chronology10);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int8 = fixedDateTimeZone6.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTime dateTime10 = instant0.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.DateTime dateTime12 = dateTime10.minusYears(9);
        org.joda.time.DateTimeZone dateTimeZone13 = dateTime10.getZone();
        org.joda.time.DateTime.Property property14 = dateTime10.millisOfSecond();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1560632677806L, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        java.util.Locale locale16 = null;
        java.lang.String str17 = property15.getAsText(locale16);
        int int18 = property15.getMinimumValueOverall();
        java.util.Locale locale19 = null;
        int int20 = property15.getMaximumShortTextLength(locale19);
        org.joda.time.MonthDay monthDay21 = property15.getMonthDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long30 = fixedDateTimeZone26.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26, readableInstant31);
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.MonthDay monthDay36 = monthDay34.minusDays((int) (byte) -1);
        int int37 = property15.compareTo((org.joda.time.ReadablePartial) monthDay36);
        org.joda.time.ReadableInstant readableInstant38 = null;
        try {
            int int39 = property15.compareTo(readableInstant38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June" + "'", str17.equals("June"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-9L) + "'", long30 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        java.io.Writer writer2 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (-1), chronology4);
        org.joda.time.DateTime dateTime7 = dateTime5.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property8 = dateTime7.year();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (-1), chronology10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime11);
        int int13 = dateTime7.compareTo((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime.Property property14 = dateTime11.yearOfCentury();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (-1), chronology16);
        org.joda.time.DateTime dateTime19 = dateTime17.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property20 = dateTime19.year();
        int int21 = property20.getMaximumValue();
        java.util.Locale locale22 = null;
        java.lang.String str23 = property20.getAsText(locale22);
        org.joda.time.DateTime dateTime25 = property20.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay26 = dateTime25.toTimeOfDay();
        boolean boolean27 = dateTime11.isBefore((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime.Property property28 = dateTime25.dayOfMonth();
        java.lang.String str29 = property28.toString();
        java.lang.String str30 = property28.getAsText();
        int int31 = property28.getMinimumValueOverall();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime((long) (-1), chronology33);
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime37 = dateTime34.withDurationAdded(readableDuration35, 0);
        org.joda.time.Chronology chronology39 = null;
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) (-1), chronology39);
        org.joda.time.Chronology chronology41 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime40);
        org.joda.time.DateTimeZone dateTimeZone42 = dateTime40.getZone();
        java.util.TimeZone timeZone43 = dateTimeZone42.toTimeZone();
        org.joda.time.DateTime dateTime44 = dateTime37.toDateTime(dateTimeZone42);
        org.joda.time.DateTime dateTime46 = dateTime37.withEra((int) (byte) 1);
        int int47 = property28.compareTo((org.joda.time.ReadableInstant) dateTime46);
        try {
            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) dateTime46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 292278993 + "'", int21 == 292278993);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1969" + "'", str23.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(timeOfDay26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Property[dayOfMonth]" + "'", str29.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "24" + "'", str30.equals("24"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.year();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int29 = fixedDateTimeZone27.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone27);
        int int31 = monthDay22.compareTo((org.joda.time.ReadablePartial) monthDay30);
        org.joda.time.MonthDay monthDay33 = monthDay22.minusMonths(0);
        int[] intArray35 = buddhistChronology9.get((org.joda.time.ReadablePartial) monthDay33, (long) 89);
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime((long) (-1), chronology37);
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime38.withDurationAdded(readableDuration39, 0);
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime((long) (-1), chronology43);
        org.joda.time.Chronology chronology45 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime44);
        org.joda.time.DateTimeZone dateTimeZone46 = dateTime44.getZone();
        java.util.TimeZone timeZone47 = dateTimeZone46.toTimeZone();
        org.joda.time.DateTime dateTime48 = dateTime41.toDateTime(dateTimeZone46);
        org.joda.time.DateTime.Property property49 = dateTime41.yearOfEra();
        org.joda.time.DateTime dateTime51 = dateTime41.minusDays(0);
        org.joda.time.Chronology chronology53 = null;
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime((long) (-1), chronology53);
        org.joda.time.DateTime dateTime56 = dateTime54.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property57 = dateTime56.year();
        org.joda.time.Chronology chronology59 = null;
        org.joda.time.DateTime dateTime60 = new org.joda.time.DateTime((long) (-1), chronology59);
        org.joda.time.Chronology chronology61 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime60);
        int int62 = dateTime56.compareTo((org.joda.time.ReadableInstant) dateTime60);
        org.joda.time.DateTime.Property property63 = dateTime60.yearOfCentury();
        boolean boolean64 = dateTime41.isEqual((org.joda.time.ReadableInstant) dateTime60);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone69 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long73 = fixedDateTimeZone69.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant74 = null;
        org.joda.time.chrono.GJChronology gJChronology75 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone69, readableInstant74);
        org.joda.time.MonthDay monthDay76 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone69);
        org.joda.time.DateTime dateTime77 = dateTime41.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone69);
        org.joda.time.DateTime.Property property78 = dateTime77.secondOfMinute();
        org.joda.time.chrono.CopticChronology copticChronology79 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField80 = copticChronology79.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField81 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField80);
        long long84 = delegatedDateTimeField81.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType85 = delegatedDateTimeField81.getType();
        org.joda.time.DateTime.Property property86 = dateTime77.property(dateTimeFieldType85);
        try {
            org.joda.time.MonthDay.Property property87 = monthDay33.property(dateTimeFieldType85);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'millisOfSecond' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(chronology61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-9L) + "'", long73 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology75);
        org.junit.Assert.assertNotNull(monthDay76);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertNotNull(property78);
        org.junit.Assert.assertNotNull(copticChronology79);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 292278122L + "'", long84 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType85);
        org.junit.Assert.assertNotNull(property86);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(1560632687348L, 62135510400000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 63696143087348L + "'", long2 == 63696143087348L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime dateTime26 = dateTime22.plusWeeks(365);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        long long26 = offsetDateTimeField13.set((long) '#', "2067");
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField13.getAsText((int) (byte) 100, locale28);
        long long32 = offsetDateTimeField13.add((long) 100, 100L);
        int int34 = offsetDateTimeField13.getLeapAmount(0L);
        java.util.Locale locale36 = null;
        java.lang.String str37 = offsetDateTimeField13.getAsText((int) ' ', locale36);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "100" + "'", str29.equals("100"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 3155760000100L + "'", long32 == 3155760000100L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "32" + "'", str37.equals("32"));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.DateTime dateTime9 = dateTime7.minus((long) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths(53);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        try {
            long long5 = dateTimeFormatter2.parseMillis("+00:00:00.010");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+00:00:00.010\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        int int26 = dateTime22.getYearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime28 = dateTime22.plus(readablePeriod27);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = dateTime28.toDateTime(dateTimeZone29);
        org.joda.time.DateTime.Property property31 = dateTime28.monthOfYear();
        java.util.Locale locale32 = null;
        int int33 = property31.getMaximumTextLength(locale32);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 9 + "'", int33 == 9);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendTimeZoneOffset("-01:00", "DateTimeField[yearOfEra]", false, 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = skipUndoDateTimeField32.getWrappedField();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long42 = fixedDateTimeZone38.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant43 = null;
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone38, readableInstant43);
        org.joda.time.MonthDay monthDay45 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone38);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone50 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int52 = fixedDateTimeZone50.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay53 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone50);
        int int54 = monthDay45.compareTo((org.joda.time.ReadablePartial) monthDay53);
        java.util.Locale locale56 = null;
        java.lang.String str57 = skipUndoDateTimeField32.getAsShortText((org.joda.time.ReadablePartial) monthDay45, 0, locale56);
        org.joda.time.MonthDay monthDay59 = monthDay45.minusDays(359);
        org.joda.time.ReadablePeriod readablePeriod60 = null;
        org.joda.time.MonthDay monthDay61 = monthDay45.minus(readablePeriod60);
        try {
            java.lang.String str63 = monthDay61.toString("year");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-9L) + "'", long42 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "0" + "'", str57.equals("0"));
        org.junit.Assert.assertNotNull(monthDay59);
        org.junit.Assert.assertNotNull(monthDay61);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.clockhourOfHalfday();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (-1), chronology4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded(readableDuration6, 0);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (-1), chronology10);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTimeZone dateTimeZone13 = dateTime11.getZone();
        java.util.TimeZone timeZone14 = dateTimeZone13.toTimeZone();
        org.joda.time.DateTime dateTime15 = dateTime8.toDateTime(dateTimeZone13);
        org.joda.time.DateTime.Property property16 = dateTime8.yearOfEra();
        org.joda.time.DateTime dateTime18 = dateTime8.minusMillis(10);
        boolean boolean19 = dateTime2.isBefore((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime21 = dateTime2.minusYears(0);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTime21);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("1969");
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withZoneUTC();
        java.lang.Appendable appendable4 = null;
        try {
            dateTimeFormatter3.printTo(appendable4, (long) (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        java.lang.String str1 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[UTC]" + "'", str1.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long14 = fixedDateTimeZone10.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone10, readableInstant15);
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        boolean boolean19 = fixedDateTimeZone10.isFixed();
        org.joda.time.Chronology chronology20 = julianChronology5.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone10);
        org.joda.time.DurationField durationField21 = julianChronology5.months();
        org.joda.time.DateTimeZone dateTimeZone22 = julianChronology5.getZone();
        try {
            org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((int) (byte) 100, (-25200000), 89, 86399, 718790, (org.joda.time.Chronology) julianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-9L) + "'", long14 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = skipUndoDateTimeField32.getWrappedField();
        org.joda.time.chrono.CopticChronology copticChronology34 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField35 = copticChronology34.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField36 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField35);
        long long39 = delegatedDateTimeField36.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay40 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay41 = org.joda.time.MonthDay.now();
        boolean boolean42 = monthDay40.isEqual((org.joda.time.ReadablePartial) monthDay41);
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.MonthDay monthDay44 = monthDay40.plus(readablePeriod43);
        int[] intArray46 = new int[] { 0 };
        int int47 = delegatedDateTimeField36.getMaximumValue((org.joda.time.ReadablePartial) monthDay44, intArray46);
        org.joda.time.chrono.JulianChronology julianChronology48 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay49 = monthDay44.withChronologyRetainFields((org.joda.time.Chronology) julianChronology48);
        java.util.Locale locale51 = null;
        java.lang.String str52 = skipUndoDateTimeField32.getAsText((org.joda.time.ReadablePartial) monthDay49, 1, locale51);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone57 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long61 = fixedDateTimeZone57.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant62 = null;
        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone57, readableInstant62);
        java.lang.Object obj64 = null;
        boolean boolean65 = fixedDateTimeZone57.equals(obj64);
        org.joda.time.MonthDay monthDay66 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone57);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone72 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long76 = fixedDateTimeZone72.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant77 = null;
        org.joda.time.chrono.GJChronology gJChronology78 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone72, readableInstant77);
        org.joda.time.DateTimeField dateTimeField79 = gJChronology78.yearOfEra();
        java.lang.String str80 = gJChronology78.toString();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone85 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int87 = fixedDateTimeZone85.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay88 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone85);
        int[] intArray90 = gJChronology78.get((org.joda.time.ReadablePartial) monthDay88, 100L);
        try {
            int[] intArray92 = skipUndoDateTimeField32.add((org.joda.time.ReadablePartial) monthDay66, (int) (short) 100, intArray90, 718790);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(copticChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 292278122L + "'", long39 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 999 + "'", int47 == 999);
        org.junit.Assert.assertNotNull(julianChronology48);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "1" + "'", str52.equals("1"));
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + (-9L) + "'", long61 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(monthDay66);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-9L) + "'", long76 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "GJChronology[]" + "'", str80.equals("GJChronology[]"));
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 10 + "'", int87 == 10);
        org.junit.Assert.assertNotNull(intArray90);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(10990L, (int) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 571480L + "'", long2 == 571480L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long30 = fixedDateTimeZone26.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone26, readableInstant31);
        org.joda.time.MonthDay monthDay33 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone38 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int40 = fixedDateTimeZone38.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone38);
        int int42 = monthDay33.compareTo((org.joda.time.ReadablePartial) monthDay41);
        org.joda.time.MonthDay monthDay44 = monthDay41.plusDays((-1));
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone50 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int52 = fixedDateTimeZone50.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str54 = fixedDateTimeZone50.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology55 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone50);
        org.joda.time.DateTimeField dateTimeField56 = buddhistChronology55.year();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone61 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long65 = fixedDateTimeZone61.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant66 = null;
        org.joda.time.chrono.GJChronology gJChronology67 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone61, readableInstant66);
        org.joda.time.MonthDay monthDay68 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone61);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone73 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int75 = fixedDateTimeZone73.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay76 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone73);
        int int77 = monthDay68.compareTo((org.joda.time.ReadablePartial) monthDay76);
        org.joda.time.MonthDay monthDay79 = monthDay68.minusMonths(0);
        int[] intArray81 = buddhistChronology55.get((org.joda.time.ReadablePartial) monthDay79, (long) 89);
        try {
            int[] intArray83 = offsetDateTimeField13.set((org.joda.time.ReadablePartial) monthDay44, 98, intArray81, 57599999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 98");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-9L) + "'", long30 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 10 + "'", int40 == 10);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(monthDay44);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 10 + "'", int52 == 10);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + (-9L) + "'", long65 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology67);
        org.junit.Assert.assertNotNull(monthDay68);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 10 + "'", int75 == 10);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(monthDay79);
        org.junit.Assert.assertNotNull(intArray81);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds((int) (short) 1);
        int int15 = dateTime14.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 58 + "'", int15 == 58);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 15, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((int) ' ', 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), chronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property16 = dateTime15.year();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), chronology18);
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime19);
        int int21 = dateTime15.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime.Property property22 = dateTime19.yearOfCentury();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), chronology24);
        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property28 = dateTime27.year();
        int int29 = property28.getMaximumValue();
        java.util.Locale locale30 = null;
        java.lang.String str31 = property28.getAsText(locale30);
        org.joda.time.DateTime dateTime33 = property28.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay34 = dateTime33.toTimeOfDay();
        boolean boolean35 = dateTime19.isBefore((org.joda.time.ReadableInstant) dateTime33);
        int int36 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean38 = cachedDateTimeZone37.isFixed();
        java.lang.String str40 = cachedDateTimeZone37.getNameKey((long) 1);
        int int42 = cachedDateTimeZone37.getOffset((long) 100);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 292278993 + "'", int29 == 292278993);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969" + "'", str31.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(timeOfDay34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 10 + "'", int42 == 10);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        int int16 = property15.getMaximumValue();
        java.lang.String str17 = property15.getAsString();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "6" + "'", str17.equals("6"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        boolean boolean8 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay6.plus(readablePeriod9);
        int[] intArray12 = new int[] { 0 };
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay10, intArray12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField2.getDurationField();
        java.util.Locale locale16 = null;
        java.lang.String str17 = delegatedDateTimeField2.getAsText((long) 0, locale16);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.plusYears((int) (byte) 100);
        org.joda.time.DateTime.Property property16 = dateTime5.dayOfYear();
        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay18 = org.joda.time.MonthDay.now();
        boolean boolean19 = monthDay17.isEqual((org.joda.time.ReadablePartial) monthDay18);
        org.joda.time.MonthDay monthDay21 = monthDay17.minusDays((int) (byte) 0);
        org.joda.time.DateTimeField[] dateTimeFieldArray22 = monthDay17.getFields();
        org.joda.time.DateTime dateTime23 = dateTime5.withFields((org.joda.time.ReadablePartial) monthDay17);
        int int24 = dateTime23.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(dateTimeFieldArray22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 59 + "'", int24 == 59);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        java.lang.Object obj22 = null;
        boolean boolean23 = fixedDateTimeZone15.equals(obj22);
        long long25 = fixedDateTimeZone15.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology26 = gJChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTimeField dateTimeField27 = gJChronology10.era();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31556476799900L) + "'", long25 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        java.lang.Object obj22 = null;
        boolean boolean23 = fixedDateTimeZone15.equals(obj22);
        long long25 = fixedDateTimeZone15.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology26 = gJChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTimeField dateTimeField27 = gJChronology10.secondOfDay();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology10.millisOfDay();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31556476799900L) + "'", long25 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        int int4 = delegatedDateTimeField2.getMinimumValue((long) (byte) 10);
        org.joda.time.ReadablePartial readablePartial5 = null;
        int int6 = delegatedDateTimeField2.getMinimumValue(readablePartial5);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField8 = copticChronology7.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField9 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField8);
        long long12 = delegatedDateTimeField9.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay14 = org.joda.time.MonthDay.now();
        boolean boolean15 = monthDay13.isEqual((org.joda.time.ReadablePartial) monthDay14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay17 = monthDay13.plus(readablePeriod16);
        int[] intArray19 = new int[] { 0 };
        int int20 = delegatedDateTimeField9.getMaximumValue((org.joda.time.ReadablePartial) monthDay17, intArray19);
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay22 = monthDay17.withChronologyRetainFields((org.joda.time.Chronology) julianChronology21);
        int[] intArray24 = null;
        try {
            int[] intArray26 = delegatedDateTimeField2.set((org.joda.time.ReadablePartial) monthDay17, (int) ' ', intArray24, 366);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 292278122L + "'", long12 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 999 + "'", int20 == 999);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(monthDay22);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime dateTime12 = dateTime8.minusHours(10);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMillis((int) '#');
        org.joda.time.DateTime.Property property15 = dateTime14.era();
        int int16 = dateTime14.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 34 + "'", int16 == 34);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        boolean boolean8 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay6.plus(readablePeriod9);
        int[] intArray12 = new int[] { 0 };
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay10, intArray12);
        int int14 = monthDay10.size();
        org.joda.time.MonthDay.Property property15 = monthDay10.dayOfMonth();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay18 = monthDay10.withPeriodAdded(readablePeriod16, 0);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(monthDay18);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "2019-06-15T21:04:46.111Z");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        int int26 = dateTime22.getYearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime28 = dateTime22.plus(readablePeriod27);
        java.util.GregorianCalendar gregorianCalendar29 = dateTime28.toGregorianCalendar();
        boolean boolean31 = dateTime28.isAfter(94694400010L);
        org.joda.time.DateTime.Property property32 = dateTime28.weekyear();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gregorianCalendar29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(property32);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("31", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"31/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = gJChronology10.monthOfYear();
        org.joda.time.Instant instant34 = gJChronology10.getGregorianCutover();
        org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField36 = copticChronology35.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField36);
        java.lang.String str39 = delegatedDateTimeField37.getAsText((long) (byte) 10);
        java.util.Locale locale41 = null;
        java.lang.String str42 = delegatedDateTimeField37.getAsText(0L, locale41);
        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) delegatedDateTimeField37, 358);
        org.joda.time.DurationField durationField45 = delegatedDateTimeField37.getDurationField();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(instant34);
        org.junit.Assert.assertNotNull(copticChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10" + "'", str39.equals("10"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "0" + "'", str42.equals("0"));
        org.junit.Assert.assertNotNull(durationField45);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(15, 9, 4, 59, 358, 4, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("21:05");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"21:05\" is malformed at \":05\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(10990L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField[] dateTimeFieldArray12 = monthDay11.getFields();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay14 = monthDay11.minus(readablePeriod13);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(dateTimeFieldArray12);
        org.junit.Assert.assertNotNull(monthDay14);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfCentury();
        boolean boolean28 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long37 = fixedDateTimeZone33.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone33, readableInstant38);
        org.joda.time.MonthDay monthDay40 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.DateTime dateTime41 = dateTime5.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.DateTime.Property property42 = dateTime41.secondOfMinute();
        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.Chronology chronology44 = buddhistChronology43.withUTC();
        org.joda.time.MutableDateTime mutableDateTime45 = dateTime41.toMutableDateTime(chronology44);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-9L) + "'", long37 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(buddhistChronology43);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertNotNull(mutableDateTime45);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        org.joda.time.DurationField durationField16 = property15.getRangeDurationField();
        int int17 = property15.getMinimumValueOverall();
        org.joda.time.DateTimeField dateTimeField18 = property15.getField();
        org.joda.time.DurationField durationField19 = property15.getRangeDurationField();
        org.joda.time.DurationFieldType durationFieldType20 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField21 = new org.joda.time.field.DecoratedDurationField(durationField19, durationFieldType20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.Interval interval14 = property13.toInterval();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        boolean boolean16 = property13.equals((java.lang.Object) dateTimeFormatter15);
        java.util.Locale locale17 = null;
        int int18 = property13.getMaximumTextLength(locale17);
        org.joda.time.Interval interval19 = property13.toInterval();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(interval14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 9 + "'", int18 == 9);
        org.junit.Assert.assertNotNull(interval19);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValue();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        org.joda.time.DateTime dateTime10 = property5.setCopy(0);
        org.joda.time.DateTime dateTime12 = dateTime10.minusHours(359);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        java.lang.String str26 = property25.toString();
        boolean boolean27 = property25.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
        java.lang.Number number29 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, number29, (java.lang.Number) 10L, (java.lang.Number) 999);
        org.joda.time.IllegalFieldValueException illegalFieldValueException37 = new org.joda.time.IllegalFieldValueException("1969", (java.lang.Number) 10.0f, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 1);
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException("1969", (java.lang.Number) 10.0f, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 1);
        illegalFieldValueException37.addSuppressed((java.lang.Throwable) illegalFieldValueException42);
        boolean boolean44 = org.joda.time.field.FieldUtils.equals((java.lang.Object) illegalFieldValueException32, (java.lang.Object) illegalFieldValueException37);
        java.lang.String str45 = illegalFieldValueException37.getFieldName();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[dayOfMonth]" + "'", str26.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "1969" + "'", str45.equals("1969"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 31");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.centuries();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), chronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property16 = dateTime15.year();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), chronology18);
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime19);
        int int21 = dateTime15.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime.Property property22 = dateTime19.yearOfCentury();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), chronology24);
        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property28 = dateTime27.year();
        int int29 = property28.getMaximumValue();
        java.util.Locale locale30 = null;
        java.lang.String str31 = property28.getAsText(locale30);
        org.joda.time.DateTime dateTime33 = property28.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay34 = dateTime33.toTimeOfDay();
        boolean boolean35 = dateTime19.isBefore((org.joda.time.ReadableInstant) dateTime33);
        int int36 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean38 = cachedDateTimeZone37.isFixed();
        long long40 = cachedDateTimeZone37.previousTransition((long) 31);
        boolean boolean41 = cachedDateTimeZone37.isFixed();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 292278993 + "'", int29 == 292278993);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969" + "'", str31.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(timeOfDay34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 31L + "'", long40 == 31L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValue();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        org.joda.time.DateTime dateTime10 = property5.setCopy(0);
        org.joda.time.DateTime dateTime12 = dateTime10.withWeekyear(0);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), chronology14);
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime15.getZone();
        org.joda.time.LocalTime localTime18 = dateTime15.toLocalTime();
        org.joda.time.MutableDateTime mutableDateTime19 = dateTime15.toMutableDateTime();
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime10, (org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.TimeOfDay timeOfDay21 = dateTime15.toTimeOfDay();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(localTime18);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(timeOfDay21);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        int int3 = dateTime2.getDayOfWeek();
        org.joda.time.DateTime dateTime5 = dateTime2.plusHours(0);
        org.joda.time.DateTime.Property property6 = dateTime5.hourOfDay();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 3 + "'", int3 == 3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long11 = fixedDateTimeZone7.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone7, readableInstant12);
        org.joda.time.DateTimeField dateTimeField14 = gJChronology13.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) 'a');
        long long18 = offsetDateTimeField16.roundCeiling(10L);
        long long20 = offsetDateTimeField16.roundCeiling(0L);
        long long22 = offsetDateTimeField16.roundHalfEven((long) (short) 0);
        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay24 = org.joda.time.MonthDay.now();
        boolean boolean25 = monthDay23.isEqual((org.joda.time.ReadablePartial) monthDay24);
        org.joda.time.MonthDay monthDay27 = monthDay23.minusDays((int) (byte) 0);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.MonthDay monthDay29 = monthDay23.plus(readablePeriod28);
        int int30 = offsetDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) monthDay23);
        boolean boolean31 = copticChronology0.equals((java.lang.Object) int30);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-9L) + "'", long11 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 31535999990L + "'", long18 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 31535999990L + "'", long20 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-10L) + "'", long22 == (-10L));
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 98 + "'", int30 == 98);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        java.lang.String str26 = property25.toString();
        java.lang.String str27 = property25.getAsText();
        int int28 = property25.getMinimumValueOverall();
        long long29 = property25.remainder();
        java.util.Locale locale30 = null;
        int int31 = property25.getMaximumTextLength(locale30);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[dayOfMonth]" + "'", str26.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "24" + "'", str27.equals("24"));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 57599999L + "'", long29 == 57599999L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        long long15 = gJChronology10.add((-27471802021969L), (long) 34, 53);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-27471802020167L) + "'", long15 == (-27471802020167L));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType24);
        int int27 = offsetDateTimeField13.get(1560632677806L);
        org.joda.time.MonthDay monthDay29 = new org.joda.time.MonthDay((long) (short) 10);
        org.joda.time.MonthDay.Property property30 = monthDay29.dayOfMonth();
        int int31 = offsetDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) monthDay29);
        int int32 = offsetDateTimeField13.getOffset();
        long long35 = offsetDateTimeField13.add(0L, 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2116 + "'", int27 == 2116);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 292279090 + "'", int31 == 292279090);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 97 + "'", int32 == 97);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        java.lang.String str26 = property25.toString();
        int int27 = property25.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[dayOfMonth]" + "'", str26.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        int int12 = dateTime8.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime8.minusWeeks(0);
        org.joda.time.DateTime dateTime16 = dateTime14.plus(1560632677806L);
        java.lang.String str17 = dateTime14.toString();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1969-12-31T15:59:59.999-08:00" + "'", str17.equals("1969-12-31T15:59:59.999-08:00"));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((-98), (int) (byte) 100, 100, (int) 'a', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        java.lang.Object obj22 = null;
        boolean boolean23 = fixedDateTimeZone15.equals(obj22);
        long long25 = fixedDateTimeZone15.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology26 = gJChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTimeField dateTimeField27 = gJChronology10.secondOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField27);
        try {
            long long31 = delegatedDateTimeField28.set(57599999L, "+00:00:00.010");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00:00.010\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-31556476799900L) + "'", long25 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        boolean boolean8 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay6.plus(readablePeriod9);
        int[] intArray12 = new int[] { 0 };
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay10, intArray12);
        int int14 = monthDay10.size();
        org.joda.time.MonthDay.Property property15 = monthDay10.dayOfMonth();
        org.joda.time.chrono.CopticChronology copticChronology16 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = copticChronology16.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField18 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField17);
        long long21 = delegatedDateTimeField18.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now();
        boolean boolean24 = monthDay22.isEqual((org.joda.time.ReadablePartial) monthDay23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.MonthDay monthDay26 = monthDay22.plus(readablePeriod25);
        int[] intArray28 = new int[] { 0 };
        int int29 = delegatedDateTimeField18.getMaximumValue((org.joda.time.ReadablePartial) monthDay26, intArray28);
        org.joda.time.chrono.JulianChronology julianChronology30 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.MonthDay monthDay31 = monthDay26.withChronologyRetainFields((org.joda.time.Chronology) julianChronology30);
        boolean boolean32 = monthDay10.isAfter((org.joda.time.ReadablePartial) monthDay31);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(copticChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 292278122L + "'", long21 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 999 + "'", int29 == 999);
        org.junit.Assert.assertNotNull(julianChronology30);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(1);
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter2.printTo(stringBuffer3, (-1560632710L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(571480L);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(86399);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendPattern("");
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfMonth((-292275054));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), chronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property16 = dateTime15.year();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), chronology18);
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime19);
        int int21 = dateTime15.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime.Property property22 = dateTime19.yearOfCentury();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), chronology24);
        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property28 = dateTime27.year();
        int int29 = property28.getMaximumValue();
        java.util.Locale locale30 = null;
        java.lang.String str31 = property28.getAsText(locale30);
        org.joda.time.DateTime dateTime33 = property28.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay34 = dateTime33.toTimeOfDay();
        boolean boolean35 = dateTime19.isBefore((org.joda.time.ReadableInstant) dateTime33);
        int int36 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean38 = cachedDateTimeZone37.isFixed();
        boolean boolean39 = cachedDateTimeZone37.isFixed();
        try {
            org.joda.time.chrono.CopticChronology copticChronology41 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone37, (-54));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -54");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 292278993 + "'", int29 == 292278993);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969" + "'", str31.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(timeOfDay34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(86399);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap3);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(int2);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (-28800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatterBuilder0.toPrinter();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfMonth((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValue();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        org.joda.time.DateTime dateTime10 = property5.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay11 = dateTime10.toTimeOfDay();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.minus(readablePeriod12);
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime13);
        try {
            org.joda.time.DateTime dateTime16 = dateTime13.withDayOfMonth(1099);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1099 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(timeOfDay11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(chronology14);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType24);
        long long28 = offsetDateTimeField13.getDifferenceAsLong((long) (short) 1, (long) 292278993);
        long long31 = offsetDateTimeField13.add((long) 86399, 0);
        int int33 = offsetDateTimeField13.getLeapAmount((-27471802020167L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 86399L + "'", long31 == 86399L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DurationField durationField2 = copticChronology0.halfdays();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.Chronology chronology4 = copticChronology0.withZone(dateTimeZone3);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType24);
        int int27 = offsetDateTimeField13.get(1560632677806L);
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField13.getAsText((long) 1, locale29);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2116 + "'", int27 == 2116);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "2067" + "'", str30.equals("2067"));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.year();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int29 = fixedDateTimeZone27.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone27);
        int int31 = monthDay22.compareTo((org.joda.time.ReadablePartial) monthDay30);
        org.joda.time.MonthDay monthDay33 = monthDay22.minusMonths(0);
        int[] intArray35 = buddhistChronology9.get((org.joda.time.ReadablePartial) monthDay33, (long) 89);
        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology9.halfdayOfDay();
        org.joda.time.Chronology chronology37 = buddhistChronology9.withUTC();
        org.joda.time.DateTimeField dateTimeField38 = buddhistChronology9.yearOfCentury();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValue();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        org.joda.time.DateTime dateTime10 = property5.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay11 = dateTime10.toTimeOfDay();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime14.getZone();
        org.joda.time.LocalTime localTime17 = dateTime14.toLocalTime();
        org.joda.time.DateTime dateTime18 = dateTime10.withFields((org.joda.time.ReadablePartial) localTime17);
        int int19 = dateTime10.getMillisOfDay();
        org.joda.time.Chronology chronology20 = dateTime10.getChronology();
        org.joda.time.DurationFieldType durationFieldType21 = null;
        try {
            org.joda.time.DateTime dateTime23 = dateTime10.withFieldAdded(durationFieldType21, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(timeOfDay11);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(localTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 57599999 + "'", int19 == 57599999);
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        java.lang.String str26 = property25.toString();
        boolean boolean27 = property25.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
        java.util.Locale locale29 = null;
        int int30 = property25.getMaximumTextLength(locale29);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[dayOfMonth]" + "'", str26.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.lang.Object obj0 = null;
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.DateTimeField dateTimeField12 = gJChronology11.yearOfEra();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.weekyear();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gJChronology11);
        boolean boolean15 = dateTime14.isAfterNow();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField3 = copticChronology0.year();
        org.joda.time.chrono.CopticChronology copticChronology4 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = copticChronology4.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        long long9 = delegatedDateTimeField6.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = delegatedDateTimeField6.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField12 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType10, 86399);
        long long15 = dividedDateTimeField12.addWrapField((-10981L), 5);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(copticChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 292278122L + "'", long9 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 13632725433589019L + "'", long15 == 13632725433589019L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int22 = offsetDateTimeField13.getMaximumValue();
        org.joda.time.DurationField durationField23 = offsetDateTimeField13.getLeapDurationField();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292279090 + "'", int22 == 292279090);
        org.junit.Assert.assertNull(durationField23);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int22 = offsetDateTimeField13.getMaximumValue();
        try {
            long long25 = offsetDateTimeField13.set((long) 166, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3 for yearOfEra must be in the range [98,292279090]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 292279090 + "'", int22 == 292279090);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfCentury();
        boolean boolean28 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long37 = fixedDateTimeZone33.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone33, readableInstant38);
        org.joda.time.MonthDay monthDay40 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.DateTime dateTime41 = dateTime5.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone33);
        org.joda.time.DateTime.Property property42 = dateTime41.millisOfSecond();
        org.joda.time.DateTime.Property property43 = dateTime41.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + (-9L) + "'", long37 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(property43);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.Chronology chronology12 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        long long16 = gregorianChronology0.add(readablePeriod13, (long) (byte) 10, 53);
        org.joda.time.DurationField durationField17 = gregorianChronology0.years();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019-06-15T21:04:52.040Z");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.Object obj3 = null;
        jodaTimePermission1.checkGuard(obj3);
        java.security.PermissionCollection permissionCollection5 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertNotNull(permissionCollection5);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(86399);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap3);
        dateTimeFormatterBuilder2.clear();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendFixedDecimal(dateTimeFieldType6, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (-1), chronology17);
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property21 = dateTime20.year();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (-1), chronology23);
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime24);
        int int26 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property27 = dateTime24.yearOfCentury();
        boolean boolean28 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime24);
        org.joda.time.DateTime.Property property29 = dateTime5.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(property29);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        java.lang.String str24 = offsetDateTimeField13.toString();
        long long26 = offsetDateTimeField13.roundCeiling((long) (-25200000));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "DateTimeField[yearOfEra]" + "'", str24.equals("DateTimeField[yearOfEra]"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-10L) + "'", long26 == (-10L));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long20 = fixedDateTimeZone16.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant21 = null;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone16, readableInstant21);
        java.lang.Object obj23 = null;
        boolean boolean24 = fixedDateTimeZone16.equals(obj23);
        long long26 = fixedDateTimeZone16.nextTransition((-31556476799900L));
        org.joda.time.Chronology chronology27 = gJChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DateTimeField dateTimeField28 = gJChronology11.secondOfDay();
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) 0, (org.joda.time.Chronology) gJChronology11);
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((org.joda.time.Chronology) gJChronology11);
        org.joda.time.DurationField durationField31 = gJChronology11.minutes();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-9L) + "'", long20 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-31556476799900L) + "'", long26 == (-31556476799900L));
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(durationField31);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DurationField durationField11 = gJChronology10.millis();
        org.joda.time.DurationField durationField12 = gJChronology10.centuries();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DateTimeField dateTimeField24 = gJChronology23.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) 'a');
        long long28 = offsetDateTimeField26.roundCeiling(10L);
        long long30 = offsetDateTimeField26.roundCeiling(0L);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) offsetDateTimeField26, (int) (short) 1);
        org.joda.time.DateTimeField dateTimeField33 = gJChronology10.monthOfYear();
        boolean boolean35 = gJChronology10.equals((java.lang.Object) (short) 100);
        org.joda.time.DateTimeZone dateTimeZone36 = gJChronology10.getZone();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 31535999990L + "'", long28 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31535999990L + "'", long30 == 31535999990L);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dateTimeZone36);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        java.lang.Object obj11 = null;
        boolean boolean12 = fixedDateTimeZone4.equals(obj11);
        org.joda.time.MonthDay monthDay13 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.TimeZone timeZone14 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forTimeZone(timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(monthDay13);
        org.junit.Assert.assertNotNull(timeZone14);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTime8.toString("-01:00", locale12);
        org.joda.time.DateTime dateTime14 = dateTime8.toDateTime();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "-01:00" + "'", str13.equals("-01:00"));
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        int int6 = property5.getMaximumValue();
        java.util.Locale locale7 = null;
        java.lang.String str8 = property5.getAsText(locale7);
        java.util.Locale locale9 = null;
        int int10 = property5.getMaximumTextLength(locale9);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 292278993 + "'", int6 == 292278993);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 9 + "'", int10 == 9);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        java.lang.Object obj11 = null;
        boolean boolean12 = fixedDateTimeZone4.equals(obj11);
        int int14 = fixedDateTimeZone4.getOffsetFromLocal((-9L));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType24);
        long long28 = offsetDateTimeField13.getDifferenceAsLong((long) (short) 1, (long) 292278993);
        long long31 = offsetDateTimeField13.add((long) 86399, 0);
        boolean boolean33 = offsetDateTimeField13.isLeap((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 86399L + "'", long31 == 86399L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        java.lang.String str26 = property25.toString();
        boolean boolean27 = property25.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
        java.lang.Number number29 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType28, number29, (java.lang.Number) 10L, (java.lang.Number) 999);
        java.lang.String str33 = illegalFieldValueException32.toString();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[dayOfMonth]" + "'", str26.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.joda.time.IllegalFieldValueException: Value null for dayOfMonth must be in the range [10,999]" + "'", str33.equals("org.joda.time.IllegalFieldValueException: Value null for dayOfMonth must be in the range [10,999]"));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        boolean boolean14 = fixedDateTimeZone5.isFixed();
        org.joda.time.Chronology chronology15 = julianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.Chronology chronology16 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long2 = dateTimeZone0.convertUTCToLocal((long) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28799903L) + "'", long2 == (-28799903L));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DurationField durationField1 = copticChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.minuteOfHour();
        org.joda.time.Chronology chronology3 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (-1), chronology2);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10, chronology4);
        org.joda.time.LocalTime localTime6 = dateTime5.toLocalTime();
        org.joda.time.DateTime dateTime8 = dateTime5.plusMonths(366);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(localTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        long long5 = delegatedDateTimeField2.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay6 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        boolean boolean8 = monthDay6.isEqual((org.joda.time.ReadablePartial) monthDay7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.MonthDay monthDay10 = monthDay6.plus(readablePeriod9);
        int[] intArray12 = new int[] { 0 };
        int int13 = delegatedDateTimeField2.getMaximumValue((org.joda.time.ReadablePartial) monthDay10, intArray12);
        org.joda.time.DurationField durationField14 = delegatedDateTimeField2.getDurationField();
        int int16 = delegatedDateTimeField2.getMaximumValue((-3599999L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 292278122L + "'", long5 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay6);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 999 + "'", int13 == 999);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 999 + "'", int16 == 999);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        java.lang.Object obj11 = null;
        boolean boolean12 = fixedDateTimeZone4.equals(obj11);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (-1), chronology14);
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.DateTime dateTime18 = dateTime15.withDurationAdded(readableDuration16, 0);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (-1), chronology20);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime21.getZone();
        java.util.TimeZone timeZone24 = dateTimeZone23.toTimeZone();
        org.joda.time.DateTime dateTime25 = dateTime18.toDateTime(dateTimeZone23);
        org.joda.time.DateTime.Property property26 = dateTime18.yearOfEra();
        org.joda.time.DateTime dateTime28 = dateTime18.minusMillis(10);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTimeField dateTimeField30 = gJChronology29.millisOfSecond();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime4.compareTo((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property11 = dateTime8.yearOfCentury();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (-1), chronology13);
        org.joda.time.DateTime dateTime16 = dateTime14.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        int int18 = property17.getMaximumValue();
        java.util.Locale locale19 = null;
        java.lang.String str20 = property17.getAsText(locale19);
        org.joda.time.DateTime dateTime22 = property17.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay23 = dateTime22.toTimeOfDay();
        boolean boolean24 = dateTime8.isBefore((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property25 = dateTime22.dayOfMonth();
        java.lang.String str26 = property25.toString();
        boolean boolean27 = property25.isLeap();
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
        java.lang.String str29 = property25.getAsText();
        org.joda.time.DateTime dateTime30 = property25.roundCeilingCopy();
        org.joda.time.DateTime dateTime32 = dateTime30.withMillisOfSecond((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 292278993 + "'", int18 == 292278993);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969" + "'", str20.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(timeOfDay23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Property[dayOfMonth]" + "'", str26.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "24" + "'", str29.equals("24"));
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int13 = fixedDateTimeZone11.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str15 = fixedDateTimeZone11.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology16.year();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long26 = fixedDateTimeZone22.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone22, readableInstant27);
        org.joda.time.MonthDay monthDay29 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone34 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int36 = fixedDateTimeZone34.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay37 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone34);
        int int38 = monthDay29.compareTo((org.joda.time.ReadablePartial) monthDay37);
        org.joda.time.MonthDay monthDay40 = monthDay29.minusMonths(0);
        int[] intArray42 = buddhistChronology16.get((org.joda.time.ReadablePartial) monthDay40, (long) 89);
        org.joda.time.DateTimeField dateTimeField43 = buddhistChronology16.halfdayOfDay();
        try {
            org.joda.time.DateTime dateTime44 = new org.joda.time.DateTime(999, 1099, 2116, 5, 365, 57599999, 31, (org.joda.time.Chronology) buddhistChronology16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1099 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-9L) + "'", long26 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(monthDay40);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(dateTimeField43);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str8 = fixedDateTimeZone4.getNameKey((long) 0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology9.year();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long19 = fixedDateTimeZone15.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant20 = null;
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15, readableInstant20);
        org.joda.time.MonthDay monthDay22 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone27 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int29 = fixedDateTimeZone27.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone27);
        int int31 = monthDay22.compareTo((org.joda.time.ReadablePartial) monthDay30);
        org.joda.time.MonthDay monthDay33 = monthDay22.minusMonths(0);
        int[] intArray35 = buddhistChronology9.get((org.joda.time.ReadablePartial) monthDay33, (long) 89);
        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology9.yearOfEra();
        org.joda.time.Chronology chronology37 = buddhistChronology9.withUTC();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-9L) + "'", long19 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 10 + "'", int29 == 10);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(monthDay33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(chronology37);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int7 = fixedDateTimeZone5.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        long long11 = fixedDateTimeZone5.adjustOffset(0L, false);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(86399L, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.minus(readablePeriod13);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(1);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter2.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int7 = fixedDateTimeZone5.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        long long11 = fixedDateTimeZone5.adjustOffset(0L, false);
        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(86399L, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        java.lang.String str19 = fixedDateTimeZone17.getNameKey((long) (short) 10);
        long long21 = fixedDateTimeZone17.previousTransition((long) (short) 1);
        long long23 = fixedDateTimeZone5.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone17, 31L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 31L + "'", long23 == 31L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(86399);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendTimeZoneShortName(strMap3);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (-1), chronology9);
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property13 = dateTime12.year();
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (-1), chronology15);
        org.joda.time.Chronology chronology17 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime16);
        int int18 = dateTime12.compareTo((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime.Property property19 = dateTime16.yearOfCentury();
        int int20 = dateTime16.getSecondOfMinute();
        org.joda.time.DateTime dateTime22 = dateTime16.minusSeconds((-1));
        boolean boolean23 = gregorianChronology7.equals((java.lang.Object) dateTime16);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter24 = dateTimeFormatter6.withChronology((org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.format.DateTimeParser dateTimeParser25 = dateTimeFormatter6.getParser();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder4.append(dateTimePrinter5, dateTimeParser25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 59 + "'", int20 == 59);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter24);
        org.junit.Assert.assertNotNull(dateTimeParser25);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType24);
        int int27 = offsetDateTimeField13.get(1560632677806L);
        org.joda.time.DurationField durationField28 = offsetDateTimeField13.getLeapDurationField();
        org.joda.time.chrono.CopticChronology copticChronology29 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = copticChronology29.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField30);
        long long34 = delegatedDateTimeField31.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.MonthDay monthDay35 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay36 = org.joda.time.MonthDay.now();
        boolean boolean37 = monthDay35.isEqual((org.joda.time.ReadablePartial) monthDay36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.MonthDay monthDay39 = monthDay35.plus(readablePeriod38);
        int[] intArray41 = new int[] { 0 };
        int int42 = delegatedDateTimeField31.getMaximumValue((org.joda.time.ReadablePartial) monthDay39, intArray41);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField31, (int) (byte) 100);
        org.joda.time.MonthDay monthDay45 = org.joda.time.MonthDay.now();
        org.joda.time.MonthDay monthDay46 = org.joda.time.MonthDay.now();
        boolean boolean47 = monthDay45.isEqual((org.joda.time.ReadablePartial) monthDay46);
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.MonthDay monthDay49 = monthDay45.plus(readablePeriod48);
        int int50 = offsetDateTimeField44.getMaximumValue((org.joda.time.ReadablePartial) monthDay45);
        java.util.Locale locale51 = null;
        try {
            java.lang.String str52 = offsetDateTimeField13.getAsText((org.joda.time.ReadablePartial) monthDay45, locale51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfEra' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2116 + "'", int27 == 2116);
        org.junit.Assert.assertNull(durationField28);
        org.junit.Assert.assertNotNull(copticChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 292278122L + "'", long34 == 292278122L);
        org.junit.Assert.assertNotNull(monthDay35);
        org.junit.Assert.assertNotNull(monthDay36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 999 + "'", int42 == 999);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertNotNull(monthDay46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1099 + "'", int50 == 1099);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((-292275054));
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) (-100));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property5 = dateTime4.year();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        boolean boolean10 = property7.isLeap();
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long9 = fixedDateTimeZone5.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone5, readableInstant10);
        java.lang.Object obj12 = null;
        boolean boolean13 = fixedDateTimeZone5.equals(obj12);
        long long15 = fixedDateTimeZone5.nextTransition((-31556476799900L));
        int int17 = fixedDateTimeZone5.getOffsetFromLocal((long) 2);
        org.joda.time.Chronology chronology18 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        long long20 = fixedDateTimeZone5.convertUTCToLocal(86399L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-9L) + "'", long9 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-31556476799900L) + "'", long15 == (-31556476799900L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 86409L + "'", long20 == 86409L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int18 = fixedDateTimeZone16.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        int int20 = monthDay11.compareTo((org.joda.time.ReadablePartial) monthDay19);
        boolean boolean21 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) monthDay11);
        try {
            int int23 = monthDay11.getValue((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.lang.String str4 = delegatedDateTimeField2.getAsText((long) (byte) 10);
        int int6 = delegatedDateTimeField2.getMinimumValue(52L);
        long long8 = delegatedDateTimeField2.roundHalfCeiling((long) 'a');
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10" + "'", str4.equals("10"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 97L + "'", long8 == 97L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        boolean boolean1 = dateTimeFormatterBuilder0.canBuildParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendYear(0, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfHour((int) (short) 100, 24);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTimeZoneShortName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendMillisOfSecond(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long10 = fixedDateTimeZone6.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone6, readableInstant11);
        org.joda.time.Chronology chronology13 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = gregorianChronology1.add(readablePeriod14, (long) (byte) 10, 53);
        org.joda.time.DateTimeZone dateTimeZone18 = gregorianChronology1.getZone();
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(10L, (org.joda.time.Chronology) gregorianChronology1);
        try {
            org.joda.time.DateTime dateTime21 = dateTime19.withMillisOfSecond(292278993);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-9L) + "'", long10 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (-1), chronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property16 = dateTime15.year();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (-1), chronology18);
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime19);
        int int21 = dateTime15.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime.Property property22 = dateTime19.yearOfCentury();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (-1), chronology24);
        org.joda.time.DateTime dateTime27 = dateTime25.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property28 = dateTime27.year();
        int int29 = property28.getMaximumValue();
        java.util.Locale locale30 = null;
        java.lang.String str31 = property28.getAsText(locale30);
        org.joda.time.DateTime dateTime33 = property28.setCopy(0);
        org.joda.time.TimeOfDay timeOfDay34 = dateTime33.toTimeOfDay();
        boolean boolean35 = dateTime19.isBefore((org.joda.time.ReadableInstant) dateTime33);
        int int36 = fixedDateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        boolean boolean38 = cachedDateTimeZone37.isFixed();
        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) cachedDateTimeZone37);
        org.joda.time.Chronology chronology41 = null;
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) (-1), chronology41);
        org.joda.time.DateTime dateTime44 = dateTime42.plusWeeks((int) (short) -1);
        int int45 = dateTime44.getDayOfMonth();
        org.joda.time.DateTime dateTime47 = dateTime44.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology48 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField49 = copticChronology48.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField50 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField49);
        long long53 = delegatedDateTimeField50.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = delegatedDateTimeField50.getType();
        int int55 = dateTime44.get(dateTimeFieldType54);
        boolean boolean56 = dateTime39.equals((java.lang.Object) dateTimeFieldType54);
        java.lang.Number number57 = null;
        java.lang.Number number58 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException60 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType54, number57, number58, (java.lang.Number) 10.0d);
        java.lang.Number number63 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException64 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType54, (java.lang.Number) 1560632687348L, (java.lang.Number) 10990L, number63);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 292278993 + "'", int29 == 292278993);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "1969" + "'", str31.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(timeOfDay34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 10 + "'", int36 == 10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 24 + "'", int45 == 24);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(copticChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 292278122L + "'", long53 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 999 + "'", int55 == 999);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.MonthDay monthDay11 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.MonthDay monthDay14 = monthDay12.minusDays((int) (byte) -1);
        org.joda.time.MonthDay.Property property15 = monthDay14.monthOfYear();
        int int16 = property15.getMaximumValue();
        java.util.Locale locale18 = null;
        try {
            org.joda.time.MonthDay monthDay19 = property15.setCopy("2019-06-15T21:04:52.040Z", locale18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-15T21:04:52.040Z\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        long long26 = offsetDateTimeField13.set((long) '#', "2067");
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField13.getAsText((int) (byte) 100, locale28);
        long long32 = offsetDateTimeField13.add((long) 100, 100L);
        long long34 = offsetDateTimeField13.roundFloor((long) 53);
        java.util.Locale locale36 = null;
        java.lang.String str37 = offsetDateTimeField13.getAsText(34, locale36);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 35L + "'", long26 == 35L);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "100" + "'", str29.equals("100"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 3155760000100L + "'", long32 == 3155760000100L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-10L) + "'", long34 == (-10L));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "34" + "'", str37.equals("34"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime5 = dateTime2.withDurationAdded(readableDuration3, 0);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (-1), chronology7);
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime8.getZone();
        java.util.TimeZone timeZone11 = dateTimeZone10.toTimeZone();
        org.joda.time.DateTime dateTime12 = dateTime5.toDateTime(dateTimeZone10);
        org.joda.time.DateTime.Property property13 = dateTime5.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime5.minusDays(0);
        org.joda.time.DateTime dateTime17 = dateTime15.minusHours((int) (byte) 100);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (-1), chronology19);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded(readableDuration21, 0);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (-1), chronology25);
        org.joda.time.Chronology chronology27 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.DateTimeZone dateTimeZone28 = dateTime26.getZone();
        java.util.TimeZone timeZone29 = dateTimeZone28.toTimeZone();
        org.joda.time.DateTime dateTime30 = dateTime23.toDateTime(dateTimeZone28);
        org.joda.time.DateTime dateTime32 = dateTime30.minusSeconds((int) (short) 1);
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (-1), chronology34);
        org.joda.time.ReadableDuration readableDuration36 = null;
        org.joda.time.DateTime dateTime38 = dateTime35.withDurationAdded(readableDuration36, 0);
        org.joda.time.Chronology chronology40 = null;
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime((long) (-1), chronology40);
        org.joda.time.Chronology chronology42 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime41);
        org.joda.time.DateTimeZone dateTimeZone43 = dateTime41.getZone();
        java.util.TimeZone timeZone44 = dateTimeZone43.toTimeZone();
        org.joda.time.DateTime dateTime45 = dateTime38.toDateTime(dateTimeZone43);
        org.joda.time.DateTime.Property property46 = dateTime38.yearOfEra();
        org.joda.time.DateTime dateTime48 = dateTime38.minusDays(0);
        org.joda.time.DateTime dateTime50 = dateTime48.minusHours((int) (byte) 100);
        org.joda.time.chrono.CopticChronology copticChronology51 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField52 = copticChronology51.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField53 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField52);
        long long56 = delegatedDateTimeField53.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType57 = delegatedDateTimeField53.getType();
        org.joda.time.DateTime.Property property58 = dateTime48.property(dateTimeFieldType57);
        org.joda.time.DateTime.Property property59 = dateTime30.property(dateTimeFieldType57);
        int int60 = dateTime17.get(dateTimeFieldType57);
        org.joda.time.DateTime.Property property61 = dateTime17.millisOfSecond();
        org.joda.time.DateTime.Property property62 = dateTime17.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(timeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(timeZone44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(copticChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 292278122L + "'", long56 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType57);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(property59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 999 + "'", int60 == 999);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(property62);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (-1), chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks((int) (short) -1);
        int int5 = dateTime4.getDayOfMonth();
        org.joda.time.DateTime dateTime7 = dateTime4.minusYears(358);
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = copticChronology8.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField10 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField9);
        long long13 = delegatedDateTimeField10.getDifferenceAsLong(3068L, (long) (-292275054));
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = delegatedDateTimeField10.getType();
        int int15 = dateTime4.get(dateTimeFieldType14);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone20 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long24 = fixedDateTimeZone20.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone20, readableInstant25);
        org.joda.time.DurationField durationField27 = gJChronology26.millis();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField28 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType14, durationField27);
        try {
            long long30 = unsupportedDateTimeField28.remainder((long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: millisOfSecond field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24 + "'", int5 == 24);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 292278122L + "'", long13 == 292278122L);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 999 + "'", int15 == 999);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-9L) + "'", long24 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField28);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.weekyear();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long21 = fixedDateTimeZone17.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone17, readableInstant22);
        org.joda.time.DurationField durationField24 = gJChronology23.millis();
        org.joda.time.DurationField durationField25 = gJChronology23.centuries();
        org.joda.time.DateTimeField dateTimeField26 = gJChronology23.monthOfYear();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, dateTimeField26, (-1));
        org.joda.time.DateTimeField dateTimeField29 = gJChronology10.minuteOfDay();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-9L) + "'", long21 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeField29);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long8 = fixedDateTimeZone4.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, readableInstant9);
        org.joda.time.DateTimeField dateTimeField11 = gJChronology10.yearOfEra();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) 'a');
        long long15 = offsetDateTimeField13.roundCeiling(10L);
        long long17 = offsetDateTimeField13.roundCeiling(0L);
        long long19 = offsetDateTimeField13.roundFloor((long) 'a');
        long long21 = offsetDateTimeField13.roundHalfCeiling((-1L));
        int int23 = offsetDateTimeField13.getMinimumValue((long) 24);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField25 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType24);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone30 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long34 = fixedDateTimeZone30.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant35 = null;
        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone30, readableInstant35);
        org.joda.time.MonthDay monthDay37 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone30);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone42 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int44 = fixedDateTimeZone42.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone42);
        int int46 = monthDay37.compareTo((org.joda.time.ReadablePartial) monthDay45);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone51 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        long long55 = fixedDateTimeZone51.convertLocalToUTC((long) (short) 1, true, (long) 1);
        org.joda.time.ReadableInstant readableInstant56 = null;
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone51, readableInstant56);
        org.joda.time.MonthDay monthDay58 = org.joda.time.MonthDay.now((org.joda.time.DateTimeZone) fixedDateTimeZone51);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone63 = new org.joda.time.tz.FixedDateTimeZone("", "", (int) (short) 10, (int) (byte) 10);
        int int65 = fixedDateTimeZone63.getOffsetFromLocal((long) (byte) 100);
        org.joda.time.MonthDay monthDay66 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone63);
        int int67 = monthDay58.compareTo((org.joda.time.ReadablePartial) monthDay66);
        org.joda.time.MonthDay monthDay69 = monthDay58.minusMonths(0);
        org.joda.time.MonthDay monthDay71 = monthDay69.plusMonths((int) (short) 0);
        int int72 = monthDay69.size();
        boolean boolean73 = monthDay37.isBefore((org.joda.time.ReadablePartial) monthDay69);
        int int74 = delegatedDateTimeField25.getMaximumValue((org.joda.time.ReadablePartial) monthDay69);
        org.joda.time.DateTimeField dateTimeField75 = delegatedDateTimeField25.getWrappedField();
        org.joda.time.DateTimeField dateTimeField76 = delegatedDateTimeField25.getWrappedField();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-9L) + "'", long8 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 31535999990L + "'", long15 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31535999990L + "'", long17 == 31535999990L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-10L) + "'", long19 == (-10L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-10L) + "'", long21 == (-10L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 98 + "'", int23 == 98);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-9L) + "'", long34 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology36);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 10 + "'", int44 == 10);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-9L) + "'", long55 == (-9L));
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(monthDay58);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 10 + "'", int65 == 10);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(monthDay69);
        org.junit.Assert.assertNotNull(monthDay71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 2 + "'", int72 == 2);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 292279090 + "'", int74 == 292279090);
        org.junit.Assert.assertNotNull(dateTimeField75);
        org.junit.Assert.assertNotNull(dateTimeField76);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology1.getZone();
        org.joda.time.DurationField durationField3 = copticChronology1.halfdays();
        org.joda.time.DurationField durationField4 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField5 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField3, durationField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
    }
}

